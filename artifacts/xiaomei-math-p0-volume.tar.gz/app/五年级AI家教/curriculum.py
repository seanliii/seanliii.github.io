"""独立课程范围登记；不改变旧 engine、题库、服务或学生掌握状态。

coverage 只接受实际评分字段绑定，报告题库支持而非作答结果。
当前官网上下册目录来自本机整页OCR；范围依据不等于掌握证据。
"""
from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
import hashlib
import json
from pathlib import Path

REGISTRY = Path(__file__).resolve().with_name('curriculum.json')


def _load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _edition_units(document, row, edition_name):
    edition = document['editions'][edition_name]
    units = document['catalogs'][edition['catalog']]
    ids = {unit['id'] for unit in units}
    explicit = row.get('editionUnits', {}).get(edition_name)
    if explicit is not None:
        return explicit.copy()
    if edition['catalog'] == 'legacy':
        return row['units'].copy()
    # 只在已核目录中取同ID主题且该题族确实绑定目标技能的交集。
    # 不因旧版册次或相近字词把方程、位置挂到新版章节。
    return [unit['id'] for unit in units if unit['id'] in ids & set(row['units'])
            and unit['targetSkills']]


def _requirements(document, row, edition):
    """保留原始必要条件；跨册条件转为登记先备，不导入另一册单元。"""
    ids = {u['id'] for u in document['catalogs'][edition['catalog']]}
    required = row.get('requiredUnits', [])
    external = [uid for uid in required if uid not in ids]
    skills = document.get('prerequisiteSkills', {})
    registered = {item['requiredUnit']: skill for skill, item in skills.items()}
    if any(uid not in registered for uid in external):
        raise ValueError('跨册必要单元缺少显式先备登记')
    return {'requiredUnits': [uid for uid in required if uid in ids],
            'externalRequiredUnits': external,
            'requiredPrerequisiteSkills': [registered[uid] for uid in external]}


def _metadata(document):
    result = deepcopy(document['families'])
    for row in result.values():
        source = document['sources'][row['sourceId']]
        row.update(sourceURL=source['sourceURL'], physicalPage=source.get('physicalPage'),
                   reviewStatus=source['reviewStatus'], copyright='原创研究题；教材仅作范围依据')
        row['editionScopes'] = {
            name: {'catalog': edition['catalog'], 'reviewStatus': edition['reviewStatus'],
                   'units': _edition_units(document, row, name),
                   **(_requirements(document, row, edition)
                      if _edition_units(document, row, name) else
                      {'requiredUnits': [], 'externalRequiredUnits': [], 'requiredPrerequisiteSkills': []}),
                   'terms': sorted({u['term'] for u in document['catalogs'][edition['catalog']]
                                    if u['id'] in _edition_units(document, row, name)}),
                   'sourceURL': document['sources'][edition['sourceId']]['sourceURL']}
            for name, edition in document['editions'].items()
        }
    return result


# 与 questions.CURRICULUM_METADATA 独立，包含旧28族与新增18族。
CURRICULUM_METADATA = _metadata(_load(REGISTRY))


class CurriculumIndex:
    def __init__(self, graph, bank=None, source=None):
        self.graph = graph
        self.source = Path(source or REGISTRY)
        raw = self.source.read_bytes()
        self.version = hashlib.sha256(raw).hexdigest()[:16]
        self.document = json.loads(raw)
        self._builder = None
        if bank is None:
            from questions import FAMILIES, build_question
            bank, self._builder = FAMILIES, build_question
        elif hasattr(bank, 'FAMILIES'):
            self._builder = getattr(bank, 'build_question', None)
            bank = bank.FAMILIES
        if not isinstance(bank, Mapping):
            raise ValueError('bank必须为FAMILIES映射或题库模块')
        self.bank = deepcopy(dict(bank))
        self.metadata = _metadata(self.document)
        self.nodes = graph.nodes if hasattr(graph, 'nodes') else graph
        if not isinstance(self.nodes, Mapping):
            raise ValueError('graph必须提供nodes映射')
        self._validate_registry()

    def _validate_registry(self):
        doc = self.document
        if doc.get('schemaVersion') != 1:
            raise ValueError('不支持的课程登记版本')
        missing = set(self.bank) - set(self.metadata)
        if missing:
            raise ValueError('未登记题族: ' + ', '.join(sorted(missing)))
        for skill, item in doc.get('prerequisiteSkills', {}).items():
            if skill not in self.nodes or item['probeFamily'] not in self.metadata:
                raise ValueError('先备技能或探测题族未登记')
            if skill not in self.bank.get(item['probeFamily'], {}).get('skills', []):
                # 精简题库可以没有探测题，但已有题族不能错误绑定技能。
                if item['probeFamily'] in self.bank:
                    raise ValueError('先备探测题族未绑定对应技能')
            sources = [u for rows in doc['catalogs'].values() for u in rows
                       if u['id'] == item['catalogUnit'] and u['sourceId'] == item['sourceId']]
            if not sources or not any(skill in u['targetSkills'] for u in sources):
                raise ValueError('先备缺真实来源单元及目标技能')
        clauses = {row['id'] for row in doc['sourceClauses']}
        for name, row in self.metadata.items():
            if row['scopeRole'] not in ('current_learned', 'prerequisite', 'challenge'):
                raise ValueError('非法scopeRole: ' + name)
            if not set(row.get('sourceClauseIds', [])) <= clauses:
                raise ValueError('未知课标条款: ' + name)
            if row['term'] not in ('fall', 'spring', 'prior', 'extension'):
                raise ValueError('非法题族学期: ' + name)
        for edition in doc['editions'].values():
            units = doc['catalogs'][edition['catalog']]
            ids = {unit['id'] for unit in units}
            if len(ids) != len(units):
                raise ValueError('单元ID重复')
            for unit in units:
                if unit['term'] not in ('fall', 'spring'):
                    raise ValueError('非法单元学期')
                if not set(unit['targetSkills']) <= set(self.nodes):
                    raise ValueError('单元目标引用未知图谱节点: ' + unit['id'])
                if not set(unit['prerequisiteFamilies']) <= set(self.metadata):
                    raise ValueError('单元引用未知先备题族')
            if edition['catalog'] == 'legacy':
                for name, row in self.metadata.items():
                    if not set(row['units'] + row.get('requiredUnits', [])) <= ids:
                        raise ValueError('题族引用未知单元: ' + name)
        for row in self.metadata.values():
            if set(row.get('editionUnits', {})) - set(doc['editions']):
                raise ValueError('题族引用未知版本')
            for name, scope in row['editionScopes'].items():
                edition = doc['editions'][name]
                ids = {u['id'] for u in doc['catalogs'][edition['catalog']]}
                if not set(scope['units']) <= ids:
                    raise ValueError('版本题族引用未知单元')
        if not set(doc['selection']['unknownProgressRoots']) <= set(self.metadata):
            raise ValueError('未知进度先备题未登记')

    def _units(self, profile):
        edition = self.document['editions'][profile['edition']]
        return self.document['catalogs'][edition['catalog']]

    def normalize_profile(self, payload=None):
        """不由年级/学期推断已学，不由currentUnit推断整个单元已完成。

        completedUnits允许显式登记过去学期单元，但拒绝fall声明spring已学。
        spring不会自动补全fall；year也不会自动补全全年。
        prerequisiteSkills只记录用户显式确认以前学过的登记技能，非掌握证据。
        """
        if payload is None:
            payload = {}
        if not isinstance(payload, Mapping):
            raise ValueError('curriculum profile必须为对象')
        allowed = {'edition', 'grade', 'term', 'completedUnits', 'currentUnit',
                   'progressConfirmed', 'prerequisiteSkills'}
        if set(payload) - allowed:
            raise ValueError('未知profile字段: ' + ', '.join(sorted(set(payload) - allowed)))
        edition = payload.get('edition', self.document['defaultEdition'])
        if not isinstance(edition, str) or edition not in self.document['editions']:
            raise ValueError('未知教材版本')
        grade = payload.get('grade', 5)
        if type(grade) is not int or grade != 5:
            raise ValueError('本登记仅支持grade=5')
        edition_terms = self.document['editions'][edition].get('terms', ['fall', 'spring'])
        term = payload.get('term', edition_terms[0])
        if not isinstance(term, str) or term not in ('fall', 'spring', 'year'):
            raise ValueError('term必须为fall/spring/year')
        if term != 'year' and term not in edition_terms:
            raise ValueError('当前独立册来源不含该学期；不能自动拼接版本')
        confirmed = payload.get('progressConfirmed', False)
        if type(confirmed) is not bool:
            raise ValueError('progressConfirmed必须为布尔值')
        completed = payload.get('completedUnits', [])
        if not isinstance(completed, list) or any(not isinstance(x, str) for x in completed):
            raise ValueError('completedUnits必须为单元ID数组')
        if len(set(completed)) != len(completed):
            raise ValueError('completedUnits不能重复')
        current = payload.get('currentUnit')
        if current is not None and not isinstance(current, str):
            raise ValueError('currentUnit必须为单元ID或null')
        if completed and not confirmed:
            raise ValueError('声明已学单元必须明确progressConfirmed=true')
        prior = payload.get('prerequisiteSkills', [])
        if not isinstance(prior, list) or any(not isinstance(x, str) for x in prior):
            raise ValueError('prerequisiteSkills必须为登记技能ID数组')
        if len(set(prior)) != len(prior):
            raise ValueError('prerequisiteSkills不能重复')
        if set(prior) - set(self.document.get('prerequisiteSkills', {})):
            raise ValueError('未知或未登记的先备技能')
        if prior and not confirmed:
            raise ValueError('确认以前学过先备必须明确progressConfirmed=true')
        profile = {'edition': edition, 'grade': grade, 'term': term,
                   'completedUnits': completed.copy(), 'currentUnit': current,
                   'progressConfirmed': confirmed, 'prerequisiteSkills': prior.copy()}
        units = {unit['id']: unit for unit in self._units(profile)}
        for uid in completed + ([current] if current is not None else []):
            if uid not in units:
                raise ValueError('未知或尚未核实的版本单元: ' + uid)
            if term == 'fall' and units[uid]['term'] == 'spring':
                raise ValueError('五上不能声明五下单元已学；提前学习另走challenge')
        if current is not None and term != 'year' and units[current]['term'] != term:
            raise ValueError('currentUnit须属于当前学期')
        return profile

    def _learned(self, profile):
        return set(profile['completedUnits']) if profile['progressConfirmed'] else set()

    def _family(self, family):
        if not isinstance(family, str) or family not in self.metadata or family not in self.bank:
            raise ValueError('未知或题库未提供的题族: ' + str(family))
        return self.metadata[family]

    def _scope(self, row, profile):
        return row['editionScopes'][profile['edition']]

    def _missing_requirements(self, row, profile):
        scope = self._scope(row, profile)
        prior = set(profile['prerequisiteSkills']) if profile['progressConfirmed'] else set()
        registry = self.document.get('prerequisiteSkills', {})
        satisfied_units = {registry[skill]['requiredUnit'] for skill in prior}
        return {'missingRequiredUnits': sorted(set(scope['requiredUnits'])
                                              - self._learned(profile) - satisfied_units),
                'missingPrerequisiteSkills': sorted(set(scope['requiredPrerequisiteSkills']) - prior)}

    def _requirements_met(self, row, profile):
        return not any(self._missing_requirements(row, profile).values())

    def _related_prior_targets(self, skill, profile):
        """只在显式已学当册目标确实需要此跨册技能时安排探测。"""
        learned = self._learned(profile)
        return [name for name, row in self.metadata.items()
                if name in self.bank and row['scopeRole'] == 'current_learned'
                and set(self._scope(row, profile)['units']) & learned
                and skill in self._scope(row, profile)['requiredPrerequisiteSkills']]

    def _prior_source(self, skill):
        item = self.document['prerequisiteSkills'][skill]
        unit = next(u for rows in self.document['catalogs'].values() for u in rows
                    if u['sourceId'] == item['sourceId'] and u['id'] == item['catalogUnit'])
        return {'sourceURL': self.document['sources'][item['sourceId']]['sourceURL'],
                'sourceId': item['sourceId'], 'unitId': unit['id'],
                'physicalPage': unit['physicalPage'], 'printedPage': unit.get('printedPage'),
                'catalogPhysicalPage': unit.get('catalogPhysicalPage'),
                'reviewStatus': unit['reviewStatus']}

    def root_context(self, family, profile):
        """供主线程记录先备probe上下文；不更改题目phase、签名或掌握状态。"""
        p = self.normalize_profile(profile)
        row = self._family(family)
        helpers = {skill: self._related_prior_targets(skill, p)
                   for skill, item in self.document.get('prerequisiteSkills', {}).items()
                   if item['probeFamily'] == family}
        helpers = {skill: targets for skill, targets in helpers.items() if targets}
        targets = sorted({name for names in helpers.values() for name in names})
        related = sorted({uid for name in targets for uid in self._scope(self.metadata[name], p)['units']
                          if uid in self._learned(p)})
        role = self.role_for(family, p)
        return {'family': family, 'scopeRole': role,
                'recommendedPhase': 'probe' if role == 'prerequisite' else 'screen',
                'scopeUnits': self._scope(row, p)['units'].copy(),
                'relatedUnits': related, 'supportsFamilies': targets,
                'prerequisiteSkills': sorted(helpers),
                'confirmedPrerequisiteSkills': sorted(set(helpers) & set(p['prerequisiteSkills'])),
                'sources': [self._prior_source(skill) for skill in sorted(helpers)],
                'confirmationImpliesMastery': False, 'version': self.version}

    def eligible_prerequisite(self, family, profile):
        """只允许与显式已学单元相关的先备；允许探测不等于宣称已掌握。

        五下本学期目标不会因题库的prerequisite指针误作为五上先备。
        """
        p = self.normalize_profile(profile)
        row = self._family(family)
        scope = self._scope(row, p)
        if not self._learned(p):
            return family in self.document['selection']['unknownProgressRoots']
        learned = self._learned(p)
        if any(item['probeFamily'] == family and self._related_prior_targets(skill, p)
               for skill, item in self.document.get('prerequisiteSkills', {}).items()):
            return True
        for unit in self._units(p):
            if unit['id'] not in learned or family not in unit['prerequisiteFamilies']:
                continue
            if row['scopeRole'] == 'prerequisite':
                return True
            if set(scope['units']) & learned and self._requirements_met(row, p):
                return True
        return False

    def role_for(self, family, profile):
        p = self.normalize_profile(profile)
        row = self._family(family)
        scope = self._scope(row, p)
        learned = self._learned(p)
        if row['scopeRole'] == 'challenge':
            return 'challenge'
        if (row['scopeRole'] == 'current_learned'
                and set(scope['units']) & learned
                and self._requirements_met(row, p)):
            return 'current_learned'
        if self.eligible_prerequisite(family, p):
            return 'prerequisite'
        return 'not_yet_taught'

    def _seconds(self, family):
        fallback = self.document['selection']['questionSeconds']
        if self._builder is None:
            return fallback
        question = self._builder(family)
        return max(fallback, question['estimatedSeconds'])

    def roots_for(self, profile, mode='Lite', previously_seen=None):
        """返回题族ID列表；每单元最多一题，预留同组一题对照及反馈预算。

        previously_seen为跨次已取初筛的family ID列表，轮换代表题；不推断
        正确、错误或掌握。对照须由调用方另取verify/transfer变式执行。
        """
        p = self.normalize_profile(profile)
        policy = self.document['selection']
        if not isinstance(mode, str) or mode not in policy['minutes']:
            raise ValueError('未知mode；支持Lite/Pro')
        seen = [] if previously_seen is None else previously_seen
        if not isinstance(seen, (list, tuple)) or any(not isinstance(x, str) for x in seen):
            raise ValueError('previously_seen必须为题族ID列表')
        for family in seen:
            self._family(family)
        if not self._learned(p):
            # unknown先确认最小小数先备，重复不扩大到全年必会。
            return [name for name in policy['unknownProgressRoots'] if name in self.bank]
        priority = policy['priorityUnits']
        units = [u for u in self._units(p) if u['id'] in self._learned(p)]
        order = {unit['id']: i for i, unit in enumerate(units)}
        units.sort(key=lambda u: (0 if u['id'] == p['currentUnit'] else 1,
                                  priority.index(u['id']) if u['id'] in priority else len(priority),
                                  order[u['id']]))
        remaining = policy['minutes'][mode] * 60 - policy['feedbackReserveSeconds']
        roots = []
        for unit in units:
            candidates = [name for name, row in self.metadata.items()
                          if name in self.bank and unit['id'] in self._scope(row, p)['units']
                          and self.role_for(name, p) == 'current_learned']
            candidates.sort(key=lambda name: (name in seen, name not in ('parallelogram_area',)))
            # 尚未确认的跨册必要条件先安排一题相关probe，不当作当册核心。
            helpers = [item['probeFamily']
                       for skill, item in self.document.get('prerequisiteSkills', {}).items()
                       if skill not in p['prerequisiteSkills'] and item['probeFamily'] in self.bank
                       and any(unit['id'] in self._scope(self.metadata[name], p)['units']
                               for name in self._related_prior_targets(skill, p))]
            helpers.sort(key=lambda name: name in seen)
            # 已探测过但尚未确认时可轮到同单元其他可达目标，不自动解锁互化。
            candidates = [name for name in helpers if name not in seen] + candidates + helpers
            if not candidates:
                continue
            family = candidates[0]
            if family in roots:
                continue
            cost = self._seconds(family) + policy['contrastSeconds']
            if cost > remaining:
                continue
            roots.append(family)
            remaining -= cost
            if len(roots) >= policy['maxInitialRoots'][mode]:
                break
        return roots

    def public(self):
        """可由主线程现有HTTP接口公开；本模块不新增路由或重启服务。"""
        return {'version': self.version, 'schemaVersion': self.document['schemaVersion'],
                'notice': self.document['notice'], 'profileSchema': deepcopy(self.document['profileSchema']),
                'profileSchemaVersion': self.document['profileSchemaVersion'],
                'profileMigration': deepcopy(self.document['profileMigration']),
                'prerequisiteSkills': deepcopy(self.document['prerequisiteSkills']),
                'sources': deepcopy(self.document['sources']),
                'sourceClauses': deepcopy(self.document['sourceClauses']),
                'editions': deepcopy(self.document['editions']),
                'catalogs': deepcopy(self.document['catalogs']),
                'families': deepcopy(self.metadata),
                'selection': deepcopy(self.document['selection']),
                'evidencePolicy': deepcopy(self.document['evidencePolicy']),
                'integrationStatus': 'standalone_not_wired_to_engine_or_http'}

    def _scored_fields(self, family_fields):
        """接收{family: 原始question/原始question列表}。

        或{family: {fieldId: {skills: [...], diagnosticDimension: ..., scored: true}}}。
        不读取family.skills充当字段测量；公开题面没有评分绑定，拒绝推定。
        """
        if not isinstance(family_fields, Mapping):
            raise ValueError('family_fields必须为按题族索引的实际评分字段映射')
        records = []
        for family, value in family_fields.items():
            self._family(family)
            questions = value if isinstance(value, list) else [value]
            for question in questions:
                if not isinstance(question, Mapping):
                    raise ValueError('字段证据必须为对象')
                if 'fields' in question:
                    if question.get('family') != family:
                        raise ValueError('question的family与映射键不一致')
                    mapping = question.get('_field_skills')
                    expected = question.get('_expected')
                    if not isinstance(mapping, Mapping) or not isinstance(expected, Mapping):
                        raise ValueError('缺实际评分绑定；公开题面不能推定覆盖')
                    fields = question['fields']
                    ids = [field['id'] for field in fields]
                    if len(ids) != len(set(ids)) or set(ids) != set(mapping) or set(ids) != set(expected):
                        raise ValueError('fields/expected/field_skills必须一一对应')
                    rows = [(field['id'], mapping[field['id']], field.get('diagnosticDimension'),
                             field.get('evidenceKind', 'unspecified')) for field in fields]
                else:
                    rows = []
                    for fid, field in question.items():
                        if not isinstance(field, Mapping) or field.get('scored') is not True:
                            raise ValueError('显式字段证据须声明scored=true')
                        rows.append((fid, field.get('skills'), field.get('diagnosticDimension'),
                                     field.get('evidenceKind', 'unspecified')))
                for fid, skills, dimension, kind in rows:
                    if not isinstance(skills, list) or any(not isinstance(x, str) for x in skills):
                        raise ValueError('字段skills必须为数组，不接受相关技能标签')
                    if dimension is not None and dimension not in self.document['evidencePolicy']['dimensions']:
                        raise ValueError('未知字段诊断维度')
                    if kind == 'question_only' and skills:
                        raise ValueError('question_only不得提供技能证据')
                    # 字段绑定还须由真实题族技能支持；其余相关节点不计覆盖。
                    allowed = set(self.bank[family]['skills'])
                    mapped = set(skills) & allowed & set(self.nodes) if kind != 'question_only' else set()
                    records.append({'family': family, 'fieldId': fid, 'mappedSkills': sorted(mapped),
                                    'dimension': dimension, 'evidenceKind': kind,
                                    'rejectedSkills': sorted(set(skills) - mapped)})
        return records

    def coverage(self, profile, family_fields):
        """单元目标与实际已评分字段的交集；未测不等于不会，覆盖不等于会。

        dimensions仅取每个目标实际绑定字段，未知维度明确unknown；不从
        questions.CURRICULUM_METADATA的题级声明扩大概念/推理覆盖。
        """
        p = self.normalize_profile(profile)
        records = self._scored_fields(family_fields)
        units = self._units(p)
        if p['term'] != 'year':
            units = [u for u in units if u['term'] == p['term'] or u['id'] in p['completedUnits']]
        results = []
        for unit in units:
            target = set(unit['targetSkills'])
            declared = [name for name, meta in self.metadata.items()
                        if name in self.bank and unit['id'] in self._scope(meta, p)['units']]
            direct = [record for record in records if record['family'] in declared
                      and target & set(record['mappedSkills'])]
            mapped = set().union(*(target & set(r['mappedSkills']) for r in direct)) if direct else set()
            by_skill = {skill: sorted({r['dimension'] or 'unknown' for r in direct
                                     if skill in r['mappedSkills']}) for skill in sorted(mapped)}
            eligible = [name for name in declared if self.role_for(name, p) == 'current_learned']
            limits = unit.get('supportLimits', []).copy()
            limits += ['仅反映提供的评分字段；不代表学会、全单元覆盖或全年90节点覆盖',
                       '计算正确不自动证明概念、独立迁移或长期保持']
            if any(r['dimension'] is None for r in direct):
                limits.append('旧字段未标维度，不能补称concept/reasoning已测')
            gap = ('no_dedicated_family' if not declared else
                   'no_direct_scored_fields' if not mapped else 'partial_field_support')
            results.append({'id': unit['id'], 'title': unit['title'], 'term': unit['term'],
                            'scopeRole': 'current_learned' if unit['id'] in self._learned(p) else 'not_yet_taught',
                            'targetSkills': sorted(target), 'mappedSkills': sorted(mapped),
                            'dimensions': by_skill, 'familyIds': declared, 'eligibleRoots': eligible,
                            'blockedFamilies': {name: self._missing_requirements(self.metadata[name], p)
                                                for name in declared
                                                if not self._requirements_met(self.metadata[name], p)},
                            'pendingNodes': sorted((target - mapped) | set(unit.get('pendingNodes', []))),
                            'gap': gap, 'supportLimits': limits,
                            'sourceURL': self.document['sources'][unit['sourceId']]['sourceURL'],
                            'physicalPage': unit['physicalPage'],
                            'printedPage': unit.get('printedPage'),
                            'catalogPhysicalPage': unit.get('catalogPhysicalPage'),
                            'reviewStatus': unit['reviewStatus']})
        prerequisites = []
        for skill, item in self.document.get('prerequisiteSkills', {}).items():
            related = self._related_prior_targets(skill, p)
            if not related and skill not in p['prerequisiteSkills']:
                continue
            prerequisites.append({'skillId': skill, 'title': item['title'],
                                  'confirmedLearned': skill in p['prerequisiteSkills'],
                                  'probeFamily': item['probeFamily'], 'supportsFamilies': related,
                                  'countsAsCurrentCore': False, 'confirmationImpliesMastery': False,
                                  'source': self._prior_source(skill),
                                  'supportLimits': item['supportLimits'].copy(),
                                  'scoredFields': [r for r in records
                                                   if r['family'] == item['probeFamily']
                                                   and skill in r['mappedSkills']]})
        return {'profile': p, 'version': self.version, 'units': results, 'scoredFields': records,
                'prerequisites': prerequisites,
                'catalogStatus': self.document['editions'][p['edition']]['reviewStatus'],
                'catalogGap': None if results else '所选范围无已登记目录条目',
                'yearScopeComplete': self.document['editions'][p['edition']].get('yearScopeComplete', True),
                'scopeNotice': ('仅此册来源，不代表新版全年已核'
                                if self.document['editions'][p['edition']].get('terms') else
                                '旧版全年编排基线；版权身份仍未核'),
                'evidenceNotice': '只统计字段支持，不产生掌握分、心理诊断、儿童排名或全图已测结论'}


def normalize_profile(payload=None):
    """便捷接口，与CurriculumIndex.normalize_profile相同的严格合同。"""
    from graph import GraphIndex
    return CurriculumIndex(GraphIndex()).normalize_profile(payload)
