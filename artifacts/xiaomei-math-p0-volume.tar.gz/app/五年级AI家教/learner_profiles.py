"""Field-only longitudinal evidence for anonymous learners (no model scoring)."""
from __future__ import annotations

from copy import deepcopy

DIMENSIONS = ('concept', 'procedure', 'representation', 'application', 'reasoning')
DAY = 24 * 3600


def evidence_records(session, result):
    """Called only after engine grading a server-issued instance."""
    fields = result['score']['fieldResults']
    records = []
    for field in fields:
        for skill in field['skillIds']:
            companion = any(row['correct'] and row.get('evidenceKind') == 'constructed'
                            and skill in row['skillIds'] for row in fields)
            records.append({
                'sessionId': session['id'], 'instanceId': result['instanceId'],
                'signature': result['signature'], 'family': result['family'],
                'rootFamily': result['rootFamily'], 'phase': result['phase'],
                **({'branchId': result['branchId'], 'branchKind': result['branchKind'],
                    'evidenceScope': 'child_task', 'topicVerification': False}
                   if result.get('branchId') else {}),
                'skillId': skill, 'fieldId': field['id'],
                'diagnosticDimension': field.get('diagnosticDimension', 'unspecified'),
                'correct': field['correct'], 'assisted': result['assisted'],
                'evidenceKind': field.get('evidenceKind', 'constructed'),
                'constructedCompanion': companion, 'time': result['time'],
                'received': deepcopy(field['received']), 'reason': deepcopy(field.get('reason')),
            })
    return records


def summarize(records, graph, now, skills=None, *, include_child_tasks=False):
    """Explicit counts and verification status; no percentages or ability weights.

    A later wrong field invalidates an earlier verification for that dimension.
    Two independent unseen verification instances and a related constructed field
    are required; old fields without a dimension never become concept evidence.
    """
    # Child exercises remain inspectable, never silently advance a main-course diagnosis.
    if not include_child_tasks:
        records = [r for r in records if not r.get('branchId') and r.get('evidenceScope') != 'child_task']
    selected = set(skills) if skills is not None else {r['skillId'] for r in records}
    result = []
    for skill in graph.nodes:
        if skill not in selected:
            continue
        rows = [r for r in records if r['skillId'] == skill]
        dimensions = []
        names = DIMENSIONS + (('unspecified',) if any(
            r['diagnosticDimension'] == 'unspecified' for r in rows) else ())
        for dimension in names:
            evidence = [r for r in rows if r['diagnosticDimension'] == dimension]
            wrong = [r for r in evidence if not r['correct']]
            independent = [r for r in evidence if r['correct'] and not r['assisted']]
            last_wrong = max((r['time'] for r in wrong), default=-1)
            # Ordering matters when the injected clock stays fixed across answers.
            boundary = max((i for i, r in enumerate(evidence) if not r['correct']), default=-1)
            passes = [r for r in evidence[boundary + 1:] if r['correct'] and not r['assisted']
                      and r['phase'] in ('verify', 'transfer', 'retention')]
            verified = (len({r['signature'] for r in passes}) >= 2
                        and len({r['instanceId'] for r in passes}) >= 2
                        and any(r['constructedCompanion'] for r in passes))
            conflicts = bool(wrong and independent)
            if verified:
                status = 'independently_verified'
            elif conflicts:
                status = 'conflicting_evidence'
            elif wrong:
                status = 'needs_verification'
            elif independent:
                status = 'unverified'
            elif evidence:
                status = 'assisted_only'
            else:
                status = 'unmeasured'
            latest = max((r['time'] for r in evidence), default=None)
            due = latest + DAY if latest is not None else None
            constructed_dimension = any(r['evidenceKind'] == 'constructed' for r in passes)
            choice_only = bool(passes) and not constructed_dimension
            codes = list(dict.fromkeys(r['reason']['misconceptionCode']
                    for r in wrong if r.get('reason') and r['reason'].get('misconceptionCode')))
            dimensions.append({
                'dimension': dimension, 'status': status,
                'label': ('两次独立辨析，开放解释待查' if verified and choice_only else
                          '两次独立字段验证，长期保持待查' if verified else
                          '前后字段证据有冲突，需再查' if conflicts else
                          '有错误字段线索，原因待查' if wrong else
                          '单次独立字段正确，仍待验证' if independent else
                          '仅有受助作答证据' if evidence else '该维度尚未测量'),
                'verificationKind': ('independent_choice_discrimination' if verified and choice_only else
                                     'independent_constructed_fields' if verified else 'not_verified'),
                'openExplanationStatus': 'unassessed', 'completeConceptMastery': False,
                'verificationConstraint': 'two_unseen_instances_with_same_skill_constructed_companion',
                'constructedDimensionEvidence': constructed_dimension,
                'confidence': 'verified' if verified else 'unverified',
                'independentCorrectInstances': len({r['instanceId'] for r in independent}),
                'wrongInstances': len({r['instanceId'] for r in wrong}),
                'assistedInstances': len({r['instanceId'] for r in evidence if r['assisted']}),
                'verificationInstances': len({r['instanceId'] for r in passes}),
                'constructedEvidence': any(r['constructedCompanion'] for r in passes),
                'conflict': conflicts, 'conflictRecords': deepcopy(evidence) if conflicts else [],
                'misconceptionCodes': codes,
                'misconceptionStatus': 'uncertainHypothesis' if codes else 'no_option_hypothesis',
                'misconceptionHypotheses': [{'code': code, 'status': 'uncertainHypothesis',
                                           'source': 'scored_option', 'confirmedCause': False}
                                          for code in codes],
                'lastWrongAt': last_wrong if wrong else None,
                'dueAt': due, 'reviewDue': due is not None and now >= due,
                'evidence': deepcopy(evidence),
            })
        result.append({'id': skill, 'title': graph.title(skill), 'dimensions': dimensions,
                       'longTermMastery': False})
    return result


def model_summary(records, graph, now, skills):
    """Current question's skills and direct metrics only; no identity/history."""
    rows = summarize(records, graph, now, skills)
    for row in rows:
        for dimension in row['dimensions']:
            dimension.pop('evidence')
            dimension.pop('conflictRecords')
    return rows
