"""原创五年级研究题与服务器判分；不是北京真题或掌握度诊断。

Lite/Pro 的分钟数是会话预算，不是每个学生的完成时间承诺。
前置链是追问候选，不可把一道错题自动解释成前置能力缺失。
verify/transfer 使用独立表示或条件；workText 留给人工理解，不自动评分。
本模块只产题与判分，不实现会话调度、前端或开放推理验证。
"""
from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from decimal import Decimal
from fractions import Fraction
import math
import re
import unicodedata

ROOTS_LITE = ['fraction_compare', 'decimal_compare', 'remainder', 'area_conversion',
              'equation', 'average', 'perimeter_area', 'listing']
ROOTS_PRO = ROOTS_LITE + ['factors', 'triangle_area', 'volume', 'data_trend']
MODES = {
    'Lite': {'minutes': 15, 'roots': ROOTS_LITE.copy(), 'firstFamily': 'fraction_compare'},
    'Pro': {'minutes': 25, 'roots': ROOTS_PRO.copy(), 'firstFamily': 'fraction_compare'},
}


def _family(title, domain, skills, prerequisite, hint, teaching):
    return {'title': title, 'domain': domain, 'skills': skills,
            'prerequisite': prerequisite, 'hint': hint, 'teaching': teaching}


FAMILIES = {
    'fraction_compare': _family('彩带与分数比较', 'fraction',
        ['fraction-comparison', 'equivalent-fractions', 'fraction-meaning', 'fraction-subtract'], 'fraction_equal',
        '先看看整体是否一样，再选共同单位或基准。',
        '同一整体的分数可以用共同单位或基准数比较。整体不同时还要比较实际数量。'),
    'fraction_equal': _family('分数换一种写法', 'fraction', ['equivalent-fractions'],
        'fraction_meaning', '每一份继续等分，原来取的量变了吗？',
        '分子和分母同时乘相同的非零整数，大小不变。分数也可以在共同分组后约分。'),
    'fraction_meaning': _family('整体与部分', 'fraction', ['fraction-meaning'], 'sharing',
        '先找整体，再数平均分了几份。',
        '分母表示整体平均分成的份数。分子表示取出的份数。'),
    'sharing': _family('平均分给伙伴', 'arithmetic', ['division-sharing'], 'multiplication',
        '每个人得到的一样多，总数要全部分完。',
        '平均分时每份数量相同。总数除以份数得到每份数量。'),
    'multiplication': _family('相同大小的组', 'arithmetic', ['multiplication-meaning', 'division-sharing'], 'addition',
        '区分每组几个和一共有几组。',
        '相同数量的几组可以用乘法合起来。组数与每组数各有自己的含义。'),
    'addition': _family('两部分合起来', 'arithmetic', ['addition-within-20'], None,
        '把两部分合成整体，也可以先凑十。',
        '加法表示把两部分合起来。知道整体与一部分也能反过来找另一部分。'),
    'decimal_compare': _family('小数大小比较', 'decimal', ['decimal-comparison'], 'decimal_place',
        '从高位开始比较相同数位。',
        '小数末尾补零不改变数值。比较大小要对齐相同的计数单位。'),
    'decimal_place': _family('小数中的数字价值', 'decimal', ['decimal-place-value'], 'decimal_meaning',
        '同一个数字在不同位置，表示的单位不同。',
        '小数点右边依次是十分位和百分位。数位决定数字表示多少。'),
    'decimal_meaning': _family('十分之一与百分之一', 'decimal', ['decimal-meaning'], 'place_value',
        '整体是一个，平均分成十份或一百份。',
        '把一平均分成十份，每份是十分之一。小数用位置记录取了多少这样的份。'),
    'place_value': _family('十与一的组成', 'arithmetic', ['place-value'], None,
        '十个一可以捆成一个十。',
        '两位数由几个十和几个一组成。交换数位会改变数字表示的量。'),
    'remainder': _family('完整组与剩余', 'arithmetic', ['division-remainder'], 'grouping',
        '剩下的还能不能再装满一组？',
        '余数是分完完整组后剩下的量。余数必须小于每组数量。'),
    'grouping': _family('按每组数量分组', 'arithmetic', ['division-grouping'], 'multiplication',
        '看看总数里面有几个同样大的组。',
        '总数除以每组数量得到组数。组数乘每组数量可以检查总数。'),
    'division': _family('除法中的每份与份数', 'arithmetic',
        ['division-sharing', 'division-grouping'], 'multiplication',
        '这次求的是每份数量，还是份数？',
        '除法可以求平均分后的每份数量。也可以求按固定数量分出的组数。'),
    'arithmetic': _family('生活中的运算顺序', 'arithmetic', ['operation-order'], 'multiplication',
        '先说每一步表示什么，再计算。',
        '同一个故事中可能先合并再分组。括号能明确哪些量先合起来。'),
    'area_conversion': _family('面积单位换算', 'measurement', ['area-units'], 'rectangle_area',
        '沿两个方向各能铺多少个小方格？',
        '面积单位换算要同时考虑两个方向。换单位不改变实际铺满的面积。'),
    'rectangle_area': _family('铺满长方形', 'space', ['rectangle-area'], 'length_units',
        '先数每行，再数有几行。',
        '长方形面积表示铺满它需要多少单位方格。每行方格数乘行数就是总数。'),
    'length_units': _family('米与厘米', 'measurement', ['length-units'], None,
        '同一段长度可以用不同单位记录。',
        '一米与一百厘米一样长。换单位时数值变化，实际长度不变。'),
    'equation': _family('盒子里的未知数', 'equation', ['simple-equations'], 'balance',
        '找到相等关系，再用反向运算检查。',
        '字母可以表示未知数量。求出后代回原来的等式检查。'),
    'balance': _family('等式两边保持相等', 'equation', ['equation-balance'], 'subtraction',
        '两边做同样的变化，是否仍然相等？',
        '等式两边表示相同的量。两边同时减去相同数量，仍然相等。'),
    'subtraction': _family('拿走与剩下', 'arithmetic', ['subtraction-within-20'], 'addition',
        '整体由拿走的和剩下的组成。',
        '减法可以从整体求剩下的部分。用剩下的加拿走的能检查整体。'),
    'average': _family('平均数与合并数据', 'data', ['average'], 'sharing',
        '先找总量与实际份数，不要只平均两个平均数。',
        '平均数是总量除以实际份数。合并不同人数的组时要先合并总量与人数。'),
    'perimeter_area': _family('围边与铺面', 'space', ['perimeter', 'rectangle-area'], 'rectangle_area',
        '围一圈的长度和铺满的面积不是同一件事。',
        '周长是边界长度的总和。面积相同的图形，周长不一定相同。'),
    'listing': _family('不重不漏的搭配', 'reasoning', ['systematic-listing'], 'listing_probe',
        '固定一个选择，再依次改变另一个。',
        '有顺序地列举可以避免重复与遗漏。列完后还要逐项检查限制条件。'),
    'listing_probe': _family('先固定一种选择', 'reasoning', ['systematic-listing'], None,
        '先固定上衣，再把下装逐一配上。',
        '固定一种选择有助于完整列举。再更换固定项，检查有没有漏掉。'),
    'factors': _family('因数与分组限制', 'arithmetic', ['factors-multiples'], 'grouping',
        '每组一样多且没有剩余，才符合整除。',
        '因数能把一个正整数整分。寻找因数时可以成对检查乘积。'),
    'triangle_area': _family('三角形的底与高', 'space', ['triangle-area'], 'rectangle_area',
        '想一想两个相同的三角形怎样拼起来。',
        '三角形面积是底乘对应高的一半。高要与所选的底垂直对应。'),
    'volume': _family('一层层堆积木', 'space', ['volume'], 'rectangle_area',
        '先数每层，再数层数。',
        '体积表示物体占据的空间大小。长方体每层方块数乘层数得到总体积。'),
    'data_trend': _family('记录中的变化', 'data', ['line-charts', 'data-tables'], 'subtraction',
        '按时间顺序比较相邻记录，别猜未记录的数据。',
        '相邻记录的差反映这段时间的变化。记录之外的走势不能直接当作事实。'),
}


# 独立登记，避免改变旧 FAMILIES 元数据六键合同或旧模式首题。
# 学期是题库编排建议，尚未完成官方目录校准，不是官方教学进度。
CURRICULUM_FAMILIES = {
    'decimal_multiply': ('小数乘法与缩放', 'decimal', 'decimal-multiply', 'fall', 'decimal_place'),
    'decimal_divide': ('小数除法与分组', 'decimal', 'decimal-divide', 'fall', 'decimal_place'),
    'divisibility': ('数字特征与整除', 'arithmetic', 'divisibility', 'spring', 'factors'),
    'prime_composite': ('质数合数与1', 'arithmetic', 'prime-composite', 'spring', 'factors'),
    'gcd': ('最大共同分组', 'arithmetic', 'gcd', 'spring', 'factors'),
    'lcm': ('首次重新重合', 'arithmetic', 'lcm', 'spring', 'factors'),
    'simplify_fractions': ('约分与最简形式', 'fraction', 'simplify-fractions', 'spring', 'fraction_equal'),
    'fraction_add': ('共同单位后相加', 'fraction', 'fraction-add-unlike', 'spring', 'fraction_equal'),
    'fraction_subtract_core': ('共同单位后相减', 'fraction', 'fraction-subtract', 'spring', 'fraction_equal'),
    'fraction_decimal': ('分数小数互相表示', 'fraction', 'fraction-decimal', 'spring', 'decimal_divide'),
    'parallelogram_area': ('剪移与对应高', 'space', 'parallelogram-area', 'fall', 'rectangle_area'),
    'trapezoid_area': ('两份梯形拼面积', 'space', 'trapezoid-area', 'fall', 'triangle_area'),
    'surface_area': ('外表面与缺少的面', 'space', 'surface-area', 'spring', 'rectangle_area'),
    'capacity': ('容积与升毫升', 'measurement', 'capacity', 'spring', 'volume'),
    'coordinates': ('有序数对定位', 'space', 'coordinates', 'fall', 'place_value'),
    'line_charts': ('刻度与相邻变化', 'data', 'line-charts', 'spring', 'subtraction'),
    'shape_transform': ('每点同移与绕点旋转', 'space', 'translation-rotation', 'spring', 'coordinates'),
    'fair_game': ('等可能结果与公平规则', 'reasoning', 'fair-games', 'fall', 'listing_probe'),
}
DIAGNOSTIC_DIMENSIONS = ('concept', 'procedure', 'representation', 'application', 'reasoning')
CURRICULUM_METADATA = {}
for _name, (_title, _domain, _skill, _term, _previous) in CURRICULUM_FAMILIES.items():
    FAMILIES[_name] = _family(_title, _domain, [_skill], _previous,
        '先找单位与关系，再计算；用原条件检验。',
        '先辨认题中的单位与数量关系。计算或构造后要回到原条件检验。')
    CURRICULUM_METADATA[_name] = {
        'curriculumTerm': _term, 'type': 'core',
        'diagnosticDimensions': ['concept', 'reasoning'] + (
            ['representation', 'procedure'] if _name == 'line_charts' else
            ['representation'] if _name in ('coordinates', 'shape_transform', 'fraction_decimal') else
            ['application'] if _name in ('capacity', 'fair_game') else
            ['procedure', 'representation'] if _name in ('fraction_add', 'fraction_subtract_core') else
            ['procedure', 'application'] if _name in ('decimal_multiply', 'decimal_divide', 'gcd', 'lcm',
                                                    'surface_area', 'parallelogram_area', 'trapezoid_area') else
            ['procedure']),
        'termStatus': '编排建议；待官方目录校准',
    }


def _field_dimensions(question):
    """供调度端读取；旧字段没有维度时不推定其诊断类型。"""
    return {field['id']: field['diagnosticDimension'] for field in question['fields']
            if 'diagnosticDimension' in field}


def _number(fid, label, suffix=None, dimension=None):
    field = {'id': fid, 'label': label, 'kind': 'number'}
    if suffix:
        field['suffix'] = suffix
    if dimension is not None:
        field['diagnosticDimension'] = dimension
    return field


def _choice(fid, label, options, dimension=None):
    field = {'id': fid, 'label': label, 'kind': 'choice',
             'options': [{'value': value, 'label': text} for value, text in options]}
    if dimension is not None:
        field['diagnosticDimension'] = dimension
    return field


def _relation(label='哪一个更大？'):
    return _choice('relation', label, [('A', 'A'), ('B', 'B'), ('same', '一样大')])


def _multi(fid, label, options):
    result = _choice(fid, label, [(value, value) for value in options])
    result['kind'] = 'multi'
    return result


def _compare(a, b):
    return 'A' if a > b else 'B' if a < b else 'same'


def _table(headers, rows):
    return {'kind': 'table', 'headers': headers, 'rows': rows}


def _make(family, prompt, diagram, fields, expected, representation, phase,
          field_skills=None, extra_skills=()):
    meta = FAMILIES[family]
    skills = list(dict.fromkeys(meta['skills'] + list(extra_skills)))
    fields = deepcopy(fields)
    for field in fields:
        field['evidenceKind'] = ('question_only' if family == 'data_trend' else
                                 'choice' if field['kind'] == 'choice' else 'constructed')
    mapping = ({field['id']: [] for field in fields} if family == 'data_trend' else
               field_skills or {field['id']: skills.copy() for field in fields})
    # 相关技能不等于直接测量；趋势小题只留题级证据，不假称测完折线图技能。
    # 服务器内部验证；公开题面不含答案、字段评分映射或诊断推断。
    ids = [field['id'] for field in fields]
    if len(set(ids)) != len(ids) or set(ids) != set(expected) or set(ids) != set(mapping):
        raise ValueError('题目字段、答案与评分绑定必须一一对应')
    for field in fields:
        values = mapping[field['id']]
        if 'answerRepresentation' in field:
            if field['kind'] != 'number' or not _field_correct(field, expected[field['id']], expected[field['id']]):
                raise ValueError('目标记法必须有效，且服务器答案须符合目标记法与数值')
        if family in CURRICULUM_FAMILIES:
            if len(values) != 1 or field.get('diagnosticDimension') not in DIAGNOSTIC_DIMENSIONS:
                raise ValueError('核心题字段必须绑定一个技能及有效诊断维度')
            misconceptions = field.get('_misconceptionOptions', {})
            for wrong_value in misconceptions:
                if _field_correct(field, expected[field['id']], wrong_value):
                    raise ValueError('正确答案不能登记为误解选项')
        if not set(values) <= set(skills) or (not values and field['evidenceKind'] != 'question_only'):
            raise ValueError('直接测量字段必须有对应技能；题级证据必须明确标记')
    return {'family': family, 'title': meta['title'], 'domain': meta['domain'],
            'skills': skills.copy(), 'prompt': prompt,
            'context': '原创研究题；不是北京真题。', 'diagram': diagram,
            'fields': fields, '_expected': expected, '_field_skills': deepcopy(mapping),
            'representation': representation,
            'estimatedSeconds': (150 if phase == 'challenge' else 75) + 15 * (len(fields) - 1)}


def _curriculum_question(family, v, phase):
    """四种条件/表示，不把开放解释或相关技能冒充直接测量。"""
    skill = FAMILIES[family]['skills'][0]
    fields, expected = [], {}

    def number(fid, label, value, unit=None, dimension='procedure', wrong=None):
        field = _number(fid, label, unit, dimension)
        field['_misconceptionOptions'] = wrong or {}
        fields.append(field)
        expected[fid] = str(value)

    def choice(fid, label, options, answer, dimension='concept', codes=None):
        field = _choice(fid, label, options, dimension)
        field['_misconceptionOptions'] = {
            value: (codes or {}).get(value, f'{family}:{fid}:{value}')
            for value, _ in options if value != answer}
        fields.append(field)
        expected[fid] = answer

    def idea(label, options, answer, codes=None):
        choice('idea', label, options, answer, codes=codes)

    def check(label, good, bad, other):
        # 不固定正确选项位置，公开选项不标注答案或误解编码。
        texts = [good, bad, other]
        texts = texts[v % 3:] + texts[:v % 3]
        options = list(zip(('A', 'B', 'C'), texts))
        answer = ('A', 'B', 'C')[(-v) % 3]
        choice('check', label, options, answer, 'reasoning')

    if family in ('decimal_multiply', 'decimal_divide'):
        multiply = family == 'decimal_multiply'
        a, b = ([("2.4", "0.5"), ("0.6", "0.4"), ("1.25", "2"), ("3.6", "0.25")]
                if multiply else [("6", "0.3"), ("2.4", "0.6"), ("1.2", "2"), ("0.9", "0.15")])[v]
        a_text, b_text = a, b
        a, b = Fraction(a), Fraction(b)
        result = a * b if multiply else a / b
        relation = 'smaller' if result < a else 'larger' if result > a else 'same'
        idea('结果与第一个数相比？', [('smaller', '更小'), ('larger', '更大'), ('same', '相等')], relation,
             {'larger' if multiply else 'smaller': 'multiplyalwaysbigger' if multiply else 'dividealwayssmaller'})
        op = '×' if multiply else '÷'
        prompt = [f'计算{a_text}{op}{b_text}。先判断大小，再算，最后选检验方法。',
                  f'计量记录如下。用{op}求结果，注意小数计数单位。',
                  f'每米绳价{a_text}元，买{b_text}米求总价。' if multiply else f'{a_text}升平均装入{b_text}个瓶子，求每瓶升数。',
                  f'把长度{a_text}米缩放到原来的{b_text}倍。' if multiply else f'{a_text}米绳每段{b_text}米，求段数。'][v]
        diagram = _table(['第一个数', '第二个数', '运算'], [[a_text, b_text, op]])
        number('result', '结果', result, '元' if multiply and v == 2 else '米' if multiply and v == 3 else '升' if not multiply and v == 2 else '段' if not multiply and v == 3 else None, dimension='application' if v >= 2 else 'procedure',
               wrong={str(a+b): 'multiply_as_add' if multiply else 'divide_as_add'})
        check('哪种方法能检查这次运算？', '用结果与原条件的逆运算核对',
              '乘法结果一定比原数大' if multiply else '除法结果一定比原数小', '只数答案的数字个数')
    elif family == 'divisibility':
        n, divisor = [(123, 3), (125, 5), (128, 2), (124, 3)][v]
        idea(f'判断能否被{divisor}整除，要看什么？',
             [('sum', '各位数字之和'), ('last', '个位数字'), ('length', '数字位数')],
             'sum' if divisor == 3 else 'last')
        prompt = [f'{n}张卡片，每组{divisor}张，分完后剩几张？',
                  f'{n}表示三位数的百、十、个位记录；判断能否按{divisor}张分组，填余数。',
                  f'表格记录总数{n}和每组{divisor}张。用个位特征判断，再填余数。',
                  f'有人说{n}的个位不是3就不能被3整除。检验这个依据，并填按{divisor}分组的余数。'][v]
        diagram = _table(['卡片数', '每组张数'], [[n, divisor]])
        number('remainder', '余数', n % divisor, '张', wrong={'0': 'lastdigit_for_three'} if n % divisor else {})
        check('怎样检验余数？', '完整组数乘每组数，加余数应等于总数', '余数可以等于每组数', '数字位数相同就能整除')
    elif family == 'prime_composite':
        n = [7, 9, 1, 2][v]
        factors = [i for i in range(1, n+1) if n % i == 0]
        category = 'neither' if n == 1 else 'prime' if len(factors) == 2 else 'composite'
        idea(f'{n}属于哪类？', [('prime', '质数'), ('composite', '合数'), ('neither', '都不是')], category,
             {'prime': 'one_is_prime'} if n == 1 else {'composite': 'even_always_composite'} if n == 2 else None)
        prompt = [f'列举{n}的正因数来分类，再填正因数个数。',
                  f'{n}颗珠子按每组整数颗数分完。有多少种每组颗数？据此分类。',
                  '检查1是否为质数或合数，填正因数个数。',
                  '有人说偶数全是合数。用2的正因数个数检验，并给2分类。'][v]
        diagram = _table(['整数', '要检查的候选因数范围'], [[n, f'1到{n}']])
        number('count', '不同正因数个数', len(factors))
        check('哪种检验完整？', '从1到这个数逐个检查是否整除', '只检查奇数', '把1排除在正因数之外')
    elif family in ('gcd', 'lcm'):
        a, b = [(12, 18), (8, 12), (6, 8), (5, 10)][v] if family == 'gcd' else [(6, 8), (4, 6), (3, 9), (5, 7)][v]
        gcd = family == 'gcd'
        if gcd:
            prompt = [f'{a}颗红珠和{b}颗蓝珠，分别按相同每组颗数分完，求最大的每组颗数。',
                      f'长{a}和{b}厘米的两条绳，剪成同长整数厘米小段且无剩余。小段最长几厘米？',
                      '表中两种数量都需被同一个整数整分。求最大的共同单位。',
                      f'有人把{a}和{b}中较大的数当最大公因数。检查后填正确的最大分组单位。'][v]
        else:
            prompt = [f'两盏灯现在同时亮，分别每{a}、{b}分钟亮一次。下一次同时亮等待几分钟？',
                      f'两条从0开始的刻度，分别每{a}、{b}厘米作标记。首个非零重合位置是多少厘米？',
                      f'两种包装分别每包{a}个和{b}个。最少多少个能用任一种包装恰好装完？',
                      f'有人把{a}+{b}当首个共同周期。两灯每{a}、{b}分钟亮一次，检验并填首个等待时间。'][v]
        diagram = _table(['甲数量或周期', '乙数量或周期'], [[a, b]])
        idea('应找哪种共同关系？', [('factor', '共同因数中的最大值'), ('multiple', '共同倍数中的最小正值'),
                                ('product', '直接相乘')], 'factor' if gcd else 'multiple')
        result = math.gcd(a, b) if gcd else math.lcm(a, b)
        unit = '厘米' if v == 1 else '颗' if gcd else '个' if v == 2 else '分钟'
        number('result', '最大共同单位' if gcd else '最小正共同倍数', result, unit,
               'application' if v in (1, 2) else 'procedure')
        check('还要检查哪一点？', '满足两种数量的共同条件，且没有更合适的值',
              '只需满足第一个数', '只要两数乘积就一定是最合适的值')
    elif family == 'simplify_fractions':
        a, b = [(6, 8), (12, 18), (15, 25), (14, 21)][v]
        f = Fraction(a, b)
        prompt = [f'把{a}/{b}约成最简分数，分别填分子和分母。',
                  f'{a}颗涂色珠占全部{b}颗；把这个比例约成最简分数。',
                  f'检查{a}/{b}的分组：改写成分子分母互质的分数。',
                  f'有人只把{a}/{b}的分子除以公因数。改成正确的最简形式。'][v]
        diagram = _table(['原分子', '原分母'], [[a, b]])
        idea('哪种操作保持分数大小？', [('both', '分子分母同除一个非零公因数'), ('top', '只除分子'), ('bottom', '只除分母')], 'both')
        number('numerator', '最简分子', f.numerator)
        number('denominator', '最简分母', f.denominator)
        check('怎样判断已经最简？', '分子分母的公因数只剩1', '分子比分母小即可', '分母必须是偶数')
    elif family in ('fraction_add', 'fraction_subtract_core'):
        subtract = family == 'fraction_subtract_core'
        a, b = ([("5/6", "1/3"), ("3/4", "1/6"), ("7/8", "1/4"), ("4/5", "3/10")]
                if subtract else [("3/4", "1/6"), ("1/2", "1/3"), ("2/5", "3/10"), ("1/4", "3/8")])[v]
        a, b = Fraction(a), Fraction(b)
        op = '−' if subtract else '+'
        prompt = [f'同一整体的{a}{op}{b}。先选单位处理方法，再计算和检验。',
                  f'同一瓶水，用分数记录{a}和{b}；求差。' if subtract else f'绳子两段长{a}米和{b}米；求合计长度。',
                  f'两条同长纸带分别取{a}和{b}，每份单位不同，计算{a}{op}{b}。',
                  f'有人直接对分子分母分别运算。检查并正确计算{a}{op}{b}。'][v]
        diagram = _table(['第一部分', '第二部分', '运算'], [[str(a), str(b), op]])
        idea('先怎样处理不同的单位份？', [('common', '通分成同样大小的份'), ('denominators', '分母直接相加减'), ('tops', '只运算分子')], 'common',
             {'denominators': 'fractionadddenominators', 'tops': 'fraction_ignore_units'})
        number('result', '结果', a-b if subtract else a+b,
               dimension='representation' if v == 2 else 'procedure',
               wrong={str(Fraction(a.numerator+b.numerator, a.denominator+b.denominator)): 'fractionadddenominators'} if not subtract else {})
        check('怎样回到原数量检查？', '用共同单位重新数份，或用逆运算核对', '分母越大结果一定越大', '只比较分子大小')
    elif family == 'fraction_decimal':
        value = ['3/4', '0.625', '7/20', '0.4'][v]
        reverse = v % 2 == 1
        prompt = f'把{value}米改写成' + ('分数' if reverse else '小数') + '表示，实际长度不变。'
        diagram = _table(['原记录', '目标记法'], [[value, '分数' if reverse else '小数']])
        idea('转换依据是什么？', [('place', '按十进位值写分数'), ('divide', '用分子除以分母'), ('concat', '把分子分母拼成数字')], 'place' if reverse else 'divide')
        target = Fraction(value)
        target_text = str(target) if reverse else str(Decimal(target.numerator) / Decimal(target.denominator))
        number('result', '同一长度的新记法', target_text, '米', 'representation')
        fields[-1]['answerRepresentation'] = 'fraction' if reverse else 'decimal'
        check('怎样检验两种记法？', '转回原值，数量应相等', '数字个数应相同', '分数一定比小数小')
    elif family in ('parallelogram_area', 'trapezoid_area'):
        trapezoid = family == 'trapezoid_area'
        lower, upper, height, slant = [(6, 4, 3, 5), (8, 4, 3, 5), (10, 4, 4, 5), (9, 3, 4, 5)][v]
        area = Fraction((lower+upper)*height, 2) if trapezoid else Fraction(lower*height)
        reverse = v == 2
        prompt = (f'梯形下底{lower}、上底{upper}厘米。' if trapezoid else f'平行四边形底{lower}厘米。')
        prompt += f'面积{area}平方厘米，求对应高。' if reverse else f'对应高{height}厘米，求面积。'
        prompt += f'另有斜边{slant}厘米。先选择高的含义，再求未知量。'
        rows = [['下底' if trapezoid else '底', lower], ['上底', upper]] if trapezoid else [['底', lower]]
        rows += [['面积' if reverse else '对应高', str(area) if reverse else height], ['斜边', slant]]
        diagram = _table(['图形上的量', '数值（厘米或平方厘米，见题面）'], rows)
        idea('应选哪条长度作为高？', [('perpendicular', '与底垂直的距离'), ('slant', '斜边'), ('any', '任选一条边')], 'perpendicular',
             {'slant': 'heightslants', 'any': 'height_any_side'})
        number('height' if reverse else 'area', '对应高' if reverse else '面积', height if reverse else area,
               '厘米' if reverse else '平方厘米', 'application' if reverse else 'procedure')
        check('拼接后怎样检查？', '两份梯形拼成底为两底之和的平行四边形' if trapezoid else '剪移成同底等高长方形，面积不变',
              '斜边乘底就是面积', '只加各边长度就是面积')
    elif family == 'surface_area':
        length, width, height = [(4, 3, 2), (5, 3, 2), (4, 4, 3), (6, 3, 2)][v]
        open_top = v == 1
        glued = v == 3
        prompt = f'长方体长{length}、宽{width}、高{height}厘米。'
        prompt += ('盒子没有上盖，求外面五个面的面积。' if open_top else
                   '两个这样的盒子沿长×宽的面贴合，求整体外表面积。' if glued else '求完整六个面的总面积。')
        if v == 2:
            prompt = f'封闭长方体长{length}、宽{width}厘米，完整六面总面积80平方厘米。求高。'
        diagram = _table(['长（厘米）', '宽（厘米）', '高（厘米）', '条件'],
                         [[length, width, height, '无盖' if open_top else '两盒底面贴合' if glued else '封闭']])
        if v == 2:
            diagram = _table(['长（厘米）', '宽（厘米）', '六面面积（平方厘米）', '条件'], [[length, width, 80, '封闭']])
        idea('六面总面积用什么单位？', [('area', '平方厘米：外表面'), ('volume', '立方厘米：内部空间'), ('length', '厘米：边长')], 'area')
        area = 2*(length*width+length*height+width*height)
        result = area-length*width if open_top else 2*area-2*length*width if glued else area
        if v == 2:
            number('height', '高', Fraction(80-2*length*width, 2*(length+width)), '厘米', 'application')
        else:
            number('area', '外表面积', result, '平方厘米', 'application' if open_top or glued else 'procedure',
                   {str(length*width*height): 'surface_as_volume'})
        check('哪些面要计入？', '只数露在外面的面，贴合面和不存在的面不计', '每个盒子总是算六面', '只算朝向自己的三个面')
    elif family == 'capacity':
        amount, direction = [('1.2', 'mL'), ('750', 'L'), ('2.5', 'mL'), ('1600', 'L')][v]
        prompt = (f'{amount}升水改记成毫升。' if direction == 'mL' else f'{amount}毫升水改记成升。')
        if v == 2:
            prompt = '容器内部长5、宽2、高2.5分米；求容量（毫升）。'
        diagram = _table(['内长（分米）', '内宽（分米）', '内高（分米）'], [[5, 2, '2.5']]) if v == 2 else _table(['原数值', '原单位', '目标单位'], [[amount, 'L' if direction == 'mL' else 'mL', direction]])
        idea('换算关系是哪一个？', [('thousand', '1升＝1000毫升＝1立方分米'), ('hundred', '1升＝100毫升'), ('surface', '容量等于表面积')], 'thousand')
        result = Fraction(5*2)*Fraction('2.5')*1000 if v == 2 else Fraction(amount)*1000 if direction == 'mL' else Fraction(amount)/1000
        number('result', '换算后的容量', result, '毫升' if direction == 'mL' else '升', 'application')
        check('怎样检查换单位？', '实际水量不变，反向换算能回到原记录', '换成毫升后水变多', '可用外壁尺寸直接当内部尺寸')
    elif family == 'coordinates':
        x, y, dx, dy = [(3, 2, 0, 0), (2, 4, 3, 0), (5, 3, -2, 1), (4, 5, 0, -3)][v]
        reverse = v == 3
        diagram = (_table(['点', '横坐标', '纵坐标'], [['P', x, y], ['终点', x+dx, y+dy]])
                   if reverse else _table(
                       ['点', '横坐标', '纵坐标', '横向方向', '横向格数（格）', '纵向方向', '纵向格数（格）'],
                       [['P', x, y, '向右' if dx >= 0 else '向左', abs(dx),
                         '向上' if dy >= 0 else '向下', abs(dy)]]))
        # 逆向不要求五年级未登记的负数运算：用减少格数正数作答。
        if reverse:
            prompt = f'约定先横后纵。P（{x}，{y}）到Q（{x+dx}，{y+dy}），横向不变、向下移动；分别填向右和向下的格数。'
        else:
            prompt = f'数对先横后纵，每格1单位。P（{x}，{y}）向{"右" if dx >= 0 else "左"}{abs(dx)}格、向{"上" if dy >= 0 else "下"}{abs(dy)}格，填终点数对。'
        idea('数对第一项表示什么？', [('horizontal', '横向位置'), ('vertical', '纵向位置'), ('sum', '两方向合计')], 'horizontal')
        number('x', '向右格数' if reverse else '终点横坐标', dx if reverse else x+dx, dimension='representation')
        number('y', '向下格数' if reverse else '终点纵坐标', -dy if reverse else y+dy, dimension='representation')
        check('怎样检验位置？', '按约定先横再纵走到目标点', '交换两个坐标总到同一点', '两个坐标相加就是位置')
    elif family == 'line_charts':
        values, scale = [([12, 18, 15, 22], 1), ([2, 5, 4, 6], 2), ([3, 6, 5, 8], 5), ([4, 4, 6, 3], 10)][v]
        prompt = f'连续四天折线图的点高依次为{values}格，纵轴从0起每格{scale}页。读第二天页数，再判断相邻变化。'
        diagram = _table(['天', f'点高（每格{scale}页，起点0）'], [[i+1, n] for i, n in enumerate(values)])
        idea('第三天比第二天怎样变化？', [('up', '增加'), ('down', '减少'), ('same', '不变')],
             'up' if values[2] > values[1] else 'down' if values[2] < values[1] else 'same')
        number('reading', '第二天页数', values[1]*scale, '页', 'representation')
        number('change', '第三天与第二天相差', abs(values[2]-values[1])*scale, '页', 'procedure')
        check('能否由四天记录断定第五天？', '不能断定，第五天尚未记录', '最后一段上升就一定继续上升', '有四个点就必定能确定下一点')
    elif family == 'shape_transform':
        rotate = v >= 2
        x, y, dx, dy = [(2, 1, 3, 2), (4, 3, -2, -1), (5, 3, 0, 0), (3, 1, 0, 0)][v]
        if rotate:
            # 中心(3,3)，逆时针/顺时针直角旋转，所有终点非负。
            tx, ty = (6-y, x) if v == 2 else (y, 6-x)
            prompt = f'点P（{x}，{y}）绕C（3，3）' + ('逆时针' if v == 2 else '顺时针') + '旋转90°。填终点数对。'
            diagram = _table(['点', '横', '纵'], [['P', x, y], ['旋转中心C', 3, 3]])
        else:
            tx, ty = x+dx, y+dy
            prompt = f'小旗每个点都向{"右" if dx >= 0 else "左"}{abs(dx)}格、向{"上" if dy >= 0 else "下"}{abs(dy)}格。P（{x}，{y}）移到哪里？'
            diagram = _table(
                ['点', '横', '纵', '横向方向', '横向格数（格）', '纵向方向', '纵向格数（格）'],
                [['P', x, y, '向右' if dx >= 0 else '向左', abs(dx),
                  '向上' if dy >= 0 else '向下', abs(dy)]])
        idea('哪项在平移和旋转中都保持？', [('size', '图形形状和大小'), ('position', '每个点原来的位置'), ('direction', '每条边原来的方向一定不变')], 'size')
        number('x', '终点横坐标', tx, dimension='representation')
        number('y', '终点纵坐标', ty, dimension='representation')
        check('如何检查变换？', '旋转检查到中心的距离和转角' if rotate else '平移检查每个点方向和距离一致',
              '只移动一个点其他点不动', '图形移动后可以任意改变边长')
    elif family == 'fair_game':
        total, a_count = [(6, 2), (8, 4), (10, 7), (6, 4)][v]
        prompt = f'{total}张大小材质相同的卡片充分混匀，每张被抽到的机会相同。甲有{a_count}张获胜卡，剩下为乙获胜卡。'
        if v == 2:
            prompt += '至少把几张甲卡改给乙，才能公平？'
        else:
            prompt += '数出乙的获胜卡，判断规则。'
        diagram = _table(['全部卡片', '甲获胜卡', '乙获胜卡'], [[total, a_count, '剩余']])
        if v == 3:
            prompt = f'有{total}张大小材质相同的卡片，充分混匀后每张被抽到的机会相同，每张只对应一方获胜。甲乙要机会相同，甲应分配几张？'
            diagram = _table(['全部卡片', '目标', '获胜结果分配'], [[total, '双方机会相同', '待构造']])
            idea('构造公平规则的必要条件？', [('sameCount', '双方获胜卡数相同'), ('twoPlayers', '有两个玩家即可'), ('lastWinner', '上一轮赢家少分卡')], 'sameCount',
                 {'twoPlayers': 'probabilityequalchoices', 'lastWinner': 'random_compensation'})
        else:
            idea('当前规则怎样？', [('A', '甲机会较多'), ('B', '乙机会较多'), ('equal', '机会相同')],
                 'A' if a_count*2 > total else 'B' if a_count*2 < total else 'equal',
                 {'equal': 'probabilityequalchoices'} if a_count*2 != total else None)
        number('count', '公平时甲的张数' if v == 3 else '需改给乙的张数' if v == 2 else '乙的获胜卡张数',
               total//2 if v == 3 else a_count-total//2 if v == 2 else total-a_count, '张', 'application')
        check('判断公平的依据？', '等可能的卡片中双方获胜结果数相同', '只有两个玩家就一定公平', '上次谁输，下次谁就必定赢')
    else:
        raise AssertionError(f'未实现课程题族：{family}')
    # table 保留旧 schema 合同；renderSpec 给新渲染器真实几何/折线数据，
    # 只携带已知条件，不包含计算后的目标点、面积或趋势答案。
    if family in ('coordinates', 'shape_transform'):
        diagram['renderSpec'] = {'kind': 'coordinates', 'unit': 1,
            'xRange': [0, 8], 'yRange': [0, 8], 'points': [{'name': 'P', 'x': x, 'y': y}]}
        if family == 'shape_transform' and rotate:
            diagram['renderSpec'].update(center=[3, 3], angle=90 if v == 2 else -90)
        elif family == 'coordinates' and reverse:
            diagram['renderSpec']['points'].append({'name': 'Q', 'x': x+dx, 'y': y+dy})
        else:
            diagram['renderSpec']['translation'] = [dx, dy]
    elif family == 'line_charts':
        diagram['renderSpec'] = {'kind': 'line', 'xLabel': '天', 'yLabel': '页数',
            'yOrigin': 0, 'yStep': scale, 'points': [[i+1, n*scale] for i, n in enumerate(values)]}
    elif family in ('parallelogram_area', 'trapezoid_area'):
        diagram['renderSpec'] = {'kind': 'polygon', 'shape': 'trapezoid' if trapezoid else 'parallelogram',
            'base': lower, 'unit': 'cm', 'slant': slant}
        if trapezoid:
            diagram['renderSpec']['upperBase'] = upper
        diagram['renderSpec']['area' if reverse else 'height'] = str(area) if reverse else height
    elif family == 'surface_area':
        diagram['renderSpec'] = {'kind': 'solid', 'shape': 'cuboid', 'unit': 'cm',
            'length': length, 'width': width,
            'openTop': open_top, 'copies': 2 if glued else 1, 'joinFace': 'length-width' if glued else None}
        diagram['renderSpec']['surfaceArea' if v == 2 else 'height'] = 80 if v == 2 else height
    return _make(family, prompt, diagram, fields, expected,
                 f'{family}-form-{v}', phase, {field['id']: [skill] for field in fields})


def build_question(family, variant=0, phase='screen', level=0):
    """构造独立题目。variant 为非负整数；level 为 0..3 的轻量支架难度。

    首题 screen/fraction_compare/variant0 不随 level 改变。
    固定首题之后的自适应路由应由调用方结合字段证据与会话预算决定。
    """
    if family not in FAMILIES:
        raise ValueError(f'未知题族：{family}')
    if type(variant) is not int or variant < 0:
        raise ValueError('variant 必须是非负整数')
    if type(level) is not int or not 0 <= level <= 3:
        raise ValueError('level 必须是 0..3 的整数')
    if phase not in ('screen', 'probe', 'verify', 'transfer', 'challenge'):
        raise ValueError('未知出题阶段')
    if phase == 'challenge' and family in ROOTS_PRO:
        return _challenge(family, variant, level)
    # 独立检查不复用 screen 的题面：verify 换表示，transfer 换条件。
    v = (variant + {'screen': 0, 'probe': 1, 'verify': 2,
                    'transfer': 3, 'challenge': 3}[phase]) % 4
    if family in CURRICULUM_FAMILIES:
        return _curriculum_question(family, v, phase)
    def make(prompt, diagram, fields, expected, representation, field_skills=None):
        return _make(family, prompt, diagram, fields, expected, representation,
                     phase, field_skills)

    if family == 'fraction_compare':
        if phase == 'screen' and variant == 0:
            return make('两条同长彩带，A取整条的3/4，B取整条的5/8。哪条取出的部分更长？再填3/4＝几/8。',
                {'kind': 'ribbons', 'a': [3, 4], 'b': [5, 8], 'sameWhole': True},
                [_relation('哪条取出的部分更长？'), _number('equivalent', '3/4＝几/8')],
                {'relation': 'A', 'equivalent': 6}, 'same-whole-ribbons',
                {'relation': ['fraction-comparison'], 'equivalent': ['equivalent-fractions']})
        if v == 2:
            a, b = Fraction(2, 3), Fraction(3, 5)
            return make('A长2/3米，B长3/5米。哪段绳子更长？A比B长多少米？',
                _table(['绳子', '长度（米）'], [['A', '2/3'], ['B', '3/5']]),
                [_relation('哪段更长？'), _number('difference', 'A比B长多少', '米')],
                {'relation': _compare(a, b), 'difference': str(a-b)}, 'metre-lengths',
                {'relation': ['fraction-comparison'], 'difference': ['fraction-subtract']})
        if v == 3:
            return make('同一盒12颗珠子，A选了8颗，B选了9颗。A占整盒几分之几？谁选的比例更大？',
                _table(['方案', '选中颗数', '整盒颗数'], [['A', 8, 12], ['B', 9, 12]]),
                [_number('fraction', 'A占整盒的分数'), _relation('谁选的比例更大？')],
                {'fraction': '2/3', 'relation': 'B'}, 'set-fraction',
                {'fraction': ['fraction-meaning'], 'relation': ['fraction-comparison']})
        return make('A和B各用同样大的一张纸。A涂2/3，B涂4/6，哪张涂得更多？',
            {'kind': 'ribbons', 'a': [2, 3], 'b': [4, 6], 'sameWhole': True},
            [_relation('哪张涂得更多？')], {'relation': 'same'}, 'equivalent-paper',
            {'relation': ['fraction-comparison']})
    if family in ('fraction_equal', 'fraction_meaning'):
        if family == 'fraction_equal':
            numerator, denominator = [(2, 3), (3, 4), (1, 2), (3, 5)][v]
            scale = 2 + level
            if v % 2:
                prompt = f'{numerator*scale}/{denominator*scale}＝几/{denominator}？'
                answer = numerator
            elif v == 2:
                prompt = f'几/{denominator*scale}与{numerator}/{denominator}表示同样多？'
                answer = numerator * scale
            else:
                prompt = f'{numerator}/{denominator}＝几/{denominator*scale}？'
                answer = numerator * scale
            return make(prompt, _table(['原分数', '目标分母'], [[f'{numerator}/{denominator}', denominator*scale]])
                        if v == 2 else {'kind': 'none'}, [_number('numerator', '缺少的分子')],
                        {'numerator': answer}, 'reverse-equivalence' if v % 2 else 'refine-parts')
        total, selected = [(8, 3), (6, 5), (10, 7), (12, 5)][v]
        return make(f'一盒共{total}颗同样的珠子，选出{selected}颗。选出的占整盒几分之几？',
            {'kind': 'parts', 'total': total, 'groups': total},
            [_number('fraction', '选出的占整盒的分数')], {'fraction': str(Fraction(selected, total))},
            f'set-parts-{v}')
    if family in ('sharing', 'grouping', 'division', 'multiplication'):
        groups, size = 3 + v, 4 + level
        total = groups * size
        if family == 'multiplication':
            prompt = (f'每盘有{size}块点心，共{groups}盘。一共有多少块？' if v % 2 == 0
                      else f'{groups}盘点心共{total}块，每盘一样多。每盘多少块？')
            answer = total if v % 2 == 0 else size
        elif family == 'sharing' or (family == 'division' and v % 2 == 0):
            prompt, answer = f'{total}块点心平均分给{groups}人，每人多少块？', size
        else:
            prompt, answer = f'{total}块点心每盘放{size}块，可以放几盘？', groups
        skill = ('multiplication-meaning' if family == 'multiplication' and v % 2 == 0 else
                 'division-sharing' if family == 'multiplication' or '每人' in prompt else 'division-grouping')
        if v == 2:
            diagram = (_table(['盘数', '每盘块数'], [[groups, size]]) if family == 'multiplication'
                       else _table(['总块数', '人数'], [[total, groups]]) if skill == 'division-sharing'
                       else _table(['总块数', '每盘块数'], [[total, size]]))
        else:
            diagram = ({'kind': 'none'} if family == 'multiplication' and v % 2 == 0 else
                       {'kind': 'parts', 'total': total, 'meaning': 'total_only'} if v < 2 else {'kind': 'none'})
        return make(prompt, diagram,
                    [_number('amount', '所求数量')], {'amount': answer},
                    f'groups-{v}', {'amount': [skill]})
    if family in ('addition', 'subtraction', 'arithmetic'):
        a, b = 8 + level, 5 + v
        if family == 'addition':
            prompt = f'盒里有{a}颗珠子，又放入{b}颗。现在多少颗？'
            answer = a + b
            if v % 2:
                prompt, answer = f'两袋共{a+b}颗珠子，一袋{a}颗。另一袋几颗？', b
        elif family == 'subtraction':
            prompt, answer = f'有{a+b}颗珠子，送出{b}颗。剩下几颗？', a
            if v % 2:
                prompt, answer = f'原有{a+b}颗珠子，送出一些后剩{a}颗。送出几颗？', b
        else:
            prompt, answer = '有3袋珠子，每袋4颗，又收到5颗。现在一共几颗？', 17
            if v % 2:
                prompt, answer = '原有5颗珠子，又收到7颗，全部每3颗装一袋。装满几袋？', 4
        if family == 'arithmetic' and v == 2:
            prompt, answer = '3×（4＋5）表示3份各有4颗红珠和5颗蓝珠。一共多少颗？', 27
        return make(prompt, {'kind': 'none'} if v < 2 else
                    _table(['信息'], [[prompt]]), [_number('amount', '所求数量', '颗' if family != 'arithmetic' else None)],
                    {'amount': answer}, f'story-operations-{v}')
    if family == 'decimal_compare':
        a, b = [('0.8', '0.75'), ('2.07', '2.7'), ('0.60', '0.6'), ('1.09', '1.1')][v]
        prompt = f'A为{a}，B为{b}，哪一个数更大？'
        if v == 2:
            prompt = f'A绳长{a}米，B绳长{b}米，哪段更长？'
        elif v == 3:
            prompt = f'同一场跳远，A跳{a}米，B跳{b}米，谁跳得更远？'
        return make(prompt, _table(['对象', '数值'], [['A', a], ['B', b]]),
                    [_relation()], {'relation': _compare(Fraction(a), Fraction(b))}, f'decimal-{v}')
    if family == 'decimal_place':
        value = ['2.47', '4.72', '0.34', '3.04'][v]
        digit = value[-1] if v % 2 else value[-2]
        answer = Fraction(int(digit), 100 if v % 2 else 10)
        return make(f'{value}中的数字{digit}表示多少？用小数或分数填。',
                    {'kind': 'place', 'value': value}, [_number('value', '这个数字表示的量')],
                    {'value': str(answer)}, f'place-unit-{v}')
    if family == 'decimal_meaning':
        total, selected = (10, 3 + level) if v % 2 == 0 else (100, 27 + level)
        prompt = f'把一张纸平均分成{total}份，涂{selected}份。涂色部分占整张多少？用小数填。'
        diagram = {'kind': 'parts', 'total': total, 'groups': total}
        if v == 2:
            prompt = f'一米绳子平均分成{total}段，取{selected}段。取出的长度是多少米？'
            diagram = _table(['整条长度（米）', '平均段数', '取出段数'], [[1, total, selected]])
        return make(prompt, diagram,
                    [_number('value', '涂色部分占整张的数值')],
                    {'value': str(Fraction(selected, total))}, f'decimal-parts-{v}')
    if family == 'place_value':
        tens, ones = 3 + level, 4 + v
        if v % 2:
            return make(f'{tens*10+ones}里有几个十？', {'kind': 'place', 'value': str(tens*10+ones)},
                        [_number('tens', '十的个数')], {'tens': tens}, 'extract-tens')
        return make(f'{tens}捆小棒，每捆10根，另有{ones}根。一共几根？',
                    {'kind': 'parts', 'meaning': 'bundles', 'tens': tens, 'ones': ones},
                    [_number('total', '小棒总数', '根')], {'total': tens*10+ones}, 'compose-tens')
    if family == 'remainder':
        size, groups, rest = 5 + level, 4 + v, 2
        total = size * groups + rest
        return make(f'{total}颗珠子，每{size}颗装满一袋。装满几袋，还剩几颗？',
                    {'kind': 'none'} if v < 2 else _table(['珠子总数', '每袋颗数'], [[total, size]]),
                    [_number('groups', '装满袋数'), _number('remainder', '剩余颗数')],
                    {'groups': groups, 'remainder': rest}, f'remainder-{v}')
    if family == 'length_units':
        if v % 2:
            amount = 200 + 100 * level
            prompt, answer, suffix = f'{amount}厘米等于多少米？', amount // 100, '米'
        else:
            amount = 2 + level
            prompt, answer, suffix = f'{amount}米等于多少厘米？', amount * 100, '厘米'
        if v == 2:
            prompt, answer, suffix = f'{amount}米加30厘米，共多少厘米？', amount*100+30, '厘米'
        elif v == 3:
            prompt, answer, suffix = f'{amount}厘米剪去50厘米，剩下多少米？', str(Fraction(amount-50, 100)), '米'
        return make(prompt, {'kind': 'none'}, [_number('length', '换算后的长度', suffix)],
                    {'length': answer}, 'length-reverse' if v % 2 else 'length-forward')
    if family == 'area_conversion':
        amount = 3 + level
        if v % 2:
            prompt, answer, suffix = f'{amount*100}平方厘米等于多少平方分米？', amount, '平方分米'
        else:
            prompt, answer, suffix = f'{amount}平方分米等于多少平方厘米？', amount*100, '平方厘米'
        if v == 2:
            prompt, answer = f'两张卡面积分别为{amount}平方分米与50平方厘米，合计多少平方厘米？', amount*100+50
        elif v == 3:
            prompt, answer = f'{amount*100}平方厘米的纸剪去50平方厘米，剩下多少平方分米？', str(Fraction(amount*100-50, 100))
        return make(prompt, {'kind': 'grid', 'columns': 10, 'rows': 10, 'cellUnit': 'cm'} if v < 2
                    else {'kind': 'none'}, [_number('area', '换算后的面积', suffix)],
                    {'area': answer}, f'area-unit-{v}')
    if family == 'rectangle_area':
        columns, rows = 6 + level, 3 + v
        if v % 2:
            prompt, answer, suffix = f'长方形面积{columns*rows}平方厘米，长{columns}厘米。宽多少厘米？', rows, '厘米'
        else:
            prompt, answer, suffix = f'长方形长{columns}厘米，宽{rows}厘米。面积多少？', columns*rows, '平方厘米'
        return make(prompt, {'kind': 'grid', 'columns': columns, 'rows': rows, 'cellUnit': 'cm'}
                    if v % 2 == 0 else {'kind': 'none'}, [_number('amount', '所求数量', suffix)],
                    {'amount': answer}, f'rectangle-{v}')
    if family in ('equation', 'balance'):
        count = 3 if family == 'equation' else 1
        offset, x = 4 + v, 6 + level
        total = count * x + offset
        if v >= 2:
            prompt = f'{count}x－{offset}＝{count*x-offset}，x是多少？'
            diagram = {'kind': 'none'}
        else:
            prompt = f'{count}个同样盒子和{offset}支散装笔共{total}支。每盒多少支？'
            diagram = {'kind': 'equation', 'count': count, 'offset': offset, 'total': total}
        return make(prompt, diagram, [_number('x', 'x或每盒数量')], {'x': x}, f'balance-{v}')
    if family == 'average':
        values = [6 + level, 8 + level, 10 + level]
        if v % 2:
            prompt = f'三次得分的平均数是{8+level}，前两次为{6+level}和{8+level}。第三次多少？'
            diagram, answer = {'kind': 'none'}, 10 + level
        else:
            if v == 2:
                values.append(12 + level)
            prompt = f'{len(values)}次得分为' + '、'.join(map(str, values)) + '。平均每次多少分？'
            diagram = (_table(['次数', '分数'], [[i+1, value] for i, value in enumerate(values)])
                       if v == 2 else {'kind': 'bars', 'values': values})
            answer = Fraction(sum(values), len(values))
        return make(prompt, diagram, [_number('amount', '所求分数', '分')],
                    {'amount': str(answer)}, f'average-{v}')
    if family == 'perimeter_area':
        columns, rows = 6 + level, 3 + v
        prompt = f'长方形长{columns}厘米、宽{rows}厘米。周长和面积各是多少？'
        diagram = {'kind': 'tiles', 'columns': columns, 'rows': rows, 'meaning': 'area', 'cellUnit': 'cm'}
        if v % 2:
            prompt = f'长方形面积{columns*rows}平方厘米，宽{rows}厘米。长和周长各是多少？'
            return make(prompt, {'kind': 'none'}, [_number('length', '长', '厘米'),
                        _number('perimeter', '周长', '厘米')],
                        {'length': columns, 'perimeter': 2*(columns+rows)}, 'area-to-perimeter',
                        {'length': ['rectangle-area'], 'perimeter': ['perimeter']})
        return make(prompt, diagram, [_number('perimeter', '周长', '厘米'),
                    _number('area', '面积', '平方厘米')],
                    {'perimeter': 2*(columns+rows), 'area': columns*rows}, f'boundary-surface-{v}',
                    {'perimeter': ['perimeter'], 'area': ['rectangle-area']})
    if family in ('listing', 'listing_probe'):
        tops = ['红衣', '蓝衣']
        bottoms = ['短裤', '长裤'] if family == 'listing_probe' else ['短裤', '长裤', '裙子']
        options = [f'{a}+{b}' for a in tops for b in bottoms]
        expected = options.copy()
        prompt = '每次选一件上衣和一件下装，选出所有搭配。'
        if v == 1:
            expected = [item for item in options if item != '红衣+短裤']
            prompt += '红衣不能配短裤，其他都可以。'
        elif v == 2:
            expected = [item for item in options if item.startswith('红衣+')]
            prompt += '这次必须穿红衣。'
        elif v == 3:
            expected = [item for item in options if item.endswith('+长裤')]
            prompt += '这次必须穿长裤。'
        return make(prompt, _table(['上衣', '下装'], [[','.join(tops), ','.join(bottoms)]]),
                    [_multi('combinations', '选出全部合法搭配', options)],
                    {'combinations': expected.copy()}, f'listing-{v}')
    if family == 'factors':
        total = [12, 18, 20, 24][v]
        options = [str(i) for i in range(1, total+1)]
        allowed = [str(i) for i in range(1, total+1) if total % i == 0 and (v < 2 or i > 2)]
        constraint = '每组还必须多于2颗。' if v >= 2 else ''
        return make(f'{total}颗珠子分成同样大小的组，不能剩余。{constraint}每组颗数有哪些可能？选出全部。',
                    {'kind': 'parts', 'total': total, 'meaning': 'total_only'},
                    [_multi('factors', '全部可能的每组颗数', options)], {'factors': allowed}, f'factors-{v}')
    if family == 'triangle_area':
        base, height = 6 + 2*level, 4 + v
        if v % 2:
            prompt, answer, suffix = f'三角形底{base}厘米，面积{base*height//2}平方厘米。对应高多少？', height, '厘米'
        else:
            prompt, answer, suffix = f'三角形底{base}厘米，对应高{height}厘米。面积多少？', base*height//2, '平方厘米'
        return make(prompt, _table(['底（厘米）', '对应高（厘米）'], [[base, height]])
                    if v == 2 else {'kind': 'none'}, [_number('amount', '所求数量', suffix)],
                    {'amount': answer}, f'triangle-{v}')
    if family == 'volume':
        columns, rows, layers = 4 + level, 3, 2 + v
        if v % 2:
            prompt, answer = f'每层{columns*rows}个1立方厘米方块，总体积{columns*rows*layers}立方厘米。共几层？', layers
        else:
            prompt, answer = f'每层{rows}行，每行{columns}个1立方厘米方块，共{layers}层。体积多少立方厘米？', columns*rows*layers
        if v == 2:
            prompt += '若拿走完整的一层，剩余体积多少立方厘米？只填剩余体积。'
            answer -= columns*rows
        return make(prompt, {'kind': 'tiles', 'columns': columns, 'rows': rows, 'meaning': 'volume_layer'} if v % 2 == 0
                    else {'kind': 'none'}, [_number('amount', '层数' if v % 2 else '体积', None if v % 2 else '立方厘米')],
                    {'amount': answer}, f'layer-volume-{v}')
    if family == 'data_trend':
        values = [12 + level, 18 + level, 15 + level, 22 + level]
        if v % 2:
            prompt, answer = '四天读书页数依次为' + '、'.join(map(str, values)) + '。哪一段增加最多？', '3-4'
            fields = [_choice('interval', '增加最多的时段', [('1-2', '第一到二天'), ('2-3', '第二到三天'), ('3-4', '第三到四天')])]
            expected = {'interval': answer}
        else:
            prompt = '三天读书页数依次为' + '、'.join(map(str, values[:3])) + '。第二到第三天减少几页？'
            fields, expected = [_number('decrease', '减少页数', '页')], {'decrease': values[1]-values[2]}
            if v == 2:
                prompt = '三天读书页数依次为' + '、'.join(map(str, values[:3])) + '。第一到第二天增加几页？'
                fields, expected = [_number('increase', '增加页数', '页')], {'increase': values[1]-values[0]}
        return make(prompt, _table(['天', '页数'], [[i+1, value] for i, value in enumerate(values if v % 2 else values[:3])]),
                    fields, expected, f'trend-{v}')
    raise AssertionError(f'未实现的题族：{family}')


def _challenge(family, variant, level):
    """所有根题族的挑战均改变推理要求，而非仅放大数字。"""
    phase = 'challenge'

    def make(prompt, diagram, fields, expected, representation, mapping=None, extra=()):
        return _make(family, prompt, diagram, fields, expected, representation, phase, mapping, extra)

    if family == 'fraction_compare':
        # 以平均分/等组求整数实际量，不引入六年级分数乘法技能。
        return make('A整条彩带长8米，取3/4；B整条长16米，取5/8。A、B各取多少米？哪段取出的实际长度更长？',
            {'kind': 'ribbons', 'a': [3, 4], 'b': [5, 8], 'sameWhole': False, 'sizes': [8, 16]},
            [_number('actualamount', 'A实际取出长度', '米'), _number('b_amount', 'B实际取出长度', '米'),
             _relation('哪段实际更长？')], {'actualamount': 6, 'b_amount': 10, 'relation': 'B'}, 'different-wholes',
            {'actualamount': ['fraction-meaning', 'division-sharing', 'multiplication-meaning'],
             'b_amount': ['fraction-meaning', 'division-sharing', 'multiplication-meaning'],
             'relation': ['number-comparison']},
            ['division-sharing', 'multiplication-meaning', 'number-comparison'])
    if family == 'decimal_compare':
        options = ['0.60', '0.61', '0.65', '0.70', '0.71']
        return make('从备选小数中选出所有严格大于0.6、严格小于0.7的数。端点不能选。',
            {'kind': 'none'}, [_multi('values', '全部符合条件的数', options)],
            {'values': ['0.61', '0.65']}, 'decimal-open-interval')
    if family == 'remainder':
        size = 5 + level
        return make(f'珠子每{size}颗装满一袋，恰好装满4袋还有剩余。珠子最多可能有多少颗？',
            {'kind': 'none'}, [_number('total', '最多颗数', '颗')],
            {'total': 4*size + size-1}, 'remainder-bound')
    if family == 'area_conversion':
        return make('A卡面积2平方分米，B卡面积150平方厘米。A比B大多少平方厘米？',
            _table(['卡片', '面积'], [['A', '2平方分米'], ['B', '150平方厘米']]),
            [_number('difference', 'A比B多的面积', '平方厘米')], {'difference': 50}, 'mixed-area-units')
    if family == 'equation':
        return make('3个相同盒子加4支散装笔，与2个这样的盒子加10支笔一样多。每盒几支？',
            {'kind': 'none'}, [_number('x', '每盒笔数', '支')], {'x': 6}, 'unknown-both-sides')
    if family == 'average':
        return make('甲组2人，平均每人读6页；乙组3人，平均每人读10页。合并5人后平均每人读几页？',
            _table(['组', '人数', '平均页数'], [['甲', 2, 6], ['乙', 3, 10]]),
            [_number('average', '合并后的平均页数', '页')], {'average': '42/5'}, 'unequal-group-sizes')
    if family == 'perimeter_area':
        return make('A长方形长6厘米宽2厘米，B长方形长4厘米宽3厘米。分别填面积，再选周长更大的。',
            _table(['图形', '长（厘米）', '宽（厘米）'], [['A', 6, 2], ['B', 4, 3]]),
            [_number('a_area', 'A面积', '平方厘米'), _number('b_area', 'B面积', '平方厘米'),
             _relation('哪个周长更大？')], {'a_area': 12, 'b_area': 12, 'relation': 'A'}, 'same-area-different-perimeter',
            {'a_area': ['rectangle-area'], 'b_area': ['rectangle-area'], 'relation': ['perimeter']})
    if family == 'listing':
        options = [f'{a}{b}' for a in '123' for b in '123']
        return make('用1、2、3组成两位数，每个数字最多用一次，且数必须是奇数。选出全部符合条件的数。',
            {'kind': 'none'}, [_multi('combinations', '全部合法两位数', options)],
            {'combinations': ['13', '21', '23', '31']}, 'complete-constrained-enumeration')
    if family == 'factors':
        return make('24颗珠子分成等大的组，无剩余。组数大于3且小于7，每组颗数有哪些可能？选出全部。',
            {'kind': 'none'}, [_multi('factors', '全部可能的每组颗数', ['3', '4', '5', '6', '8'])],
            {'factors': ['4', '6']}, 'factor-group-constraint')
    if family == 'triangle_area':
        return make('A三角形底8厘米、对应高3厘米。B的底6厘米，要与A面积相同，B对应高应为多少厘米？',
            _table(['三角形', '底（厘米）', '对应高（厘米）'], [['A', 8, 3], ['B', 6, '未知']]),
            [_number('height', 'B对应的高', '厘米')], {'height': 4}, 'equal-area-missing-height')
    if family == 'volume':
        return make('一堆积木共24个，每个1立方厘米。A堆每层长4个宽3个；B堆每层长3个宽2个。B比A多几层？',
            _table(['堆法', '每行个数', '行数'], [['A', 4, 3], ['B', 3, 2]]),
            [_number('difference', 'B比A多的层数')], {'difference': 2}, 'fixed-volume-layer-constraint')
    if family == 'data_trend':
        return make('四天读书页数为12、18、15、22。仅凭这些记录，能确定第五天一定比第四天多吗？',
            _table(['天', '页数'], [[1, 12], [2, 18], [3, 15], [4, 22]]),
            [_choice('claim', '选择能被记录支持的判断', [('yes', '能确定一定更多'),
                     ('no', '能确定一定更少'), ('unknown', '不能确定')])],
            {'claim': 'unknown'}, 'unrecorded-data-boundary', {'claim': ['line-charts']})
    raise AssertionError(f'未实现的根题族挑战：{family}')


def public_question(question):
    """深复制公开内容，递归移除下划线字段；必须在发送给前端前调用。"""
    if isinstance(question, Mapping):
        return {key: public_question(value) for key, value in question.items()
                if isinstance(key, str) and not key.startswith('_')}
    if isinstance(question, (list, tuple)):
        return [public_question(value) for value in question]
    return deepcopy(question)


_NUMBER = re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)\Z')
_INTEGER = re.compile(r'[+-]?[0-9]+\Z')
_COMPARATORS = {'>': '>', '＞': '>', '﹥': '>', '≻': '>',
                '<': '<', '＜': '<', '﹤': '<', '≺': '<', '=': '=', '＝': '=', '==': '='}


def parse_number(value):
    """仅接受有限整数、小数、简单整数分数；精确转 Fraction，无表达式求值。

    float 按 Python 的有限十进制字符串解释，不以二进制误差设容差。
    字符串最多128字符；拒绝指数、布尔值、单位、算式与分母零。
    """
    if isinstance(value, bool):
        return None
    if isinstance(value, Fraction):
        return value if value.numerator.bit_length() <= 512 and value.denominator.bit_length() <= 512 else None
    if type(value) not in (str, int, float, Decimal):
        return None
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Decimal) and not value.is_finite():
        return None
    if isinstance(value, int) and value.bit_length() > 512:
        return None
    if isinstance(value, Decimal) and (len(value.as_tuple().digits) > 128 or abs(value.as_tuple().exponent) > 128):
        return None
    text = str(value)
    if len(text) > 128:
        return None
    text = unicodedata.normalize('NFKC', text).strip().replace('−', '-').replace('⁄', '/').replace('∕', '/')
    try:
        if '/' in text:
            pieces = text.split('/')
            if len(pieces) != 2 or not all(_INTEGER.fullmatch(piece.strip()) for piece in pieces):
                return None
            numerator, denominator = (int(piece.strip()) for piece in pieces)
            return Fraction(numerator, denominator) if denominator else None
        if _NUMBER.fullmatch(text):
            return Fraction(text)
    except (ValueError, ZeroDivisionError, OverflowError):
        pass
    return None


def _token(value):
    if not isinstance(value, str) or len(value) > 128:
        return None
    text = unicodedata.normalize('NFKC', value).strip()
    return _COMPARATORS.get(text, text)


def _blank(value):
    return value is None or (isinstance(value, str) and not value.strip()) or value == []


def _matches_answer_representation(value, representation):
    """只约束显式声明的目标记法；值的合法性仍由 parse_number 校验。

    不将 Fraction 的相等值当作已写出小数。分数目标要求提交整数分子/
    整数分母记法，但不附加未要求的最简条件。保留 received 原始记录。
    """
    if representation not in ('decimal', 'fraction'):
        return False
    if type(value) not in (str, int, float, Decimal):
        return False
    # parse_number 已先做有限值/长度/指数边界校验；此处不放宽其语法。
    text = unicodedata.normalize('NFKC', str(value)).strip().replace('−', '-').replace('⁄', '/').replace('∕', '/')
    if representation == 'decimal':
        return '.' in text and _NUMBER.fullmatch(text) is not None
    pieces = text.split('/')
    return len(pieces) == 2 and all(_INTEGER.fullmatch(piece.strip()) for piece in pieces)


def _field_correct(field, expected, received):
    if _blank(received):
        return False
    if field['kind'] == 'number':
        actual, target = parse_number(received), parse_number(expected)
        if actual is None or target is None or actual != target:
            return False
        if 'answerRepresentation' in field:
            return _matches_answer_representation(received, field['answerRepresentation'])
        return True
    if field['kind'] == 'choice':
        actual, target = _token(received), _token(expected)
        allowed = {_token(option['value']) for option in field.get('options', [])}
        return actual is not None and actual in allowed and actual == target
    if field['kind'] == 'multi':
        if not isinstance(received, (list, tuple)) or not isinstance(expected, (list, tuple)):
            return False
        if len(received) > len(field.get('options', [])):
            return False
        actual, target = [_token(value) for value in received], [_token(value) for value in expected]
        allowed = {_token(option['value']) for option in field.get('options', [])}
        return (None not in actual and len(actual) == len(set(actual)) and
                set(actual) <= allowed and set(actual) == set(target))
    if field['kind'] == 'text':
        # 仅精确短文本答案，绝不把开放理由当作已经验证的推理。
        actual, target = _token(received), _token(expected)
        return actual is not None and target is not None and actual == target
    return False


def _field_misconceptions(question):
    """服务器私有 wrongValue→code；公开题面不携带可反推答案的映射。"""
    return {field['id']: deepcopy(field.get('_misconceptionOptions', {}))
            for field in question['fields'] if 'diagnosticDimension' in field}


def _misconception_code(field, received):
    for wrong_value, code in field.get('_misconceptionOptions', {}).items():
        if field['kind'] == 'number':
            actual, wrong = parse_number(received), parse_number(wrong_value)
            if actual is not None and actual == wrong:
                return code
        elif _token(received) is not None and _token(received) == _token(wrong_value):
            return code
    return None


def evaluate_question(q, answers):
    """仅对服务器内部题目评分；未知键（包括 workText）安全忽略。

    wrongSkills 是答错字段所测技能，不是已确认的缺失或错误原因。
    missing 包括未提交、None、空白与空列表；非法但非空的回答标错。
    """
    if not isinstance(answers, Mapping):
        answers = {}
    fields = q.get('fields', [])
    if not fields or '_expected' not in q or '_field_skills' not in q:
        raise ValueError('评分需要含服务器答案与字段绑定的非空题目')
    results, wrong, missing = [], [], []
    for field in fields:
        fid = field['id']
        received = answers.get(fid)
        if fid not in answers or _blank(received):
            missing.append(fid)
        skills = list(q['_field_skills'][fid])
        correct = _field_correct(field, q['_expected'][fid], received)
        results.append({'id': fid, 'correct': correct, 'skillIds': skills, 'received': deepcopy(received),
                        'evidenceKind': field.get('evidenceKind', 'constructed')})
        if 'diagnosticDimension' in field:
            code = None if correct else _misconception_code(field, received)
            results[-1]['diagnosticDimension'] = field['diagnosticDimension']
            results[-1]['reason'] = {
                'status': 'correct' if correct else 'missing' if fid in missing else
                          'misconception_option' if code else 'incorrect',
                'misconceptionCode': code,
                'interpretation': '字段作答证据；不是已确认的误解原因',
            }
        if not correct:
            wrong.extend(skill for skill in skills if skill not in wrong)
    return {'correct': all(item['correct'] for item in results), 'fieldResults': results,
            'wrongSkills': wrong, 'missing': missing}


def validate_open_reasoning(work_text):
    """没有开放推理验证器，不论是否有草稿都不能宣称验证通过。"""
    return False
