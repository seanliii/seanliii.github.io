"""Loopback-only research prototype. No public file server, credentials or uploads."""
from __future__ import annotations

import json
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import copy
import hashlib
import importlib.util
import mimetypes
import marshal
import sys
import types
import os
import re
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from engine import TutorError, TutorStore
from providers import TextProvider
from harness import Harness, VERSION

ROOT = Path(__file__).resolve().parent
PORT = 19950
PRODUCT_ROOT = ROOT.parent / '产品原型'
_PROXY = None


def local_learning_proxy():
    global _PROXY
    if _PROXY is None:
        spec = importlib.util.spec_from_file_location('grade5_deeptutor_proxy', PRODUCT_ROOT / 'deeptutor_proxy.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _PROXY = module
    return _PROXY


SHARED_LEARNING_ASSETS = {
    '/learning.js': 'learning.js', '/learning.css': 'learning.css', '/learning.html': 'learning.html',
}


def shared_learning_bytes(path):
    """Only three fixed product assets; never pass outside paths to Harness."""
    name = SHARED_LEARNING_ASSETS[path]
    base = PRODUCT_ROOT.resolve()
    target = PRODUCT_ROOT / name
    if (PRODUCT_ROOT.is_symlink() or target.is_symlink() or not target.is_file()
            or target.resolve().parent != base or not base.is_relative_to(ROOT.parent.resolve())):
        raise TutorError('not_found', '共享学习入口尚未就绪。', 404)
    if target.stat().st_size > 2 * 1024 * 1024:
        raise TutorError('too_large', '共享学习资源超过大小上限。', 413)
    with target.open('rb') as stream:
        content = stream.read(2 * 1024 * 1024 + 1)
    if len(content) > 2 * 1024 * 1024:
        raise TutorError('too_large', '共享学习资源超过大小上限。', 413)
    return target, content

ASSETS = {
    '/': 'index.html', '/index.html': 'index.html', '/tutor.html': 'tutor.html',
    '/style.css': 'style.css', '/app.js': 'app.js', '/plan.js': 'plan.js', '/voice.js': 'voice.js',
    '/ui-options.html': 'ui-options.html', '/ui-options.css': 'ui-options.css',
    '/ui-options.js': 'ui-options.js',
}
MIME = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
        '.txt': 'text/plain; charset=utf-8'}
STORE = None
MODEL = None
VOICE = None
MOTION_WORKER = None
MOTION_SCRIPT_SOURCES = ''
VOICE_LOCK = threading.Lock()
HARNESS = Harness(ROOT, shared_reader=shared_learning_bytes)
APP_MODE = 'local'
CLOUD = None
RUNTIME_ROOT = None
MATH_APP = False
PUBLIC_BUILD_BYTES = {
    '/media/catalog-fall-p6.jpg': 'build/media/catalog-fall-p6.jpg',
    '/media/catalog-spring-p6.jpg': 'build/media/catalog-spring-p6.jpg',
    '/media/catalog-spring-p7.jpg': 'build/media/catalog-spring-p7.jpg',
    '/notices.txt': 'build/notices.txt',
}


def public_build_bytes(relative):
    try:
        return HARNESS.read_bytes(HARNESS.build_path(relative.removeprefix('build/')), limit=4 * 1024 * 1024)
    except Exception:
        raise TutorError('not_found', '这份公开课堂资源不可用。', 404) from None


def session_reply(store, identifier, token):
    with store.lock:
        view = store.view(identifier, token)
        current = view.get('current') or {}
        teacher = view.get('classroom', {}).get('teacher')
        if teacher and teacher.get('receipt'):
            reply = {'reply': {'reply': teacher['reply'], 'question': teacher['question']},
                     'receipt': teacher['receipt']}
        else:
            rows = store.db.execute("SELECT data FROM events WHERE session_id=? AND kind='model_reply' ORDER BY seq DESC", (identifier,)).fetchall()
            reply = next((json.loads(row[0]) for row in rows
                          if json.loads(row[0]).get('instanceId') == current.get('instanceId')
                          and json.loads(row[0]).get('receipt', {}).get('state') == 'success'
                          and json.loads(row[0]).get('phase', view['phase']) == view['phase']), None)
    return {'revision': view['revision'], 'instanceId': current.get('instanceId'),
            'response': {'result': reply['reply'], 'receipt': reply['receipt']} if reply and 'receipt' in reply else None}


def public_harness():
    """Built runtime contract; no owner's filetree or package inspector."""
    contract = {key: copy.deepcopy(HARNESS.config[key]) for key in
                ('version', 'teachingPolicy', 'privacy', 'limits', 'tokens', 'defaultView', 'registry')}
    contract['designSystem'] = {key: copy.deepcopy(HARNESS.config['designSystem'][key]) for key in
                                ('package', 'version', 'actualComponents', 'themePackages', 'defaultTheme')
                                if key in HARNESS.config['designSystem']}
    if 'teacherTools' in HARNESS.config:
        contract['teacherTools'] = copy.deepcopy(HARNESS.config['teacherTools'])
    contract['privacy']['selectionScope'] = 'browser'
    contract['registry'] = [row for row in contract['registry'] if row['id'] in ('01', '05', '06')]
    contract['defaultView'] = '01'
    frontend = HARNESS.frontend_manifest()
    return {**contract, 'configState': 'loaded', 'state': 'ready' if frontend['built'] else 'configured',
            'frontend': frontend, 'selection': {'view': '01', 'persisted': False, 'scope': 'browser'},
            'packages': [], 'agentRules': {'exists': False, 'role': 'not-required-for-built-runtime'}}


def deploy_health():
    try:
        voices = voice_service().status()
    except Exception:
        voices = {}
    return {'app': 'xiaomei-math', 'release': os.environ.get('XIAOMEI_MATH_RELEASE', ''),
            'curriculum': hashlib.sha256(STORE.graph.source.read_bytes()).hexdigest(),
            'views': ['01', '05', '06'], 'voices': bool(voices.get('configured') and voices.get('available')),
            'auth': 'cookie-gated', 'budget': 'private-ledger', 'runtimeRoot': str(CLOUD.root)}


def current_process_sources():
    """Fixed executable modules only, never configs, runtime data or credentials."""
    hashes = {}
    for name in ('server.py', 'harness.py', 'engine.py', 'providers.py'):
        path = Path(__file__).resolve().parent / name
        if path.is_file() and not path.is_symlink():
            hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return hashes


def process_identity():
    current = current_process_sources()
    return {'pid': os.getpid(), 'loadedAt': PROCESS_LOADED_AT,
            'sourceSHA256': dict(PROCESS_SOURCE_SHA256),
            'loadedCodeSHA256': dict(PROCESS_CODE_SHA256),
            'sourceCurrent': current == PROCESS_SOURCE_SHA256,
            'evidence': 'module-load-source-snapshot-not-current-file-as-loaded-version'}


class TeacherMotionWorker:
    """One host-owned worker; no model requests, daemon discovery or public jobs."""
    def __init__(self, store, adapter):
        self.store, self.adapter = store, adapter
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='teacher-motion')
        self.lock = threading.RLock()
        self.closed = False
        self.owned = {}

    def schedule(self, identifier, token, request_id):
        with self.lock:
            if self.closed:
                return
            for job in self.store.pending_teacher_motions(identifier, token, request_id):
                self.owned[job['id']] = (identifier, token, job)
                try:
                    self.executor.submit(self._render, identifier, token, job)
                except Exception:
                    self.owned.pop(job['id'], None)
                    self.store.fail_teacher_motion(identifier, token, job['id'], job['version'])

    def _render(self, identifier, token, job):
        try:
            def check():
                return not self.closed and self.store.teacher_motion_check(identifier, token, job['id'], job['version'])
            if not check():
                return
            artifact = asyncio.run(self.adapter.render(job['scope'], job['canonical'], job['id'],
                duration_seconds=job['durationSeconds'], current=job.get('current'), check=check))
            self.store.complete_teacher_motion(identifier, token, job['id'], job['version'], artifact)
        except Exception:
            self.store.fail_teacher_motion(identifier, token, job['id'], job['version'])
        finally:
            with self.lock:
                self.owned.pop(job['id'], None)

    def close(self):
        with self.lock:
            self.closed = True
            owned = list(self.owned.values())
        for identifier, token, job in owned:
            self.store.fail_teacher_motion(identifier, token, job['id'], job['version'],
                                           cancelled=True, code='worker_closed')
        self.executor.shutdown(wait=True, cancel_futures=True)
        with self.lock:
            self.owned.clear()


def local_teacher_motion():
    if APP_MODE == 'public-math':
        return None
    # Fixed shared production adapter only, not an HTTP path nor a helper/fallback.
    path = ROOT.parent / '学习服务' / 'teacher_motion.py'
    if path.parent.is_symlink() or path.is_symlink() or not path.is_file():
        return None
    spec = importlib.util.spec_from_file_location('grade5_teacher_motion', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.TeacherMotion()


def initialize_runtime(app_mode='local', runtime_root=None, private_config=None, *, frontend_root=None):
    """Load the contract before services; never require a completed frontend build."""
    global STORE, MODEL, HARNESS, APP_MODE, CLOUD, RUNTIME_ROOT, MATH_APP, VOICE, MOTION_WORKER, MOTION_SCRIPT_SOURCES
    if frontend_root is not None and app_mode not in ('local', 'math'):
        raise ValueError('frontend-root is only allowed in loopback local/math mode')
    # Validate the trusted startup option before touching stores or provider configuration.
    harness = Harness(ROOT, build_root=frontend_root if frontend_root is not None else 'build',
                      shared_reader=shared_learning_bytes if app_mode == 'local' else None)
    APP_MODE, MATH_APP = app_mode, app_mode in ('math', 'public-math')
    RUNTIME_ROOT = Path(runtime_root) if runtime_root else None
    if app_mode == 'public-math':
        if not runtime_root or not private_config:
            raise ValueError('public-math requires explicit runtime-root and private-config')
        from cloud_runtime import CloudRuntime
        for variable, ceiling in (('CLASSROOM_DOUBAO_MAX_SECONDS', 180), ('CLASSROOM_DOUBAO_DAILY_SECONDS', 600)):
            if variable in os.environ:
                try:
                    value = int(os.environ[variable])
                except ValueError:
                    raise ValueError('invalid voice time policy') from None
                if not 1 <= value <= ceiling:
                    raise ValueError('public-math cannot expand voice time policy')
        CLOUD = CloudRuntime(private_config, runtime_root)
    else:
        CLOUD = None
        if RUNTIME_ROOT:
            from cloud_runtime import private_directory, private_database
            private_directory(RUNTIME_ROOT)
            private_database(RUNTIME_ROOT / 'sessions.sqlite3').close()
    if MOTION_WORKER:
        MOTION_WORKER.close()
    MOTION_WORKER, MOTION_SCRIPT_SOURCES = None, ''
    HARNESS = harness
    quota_policy = 'unlimited' if app_mode == 'math' or CLOUD and CLOUD.unlimited_budget else 'legacy'
    STORE = TutorStore(RUNTIME_ROOT / 'sessions.sqlite3' if RUNTIME_ROOT else None,
                       model_quota_policy=quota_policy)
    STORE.interrupt_teacher_motions()
    if app_mode in ('local', 'math'):
        try:
            adapter = local_teacher_motion()
            if adapter and adapter.status().get('available'):
                hashes = adapter.script_sources()
                if not re.fullmatch(r"'sha256-[A-Za-z0-9+/]{43}='(?: 'sha256-[A-Za-z0-9+/]{43}=')*", hashes):
                    raise ValueError('invalid trusted script hashes')
                STORE.teacher_motion = adapter
                MOTION_SCRIPT_SOURCES = hashes
                MOTION_WORKER = TeacherMotionWorker(STORE, adapter)
        except Exception:
            STORE.teacher_motion = None
    MODEL = TextProvider(HARNESS.model_store(STORE), runtime=CLOUD, quota_policy=quota_policy)
    VOICE = None
    return public_harness() if MATH_APP else HARNESS.public()


def voice_service():
    global VOICE
    with VOICE_LOCK:
        if VOICE is None:
            from realtime import TutorRealtime
            options = {'runtime_root': RUNTIME_ROOT} if RUNTIME_ROOT else {}
            if CLOUD:
                options['credential_path'] = CLOUD.config['credentials']['doubao']
            if APP_MODE == 'math' or CLOUD and CLOUD.unlimited_budget:
                options['voice_policy'] = 'unlimited'
            VOICE = TutorRealtime(HARNESS.model_store(STORE), **options)
        return VOICE


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def setup(self):
        super().setup()
        if hasattr(self.connection, 'settimeout'):
            self.connection.settimeout(90)

    def log_message(self, _format, *_args):
        # Do not log request bodies, learner capabilities or query strings.
        pass

    def _allowed(self):
        if CLOUD:
            internal = (urlsplit(self.path).path == '/api/deploy-health'
                        and not self.headers.get('X-Math-Prefix') and not self.headers.get('Origin')
                        and not self.headers.get('Sec-Fetch-Site'))
            if (self.client_address[0] not in ('127.0.0.1', '::1')
                    or self.headers.get_all('Host') != [f'127.0.0.1:{PORT}']
                    or (not internal and self.headers.get_all('X-Math-Prefix') != ['/xiaomei-math'])):
                raise TutorError('proxy_required', '访问来源未通过安全核验。', 403)
            if (len(self.headers.get_all('Origin', [])) > 1
                    or self.headers.get('Origin') not in (None, 'https://play.vortexsean.com')):
                raise TutorError('origin_blocked', '只接受当前课堂的同源操作。', 403)
            if (len(self.headers.get_all('Sec-Fetch-Site', [])) > 1
                    or self.headers.get('Sec-Fetch-Site') == 'cross-site'):
                raise TutorError('cross_site', '不接受跨站操作。', 403)
            if unquote(urlsplit(self.path).path) == '/api/deploy-health' and not internal:
                raise TutorError('not_found', '此接口不公开。', 404)
            return
        hosts = {f'127.0.0.1:{PORT}', f'localhost:{PORT}'}
        if self.client_address[0] not in ('127.0.0.1', '::1') or self.headers.get('Host') not in hosts:
            raise TutorError('local_only', '这是本机私有研究原型，不开放远程访问。', 403)
        origin = self.headers.get('Origin')
        if origin and origin not in {f'http://{host}' for host in hosts}:
            raise TutorError('origin_blocked', '只接受本机课堂发起的操作。', 403)
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            raise TutorError('cross_site', '不接受其他网站调用这份私有课堂。', 403)

    def _headers(self, status, mime, size=None):
        self.send_response(status)
        self.send_header('Content-Type', mime)
        if size is not None:
            self.send_header('Content-Length', str(size))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Permissions-Policy', 'camera=(), microphone=(self)')
        self.send_header('Content-Security-Policy',
                         "default-src 'self'; script-src 'self'" + (' ' + MOTION_SCRIPT_SOURCES if MOTION_SCRIPT_SOURCES else '') + "; style-src 'self' 'unsafe-inline'; "
                         "img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; "
                         "font-src 'self'; frame-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'")
        if CLOUD:
            self.send_header('Connection', 'close')
            self.close_connection = True
        if getattr(self, '_access_cookie', None):
            self.send_header('Set-Cookie', self._access_cookie)
        if getattr(self, '_device_cookie', None):
            self.send_header('Set-Cookie', self._device_cookie)
        self.end_headers()

    def _json(self, value, status=200):
        if CLOUD and status == 200 and isinstance(value, dict):
            path = unquote(urlsplit(self.path).path)
            kind = ('profile' if path == '/api/profile/create' else 'voice' if path == '/api/voice/start'
                    else 'session' if path in ('/api/session/start', '/api/session/review') else None)
            if kind and value.get('id'):
                CLOUD.bind(self._access_owner, kind, value['id'])
        data = json.dumps(value, ensure_ascii=False, allow_nan=False).encode()
        self._headers(status, 'application/json; charset=utf-8', len(data))
        self.wfile.write(data)

    def _body(self, strict=False):
        if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            raise TutorError('json_required', '只接受课堂约定的JSON数据。', 415)
        if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length', [])) != 1:
            raise TutorError('invalid_size', '请求长度不正确。', 422)
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            raise TutorError('invalid_size', '请求长度不正确。') from None
        limit = 4096 if CLOUD and unquote(urlsplit(self.path).path).startswith('/api/access/') else 512 * 1024
        if not 0 < size <= limit:
            raise TutorError('too_large', '请求内容太大，未覆盖已有草稿。', 413)
        try:
            def unique_pairs(items):
                value = {}
                for key, item in items:
                    if key in value:
                        raise ValueError('duplicate JSON key')
                    value[key] = item
                return value

            value = json.loads(self.rfile.read(size),
                               object_pairs_hook=unique_pairs if strict else None,
                               parse_constant=lambda _value: (_ for _ in ()).throw(ValueError()))
        except (ValueError, UnicodeDecodeError):
            raise TutorError('invalid_json', '数据格式不正确；原课堂状态不变。') from None
        if not isinstance(value, dict):
            raise TutorError('invalid_json', '课堂请求必须是对象。')
        return value

    def _learner(self):
        identifier = self.headers.get('X-Learner-Id', '')
        if CLOUD and identifier:
            CLOUD.require_binding(self._access_owner, 'session', identifier)
        return identifier, self.headers.get('X-Tutor-Token', '')

    def _profile(self):
        # Persistent profile capability is distinct from a classroom/session capability.
        identifier = self.headers.get('X-Profile-Id', '')
        if CLOUD:
            CLOUD.require_binding(self._access_owner, 'profile', identifier)
        return identifier, self.headers.get('X-Profile-Token', '')

    def _login_page(self):
        content = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>小美家教－小学数学 · 进入课堂</title>
<style>body{margin:0;background:#f5f5f7;color:#202124;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;min-height:100vh;display:grid;place-items:center}main{box-sizing:border-box;width:min(420px,calc(100% - 40px));padding:36px;background:white;border-radius:24px;box-shadow:0 12px 40px #00000008}h1{font-size:28px;font-weight:600;margin:0 0 16px}p{font-size:16px;line-height:1.6;color:#64666b}label{display:block;margin:24px 0 10px}input,button{box-sizing:border-box;width:100%;font:inherit;border-radius:12px;padding:14px}input{border:1px solid #ddd}button{border:0;background:#285bc5;color:white;margin-top:16px;cursor:pointer}#message{min-height:26px;font-size:14px}</style>
<main><h1>小美家教－小学数学</h1><p>这是个人家庭课堂，请输入个人访问密码。选一间喜欢的课堂，听老师讲，也留时间自己想。</p>
<form id="access"><label for="password">课堂访问密码</label><input id="password" type="password" autocomplete="current-password" maxlength="256" required><button>进入课堂</button><p id="message" role="status" aria-live="polite"></p></form></main><script src="/xiaomei-math/api/access/login.js" defer></script></html>'''.encode()
        self._headers(200, 'text/html; charset=utf-8', len(content))
        self.wfile.write(content)

    def _cloud_gate(self, path, method):
        self._access_cookie = None
        self._device_cookie = None
        cookies = self.headers.get_all('Cookie', [])
        self._access_owner = CLOUD.authenticate(cookies[0]) if len(cookies) == 1 else None
        if path == '/api/deploy-health' and method == 'GET':
            self._json(deploy_health())
            return True
        if path == '/api/access/status' and method == 'GET':
            self._json({'loggedIn': bool(self._access_owner),
                        'accessMode': 'anonymous' if CLOUD.anonymous else 'password'})
            return True
        if path == '/api/access/start' and method == 'POST':
            if self._body(strict=True) != {}:
                raise TutorError('invalid_access', '匿名进入不接收身份或其他数据。', 422)
            token, device = CLOUD.open_anonymous(cookies[0] if len(cookies) == 1 else None)
            self._access_owner = CLOUD.digest(device)
            self._access_cookie = CLOUD.cookie(token)
            self._device_cookie = CLOUD.device_cookie(device)
            self._json({'loggedIn': True, 'accessMode': 'anonymous'})
            return True
        if CLOUD.anonymous and method == 'GET' and path in ('/', '/index.html', '/studio.html', '/login'):
            if not self._access_owner:
                token, device = CLOUD.open_anonymous(cookies[0] if len(cookies) == 1 else None)
                self._access_owner = CLOUD.digest(device)
                self._access_cookie = CLOUD.cookie(token)
                self._device_cookie = CLOUD.device_cookie(device)
            if path == '/login':
                self.send_response(303)
                self.send_header('Location', '/xiaomei-math/')
                self.send_header('Content-Length', '0')
                self.send_header('Cache-Control', 'no-store')
                if self._access_cookie:
                    self.send_header('Set-Cookie', self._access_cookie)
                    self.send_header('Set-Cookie', self._device_cookie)
                self.end_headers()
                return True
        if path == '/login' and method == 'GET':
            self._login_page()
            return True
        if path == '/api/access/login.js' and method == 'GET':
            content = "document.getElementById('access').addEventListener('submit',async e=>{e.preventDefault();const p=document.getElementById('password'),m=document.getElementById('message'),b=e.target.querySelector('button');b.disabled=true;m.textContent='';try{const r=await fetch('/xiaomei-math/api/access/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:p.value})});p.value='';const v=await r.json();if(r.ok){const q=new URLSearchParams(location.search),n=new URLSearchParams();for(const k of ['live','view','audit']){const v=q.get(k);if(v===null)continue;if(k==='view'&&!['01','05','06'].includes(v))continue;if(k!=='view'&&!['1',''].includes(v))continue;n.set(k,v)}location.replace('/xiaomei-math/studio.html'+(n.size?'?'+n:''))}else{m.textContent=v.message||'暂时无法进入课堂'}}catch{p.value='';m.textContent='连接暂时中断，请稍后再试'}finally{b.disabled=false}});".encode()
            self._headers(200, 'text/javascript; charset=utf-8', len(content))
            self.wfile.write(content)
            return True
        if path == '/api/access/login' and method == 'POST':
            token, device = CLOUD.login(self._body(strict=True), cookies[0] if len(cookies) == 1 else None)
            self._access_cookie = CLOUD.cookie(token)
            self._device_cookie = CLOUD.device_cookie(device)
            self._json({'loggedIn': True})
            return True
        if not self._access_owner:
            if method == 'GET' and path in ('/', '/index.html', '/studio.html'):
                self._login_page()
                return True
            if CLOUD.anonymous:
                raise TutorError('access_required', '请重新打开课堂，匿名记录只属于当前设备。', 403)
            raise TutorError('access_required', '请先输入课堂访问密码。', 401)
        if path == '/api/access/logout' and method == 'POST':
            if self._body(strict=True) != {}:
                raise TutorError('invalid_access', '退出请求不接受其他数据。', 422)
            if VOICE is not None:
                with VOICE._lock:
                    active = copy.copy(VOICE._active)
                if active:
                    try:
                        CLOUD.require_binding(self._access_owner, 'voice', active['id'])
                    except TutorError:
                        pass
                    else:
                        try:
                            VOICE.stop({'id': active['id'], 'token': active['token']})
                        except Exception:
                            # Revoke access even if the upstream socket already failed.
                            try:
                                VOICE.close()
                            except Exception:
                                pass
            CLOUD.logout(self._access_owner, cookies[0])
            self._access_cookie = CLOUD.cookie(clear=True)
            self._json({'loggedIn': False})
            return True
        gets = {'/', '/index.html', '/studio.html', '/api/harness', '/api/harness/selection',
                '/api/curriculum', '/api/bank-coverage', '/api/graph', '/api/status', '/api/profile', '/api/session',
                '/api/session/reply', '/api/session/events', '/api/audio-worklet.js', '/api/health',
                '/media/catalog-fall-p6.jpg', '/media/catalog-spring-p6.jpg',
                '/media/catalog-spring-p7.jpg', '/notices.txt'}
        posts = {'/api/profile/create', '/api/profile/update', '/api/session/start', '/api/session/interaction',
                 '/api/session/draft', '/api/session/answer', '/api/session/next', '/api/session/action',
                 '/api/session/review', '/api/model/ask', '/api/voice/start', '/api/voice/command',
                 '/api/voice/stop', '/api/voice/stream', '/api/harness/selection', '/api/curriculum/coverage',
                 '/api/session/blackboard/motion'}
        if not ((method == 'GET' and (path in gets or path.startswith('/assets/')))
                or (method == 'POST' and path in posts)):
            raise TutorError('not_found', '此资源不在数学课堂范围内。', 404)
        if method == 'GET' and path == '/api/health':
            self._json({'ok': True, 'app': 'xiaomei-math', 'views': ['01', '05', '06'],
                        'accessMode': 'anonymous' if CLOUD.anonymous else 'password',
                        'classroomActions': 'teacher-actions-1'})
            return True
        if method == 'GET' and path == '/api/session/reply':
            identifier, token = self._learner()
            self._json(session_reply(STORE, identifier, token))
            return True
        return False

    def _error(self, error):
        status = getattr(error, 'status', getattr(error, 'http_status', 500))
        self._json({'error': getattr(error, 'code', 'server_error'),
                    'message': getattr(error, 'message', '请求未完成；已保留当前题与草稿。')}, status)

    def do_GET(self):
        self._access_cookie = None
        self._device_cookie = None
        try:
            self._allowed()
            path = unquote(urlsplit(self.path).path)
            if CLOUD and path == '/media/cover.png':
                content = public_build_bytes('build/media/cover.png')
                self._headers(200, 'image/png', len(content))
                return self.wfile.write(content)
            if CLOUD and self._cloud_gate(path, 'GET'):
                return
            if MATH_APP and (path in PUBLIC_BUILD_BYTES or path == '/media/cover.png'):
                relative = 'build/media/cover.png' if path == '/media/cover.png' else PUBLIC_BUILD_BYTES[path]
                content = public_build_bytes(relative)
                self._headers(200, MIME.get(Path(relative).suffix, mimetypes.guess_type(relative)[0] or 'application/octet-stream'), len(content))
                return self.wfile.write(content)
            if path.startswith('/api/learn'):
                if MATH_APP:
                    raise TutorError('not_found', '数学专用入口不加载旧学习服务。', 404)
                return local_learning_proxy().serve_learning(self)
            if path in SHARED_LEARNING_ASSETS:
                if MATH_APP:
                    raise TutorError('not_found', '数学专用入口不加载旧学习资源。', 404)
                target, content = shared_learning_bytes(path)
                self._headers(200, MIME[target.suffix], len(content))
                return self.wfile.write(content)
            if MATH_APP and not CLOUD and path == '/api/access/status':
                return self._json({'loggedIn': True})
            if path == '/api/health':
                contract = HARNESS.public()
                return self._json({'ok': True, 'project': 'grade5-tutor', 'version': VERSION,
                                   'diagnosis': 'personalized', 'designOptions': 10,
                                   'modelRole': 'same-question-helper-not-diagnosis-engine',
                                   'scopeNotice': '有限字段证据与个性化复核，不证明全年掌握或诊断准确率。',
                                   'harness': {'state': contract['state'], 'configState': contract['configState']},
                                   'frontend': contract['frontend'],
                                   **({'process': process_identity()} if APP_MODE == 'local' else {})})
            if path == '/api/harness':
                return self._json(public_harness() if MATH_APP else HARNESS.public())
            if path == '/api/harness/selection':
                return self._json({'view': '01', 'persisted': False, 'scope': 'browser'} if MATH_APP else HARNESS.selection())
            if path == '/api/curriculum':
                return self._json(HARNESS.curriculum(STORE))
            if path == '/api/design-example':
                try:
                    query = parse_qs(urlsplit(self.path).query, keep_blank_values=True, max_num_fields=4)
                except ValueError:
                    raise TutorError('invalid_design_example', '预览查询字段过多或格式无效。') from None
                return self._json(HARNESS.design_example(query))
            if path == '/api/profile':
                return self._json(STORE.profile_view(*self._profile()))
            if (MATH_APP and path in ('/', '/index.html')) or path == '/studio.html' or path.startswith('/assets/'):
                if MATH_APP and path in ('/', '/index.html'):
                    path = '/studio.html'
                target, content = HARNESS.static_bytes(path)
                mime = MIME.get(target.suffix, mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
                self._headers(200, mime, len(content))
                return self.wfile.write(content)
            if path == '/api/bank-coverage':
                return self._json(STORE._bank_coverage())
            if path == '/api/plan':
                return self._json(json.loads((ROOT / 'plan.json').read_text()))
            if path == '/api/research':
                return self._json(json.loads((ROOT / 'research.json').read_text()))
            if path == '/api/delivery':
                target = ROOT / '验收/交付状态.json'
                return self._json(json.loads(target.read_text()) if target.is_file() else {'state': 'in_progress'})
            if path == '/api/graph':
                return self._json(STORE.graph.public())
            if path == '/api/status':
                try:
                    voice = voice_service().status()
                except Exception as error:
                    voice = {'available': False, 'configured': False,
                             'message': getattr(error, 'message', '语音适配尚不可用；不会替换为系统语音。')}
                if CLOUD:
                    status = MODEL.status()
                    return self._json({'model': {'kie': status['kie'], 'busy': status['busy']},
                                       'voice': {'configured': bool(voice.get('configured')),
                                                 'available': bool(voice.get('available')),
                                                 'quotaPolicy': voice.get('quotaPolicy', 'legacy'),
                                                 'maxSessionSeconds': voice.get('maxSessionSeconds'),
                                                 'dailyLimitSeconds': voice.get('dailyLimitSeconds')},
                                       'budget': {'policy': 'unlimited' if CLOUD.unlimited_budget else 'daily-device-v1' if CLOUD.daily_budget else 'lifetime-v1',
                                                  'modelCallLimit': None if CLOUD.unlimited_budget else CLOUD.config['budget']['maxModelCalls']},
                                       'localOnly': False, 'childTesting': False})
                return self._json({'model': MODEL.status(), 'voice': voice,
                                   'localOnly': True, 'childTesting': False})
            if path == '/api/session/reply':
                return self._json(session_reply(STORE, *self._learner()))
            if path == '/api/session':
                return self._json(HARNESS.session_view(STORE, *self._learner()))
            if path == '/api/session/events':
                return self._json({'events': STORE.events(*self._learner())})
            if path == '/api/audio-worklet.js':
                source = ROOT.parent / '产品原型/classroom_audio_worklet.js'
                content = source.read_bytes()
                self._headers(200, 'text/javascript; charset=utf-8', len(content))
                return self.wfile.write(content)
            if path.startswith('/验收/'):
                name = path.removeprefix('/验收/')
                if name != '交付状态.json' and not re.fullmatch(r'[A-Za-z0-9_\-\u4e00-\u9fff]+\.(png|jpg|jpeg|mp4|wav)', name):
                    raise TutorError('not_found', '这份验收文件不存在。', 404)
                target = ROOT / '验收' / name
            elif path in ASSETS:
                target = ROOT / ASSETS[path]
            else:
                raise TutorError('not_found', '这个页面不在原型交付范围内。', 404)
            if not target.is_file() or target.is_symlink():
                raise TutorError('not_found', '页面尚未生成，请稍后回到方案入口。', 404)
            content = HARNESS.read_bytes(target.relative_to(ROOT).as_posix(), limit=64 * 1024 * 1024)
            mime = MIME.get(target.suffix, mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
            requested_range = self.headers.get('Range') if target.suffix in ('.mp4', '.wav') else None
            if requested_range:
                match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested_range)
                if not match or not any(match.groups()):
                    raise TutorError('invalid_range', '音视频请求范围不正确。', 416)
                start = int(match[1]) if match[1] else max(0, len(content) - int(match[2]))
                end = min(len(content) - 1, int(match[2])) if match[1] and match[2] else len(content) - 1
                if start > end or start >= len(content):
                    raise TutorError('invalid_range', '音视频请求超出文件长度。', 416)
                self.send_response(206)
                self.send_header('Content-Type', mime)
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Content-Range', f'bytes {start}-{end}/{len(content)}')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                return self.wfile.write(content[start:end + 1])
            self._headers(200, mime, len(content))
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:
            try:
                self._error(error)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def do_POST(self):
        self._access_cookie = None
        try:
            self._allowed()
            path = unquote(urlsplit(self.path).path)
            if CLOUD and self._cloud_gate(path, 'POST'):
                return
            if path.startswith('/api/learn'):
                if MATH_APP:
                    raise TutorError('not_found', '数学专用入口不加载旧学习服务。', 404)
                return local_learning_proxy().serve_learning(self)
            if path == '/api/harness/selection':
                if MATH_APP:
                    raise TutorError('selection_read_only', '呈现选择保存在当前浏览器，不修改服务器全局选型。', 403)
                host = self.headers.get('Host')
                server_origin = f'http://{host}'
                HARNESS.authorize_selection(host, self.headers.get('Origin'), self.client_address[0],
                                            self.headers.get('Sec-Fetch-Site'), server_origin)
                return self._json(HARNESS.persist_selection(
                    self._body(strict=True), host=host, origin=self.headers.get('Origin'),
                    client_address=self.client_address[0], fetch_site=self.headers.get('Sec-Fetch-Site'),
                    server_origin=server_origin))
            payload = self._body(strict=CLOUD is not None or path in ('/api/curriculum/coverage', '/api/profile/create', '/api/profile/update',
                                               '/api/session/start', '/api/session/interaction', '/api/model/ask', '/api/session/action',
                                               '/api/session/blackboard/motion'))
            if path == '/api/curriculum/coverage':
                return self._json(HARNESS.curriculum_coverage(STORE, payload))
            if path == '/api/profile/create':
                if CLOUD:
                    with CLOUD.lock:
                        CLOUD.check_capacity(self._access_owner, 'profile')
                        return self._json(STORE.create_profile(payload))
                return self._json(STORE.create_profile(payload))
            if path == '/api/profile/update':
                return self._json(STORE.update_profile(*self._profile(), payload))
            identifier, token = self._learner()
            if CLOUD and path in ('/api/voice/command', '/api/voice/stop', '/api/voice/stream'):
                CLOUD.require_binding(self._access_owner, 'voice', payload.get('id', ''))
            if path == '/api/session/start':
                if CLOUD:
                    if payload.get('answerFlow') not in (None, 'automatic'):
                        raise TutorError('invalid_answer_flow', '公网课堂仅使用自动进题。', 422)
                    payload['answerFlow'] = 'automatic'
                    presentation = HARNESS.validate_presentation(payload.get('presentation'))
                    if (presentation.get('policyVersion') != 'automatic-1'
                            or presentation['view'] not in ('01', '05', '06')):
                        raise TutorError('invalid_presentation', '请选择01、05、06自动课堂。', 422)
                    learner = payload.get('learner', {})
                    if not isinstance(learner, dict):
                        raise TutorError('invalid_profile', '学习档案格式不正确。', 422)
                    CLOUD.require_binding(self._access_owner, 'profile', learner.get('id', ''))
                if CLOUD:
                    with CLOUD.lock:
                        return self._json(HARNESS.start_session(STORE, payload,
                            owner=self._access_owner,
                            check_capacity=lambda: CLOUD.check_capacity(self._access_owner, 'session')))
                return self._json(HARNESS.start_session(STORE, payload))
            if path == '/api/session/interaction':
                return self._json(HARNESS.interaction(STORE, identifier, token, payload))
            if path == '/api/session/draft':
                return self._json(HARNESS.session_view(STORE, identifier, token,
                                  lambda: STORE.draft(identifier, token, payload)))
            if path == '/api/session/answer':
                return self._json(HARNESS.session_view(STORE, identifier, token,
                                  lambda: STORE.answer(identifier, token, payload)))
            if path == '/api/session/next':
                return self._json(HARNESS.session_view(STORE, identifier, token,
                                  lambda: STORE.next(identifier, token)))
            if path == '/api/session/action':
                return self._json(HARNESS.session_view(STORE, identifier, token,
                                  lambda: STORE.action(identifier, token, payload)))
            if path == '/api/session/review' and CLOUD:
                with CLOUD.lock:
                    CLOUD.check_capacity(self._access_owner, 'session')
                    return self._json(HARNESS.session_view(STORE, identifier, token,
                                      lambda: STORE.review(identifier, token)))
            if path == '/api/session/review':
                return self._json(HARNESS.session_view(STORE, identifier, token,
                                  lambda: STORE.review(identifier, token)))
            if path == '/api/session/blackboard/motion':
                if STORE.teacher_motion is None or not STORE.teacher_motion.status().get('available'):
                    raise TutorError('teacher_motion_unavailable', '此运行环境没有本机动画工具；未切换付费通路。', 503)
                return self._json(STORE.teacher_motion_playback(identifier, token, payload))
            if path == '/api/model/ask':
                response = (MODEL.ask(identifier, token, payload, budget_owner=self._access_owner)
                            if CLOUD else MODEL.ask(identifier, token, payload))
                self._json(response)
                self.wfile.flush()  # Send accepted typed board before any animation work.
                if MOTION_WORKER and payload.get('classroomActions') is True:
                    try:
                        MOTION_WORKER.schedule(identifier, token, payload.get('requestId'))
                    except Exception:
                        pass  # Accepted teacher reply is a fact; worker failure is not a model failure.
                return
            if path == '/api/voice/start':
                return self._json(voice_service().start(payload, identifier, token))
            if path == '/api/voice/command':
                return self._json(voice_service().command(payload))
            if path == '/api/voice/stop':
                return self._json(voice_service().stop(payload))
            if path == '/api/voice/stream':
                stream = voice_service().stream(payload)
                self._headers(200, 'text/event-stream; charset=utf-8')
                self.close_connection = True
                try:
                    for event in stream:
                        if CLOUD and not CLOUD.authenticate(self.headers.get('Cookie', '')):
                            break
                        packet = ('data: ' + json.dumps(event, ensure_ascii=False) + '\n\n').encode()
                        self.wfile.write(packet)
                        self.wfile.flush()
                finally:
                    stream.close()
                return
            raise TutorError('not_found', '这个操作不在原型范围内。', 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:
            try:
                self._error(error)
            except (BrokenPipeError, ConnectionResetError):
                pass


class BoundedHTTPServer(ThreadingHTTPServer):
    """Bound workers and socket reads; slow requests cannot spawn unlimited threads."""
    daemon_threads = True
    request_queue_size = 16

    def __init__(self, *args, **kwargs):
        self._slots = threading.BoundedSemaphore(32)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()


def loaded_process_code_hashes():
    """Fingerprint actual imported Python code objects, not a reread of source files."""
    hashes = {}
    for module_name in (__name__, 'harness', 'engine', 'providers'):
        module = sys.modules[module_name]
        codes = []
        for name, value in sorted(vars(module).items()):
            if isinstance(value, types.FunctionType) and value.__module__ == module_name:
                codes.append((name, value.__code__))
            elif isinstance(value, type) and value.__module__ == module_name:
                for method, member in sorted(vars(value).items()):
                    if isinstance(member, (staticmethod, classmethod)):
                        member = member.__func__
                    if isinstance(member, types.FunctionType):
                        codes.append((name + '.' + method, member.__code__))
        hashes['server' if module_name == __name__ else module_name] = hashlib.sha256(
            b''.join(name.encode() + marshal.dumps(code) for name, code in codes)).hexdigest()
    return hashes


PROCESS_LOADED_AT = datetime.now(timezone.utc).isoformat()
PROCESS_SOURCE_SHA256 = current_process_sources()
PROCESS_CODE_SHA256 = loaded_process_code_hashes()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='小美数学私有课堂服务器')
    parser.add_argument('--host', default='127.0.0.1', choices=['127.0.0.1'])
    parser.add_argument('--port', type=int, default=19950)
    parser.add_argument('--app-mode', choices=['local', 'math', 'public-math'], default='local')
    parser.add_argument('--frontend-root', help='Local only: strict project-relative frontend build directory')
    parser.add_argument('--runtime-root')
    parser.add_argument('--private-config')
    args = parser.parse_args()
    PORT = args.port
    if args.app_mode == 'public-math' and PORT != 19952:
        parser.error('public-math requires port 19952')
    if args.frontend_root is not None and args.app_mode not in ('local', 'math'):
        parser.error('--frontend-root requires --app-mode local/math on loopback')
    os.umask(0o077)
    initialize_runtime(args.app_mode, args.runtime_root, args.private_config, frontend_root=args.frontend_root)
    server = BoundedHTTPServer((args.host, PORT), Handler)
    server.daemon_threads = True
    print(f'小问 · 五年级AI家教，本机入口 http://127.0.0.1:{PORT}，不公开上传。', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if VOICE:
            VOICE.close()
        if MOTION_WORKER:
            MOTION_WORKER.close()
        server.server_close()
        STORE.close()
        if CLOUD:
            CLOUD.close()
