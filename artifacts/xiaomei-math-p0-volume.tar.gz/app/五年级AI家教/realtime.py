"""Current-question-only adapter; no credential configuration or transcript storage."""
from __future__ import annotations

import copy
from collections import OrderedDict
from contextlib import contextmanager
from datetime import datetime
import hashlib
import hmac
import importlib.util
import json
import os
import re
from pathlib import Path
import stat
import sys
import threading
import time
from types import SimpleNamespace
import uuid

from engine import TutorError

ROOT = Path(__file__).resolve().parent
PROTOTYPE = ROOT.parent / '产品原型'
# Shared service also has lazy sibling imports (teaching_bundle, etc.).
if str(PROTOTYPE) not in sys.path:
    sys.path.append(str(PROTOTYPE))
_SPEC = importlib.util.spec_from_file_location('grade5_shared_realtime', PROTOTYPE / 'doubao_realtime.py')
_SHARED = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_SHARED)
RealtimeService, VoiceError = _SHARED.RealtimeService, _SHARED.VoiceError

NOTICE = ('仅当前题语音辅导；仅实际辅导记受助，保留初答。配置或connecting不是连接成功，'
          '以真实classroom.ready事件为准。无视觉输入，不能声称看懂笔迹或画面；'
          '换题须显式重新绑定，撤权即停止。宿主可不设时间配额，仍记实际使用；上游可能断线，不保证永远不停。')
_DIAGRAM_KEYS = frozenset(('kind', 'a', 'b', 'sameWhole', 'sizes', 'total', 'groups',
                           'headers', 'rows', 'value', 'columns', 'cellUnit', 'count',
                           'offset', 'values'))


def _voice_policy(value):
    if value is not None and value != 'unlimited':
        raise VoiceError('invalid_limits', 'voice_policy只接受可信宿主的unlimited或默认预算。', 503)
    return value


def _unsupported():
    raise VoiceError('unsupported', '题级短对话不提供独立练习服务。', 409)


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     allow_nan=False).encode()).hexdigest()


def _text(value, limit=2400):
    if not isinstance(value, str) or len(value) > limit:
        raise VoiceError('invalid_context', '当前题文字格式或容量异常；未发送。', 409)
    return value


def _data(value, depth=0):
    """Only small scalar/list facts, never arbitrary nested private objects."""
    if depth > 4:
        raise VoiceError('invalid_context', '题面数据嵌套过深；未发送。', 409)
    if isinstance(value, str):
        return _text(value)
    if value is None or type(value) in (bool, int, float):
        return value
    if isinstance(value, list) and len(value) <= 64:
        return [_data(item, depth + 1) for item in value]
    raise VoiceError('invalid_context', '题面数据格式异常；未发送。', 409)


def _private_directory(runtime_root=None):
    # Check before chmod: never follow symlinks into another project's files.
    root = Path(runtime_root) if runtime_root is not None else ROOT / '.runtime'
    if runtime_root is not None:
        from cloud_runtime import no_links
        no_links(root)
    for path in (root, root / 'voice'):
        try:
            path.mkdir(mode=0o700)
        except FileExistsError:
            pass
        descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            info = os.fstat(descriptor)
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
                raise OSError('unsafe voice directory')
            os.fchmod(descriptor, 0o700)
        finally:
            os.close(descriptor)
    return root / 'voice'


class TutorRealtime:
    def __init__(self, store, *, runtime_root=None, credential_path=None,
                 voice_policy=None, _usage_dir=None, _service_factory=None):
        self.store = store
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)
        self._bindings = {}  # learner capability is memory-only, never returned or logged.
        self._active = None
        self._closed = False
        self._disposed = False
        self._stopped = OrderedDict()  # Bounded capability hashes, no learner/transcript persistence.
        self._failed_stop = None
        self._policy = _voice_policy(voice_policy)
        self._factory = _service_factory or RealtimeService
        try:
            self._usage_dir = _usage_dir if _usage_dir is not None else _private_directory(runtime_root)
            self._options = {'credential_path': credential_path} if credential_path is not None else {}
            self.service = self._new_service()
        except VoiceError:
            raise
        except Exception:
            raise VoiceError('factory_fail_closed', '语音服务无法安全初始化；未连接。', 503) from None

    def _new_service(self):
        service = self._factory(usage_dir=self._usage_dir, context_resolver=self.resolve,
                                practice_factory=_unsupported, response_resolver=self.resolve_response,
                                interactive_feedback_only=True, host_managed_dialogue=True,
                                quota_policy=self._policy, **self._options)
        return service

    def recover_closed(self):
        """Explicit recovery only; never clear reservations or reopen a live transport."""
        with self._lock:
            if self._disposed or not self._closed or self._active is not None or self._bindings:
                raise VoiceError('service_closed', '服务尚不可安全恢复。', 503)
            service = self.service
            if isinstance(service, _SHARED.RealtimeService):
                with service._guard:
                    session = service._session
                    if not service._closed or (session is not None and (
                            not session.finished or session.ws is not None
                            or session.connecting_ws is not None or session.lease is not None)):
                        raise VoiceError('recovery_pending', '旧连接停止尚未确认。', 503)
                    try:
                        with _SHARED._directory(self._usage_dir) as fd:
                            lease = _SHARED._lock_at(fd, 'doubao-active.lock', True)
                            os.close(lease)
                    except Exception:
                        raise VoiceError('recovery_pending', '旧连接私有锁未释放。', 503) from None
            else:
                # Injected offline adapters must explicitly attest transport + lock release.
                verify = getattr(service, 'recover_closed', None)
                if not callable(verify) or verify() is not True:
                    raise VoiceError('recovery_pending', '旧连接停止尚未确认。', 503)
            replacement = self._new_service()
            if isinstance(service, _SHARED.RealtimeService):
                replacement._last_failure = copy.deepcopy(service._last_failure)
                replacement._permission_verified = service._permission_verified
            self.service = replacement
            self._closed = False
            if self._failed_stop is not None:
                self._remember_stop(self._failed_stop, {'status': 'closed'})
                self._failed_stop = None
            return {'status': 'recovered', 'connected': False}

    def _remember_stop(self, active, result):
        key = active['id']
        self._stopped[key] = (_digest(active['token']), copy.deepcopy(result))
        self._stopped.move_to_end(key)
        while len(self._stopped) > 64:
            self._stopped.popitem(last=False)

    def _store(self, method, *args, **kwargs):
        try:
            return getattr(self.store, method)(*args, **kwargs)
        except TutorError as error:
            raise VoiceError(error.code, error.message, error.status) from None
        except Exception:
            raise VoiceError('tutor_unavailable', '课堂状态无法安全核验；未继续语音。', 503) from None

    def status(self):
        return {**self.service.status(), 'notice': NOTICE,
                'lastConnection': getattr(self, 'last_connection', None),
                'visionAvailable': False, 'textModelBridge': True,
                'bridgeNotice': '语音负责转写与音频；DeepSeek复杂回复仅经同题回执接口播放，不冒称同一个原生模型。'}

    def _current(self, paper, token):
        view = self._store('view', paper, token)
        if view.get('voiceConsent') is not True or view.get('onlineConsent') is not True:
            raise VoiceError('consent_required', '语音与在线授权均须开启；未继续发送。', 403)
        if view.get('closed') or view.get('paused'):
            raise VoiceError('session_closed', '课堂已结束或暂停；请停止语音后显式重新开始。', 409)
        context = self._store('context', paper, token, require_consent=True)
        question = context.get('question')
        current = view.get('current')
        if (not isinstance(question, dict) or not isinstance(current, dict)
                or question.get('instanceId') != current.get('instanceId')):
            raise VoiceError('context_changed', '当前题已变化，请显式重新绑定语音。', 409)
        return view, context, question

    def start(self, payload, learner_id, learner_token):
        if (not isinstance(payload, dict) or set(payload) - {'instanceId', 'revision', 'outputOnly'}
                or ('outputOnly' in payload and type(payload['outputOnly']) is not bool)):
            raise VoiceError('invalid_request', '仅接受当前题标识；不接受视觉、题面或预算覆盖。', 422)
        try:
            if str(uuid.UUID(learner_id)) != learner_id:
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise VoiceError('invalid_request', '课堂标识须为规范UUID。', 422) from None
        with self._lock:
            if self._closed:
                self.recover_closed()  # This explicit start is not an automatic retry.
            if self._active is not None:
                raise VoiceError('session_active', '先停止原语音，再显式绑定当前题。', 409)
        view, context, q = self._current(learner_id, learner_token)
        if (payload.get('instanceId', q['instanceId']) != q['instanceId']
                or payload.get('revision', context['revision']) != context['revision']):
            raise VoiceError('stale_question', '请求属于旧题或旧页面；未启动语音。', 409)
        output_only = payload.get('outputOnly', False)
        # Opening a listener/output channel is not teaching evidence.
        # Assistance is recorded on a usable ASR completion or validated reply/audio.
        with self._lock:
            if self._closed or self._active is not None or self._bindings:
                raise VoiceError('session_active', '语音正在启动或已关闭；未重复连接。', 409)
            self._bindings[learner_id] = {'token': learner_token, 'instanceId': q['instanceId'],
                                         'number': q['ordinal'], 'topic': q['family'], 'fingerprint': None,
                                         'outputOnly': output_only, 'helpRecorded': False,
                                         'feedbackResponse': None}
        binding = {'paper': learner_id, 'number': q['ordinal'], 'topic': q['family'],
                   'stepIndex': 0, 'dialogueOnly': True, 'teacherProfile': 'warm'}
        try:
            self.resolve(binding)  # Recheck current question before shared start.
            descriptor = self.service.start(binding)
            with self._lock:
                closed = self._closed
                if not closed:
                    self._active = {'id': descriptor['id'], 'token': descriptor['token'], 'paper': learner_id,
                                    'binding': binding, 'ready': False, 'generation': 0}
            if closed:
                self.service.close()
                raise VoiceError('service_closed', '启动期间服务已关闭；未继续语音。', 503)
            return descriptor  # Preserve connecting; never invent ready/connected.
        except BaseException:
            with self._lock:
                self._bindings.pop(learner_id, None)
            raise

    def resolve(self, binding_payload):
        try:
            return self._resolve(binding_payload)
        except VoiceError:
            raise
        except Exception:
            raise VoiceError('invalid_context', '题级上下文结构异常；未继续发送。', 409) from None

    def _resolve(self, binding_payload):
        if not isinstance(binding_payload, dict):
            raise VoiceError('invalid_context', '题级绑定格式不正确。', 409)
        paper = binding_payload.get('paper')
        with self._lock:
            bound = copy.copy(self._bindings.get(paper)) if isinstance(paper, str) else None
        if not bound:
            raise VoiceError('unauthorized', '题目尚未绑定语音；请显式开始。', 403)
        if (type(binding_payload.get('number')) is not int
                or binding_payload['number'] != bound['number']
                or binding_payload.get('topic') != bound['topic']
                or binding_payload.get('vision', False) is not False):
            raise VoiceError('context_changed', '题号、题族或语音模式不匹配，请重新绑定。', 409)
        _, context, q = self._current(paper, bound['token'])
        if (q.get('instanceId') != bound['instanceId'] or type(q.get('ordinal')) is not int
                or not 1 <= q['ordinal'] <= 1000 or q['ordinal'] != bound['number']
                or q.get('family') != bound['topic'] or not q.get('skills')):
            raise VoiceError('context_changed', '题目已更换，旧语音须停止；请显式重新绑定。', 409)
        fields = []
        for field in q.get('fields', []):
            row = {key: _data(field[key]) for key in ('id', 'label', 'kind', 'suffix') if key in field}
            if 'options' in field:
                row['options'] = [{key: _data(option[key]) for key in ('value', 'label') if key in option}
                                  for option in field['options']]
            fields.append(row)
        diagram = {key: _data(value) for key, value in q.get('diagram', {}).items() if key in _DIAGRAM_KEYS}
        # JSON inside allowlisted text preserves the exact diagram/field facts through _public_facts.
        conditions = [{'title': '作答字段', 'text': json.dumps(fields, ensure_ascii=False, allow_nan=False)},
                      {'title': '后端登记题图参数（不是视觉识别）',
                       'text': json.dumps(diagram, ensure_ascii=False, allow_nan=False)}]
        nodes = context.get('graph', {}).get('nodes', {})
        node = nodes.get(q['skills'][0], {})
        definition = _text(node.get('description', '当前概念定义尚未登记。'))
        concept = {'title': _text(node.get('title', q.get('title', q['family']))),
                   'definition': definition, 'teachingKnowledge': definition,
                   'description': definition, 'explanation': definition}
        stable = {'schemaVersion': context['version'], 'graphVersion': context['graphVersion'],
                  'contentVersion': _digest({'prompt': q['prompt'], 'fields': fields, 'diagram': diagram,
                                             'skills': q['skills'], 'concept': concept}),
                  'instanceId': q['instanceId']}
        # Deliberately no session revision: drafts and help must not invalidate the same question.
        with self._lock:
            live = self._bindings.get(paper)
            if live is None or live['instanceId'] != bound['instanceId']:
                raise VoiceError('context_changed', '语音绑定已结束。', 409)
            if live['fingerprint'] is None:
                live['fingerprint'] = stable
            elif live['fingerprint'] != stable:
                raise VoiceError('context_changed', '题目内容或版本变化，请显式重新绑定。', 409)
        ids = {field['id'] for field in fields}
        answers = {key: _data(value) for key, value in q.get('answers', {}).items() if key in ids}
        attempt_source = context.get('currentAttempt', {})
        submitted = (attempt_source.get('instanceId') == q['instanceId']
                     and attempt_source.get('submitted') is True)
        evidence = []
        for row in context.get('studentEvidence', []):
            if row.get('fieldId') in ids:
                evidence.append({key: _data(row[key]) for key in
                                 ('fieldId', 'label', 'source', 'received', 'correct', 'assisted', 'skillIds')
                                 if key in row})
        if submitted:
            answers = {row['fieldId']: row.get('received') for row in evidence if row.get('source') == 'scored'}
        attempt = {'instanceId': q['instanceId'], 'submitted': submitted,
                   'helped': attempt_source.get('helped') is True,
                   'workText': _text(attempt_source.get('workText', q.get('workText', ''))),
                   'notice': 'helped是当前辅导状态；初答以已评分studentEvidence.assisted为准。'}
        work = {'answers': answers, 'workText': attempt['workText'],
                'confirmed': False, 'trust': 'UNTRUSTED',
                'notice': '学生自填过程未经核验；未识别笔迹，不推断掌握，不泄露答案或完整等价解法。'}
        reader = [{'title': '学生过程（未经核验）', 'text': json.dumps(work, ensure_ascii=False, allow_nan=False)},
                  {'title': '当前提交与字段评分（不含标准答案）',
                   'text': json.dumps({'currentAttempt': attempt, 'studentEvidence': evidence},
                                      ensure_ascii=False, allow_nan=False)}]
        result = {'paper': paper, 'number': q['ordinal'], 'unitId': None, 'topic': q['family'],
                  'mainConceptId': _text(q['skills'][0], 240),
                  'question': {'questionText': _text(q['prompt']), 'conditions': conditions,
                               'studentWork': work, 'readerGuide': reader},
                  'concept': concept, 'authorLesson': None, 'scope': 'question_only', '_binding': stable,
                  'currentAttempt': attempt, 'studentEvidence': evidence}
        _digest(result)  # Reject nonfinite/non-JSON data before it reaches shared service.
        return result

    def _auth(self, payload):
        with self._lock:
            active = copy.copy(self._active)
        if (not active or not isinstance(payload, dict) or payload.get('id') != active['id']
                or not isinstance(payload.get('token'), str)
                or not hmac.compare_digest(payload['token'].encode(), active['token'].encode())):
            raise VoiceError('unauthorized', '语音会话能力令牌无效。', 403)
        return active

    def _recheck(self, active):
        with self._lock:
            if not self._active or self._active['id'] != active['id']:
                raise VoiceError('session_closed', '旧语音已结束，不向新绑定转发事件。', 409)
            binding = copy.deepcopy(self._active['binding'])
        try:
            return self.resolve(binding)
        except Exception:
            self._stop_active(active)
            raise

    def _stop_active(self, active):
        with self._lock:
            if not self._active or self._active['id'] != active['id']:
                return {'status': 'closed'}
        try:
            result = self.service.stop({'id': active['id'], 'token': active['token']})
            if not isinstance(result, dict) or result.get('status') != 'closed':
                raise ValueError('stop unconfirmed')
            with self._lock:
                self._remember_stop(active, result)
            return result
        except Exception:
            # A failed stop must not leave a transport running with forgotten credentials.
            with self._lock:
                self._closed = True
                self._failed_stop = {'id': active['id'], 'token': active['token']}
            try:
                self.service.close()
            except Exception:
                pass  # Recovery still requires positive transport/lock confirmation.
            raise VoiceError('stop_failed', '语音停止未完成，服务已失败关闭；不自动重启。', 503) from None
        finally:
            with self._lock:
                if self._active and self._active['id'] == active['id']:
                    self._active = None
                    self._bindings.pop(active['paper'], None)

    def _record_help(self, paper, bound):
        if bound['helpRecorded']:
            return
        _, context, q = self._current(paper, bound['token'])
        if q['instanceId'] != bound['instanceId']:
            raise VoiceError('context_changed', '旧题不能登记到当前辅导。', 409)
        self._store('action', paper, bound['token'],
                    {'action': 'ai_help', 'instanceId': q['instanceId'], 'revision': context['revision']})
        self.resolve({'paper': paper, 'number': bound['number'], 'topic': bound['topic']})
        with self._lock:
            live = self._bindings.get(paper)
            if live and live['instanceId'] == bound['instanceId']:
                live['helpRecorded'] = True

    def _feedback(self, paper, bound):
        view, context, q = self._current(paper, bound['token'])
        attempt = context.get('currentAttempt', {})
        feedback = view.get('feedback')
        if (q['instanceId'] != bound['instanceId'] or attempt.get('instanceId') != q['instanceId']
                or attempt.get('submitted') is not True or not isinstance(feedback, dict)
                or feedback.get('correct') is not False):
            raise VoiceError('feedback_unavailable', '只播放当前题已提交的错误短反馈。', 409)
        fields = {field['id']: field for field in q['fields']}
        graded = {row['fieldId']: row for row in context.get('studentEvidence', [])
                  if isinstance(row, dict) and row.get('source') == 'scored' and row.get('fieldId') in fields}
        wrong = [row for row in feedback.get('fieldResults', []) if isinstance(row, dict)
                 and row.get('correct') is False and row.get('id') in fields
                 and graded.get(row['id'], {}).get('correct') is False
                 and row.get('received') == graded[row['id']].get('received')]
        coaching = view.get('coaching') or {}
        same_question_teach = (context.get('phase') == 'teach' and q.get('sameQuestion') is True
                               and q.get('initialAnswerLocked') is True
                               and coaching.get('instanceId') == q['instanceId']
                               and coaching.get('correctness') is False)
        if not wrong or ('phase' in q and q['phase'] != context.get('phase') and not same_question_teach):
            raise VoiceError('feedback_unavailable', '没有当前题已评分的错误字段。', 409)
        # Teacher-owned field label only; never received/expected/reason/client prose.
        label = fields[wrong[0]['id']].get('label', '')
        safe_label = (isinstance(label, str) and 0 < len(label) <= 24
                      and not any(char in label for char in '\n\r<>'))
        text = (f'“{label}”这一处还没对上。先说说你是怎样想的。' if safe_label else
                '这里有一处还没对上。先说说你是怎样想的。')
        anchor = {'instanceId': q['instanceId'], 'phase': context.get('phase'),
                  'feedback': _digest(feedback)}
        return anchor, {'answer': text, 'steps': [], 'connections': [], 'nextQuestion': '', 'narration': text}

    def speak_feedback(self, payload):
        """POST /api/voice/feedback: id, token, instanceId, optional revision."""
        if not isinstance(payload, dict) or 'action' in payload:
            raise VoiceError('invalid_request', '短反馈请求格式不正确。', 422)
        return self.command({**payload, 'action': 'speak_feedback'})

    def resolve_response(self, response_id, context):
        paper = context.get('paper')
        with self._lock:
            bound = copy.copy(self._bindings.get(paper))
        if not bound:
            raise VoiceError('unauthorized', '当前回复还未绑定语音。', 403)
        current = self.resolve({'paper': paper, 'number': bound['number'], 'topic': bound['topic']})
        if context.get('_binding', current['_binding']) != current['_binding']:
            raise VoiceError('context_changed', '回复上下文属于旧语音绑定。', 409)
        if isinstance(response_id, str) and response_id.startswith('feedback-'):
            anchor, result = self._feedback(paper, bound)
            if (response_id != 'feedback-' + bound['instanceId'] or not bound.get('feedbackResponse')
                    or bound['feedbackResponse'] != anchor):
                raise VoiceError('feedback_stale', '短反馈未登记或已不属于当前提交。', 409)
        else:
            result = self._store('response_for_speech', paper, bound['token'], response_id, bound['instanceId'])
        self._record_help(paper, bound)
        return result

    def _rebind(self, payload, active):
        if set(payload) != {'id', 'token', 'action', 'instanceId', 'revision'}:
            raise VoiceError('invalid_request', '换题仅接受当前instanceId与revision。', 422)
        with self._lock:
            self._auth(payload)
            if self._active.get('rebinding'):
                raise VoiceError('update_pending', '上一换题尚未确认。', 409)
            bound = copy.copy(self._bindings[active['paper']])
            try:
                _, context, q = self._current(active['paper'], bound['token'])
            except VoiceError:
                self._stop_active(active)
                raise
            if (payload['instanceId'] != q['instanceId'] or type(payload['revision']) is not int
                    or payload['revision'] != context['revision']):
                raise VoiceError('stale_question', '换题请求不属于服务端最新题目与版本。', 409)
            if not self._active['ready']:
                raise VoiceError('not_ready', '等待classroom.ready再换题。', 409)
            update = getattr(self.service, 'rebind', None)
            if not callable(update):
                raise VoiceError('unsupported', '共享服务没有可信换题入口。', 409)
            binding = dict(active['binding'], number=q['ordinal'], topic=q['family'])
            self._active['rebinding'] = True
        # Never hold the adapter lock while waiting for the provider ACK: receive
        # may need the resolver under its own session lock.
        def prepare():
            with self._lock:
                self._auth(payload)
                _, fresh, question = self._current(active['paper'], bound['token'])
                if question['instanceId'] != q['instanceId'] or fresh['revision'] != payload['revision']:
                    raise VoiceError('stale_question', '换题准备期间课堂已变化。', 409)
                self._bindings[active['paper']] = dict(bound, instanceId=q['instanceId'],
                    number=q['ordinal'], topic=q['family'], fingerprint=None,
                    helpRecorded=False, feedbackResponse=None)
                self.resolve(binding)
        try:
            result = update({'id': active['id'], 'token': active['token']}, binding, prepare=prepare)
            with self._lock:
                self._auth(payload)
                if (not isinstance(result, dict) or result.get('status') != 'rebound'
                        or result.get('sourceDataConfirmed') is not True
                        or result.get('instanceId') != q['instanceId']
                        or type(result.get('bindingGeneration')) is not int
                        or result['bindingGeneration'] != self._active['generation'] + 1):
                    raise VoiceError('rebind_unconfirmed', '换题未获真实上下文确认。', 503)
                self.resolve(binding)
                self._active.update(binding=binding, generation=result['bindingGeneration'], rebinding=False)
                self._condition.notify_all()
                return result
        except Exception:
            self._stop_active(active)
            raise

    def command(self, payload):
        active = self._auth(payload)
        if payload.get('action') == 'rebind':
            return self._rebind(payload, active)
        with self._lock:
            if self._active.get('rebinding'):
                raise VoiceError('update_pending', '换题确认前不发送音频或回复。', 409)
        self._recheck(active)
        allowed = {'audio': {'frames'}, 'mute': {'muted'}, 'interrupt': set(),
                   'page': {'stepIndex', 'visibleText'}, 'speak_response': {'responseId'},
                   'advance': {'speechId'}, 'speak_feedback': {'instanceId'}}
        action = payload.get('action')
        if not isinstance(action, str) or action not in allowed:
            raise VoiceError('unsupported', '仅支持语音、打断、静音与当前题过程同步；禁止视觉。', 422)
        keys = set(payload)
        if action == 'speak_feedback':
            keys.discard('revision')
        if keys != {'id', 'token', 'action'} | allowed[action]:
            raise VoiceError('invalid_request', '动作包含未允许字段。', 422)
        if action == 'page' and (type(payload['stepIndex']) is not int or payload['stepIndex'] != 0):
            raise VoiceError('context_changed', '题级短对话只有当前题，不支持切换课单。', 409)
        if action == 'speak_feedback':
            with self._lock:
                bound = copy.copy(self._bindings[active['paper']])
                ready = self._active['ready']
            _, context, _ = self._current(active['paper'], bound['token'])
            if (payload['instanceId'] != bound['instanceId']
                    or ('revision' in payload and (type(payload['revision']) is not int
                        or payload['revision'] != context['revision']))):
                raise VoiceError('stale_question', '短反馈属于旧题或旧提交。', 409)
            if not ready:
                raise VoiceError('not_ready', '须等待classroom.ready后播放短反馈。', 409)
            anchor, _ = self._feedback(active['paper'], bound)
            with self._lock:
                self._bindings[active['paper']]['feedbackResponse'] = anchor
            payload = {'id': active['id'], 'token': active['token'], 'action': 'speak_response',
                       'responseId': 'feedback-' + bound['instanceId']}
        # Shared page command re-resolves fresh student work; prose remains UNTRUSTED.
        try:
            return self.service.command(payload)
        except VoiceError as error:
            if error.code in ('context_changed', 'feedback_stale', 'feedback_unavailable'):
                self._stop_active(active)
            raise

    def stream(self, payload):
        active = self._auth(payload)
        with self._lock:
            if self._active.get('rebinding'):
                raise VoiceError('update_pending', '换题确认后再订阅。', 409)
        self._recheck(active)
        source = self.service.stream(payload)

        def events():
            try:
                for event in source:
                    with self._condition:
                        while self._active and self._active['id'] == active['id'] and self._active.get('rebinding'):
                            self._condition.wait(0.1)
                        self._recheck(active)  # Including heartbeat: never forward stale audio/replies.
                        live = self._active
                        bound_instance = self._bindings[active['paper']]['instanceId']
                        if (event.get('bindingGeneration', 0) != live['generation']
                                or event.get('instanceId', bound_instance) != bound_instance):
                            continue
                    kind = event.get('type')
                    if (kind in ('response.output_audio.started', 'response.output_audio.delta')
                            or (kind == 'conversation.item.input_audio_transcription.completed'
                                and isinstance(event.get('transcript'), str) and event['transcript'].strip())):
                        with self._lock:
                            # Rebind may have begun after the first check. Never
                            # attach an already-dequeued old event to new help.
                            live = self._active
                            if (not live or live['id'] != active['id'] or live.get('rebinding')
                                    or event.get('bindingGeneration', 0) != live['generation']):
                                continue
                            bound = copy.copy(self._bindings[active['paper']])
                            if event.get('instanceId', bound['instanceId']) != bound['instanceId']:
                                continue
                            self._record_help(active['paper'], bound)
                    if kind in ('classroom.ready', 'classroom.error', 'classroom.closed'):
                        with self._lock:
                            if self._active and self._active['id'] == active['id']:
                                self._active['ready'] = kind == 'classroom.ready'
                        self.last_connection = {'type': kind, 'connectionVerified': kind == 'classroom.ready',
                                                'model': event.get('model'), 'message': event.get('message')}
                        with self._lock:
                            bound = self._bindings.get(active['paper'])
                            token = bound['token'] if bound else None
                            instance = bound['instanceId'] if bound else None
                        self._store('model_event', active['paper'], token,
                                    {'provider': 'doubao', 'type': kind, 'instanceId': instance,
                                     'evaluated': False, 'connectionVerified': kind == 'classroom.ready'})
                    yield event
                    if kind == 'classroom.closed':
                        break
            finally:
                try:
                    source.close()
                finally:
                    self._stop_active(active)
        return events()

    def stop(self, payload):
        if not isinstance(payload, dict):
            raise VoiceError('unauthorized', '语音会话能力令牌无效。', 403)
        with self._lock:
            stopped = self._stopped.get(payload.get('id')) if isinstance(payload.get('id'), str) else None
            if stopped is not None:
                token = payload.get('token')
                if not isinstance(token, str) or not hmac.compare_digest(_digest(token), stopped[0]):
                    raise VoiceError('unauthorized', '语音会话能力令牌无效。', 403)
                if set(payload) != {'id', 'token'}:
                    raise VoiceError('invalid_request', '停止请求仅接受语音会话令牌。', 422)
                return copy.deepcopy(stopped[1])
            active = self._auth(payload)
            if set(payload) != {'id', 'token'}:
                raise VoiceError('invalid_request', '停止请求仅接受语音会话令牌。', 422)
            return self._stop_active(active)  # Stopping remains possible after consent revocation.

    def close(self):
        with self._lock:
            self._disposed = True
            self._closed = True
        try:
            self.service.close()
        finally:
            with self._lock:
                self._active = None
                self._bindings.clear()
