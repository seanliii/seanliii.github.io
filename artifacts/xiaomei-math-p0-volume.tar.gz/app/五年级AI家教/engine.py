"""Evidence-first, bounded adaptive sessions. No learned probabilities or LLM scoring."""
from __future__ import annotations

import ast
import copy
import math
from fractions import Fraction
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
from pathlib import Path

from graph import GraphIndex
from learner_profiles import DIMENSIONS, evidence_records, summarize, model_summary
from questions import FAMILIES, ROOTS_LITE, ROOTS_PRO, build_question, evaluate_question, public_question

ROOT = Path(__file__).resolve().parent
SCHEMA_VERSION = '0.1.0'
PHASE_LABELS = {
    'screen': '先自己试试', 'probe': '定位卡点 · 检查必要先备', 'teach': '一起弄明白这一步',
    'guided': '带着方法试一次', 'verify': '现在你自己来', 'transfer': '换个情境再试',
    'challenge': '多想一步', 'retention': '隔天再试一次', 'report': '今天的发现',
}
DOMAIN_NAMES = {'fraction': '分数与整体', 'decimal': '小数与位值', 'arithmetic': '整数与运算',
                'measurement': '单位与度量', 'equation': '关系与方程', 'data': '数据与平均数',
                'space': '图形与空间', 'reasoning': '综合与思维'}


class TutorError(Exception):
    def __init__(self, code, message, status=422):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def _now():
    return time.time()


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def _clean_text(value, limit):
    if not isinstance(value, str) or len(value) > limit:
        raise TutorError('invalid_text', '这段文字太长或格式不正确；原草稿仍保留。')
    return value


CLASSROOM_VERSION = 'teacher-actions-1'


def _action_error():
    raise TutorError('invalid_classroom_action', '课堂动作无效；整轮未采用，原题与学生稿保留。', 503)


def _plain(value, limit, *, empty=True):
    if (not isinstance(value, str) or len(value) > limit or (not empty and not value.strip())
            or re.search(r'<\s*[A-Za-z/!]|[\x00-\x08\x0b\x0c\x0e-\x1f]|(?:https?://|www\.|javascript:|data:|file:|://)|'
                         r'(?:\b(?:eval|exec|function|alert|fetch|import|require)\s*\(|=>|\bscript\b|'
                         r'\b(?:document|window|globalThis)\s*\.|\b(?:const|let|var)\s+\w+\s*=)', value, re.I)):
        _action_error()
    return value


def _keys(value, keys):
    if not isinstance(value, dict) or set(value) != set(keys):
        _action_error()


def _finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def _equation(expression):
    """Bounded arithmetic AST only; symbolic expressions are never executed."""
    _plain(expression, 100, empty=False)
    normalized = (expression.replace('＝', '=').replace('×', '*').replace('÷', '/')
                  .replace('−', '-').replace('＜', '<').replace('＞', '>').replace('≤', '<=').replace('≥', '>='))
    if not re.fullmatch(r'[\w\s.+*/()=<>\-]+', normalized, re.UNICODE):
        _action_error()
    pieces = re.split(r'(?:<=|>=|=|<|>)', normalized)
    symbols = re.findall(r'<=|>=|=|<|>', normalized)
    if len(pieces) > 5 or any(not p.strip() for p in pieces):
        _action_error()
    symbolic = False
    values = []

    def arithmetic(node):
        nonlocal symbolic
        if isinstance(node, ast.Constant) and type(node.value) in (int, float) and math.isfinite(node.value):
            value = Fraction(str(node.value))
        elif isinstance(node, ast.Name):
            symbolic = True
            return None
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            v = arithmetic(node.operand)
            value = None if v is None else (-v if isinstance(node.op, ast.USub) else v)
        elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
            a, b = arithmetic(node.left), arithmetic(node.right)
            if isinstance(node.op, ast.Div) and b == 0:
                _action_error()
            if a is None or b is None:
                return None
            if isinstance(node.op, ast.Add):
                value = a + b
            elif isinstance(node.op, ast.Sub):
                value = a - b
            elif isinstance(node.op, ast.Mult):
                value = a * b
            else:
                value = a / b
        else:
            _action_error()
        if value is not None and (abs(value.numerator) > 10**12 or value.denominator > 10**12):
            _action_error()
        return value

    try:
        for piece in pieces:
            tree = ast.parse(piece.strip(), mode='eval')
            if sum(1 for _ in ast.walk(tree)) > 70:
                _action_error()
            values.append(arithmetic(tree.body))
    except (SyntaxError, ValueError, OverflowError, RecursionError, ZeroDivisionError):
        _action_error()
    # Reject even a false numeric segment of a partly symbolic chain.
    for a, symbol, b in zip(values, symbols, values[1:]):
        if a is not None and b is not None:
            correct = {'=': a == b, '<': a < b, '>': a > b, '<=': a <= b, '>=': a >= b}[symbol]
            if not correct:
                raise TutorError('incorrect_equation', '板书数字等式或大小关系不成立；整轮未采用。', 503)
    return 'unsolved' if symbolic else 'verified'


_ANSWER_CUE = re.compile(r'答案(?:是|为)?|(?:应(?:该)?|该)填|空格(?:里|中)?(?:应)?(?:写|填)|'
                         r'分子(?:是|为|=)|结果(?:是|为|=)|所以(?:选|是)')
_CN_NUMBER = r'[负正+-]?(?:[零〇一二两三四五六七八九十百千万亿壹贰叁肆伍陆柒捌玖拾佰仟]+(?:点[零〇一二两三四五六七八九壹贰叁肆伍陆柒捌玖]+)?|\d+(?:\.\d+)?)'
_ANSWER_NUMBER = re.compile(r'(?<![\d.])(?:' + _CN_NUMBER + r'分之' + _CN_NUMBER +
                            r'|' + _CN_NUMBER + r'/\d+|' + _CN_NUMBER + r')(?![\d.])')


def _answer_number(value):
    """Private deterministic exposure comparison only; not grading or model context."""
    from questions import parse_number
    if not isinstance(value, str) or len(value) > 80:
        return None
    value = value.translate(str.maketrans('〇两壹贰叁肆伍陆柒捌玖拾佰仟', '零二一二三四五六七八九十百千'))
    sign = -1 if value.startswith(('负', '-')) else 1
    value = value.removeprefix('负').removeprefix('正').removeprefix('-').removeprefix('+')
    if '分之' in value:
        denominator, numerator = value.split('分之', 1)
        a, b = _answer_number(numerator), _answer_number(denominator)
        return sign * a / b if a is not None and b is not None and b != 0 else None
    if '点' in value:
        whole, decimal = value.split('点', 1)
        integer = _answer_number(whole)
        digits = '零一二三四五六七八九'
        if integer is None or not decimal or any(c not in digits for c in decimal):
            return None
        return sign * (integer + Fraction(int(''.join(str(digits.index(c)) for c in decimal)), 10 ** len(decimal)))
    if re.fullmatch(r'[\d./]+', value):
        number = parse_number(value)
        return sign * number if number is not None else None
    digits = '零一二三四五六七八九'
    if not value or any(c not in digits + '十百千万亿' for c in value):
        return None
    if all(c in digits for c in value):
        return Fraction(sign * int(''.join(str(digits.index(c)) for c in value)))
    total = section = number = 0
    for char in value:
        if char in digits:
            number = digits.index(char)
        elif char in '十百千':
            unit = {'十': 10, '百': 100, '千': 1000}[char]
            section += (number or 1) * unit
            number = 0
        else:
            unit = {'万': 10000, '亿': 100000000}[char]
            section += number
            total = (total + section) * unit if char == '亿' else total + section * unit
            section = number = 0
    return Fraction(sign * (total + section + number))


def _explicit_answer_values(text):
    """Only values after an explicit teacher fill-answer cue in the same clause."""
    for clause in re.split(r'[。！？!?；;\n]', text.replace('＝', '=')):
        for cue in _ANSWER_CUE.finditer(clause):
            for match in _ANSWER_NUMBER.finditer(clause[cue.end():]):
                number = _answer_number(match.group())
                if number is not None:
                    yield number


def _action_strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from _action_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from _action_strings(item)


def _scan_action_math(value):
    for text in _action_strings(value):
        _plain(text, 180)
        # Every nested string: table cells, links nodes/labels, titles, reason, etc.
        # Superscripts/exponents are outside this bounded arithmetic grammar, not unchecked maths.
        if re.search(r'[=＝<>＜＞≤≥]', text) and re.search(r'[⁰¹²³⁴⁵⁶⁷⁸⁹^√∑∫]', text):
            _action_error()
        # Include whole ASCII symbolic names; never extract '+2=7' out of 'x+2=7'.
        pattern = r'(?<![A-Za-z0-9_.])(?:[A-Za-z][A-Za-z0-9_]*|[0-9.()+*/×÷−\-])(?:[A-Za-z0-9_.()+*/×÷−\- ]*)(?:(?:<=|>=|[=＝<>＜＞≤≥])[A-Za-z0-9_.()+*/×÷−\- ]+)+'
        for match in re.finditer(pattern, text):
            _equation(match.group().strip())


def validate_classroom_actions(actions):
    """Shape validation without trusting model-authored graph or routing metadata."""
    if not isinstance(actions, list) or len(actions) > 4:
        _action_error()
    actions = copy.deepcopy(actions)
    for action in actions:
        if not isinstance(action, dict):
            _action_error()
        kind = action.get('type')
        if kind == 'board.write':
            _keys(action, ('type', 'mode', 'block'))
            if action['mode'] not in ('upsert', 'replace'):
                _action_error()
            block = action['block']
            _keys(block, ('id', 'kind', 'title', 'text', 'data', 'graphRefs'))
            if not isinstance(block['id'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', block['id']):
                _action_error()
            _plain(block['title'], 36)
            _plain(block['text'], 180)
            refs = block['graphRefs']
            if (not isinstance(refs, list) or not 1 <= len(refs) <= 20
                    or any(not isinstance(r, str) for r in refs) or len(set(refs)) != len(refs)):
                _action_error()
            data = block['data']
            if block['kind'] in ('note', 'given'):
                _keys(data, ())
            elif block['kind'] == 'equation':
                _keys(data, ('expression',))
                _equation(data['expression'])
            elif block['kind'] == 'bars':
                _keys(data, ('whole', 'parts', 'selected', 'unit'))
                if (not _finite(data['whole']) or not 0 < data['whole'] <= 1e5
                        or type(data['parts']) is not int or not 1 <= data['parts'] <= 20
                        or type(data['selected']) is not int or not 0 <= data['selected'] <= data['parts']):
                    _action_error()
                _plain(data['unit'], 12)
            elif block['kind'] == 'groups':
                _keys(data, ('each', 'count', 'unit'))
                if (not _finite(data['each']) or not 0 < data['each'] <= 1e5
                        or type(data['count']) is not int or not 1 <= data['count'] <= 20):
                    _action_error()
                _plain(data['unit'], 12)
            elif block['kind'] == 'links':
                _keys(data, ('nodes', 'edges'))
                nodes, edges = data['nodes'], data['edges']
                if not isinstance(nodes, list) or not 2 <= len(nodes) <= 6 or not isinstance(edges, list) or len(edges) > 20:
                    _action_error()
                for label in nodes:
                    _plain(label, 24, empty=False)
                for edge in edges:
                    _keys(edge, ('from', 'to', 'label'))
                    if any(type(edge[k]) is not int or not 0 <= edge[k] < len(nodes) for k in ('from', 'to')):
                        _action_error()
                    _plain(edge['label'], 24)
            elif block['kind'] == 'table':
                _keys(data, ('headers', 'rows'))
                headers, rows = data['headers'], data['rows']
                if not isinstance(headers, list) or not 1 <= len(headers) <= 4 or not isinstance(rows, list) or not 1 <= len(rows) <= 6:
                    _action_error()
                for header in headers:
                    _plain(header, 24, empty=False)
                for row in rows:
                    if not isinstance(row, list) or len(row) != len(headers):
                        _action_error()
                    for cell in row:
                        if isinstance(cell, str):
                            _plain(cell, 48)
                        elif not _finite(cell):
                            _action_error()
            else:
                _action_error()
        elif kind == 'board.focus':
            _keys(action, ('type', 'fieldId'))
            _plain(action['fieldId'], 80, empty=False)
        elif kind == 'board.animate':
            _keys(action, ('type', 'blockId', 'durationSeconds'))
            if (not isinstance(action['blockId'], str)
                    or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', action['blockId'])
                    or type(action['durationSeconds']) is not int
                    or not 4 <= action['durationSeconds'] <= 12):
                _action_error()
        elif kind == 'task.open':
            _keys(action, ('type', 'family', 'kind', 'level', 'reason'))
            if (not isinstance(action['family'], str) or action['family'] not in FAMILIES
                    or action['kind'] not in ('assessment', 'practice', 'challenge')
                    or type(action['level']) is not int or not 0 <= action['level'] <= 2):
                _action_error()
            _plain(action['reason'], 100, empty=False)
        elif kind == 'task.return':
            _keys(action, ('type',))
        else:
            _action_error()
    motions = [a for a in actions if a['type'] == 'board.animate']
    if len(motions) > 1 or (motions and any(a['type'].startswith('task.') for a in actions)):
        _action_error()
    _scan_action_math(actions)
    return actions


class TutorStore:
    def __init__(self, path=None, graph=None, clock=None, *, model_quota_policy='legacy'):
        if model_quota_policy not in ('legacy', 'unlimited'):
            raise ValueError('model_quota_policy must be legacy or unlimited')
        self.model_quota_policy = model_quota_policy
        self.path = Path(path or ROOT / '.runtime/sessions.sqlite3')
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.path.parent.is_symlink() or self.path.is_symlink():
            raise ValueError('私有存档路径不能是符号链接')
        os.chmod(self.path.parent, 0o700)
        self.graph = graph or GraphIndex()
        self.clock = clock or _now
        self._curriculum_index = None  # Strict validation only for the new strategy.
        self._curriculum_coverage = None
        self.lock = threading.RLock()
        self.teacher_motion = None  # Trusted startup injection; never selected by model/HTTP.
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        os.chmod(self.path, 0o600)
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS learner_profiles(
                id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, document TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions(
                id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, document TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(
                session_id TEXT NOT NULL REFERENCES sessions(id), seq INTEGER NOT NULL,
                kind TEXT NOT NULL, created_at REAL NOT NULL, data TEXT NOT NULL,
                PRIMARY KEY(session_id, seq));
            CREATE TABLE IF NOT EXISTS requests(
                session_id TEXT NOT NULL REFERENCES sessions(id), request_id TEXT NOT NULL,
                result TEXT NOT NULL, PRIMARY KEY(session_id, request_id));
            CREATE TABLE IF NOT EXISTS create_requests(
                request_id TEXT PRIMARY KEY, owner TEXT NOT NULL, payload_hash TEXT NOT NULL,
                session_id TEXT NOT NULL REFERENCES sessions(id), response TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS teacher_requests(
                session_id TEXT NOT NULL REFERENCES sessions(id), request_id TEXT NOT NULL,
                document TEXT NOT NULL, PRIMARY KEY(session_id, request_id));
            CREATE TABLE IF NOT EXISTS teacher_motion_jobs(
                id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES sessions(id),
                request_id TEXT NOT NULL, state TEXT NOT NULL, version INTEGER NOT NULL,
                document TEXT NOT NULL, UNIQUE(session_id, request_id));
            CREATE TABLE IF NOT EXISTS teacher_motion_pins(
                session_id TEXT NOT NULL REFERENCES sessions(id), instance_id TEXT NOT NULL,
                block_id TEXT NOT NULL, document TEXT NOT NULL,
                PRIMARY KEY(session_id, instance_id, block_id));
        ''')
        self.db.commit()
        for family, meta in FAMILIES.items():
            if any(skill not in self.graph.nodes for skill in meta['skills']):
                raise ValueError(f'题族 {family} 含未登记的本次学段技能')
        self.content_version = _fingerprint((ROOT / 'questions.py').read_text())[:16]
        # Coverage is the union of scored fields, not descriptive family skills.
        self.family_fields = {family: set() for family in FAMILIES}
        self.probe_fields = {family: set() for family in FAMILIES}
        for family in FAMILIES:
            for phase in PHASE_LABELS:
                if phase in ('teach', 'report'):
                    continue
                generation = 'verify' if phase == 'retention' else 'probe' if phase == 'guided' else phase
                for variant in range(4):
                    question = build_question(family, variant, generation)
                    mapped = {skill for field in question['fields']
                              if field.get('evidenceKind') != 'question_only'
                              for skill in question['_field_skills'].get(field['id'], [])}
                    self.family_fields[family].update(mapped)
                    if phase == 'probe':
                        self.probe_fields[family].update(mapped)

    @property
    def curriculum(self):
        if self._curriculum_index is None:
            from curriculum import CurriculumIndex
            self._curriculum_index = CurriculumIndex(self.graph)
        return self._curriculum_index

    def _profile_payload(self, payload, previous=None):
        if not isinstance(payload, dict) or set(payload) - {'curriculumProfile', 'goals'}:
            raise TutorError('invalid_profile', '仅接受课程范围和学习目标，不收集姓名或性格。')
        result = copy.deepcopy(previous or {})
        try:
            result['curriculumProfile'] = self.curriculum.normalize_profile(
                payload.get('curriculumProfile', result.get('curriculumProfile')))
        except ValueError as exc:
            raise TutorError('invalid_curriculum_profile', str(exc)) from exc
        goals = payload.get('goals', result.get('goals', []))
        if (not isinstance(goals, list) or len(goals) > len(DIMENSIONS)
                or any(not isinstance(g, str) or g not in DIMENSIONS for g in goals)
                or len(set(goals)) != len(goals)):
            raise TutorError('invalid_goals', '学习目标须为不重复的已支持诊断维度。')
        result['goals'] = goals[:]
        result['curriculumVersion'] = self.curriculum.version
        return result

    def _load_profile(self, identifier, token):
        if (not isinstance(identifier, str) or not isinstance(token, str)
                or len(identifier) > 160 or len(token) > 160):
            raise TutorError('profile_unauthorized', '请使用本机保存的学习档案凭据。', 403)
        row = self.db.execute('SELECT token_hash, document FROM learner_profiles WHERE id=?',
                              (identifier,)).fetchone()
        if not row or not hmac.compare_digest(row[0], hashlib.sha256(token.encode()).hexdigest()):
            raise TutorError('profile_unauthorized', '这份学习档案不属于当前凭据。', 403)
        return json.loads(row[1])

    def _linked_profile(self, session):
        # Binding is minted only by authorized start, never by client metadata.
        if session.get('diagnosisStrategy') != 'personalized' or not session.get('profileId'):
            return None
        row = self.db.execute('SELECT document FROM learner_profiles WHERE id=?',
                              (session['profileId'],)).fetchone()
        if not row:
            raise TutorError('profile_unauthorized', '关联学习档案已不可用。', 403)
        return json.loads(row[0])

    def _save_profile(self, profile):
        self.db.execute('UPDATE learner_profiles SET document=? WHERE id=?',
                        (json.dumps(profile, ensure_ascii=False), profile['id']))

    def _profile_view(self, profile):
        skills = summarize(profile['evidence'], self.graph, self.clock())
        priorities = [{'skillId': row['id'], 'dimension': d['dimension'], 'status': d['status'],
                       'dueAt': d['dueAt']} for row in skills for d in row['dimensions']
                      if d['status'] != 'unmeasured' and (d['status'] != 'independently_verified' or d['reviewDue'])]
        priorities.sort(key=lambda r: (r['status'] not in ('needs_verification', 'conflicting_evidence'),
                                       r['dueAt'] or 0))
        return {'id': profile['id'], 'curriculumProfile': copy.deepcopy(profile['curriculumProfile']),
                'curriculumVersion': profile.get('curriculumVersion'),
                'curriculumNeedsConfirmation': profile.get('curriculumVersion') != self.curriculum.version,
                'goals': profile['goals'][:], 'summary': {'skills': skills,
                    'evidenceCount': sum(not r.get('branchId') for r in profile['evidence']),
                    'childEvidenceCount': sum(bool(r.get('branchId')) for r in profile['evidence']),
                    'recommendations': priorities,
                    **self._evidence_summary(skills)},
                'notice': '仅累计实际字段作答；未知进度先确认，不推断全年已学或诊断准确率。'}

    def create_profile(self, payload):
        with self.lock, self.db:
            profile = self._profile_payload(payload)
            identifier, token = str(uuid.uuid4()), secrets.token_urlsafe(32)
            profile.update(id=identifier, createdAt=self.clock(), evidence=[], issued=[], screenedRoots=[])
            self.db.execute('INSERT INTO learner_profiles VALUES(?,?,?)',
                            (identifier, hashlib.sha256(token.encode()).hexdigest(),
                             json.dumps(profile, ensure_ascii=False)))
            return {**self._profile_view(profile), 'token': token}

    def profile_view(self, identifier, token):
        with self.lock:
            return self._profile_view(self._load_profile(identifier, token))

    def update_profile(self, identifier, token, payload):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            previous = self._load_profile(identifier, token)
            if (previous.get('curriculumVersion') != self.curriculum.version
                    and (not isinstance(payload, dict) or 'curriculumProfile' not in payload)):
                raise TutorError('curriculum_version_changed', '请先显式确认更新后的课程范围。', 409)
            profile = self._profile_payload(payload, previous)
            self._save_profile(profile)
            return self._profile_view(profile)

    def _sync_profile(self, session):
        profile = self._linked_profile(session)
        if profile is None:
            return
        known = {(r['sessionId'], r['instanceId'], r['fieldId'], r['skillId']) for r in profile['evidence']}
        for result in session['results']:
            for row in evidence_records(session, result):
                key = (row['sessionId'], row['instanceId'], row['fieldId'], row['skillId'])
                if key not in known:
                    profile['evidence'].append(row)
                    known.add(key)
        issued = {r['signature'] for r in profile['issued']}
        for task in session['tasks']:
            if task['signature'] not in issued:
                profile['issued'].append({'signature': task['signature'], 'family': task['family'],
                                         'sessionId': session['id'], 'instanceId': task['instanceId']})
                issued.add(task['signature'])
        profile['screenedRoots'] = list(dict.fromkeys(profile['screenedRoots'] + session['screenedRoots']))
        self._save_profile(profile)

    def _save(self, session):
        self._invalidate_teacher_motions(session)
        self._sync_profile(session)
        self.db.execute('UPDATE sessions SET document=? WHERE id=?',
                        (json.dumps(session, ensure_ascii=False), session['id']))

    def _load(self, identifier, token):
        if not isinstance(identifier, str) or not isinstance(token, str) or len(token) > 160:
            raise TutorError('unauthorized', '请从本机保存的课堂入口继续。', 403)
        row = self.db.execute('SELECT token_hash, document FROM sessions WHERE id=?', (identifier,)).fetchone()
        if not row or not hmac.compare_digest(row[0], hashlib.sha256(token.encode()).hexdigest()):
            raise TutorError('unauthorized', '这份课堂不属于当前保存的会话。', 403)
        session = json.loads(row[1])
        if session['graphVersion'] != self.graph.version or session['contentVersion'] != self.content_version:
            raise TutorError('version_changed', '题库或图谱已更新；旧记录保留，请重新开始一份课堂。', 409)
        # Missing strategy denotes an old archive; keep its original chain.
        session.setdefault('diagnosisStrategy', 'focused')
        if (session['diagnosisStrategy'] == 'personalized'
                and session.get('curriculumVersion') != self.curriculum.version):
            raise TutorError('curriculum_version_changed',
                             '课程登记已更新；旧课堂记录保留，请确认已学范围后重新开始。', 409)
        session.setdefault('followups', [])
        session.setdefault('screenedRoots', [r['family'] for r in self._main_results(session) if r['phase'] == 'screen'])
        session.setdefault('pending', [])
        session.setdefault('excludedInstances', [])
        session.setdefault('skippedRoots', [])
        session.setdefault('attempts', {})
        return session

    def _event(self, session, kind, data=None):
        session['seq'] += 1
        self.db.execute('INSERT INTO events VALUES(?,?,?,?,?)',
                        (session['id'], session['seq'], kind, self.clock(),
                         json.dumps(data or {}, ensure_ascii=False)))

    def _elapsed(self, session):
        active = 0 if session['paused'] or session['closed'] else max(0, self.clock() - session['activeSince'])
        return round(session['elapsed'] + active)

    def _limit_reached(self, session):
        return self._elapsed(session) >= session['budgetSeconds'] or session['answeredCount'] >= session['taskLimit']

    def _issue(self, session, family, phase, *, root=None, variant=None, target_skill=None,
               target_dimension=None):
        root = root or session.get('rootFamily') or family
        if session.get('answerFlow') == 'automatic' and phase == 'guided':
            raise TutorError('automatic_guided_forbidden', '自动课堂只用原题辅导和未见独立验证。', 409)
        if self._limit_reached(session):
            return self._close(session, '本次时间或题量预算已到；未完成队列保留。')
        if session.get('diagnosisStrategy') == 'personalized':
            role = self.curriculum.role_for(family, session['curriculumProfile'])
            if role not in ('current_learned', 'prerequisite'):
                return self._next_root(session, '课程范围不允许这份题；不作为薄弱证据。')
            if target_dimension == 'unspecified':
                target_dimension = None
        if (session.get('diagnosisStrategy') in ('breadth', 'personalized')
                and session.get('attempts', {}).get(family + ':' + phase, 0) >= 4):
            return self._next_root(session, '这一题族本阶段次数已到，保留待查，不循环发题。')
        if family not in FAMILIES:
            raise TutorError('unknown_family', '下一题不在已核题族中。')
        counts = session['variants']
        key = family + ':' + phase
        variant = counts.get(key, 0) if variant is None else variant
        generation_phase = 'verify' if phase == 'retention' else 'probe' if phase == 'guided' else phase
        chosen = None
        for offset in range(4):
            candidate = build_question(family, variant + offset, generation_phase, min(2, session['level']))
            mapped = {skill for field in candidate['fields']
                      if field.get('evidenceKind') != 'question_only'
                      for skill in candidate['_field_skills'].get(field['id'], [])}
            if target_skill is not None and target_skill not in mapped:
                continue
            if target_dimension is not None and not any(
                    field.get('diagnosticDimension') == target_dimension
                    and (target_skill is None or target_skill in candidate['_field_skills'][field['id']])
                    for field in candidate['fields']):
                continue
            signature = _fingerprint({k: candidate[k] for k in ('prompt', 'fields', 'diagram')})
            if signature not in session['seenQuestions']:
                chosen = candidate
                break
        if chosen is None:
            if target_skill is not None:
                active = session.get('activeFollowup')
                if active is not None:
                    session['followups'][active]['missing'].append({
                        'id': target_skill, 'title': self.graph.title(target_skill),
                        'reason': '目标未测待查：无未用过且可评分目标技能的实际变式'})
                self._event(session, 'probe_unavailable', {'family': family, 'targetSkill': target_skill})
            return self._next_root(session,
                                   '没有匹配目标的未用变式，保留未测待查，不以别的技能替代。' if target_skill is not None else
                                   '这一题族的独立变式已用过，保留未完成验证，不重复题面签掌握。')
        if (session.get('diagnosisStrategy') == 'breadth' and not session.get('reviewOf')
                and phase != 'screen' and not self._focus_budget(
                    session, family, phase, candidate=chosen, root=root)):
            return self._close_focus_budget(session)
        if session.get('diagnosisStrategy') == 'personalized' and not self._personalized_budget(
                session, family, phase, root=root, candidate=chosen):
            return self._next_root(session, '不足本题及必要独立对照与180秒反馈预算，保留未完成验证。')
        if target_skill is not None:
            chosen['targetSkill'] = target_skill
            if session.get('activeFollowup') is not None and phase == 'probe':
                session['focusProbeCount'] += 1
        if session.get('diagnosisStrategy') == 'personalized':
            context = self.curriculum.root_context(family, session['curriculumProfile'])
            chosen.update(rootContext=context, scopeRole=role,
                scopeUnits=context['scopeUnits'], relatedUnits=context['relatedUnits'],
                supportsFamilies=context['supportsFamilies'], curriculumReason={
                'edition': session['curriculumProfile']['edition'],
                'units': context['scopeUnits'], 'relatedUnits': context['relatedUnits'],
                'reason': '显式已学单元目标' if role == 'current_learned' else '相关先备探测，不推定已会'},
                priorProbe=role == 'prerequisite', targetDimension=target_dimension)
        counts[key] = variant + offset + 1 if target_skill is not None else variant + 1
        session['seenQuestions'].append(signature)
        attempts = session.setdefault('attempts', {})
        attempts[key] = attempts.get(key, 0) + 1
        scaffolded = (session.get('answerFlow') != 'automatic' and session['scheme'] == 'steps'
                      and phase in ('screen', 'probe', 'guided', 'challenge'))
        chosen.update(instanceId=str(uuid.uuid4()), phase=phase, signature=signature,
                      helped=phase == 'guided' or scaffolded, scaffolded=scaffolded,
                      answers={}, workText='', strokes=[], toolEvents=[], stepEvents=[],
                      issuedAt=self.clock(), rootFamily=root, ordinal=session['answeredCount'] + 1)
        session['current'] = chosen
        session['awaitingNext'] = False
        session['rootFamily'] = root
        session['phase'] = phase
        if session.get('diagnosisStrategy') == 'focused':
            session['diagnosisStage'] = 'sweep' if phase == 'screen' else 'focus'
        session['lesson'] = None
        session['revision'] += 1
        session['feedback'] = None
        session['teacher'] = self._teacher_for(session, phase)
        if phase == 'screen':
            session['probePath'] = [family]
        session['tasks'].append(copy.deepcopy(chosen))
        self._event(session, 'issued', {'instanceId': chosen['instanceId'], 'family': family,
                                      'rootFamily': root, 'phase': phase,
                                      'representation': chosen['representation'], 'signature': signature,
                                      'helped': chosen['helped'],
                                      **({'targetSkill': target_skill} if target_skill is not None else {})})
        if scaffolded:
            self._event(session, 'help', {'instanceId': chosen['instanceId'], 'kind': 'scaffold'})

    def _personalized_budget(self, session, family, phase, *, root=None, candidate=None):
        root = root or family
        tails = {'screen': (), 'probe': ('guided', 'verify', 'transfer'),
                 'teach': ('guided', 'verify', 'transfer'), 'guided': ('verify', 'transfer'),
                 'verify': ('transfer',), 'retention': ('transfer',),
                 'transfer': (), 'challenge': ()}
        if (phase == 'probe' and family == root and family in session['roots']
                and session.get('activeFollowup') is None
                and self.curriculum.root_context(family, session['curriculumProfile'])['recommendedPhase'] == 'probe'):
            tails = {**tails, 'probe': () if session['progressNeedsConfirmation'] else ('verify',)}
        if session.get('answerFlow') == 'automatic':
            tails = {**tails, 'teach': ('verify', 'transfer'), 'probe': ()}
        active = session.get('activeFollowup')
        if (phase == 'verify' and active is not None
                and session['followups'][active]['kind'] == 'prerequisite_probe'):
            tails = {**tails, 'verify': ()}
        sequence = [] if phase == 'teach' else [(family, phase)]
        sequence += [(root, p) for p in tails[phase]]
        needed = 180  # Feedback reserve, never an inferred child speed label.
        for i, (f, p) in enumerate(sequence):
            if i == 0 and candidate is not None:
                needed += candidate['estimatedSeconds']
            else:
                generation = 'probe' if p == 'guided' else 'verify' if p == 'retention' else p
                needed += max(build_question(f, v, generation, min(2, session['level']))['estimatedSeconds']
                              for v in range(4))
        return (session['budgetSeconds'] - self._elapsed(session) >= needed
                and session['taskLimit'] - session['answeredCount'] >= len(sequence))

    def _scope_units(self, family, profile):
        return list(self.curriculum.metadata[family]['editionScopes'][profile['edition']]['units'])

    def _root_units(self, family, profile):
        context = self.curriculum.root_context(family, profile)
        return context['scopeUnits'] or context['relatedUnits']

    def _personalized_roots(self, profile, mode, minutes, answer_flow=None):
        p = profile['curriculumProfile']
        seen = profile['screenedRoots']
        roots = self.curriculum.roots_for(p, mode.title(), seen)
        if not p['completedUnits']:
            return roots[:1]
        # Ask the curriculum for each explicitly completed unit, not a flattened grade.
        candidates = list(roots)
        for unit in p['completedUnits']:
            single = {**p, 'completedUnits': [unit], 'currentUnit': None}
            candidates += self.curriculum.roots_for(single, mode.title(), seen)
        candidates = list(dict.fromkeys(candidates))
        signatures = {r['signature'] for r in profile['issued']}
        candidates = [f for f in candidates
                      if self.curriculum.role_for(f, p) in ('current_learned', 'prerequisite') and any(
            _fingerprint({k: q[k] for k in ('prompt', 'fields', 'diagram')}) not in signatures
            for v in range(4) for q in [build_question(
                f, v, self.curriculum.root_context(f, p)['recommendedPhase'])])]
        summary = summarize(profile['evidence'], self.graph, self.clock())
        by_skill = {row['id']: row['dimensions'] for row in summary}
        seen_units = {u for f in seen for u in self._root_units(f, p)}

        order = {f: i for i, f in enumerate(candidates)}
        def rank(family):
            dimensions = [d for skill in self.family_fields[family] for d in by_skill.get(skill, [])
                          if d['dimension'] != 'unspecified']
            repeated = sum(d['wrongInstances'] >= 2 for d in dimensions)
            errors = sum(d['status'] in ('needs_verification', 'conflicting_evidence') for d in dimensions)
            due = any(d['reviewDue'] for d in dimensions)
            supported = {field.get('diagnosticDimension') for v in range(4)
                         for q in [build_question(family, v, 'verify')]
                         for field in q['fields'] if field.get('diagnosticDimension')}
            measured = {d['dimension']: d for d in dimensions}
            missing = sum(measured.get(d, {}).get('status', 'unmeasured') == 'unmeasured' for d in supported)
            strong = bool(supported) and all(measured.get(d, {}).get('status') == 'independently_verified'
                                            for d in supported)
            unseen_unit = not (set(self._root_units(family, p)) & seen_units)
            return (strong and not due, -repeated, -errors, not unseen_unit, not due,
                    -missing, family in seen, order[family])

        candidates.sort(key=rank)
        selected, units, remaining = [], set(), minutes * 60 - 180
        for family in candidates:
            group = set(self._root_units(family, p))
            if group & units:
                continue
            # Reserve two unseen independent tasks and feedback, never label pace.
            phase = self.curriculum.root_context(family, p)['recommendedPhase']
            cost = max(build_question(family, v, phase)['estimatedSeconds'] for v in range(4)) * 2
            if cost > remaining:
                continue
            selected.append(family)
            units.update(group)
            remaining -= cost
            if len(selected) >= ((4 if mode == 'lite' else 6) if answer_flow == 'automatic'
                                 else (3 if mode == 'lite' else 5)):
                break
        return selected

    def _review_dimension(self, profile, family):
        rows = summarize(profile['evidence'], self.graph, self.clock(), self.family_fields[family])
        dimensions = [d for row in rows for d in row['dimensions'] if d['reviewDue']]
        dimensions.sort(key=lambda d: (d['wrongInstances'] == 0,
                                      d['dimension'] not in ('procedure', 'application'), d['dueAt']))
        return next((d['dimension'] for d in dimensions if d['dimension'] != 'unspecified'), None)

    def _due_roots(self, profile, roots):
        rows = summarize(profile['evidence'], self.graph, self.clock())
        due_skills = {row['id'] for row in rows if any(d['reviewDue'] for d in row['dimensions'])}
        return [f for f in roots if self.family_fields[f] & due_skills]

    def _personalized_coverage(self, session):
        if self._curriculum_coverage is None:
            self._curriculum_coverage = {f: [build_question(f, v, phase) for phase in
                       ('screen', 'probe', 'verify', 'transfer', 'challenge') for v in range(4)]
                   for f in FAMILIES}
        coverage = self.curriculum.coverage(session['curriculumProfile'], self._curriculum_coverage)
        coverage.pop('scoredFields', None)  # Public unit support, not a giant internal field inventory.
        return coverage

    @staticmethod
    def _evidence_summary(skills):
        dimensions = [d for row in skills for d in row['dimensions']]
        statuses = ('unmeasured', 'unverified', 'assisted_only', 'needs_verification',
                    'conflicting_evidence', 'independently_verified')
        return {'measuredSkillCount': sum(any(d['status'] != 'unmeasured' for d in row['dimensions'])
                                          for row in skills),
                'dimensionCount': len(dimensions),
                'statusCounts': {status: sum(d['status'] == status for d in dimensions) for status in statuses},
                'choiceDiscriminationCount': sum(d['verificationKind'] == 'independent_choice_discrimination'
                                                  for d in dimensions),
                'constructedVerificationCount': sum(d['verificationKind'] == 'independent_constructed_fields'
                                                     for d in dimensions),
                'dueDimensionCount': sum(d['reviewDue'] for d in dimensions),
                'openExplanationStatus': 'unassessed', 'completeConceptMastery': False,
                'longTermMastery': False}

    def _personalization(self, session):
        profile = self._linked_profile(session)
        if profile is None:
            return None
        records = [row for result in session['results'] for row in evidence_records(session, result)]
        skills = summarize(records, self.graph, self.clock())
        return {'summary': {**self._evidence_summary(skills), 'evidenceCount': len(records),
                            'answeredCount': len(self._main_results(session)),
                            'issuedCount': sum(not t.get('branchId') for t in session['tasks']),
                            'skippedCount': len(session['excludedInstances']),
                            'plannedRootCount': len(session['roots']),
                            'screenedRootCount': len(session['screenedRoots'])},
                'curriculumProfile': copy.deepcopy(session['curriculumProfile']),
                'curriculumVersion': session['curriculumVersion'], 'scopeGroups': session['scopeGroups'],
                'rootContexts': [self.curriculum.root_context(f, session['curriculumProfile'])
                                 for f in session['roots']],
                'curriculumCoverage': self._personalized_coverage(session),
                'progressNeedsConfirmation': session['progressNeedsConfirmation'],
                'skills': skills,
                'cumulativeSkills': summarize(profile['evidence'], self.graph, self.clock()),
                'uncertainHypotheses': copy.deepcopy(session['uncertainHypotheses']),
                'goals': profile['goals'][:],
                'recommendations': self._profile_view(profile)['summary']['recommendations'],
                'notice': '维度分别保留冲突；两道未见独立验证及相关构造字段才签当次验证，不推定长期掌握。'}

    def _personalized_followup(self, session, result):
        fields = result['score']['fieldResults']
        wrong = [r for r in fields if not r['correct']]
        dimensions = list(dict.fromkeys(r.get('diagnosticDimension', 'unspecified') for r in wrong))
        numeric = any(r['correct'] and r.get('evidenceKind') == 'constructed'
                      and r.get('diagnosticDimension') in ('procedure', 'application') for r in fields)
        mismatch = numeric and any(d in ('concept', 'reasoning') for d in dimensions)
        skills = list(dict.fromkeys(s for r in (wrong or fields) for s in r['skillIds']))
        if not wrong:
            dimensions = list(dict.fromkeys(r.get('diagnosticDimension', 'unspecified') for r in fields))
            dimensions.sort(key=lambda d: (d not in ('procedure', 'application'), d))
        row = {'rootFamily': result['rootFamily'], 'domain': FAMILIES[result['family']]['domain'],
               'instanceId': result['instanceId'], 'kind': 'contrast' if mismatch else
                       'error' if wrong else 'assisted' if result['assisted'] else 'verification',
               'skills': skills, 'dimensions': dimensions, 'status': 'queued', 'probes': [], 'missing': [],
               'reason': '计算与概念／理由不一致，只用一个未见对照核查，不能据此给能力分。' if mismatch else
                         '按实际错误维度或缺少的独立验证安排下一步。'}
        if mismatch:
            session['uncertainHypotheses'].append({'status': 'uncertainHypothesis',
                'instanceId': result['instanceId'], 'skillIds': skills, 'dimensions': dimensions,
                'hypothesis': 'procedure_concept_mismatch', 'confirmedCause': False})
        if row['kind'] == 'error' and session.get('answerFlow') != 'automatic':
            row['probes'], row['missing'] = self._followup_probes(session, row)
        session['followups'].append(row)
        return row

    def _personalized_next(self, session, message=None):
        active = session.get('activeFollowup')
        if active is not None:
            row = session['followups'][active]
            row['status'] = 'pending' if message else 'completed'
            session['activeFollowup'] = None
        session.update(awaitingNext=False, repairQueue=[], repairTarget=None, repairRounds=0,
                       focusProbeCount=0, focusTeachCount=0)
        if session.get('answerFlow') == 'automatic':
            session['coaching'] = None
        if self._limit_reached(session):
            return self._close(session, '本次预算已到；未测维度与独立验证保留。')
        if session['pendingRoots']:
            family = session['pendingRoots'].pop(0)
            if family in session['excludedRoots'] or family in session['skippedRoots']:
                return self._personalized_next(session, message)
            session['nextReason'] = '先看尚未覆盖的已学单元组，错误维度记入待查；不是全图测完。'
            context = self.curriculum.root_context(family, session['curriculumProfile'])
            phase = ('retention' if family in session.get('dueReviewRoots', [])
                     and context['recommendedPhase'] != 'probe' else context['recommendedPhase'])
            if phase == 'probe':
                session['nextReason'] = '只探测关联单元需要的先备；答对不自动确认以前已学或解锁后续课程。'
            dimension = self._review_dimension(self._linked_profile(session), family) if phase == 'retention' else None
            return self._issue(session, family, phase, root=family, target_dimension=dimension)
        if session['progressNeedsConfirmation']:
            return self._close(session, '已完成最小先备试题；请先确认教材与已学单元，不扩大为全年诊断。')
        session['diagnosisStage'] = 'focus'
        queued = [(i, row) for i, row in enumerate(session['followups'])
                  if row['status'] == 'queued' and row['rootFamily'] not in session['skippedRoots']
                  and row['rootFamily'] not in session['excludedRoots']]
        profile = self._linked_profile(session)
        def priority(item):
            _, row = item
            relevant = [r for r in profile['evidence'] if r['skillId'] in row['skills']
                        and r['diagnosticDimension'] in row['dimensions']]
            repeated = sum(not r['correct'] for r in relevant)
            return (row['kind'] not in ('contrast', 'error'), -repeated, item[0])
        queued.sort(key=priority)
        if not queued:
            needs_prior = any(
                set(context['prerequisiteSkills']) - set(context['confirmedPrerequisiteSkills'])
                for family in session['roots']
                for context in [self.curriculum.root_context(family, session['curriculumProfile'])])
            if needs_prior:
                return self._close(session,
                    '先备探测收束；请先显式确认以前已学，再于新课堂安排关联课程。答对不自动确认已学或掌握。')
            return self._close(session, '本次单元初筛和有限验证收束；未测、冲突与保持证据分别保留。')
        index, row = queued[0]
        family = row['rootFamily']
        if session['budgetSeconds'] - self._elapsed(session) <= 180:
            return self._close(session, '保留反馈时间；剩余验证下次接回，不标记孩子快慢。')
        row['status'] = 'active'
        session.update(activeFollowup=index, rootFamily=family, nextReason=row['reason'])
        if row['kind'] == 'prerequisite_probe':
            return self._issue(session, family, 'verify', root=family,
                               target_dimension=next(iter(row['dimensions']), None))
        if session.get('answerFlow') == 'automatic' or row['kind'] in ('contrast', 'assisted', 'verification'):
            dimension = next(iter(row['dimensions']), None)
            if row['kind'] in ('assisted', 'verification'):
                # Missing dimensions first; choose only a dimension with two unseen
                # instances left. The bank's four forms are not infinite variants.
                metrics = {d['dimension']: d for s in summarize(profile['evidence'], self.graph,
                           self.clock(), row['skills']) for d in s['dimensions']}
                available = {}
                for v in range(4):
                    q = build_question(family, v, 'verify')
                    signature = _fingerprint({k: q[k] for k in ('prompt', 'fields', 'diagram')})
                    if signature in session['seenQuestions']:
                        continue
                    for field in q['fields']:
                        d = field.get('diagnosticDimension')
                        if d:
                            available.setdefault(d, set()).add(signature)
                candidates = [d for d, signatures in available.items() if len(signatures) >= 2
                              and metrics.get(d, {}).get('status') != 'independently_verified']
                candidates.sort(key=lambda d: (metrics.get(d, {}).get('status') != 'unmeasured',
                                                d not in profile['goals'],
                                                d not in ('procedure', 'application'), d))
                dimension = next(iter(candidates), None)
                if not candidates and available:
                    return self._personalized_next(session,
                        '该维度不足两道未见实例，保留待验证，不重复题面签掌握。')
            return self._issue(session, family, 'verify', target_skill=next(iter(row['skills']), None),
                               target_dimension=dimension)
        probe = next(iter(row['probes']), None)
        if probe:
            return self._issue(session, probe['family'], 'probe', root=family,
                               target_skill=probe['skillId'], target_dimension=probe.get('dimension'))
        return self._teach(session, family)

    def _personalized_route(self, session, result):
        family, phase = result['family'], result['phase']
        correct = result['score']['correct'] and not result['assisted']
        if phase == 'screen':
            return self._personalized_next(session)
        row = session['followups'][session['activeFollowup']] if session['activeFollowup'] is not None else None
        if (phase == 'probe' and family == result['rootFamily']
                and session.get('activeFollowup') is None):
            return self._personalized_next(session)
        if row and row['kind'] == 'prerequisite_probe':
            return self._personalized_next(session,
                '先备探测和一次独立对照已记录；请显式确认以前已学，再于新课堂安排关联课程，不自动解锁。')
        if phase == 'probe':
            return self._teach(session, result['rootFamily'])  # Exactly one contrast/prerequisite probe.
        if row and row['kind'] == 'contrast' and phase == 'verify':
            if correct:
                return self._personalized_next(session, '单题对照已记录，假设仍不等于已确认根因或掌握。')
            return self._teach(session, family)
        if phase == 'guided':
            if result['score']['correct']:
                return self._issue(session, family, 'verify',
                                   target_dimension=next(iter(row['dimensions']), None) if row else None)
            return self._personalized_next(session, '受助后仍有冲突，下次接回，不延长探针链。')
        if phase in ('verify', 'transfer', 'retention'):
            if phase == 'retention' and row is None and not correct:
                self._personalized_followup(session, result)
                return self._personalized_next(session, '延后复查有冲突，安排对应字段辅导，不记为会。')
            if correct and phase in ('verify', 'retention'):
                return self._issue(session, family, 'transfer',
                                   target_dimension=session['current'].get('targetDimension'))
            if correct:
                return self._personalized_next(session)
            if row and row['kind'] == 'error':
                return self._personalized_next(session, '独立验证仍有错误，保留对应维度，不改为会。')
            if row:
                row['kind'] = 'error'
                return self._teach(session, family)
            return self._personalized_next(session, '延后验证存在冲突，保留字段证据。')
        return self._personalized_next(session)

    def _teacher_for(self, session, phase):
        if phase == 'screen':
            return '不用急着算。先看清题目，再写下你的想法。我会等你。'
        if phase == 'probe':
            return '各类问题先看过了。现在只检查这处卡点需要的基础；这是定位，不是用简单题代替辅导。'
        if phase == 'guided':
            return '用刚才的方法试一步。这里有帮助，做对后还会给你一题自己完成。'
        if phase in ('verify', 'transfer', 'retention'):
            return '这次不带提示。你可以用自己的办法；写好后再一起看。'
        return '先判断条件有没有变。这次可以找反例、反推，或换一种方法。'

    def start(self, payload):
        if not isinstance(payload, dict):
            raise TutorError('invalid_payload', '课堂参数须为对象。')
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            return self._start(payload)

    def _start(self, payload):
        mode, scheme = payload.get('mode', 'lite'), payload.get('scheme', 'desk')
        strategy = payload.get('diagnosisStrategy', 'breadth')
        answer_flow = payload.get('answerFlow')
        if 'answerFlow' in payload and answer_flow != 'automatic':
            raise TutorError('invalid_answer_flow', 'answerFlow仅接受automatic；旧课堂请省略此字段。')
        if 'completeLive' in payload:
            raise TutorError('invalid_answer_flow', '请使用规范字段answerFlow，不接受completeLive别名。')
        if answer_flow == 'automatic' and strategy != 'personalized':
            raise TutorError('automatic_profile_required', '自动课堂须绑定personalized已学进度。')
        if strategy not in ('breadth', 'focused', 'personalized'):
            raise TutorError('invalid_strategy', '诊断策略须为breadth、focused或personalized。')
        profile = None
        if strategy == 'personalized':
            learner = payload.get('learner')
            if not isinstance(learner, dict) or set(learner) != {'id', 'token'}:
                raise TutorError('profile_required', '请先创建匿名学习档案，再开始个性化课堂。')
            profile = self._load_profile(learner['id'], learner['token'])
            if 'curriculumProfile' in payload:
                profile = self._profile_payload({'curriculumProfile': payload['curriculumProfile']}, profile)
                self._save_profile(profile)
            elif profile.get('curriculumVersion') != self.curriculum.version:
                raise TutorError('curriculum_version_changed',
                                 '学习档案的课程登记已变化，请显式确认curriculumProfile后开始。', 409)
        elif 'learner' in payload or 'curriculumProfile' in payload:
            raise TutorError('invalid_strategy', '学习档案绑定须显式选择personalized，不改写旧课堂。')
        if mode not in ('lite', 'pro') or scheme not in ('desk', 'steps', 'lab'):
            raise TutorError('invalid_mode', '请选择一份已提供的课堂方案。')
        scope = payload.get('scope', 'all')
        if scope not in ('all', 'fall'):
            raise TutorError('invalid_scope', '已学范围不正确。')
        roots = list(ROOTS_LITE if mode == 'lite' else ROOTS_PRO)
        # This is a suggested 人教版上学期 scope, not a worldwide grade-order claim.
        excluded = []
        if scope == 'fall':
            excluded = [family for family in roots if family in ('factors', 'volume', 'data_trend')]
            roots = [family for family in roots if family not in excluded]
        minutes = payload.get('minutes', 15 if mode == 'lite' else 25)
        if type(minutes) is not int or not (10 <= minutes <= 15 if mode == 'lite' else 20 <= minutes <= 30):
            raise TutorError('invalid_minutes', 'Lite支持10–15分钟，Pro支持20–30分钟。')
        if answer_flow == 'automatic' and minutes != (15 if mode == 'lite' else 25):
            raise TutorError('invalid_minutes', '自动课堂Lite为15分钟，Pro为25分钟。')
        if strategy == 'breadth':
            first, extra, domains = [], [], set()
            for family in roots:
                domain = FAMILIES[family]['domain']
                (extra if domain in domains else first).append(family)
                domains.add(domain)
            roots = first + extra
        if profile is not None:
            roots = self._personalized_roots(profile, mode, minutes, answer_flow)
            excluded = [f for f in FAMILIES if self.curriculum.role_for(f, profile['curriculumProfile'])
                        not in ('current_learned', 'prerequisite')]
            if not roots:
                raise TutorError('no_curriculum_roots', '已学范围没有可用的未重复题，请调整已学范围。')
        now, identifier, token = self.clock(), str(uuid.uuid4()), secrets.token_urlsafe(32)
        session = dict(id=identifier, mode=mode, scheme=scheme, scope=scope,
                       diagnosisStrategy=strategy, diagnosisStage='sweep', screenedRoots=[],
                       followups=[], focusSelected=False, focusQueue=[], activeFollowup=None,
                       focusProbeCount=0, focusTeachCount=0, pending=[], excludedInstances=[], skippedRoots=[],
                       attempts={}, nextReason='先看代表领域，不从一道题推断全部知识。',
                       version=SCHEMA_VERSION, graphVersion=self.graph.version,
                       contentVersion=self.content_version, createdAt=now,
                       budgetSeconds=minutes * 60, taskLimit=18 if mode == 'lite' else 28,
                       elapsed=0, activeSince=now, paused=False, closed=False,
                       roots=roots, excludedRoots=excluded, pendingRoots=roots[1:],
                       rootFamily=roots[0], phase='screen', revision=0, seq=0,
                       answeredCount=0, tasks=[], results=[], variants={}, seenQuestions=[],
                       probePath=[], repairQueue=[], repairTarget=None, repairRounds=0,
                       level=0, current=None, feedback=None, teacher='', lesson=None,
                       onlineConsent=False, voiceConsent=False, closeReason=None,
                       dueAt=None, reviewOf=None)
        if answer_flow == 'automatic':
            session.update(answerFlow='automatic', lastTransition=None, coaching=None, automaticHandled=[])
        if profile is not None:
            session.update(profileId=profile['id'], curriculumProfile=copy.deepcopy(profile['curriculumProfile']),
                           curriculumVersion=self.curriculum.version,
                           seenQuestions=[r['signature'] for r in profile['issued']],
                           scopeGroups=[self._root_units(f, profile['curriculumProfile']) for f in roots],
                           uncertainHypotheses=[],
                           progressNeedsConfirmation=not bool(profile['curriculumProfile']['completedUnits']),
                           nextReason='按已确认单元初筛；未知进度仅看最小小数先备，需先确认已学范围。')
        # Caller owns the transaction, including profile changes and capability replay.
        self.db.execute('INSERT INTO sessions VALUES(?,?,?)',
                        (identifier, hashlib.sha256(token.encode()).hexdigest(), json.dumps(session)))
        self._event(session, 'session_started', {'mode': mode, 'scheme': scheme, 'scope': scope,
                                               'minutes': minutes, 'excludedRoots': excluded,
                                               'diagnosisStrategy': strategy})
        first_phase = 'screen'
        if profile is not None:
            due = self._due_roots(profile, roots)
            session['dueReviewRoots'] = due
            first_phase = self.curriculum.root_context(roots[0], session['curriculumProfile'])['recommendedPhase']
            if first_phase == 'probe':
                session['nextReason'] = '只探测关联单元需要的先备；答对不自动确认以前已学或解锁后续课程。'
            if roots[0] in due and first_phase != 'probe':
                first_phase = 'retention'
                session['nextReason'] = '已到24小时复查，先用未见实例独立检验相关字段。'
        due_dimension = self._review_dimension(profile, roots[0]) if profile is not None and first_phase == 'retention' else None
        self._issue(session, roots[0], first_phase, variant=0, target_dimension=due_dimension)
        self._save(session)
        return {**self._view(session), 'token': token}

    def start_request(self, payload, *, owner=None, check_capacity=None):
        """HTTP creation: durable private capability, atomic session/profile/presentation.

        The full response is server-only in the 0600 database, never events/context.
        Cloud binding is retryable after commit because owner is already on the session.
        """
        request = copy.deepcopy(payload)
        key = request.pop('requestId', None)
        if 'requestId' in payload and (not isinstance(key, str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}', key)):
            raise TutorError('invalid_request_id', '开课requestId须为8至100位字母、数字、下划线或连字符。')
        scope = owner or 'local'
        digest = _fingerprint(request)
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            learner = request.get('learner')
            if learner is not None:
                if not isinstance(learner, dict) or set(learner) != {'id', 'token'}:
                    raise TutorError('invalid_profile', '学习档案格式不正确。')
                self._load_profile(learner['id'], learner['token'])
            row = self.db.execute('SELECT owner,payload_hash,response FROM create_requests WHERE request_id=?',
                                  (key,)).fetchone() if key else None
            if row:
                if not hmac.compare_digest(row[0], scope):
                    raise TutorError('access_scope', '请使用当前浏览器自己的课堂记录。', 403)
                if row[1] != digest:
                    raise TutorError('request_id_conflict', '同一开课requestId不能更换档案或课堂参数。', 409)
                initial = json.loads(row[2])
                session = self._load(initial['id'], initial['token'])
                self._settle_expired(session)
                result = {**self._view(session), 'token': initial['token']}
                if 'presentation' in session:
                    result['presentation'] = copy.deepcopy(session['presentation'])
                return result
            if check_capacity:
                check_capacity()
            presentation = request.pop('presentation', None)
            result = self._start(request)
            session = self._load(result['id'], result['token'])
            if owner is not None:
                session['accessOwner'] = owner  # Private only; checked before recovering a missing Cloud binding.
            if presentation is not None:
                session['presentation'] = presentation
                self._event(session, 'presentation_bound', {**presentation,
                    'automaticHelp': request.get('answerFlow') == 'automatic'})
            self._save(session)
            result = {**self._view(session), 'token': result['token']}
            if presentation is not None:
                result['presentation'] = copy.deepcopy(presentation)
            if key:
                self.db.execute('INSERT INTO create_requests VALUES(?,?,?,?,?)',
                                (key, scope, digest, session['id'], json.dumps(result, ensure_ascii=False)))
            return result

    def require_access_owner(self, identifier, token, owner):
        with self.lock:
            session = self._load(identifier, token)
            if not hmac.compare_digest(session.get('accessOwner', ''), owner):
                raise TutorError('access_scope', '请使用当前浏览器自己的课堂记录。', 403)

    def _settle_expired(self, session):
        # Only the actual deadline, not the 180-second new-task reserve, closes on read.
        if (session.get('answerFlow') == 'automatic' and not session['closed']
                and self._elapsed(session) >= session['budgetSeconds']):
            self._close(session, '本次课堂时间已到；初答、草稿和待验证项目已保留。')
            self._save(session)
            return True
        return False

    def settle_expired(self, identifier, token):
        if self.db.in_transaction:
            with self.lock:
                return self._view(self._load(identifier, token))
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            self._settle_expired(session)
            return self._view(session)

    def view(self, identifier, token):
        return self.settle_expired(identifier, token)

    def _view(self, session):
        current = public_question(session['current']) if session['current'] else None
        if current:
            current.pop('signature', None)
        report = self._report(session)
        return {
            'id': session['id'], 'mode': session['mode'], 'scheme': session['scheme'],
            **({'classroom': self._classroom_view(session)} if session.get('teacherWorkspace') else {}),
            **({'answerFlow': 'automatic', 'lastTransition': copy.deepcopy(session.get('lastTransition')),
                'coaching': copy.deepcopy(session.get('coaching'))}
               if session.get('answerFlow') == 'automatic' else {}),
            'scope': session['scope'], 'phase': session['phase'],
            **({'profileId': session['profileId'], 'curriculumProfile': copy.deepcopy(session['curriculumProfile'])}
               if session.get('diagnosisStrategy') == 'personalized' else {}),
            'phaseLabel': PHASE_LABELS.get(session['phase'], session['phase']),
            'revision': session['revision'], 'elapsedSeconds': self._elapsed(session),
            'budgetSeconds': session['budgetSeconds'], 'paused': session['paused'],
            'closed': session['closed'], 'closeReason': session['closeReason'],
            'canContinue': not session['closed'], 'createNewCourse': bool(session['closed']),
            'answeredCount': session['answeredCount'],
            'taskLimit': session['taskLimit'], 'current': current,
            'teacher': session['teacher'], 'feedback': session['feedback'],
            'lesson': session['lesson'], 'onlineConsent': session['onlineConsent'],
            'voiceConsent': session['voiceConsent'], 'report': report,
            **({'presentation': copy.deepcopy(session['presentation'])}
               if 'presentation' in session else {}),
            'diagnosis': self._diagnosis(session),
            'graphVersion': session['graphVersion'], 'dueAt': session['dueAt'],
            'graph': self.graph.subgraph(current['skills'], 2) if current else {'nodes': {}, 'edges': []},
            'trail': [{'instanceId': result['instanceId'], 'family': result['family'],
                       'title': FAMILIES[result['family']]['title'], 'phase': result['phase'],
                       'correct': result['score']['correct'], 'assisted': result['assisted'],
                       'representation': result['representation']}
                      for result in session['results'][-8:]],
        }

    def _diagnosis(self, session):
        roots = session['roots']
        screened = list(dict.fromkeys(session.get('screenedRoots', [])))
        current = session.get('current')
        stage = ('review' if session.get('reviewOf') or session['closed'] else
                 session.get('diagnosisStage', 'focus' if session.get('diagnosisStrategy') == 'focused' else 'sweep'))
        return {'strategy': session.get('diagnosisStrategy', 'focused'), 'stage': stage,
                'screenedDomains': list(dict.fromkeys(FAMILIES[f]['domain'] for f in screened)),
                'plannedDomains': list(dict.fromkeys(FAMILIES[f]['domain'] for f in roots)),
                'screenedRoots': screened, 'plannedRoots': list(roots),
                'currentDomain': FAMILIES[current['family']]['domain'] if current else None,
                'coverageNotice': '仅代表根题初筛，不是全部知识节点测完；跳过不算作答证据。',
                'queuedFollowups': [{key: row[key] for key in
                                     ('rootFamily', 'domain', 'kind', 'skills', 'probes', 'missing', 'status', 'reason')}
                                    for row in session.get('followups', [])],
                'nextReason': session.get('nextReason', '沿兼容focused链继续，先备关系不是错误概率。'),
                **({'scopeGroups': session['scopeGroups'],
                    'progressNeedsConfirmation': session['progressNeedsConfirmation'],
                    'queuedDimensions': [{'instanceId': row['instanceId'], 'dimensions': row['dimensions'],
                                           'kind': row['kind'], 'status': row['status']}
                                          for row in session['followups']]}
                   if session.get('diagnosisStrategy') == 'personalized' else {})}

    def _independent_skills(self, session):
        return {skill for result in self._main_results(session) if not result['assisted']
                for row in result['score']['fieldResults'] if row['correct']
                for skill in row['skillIds']}

    def _followup_probes(self, session, row):
        personalized = session.get('diagnosisStrategy') == 'personalized'
        independent = self._independent_skills(session)
        if personalized:
            profile = self._linked_profile(session)
            independent = set()
            for summary in summarize(profile['evidence'], self.graph, self.clock()):
                relevant = [d for d in summary['dimensions'] if d['dimension'] in row.get('dimensions', [])]
                if relevant and all(d['status'] == 'independently_verified' or
                    (d['status'] == 'unverified' and any(r['correct'] and not r['assisted']
                     and r['evidenceKind'] == 'constructed' for r in d['evidence'])) for d in relevant):
                    independent.add(summary['id'])
        # Direct wrong-field mappings precede registered ancestors. Never family.prerequisite.
        candidates = [{'id': skill, 'distance': 0} for skill in row['skills']]
        candidates += self.graph.nearest_prerequisites(row['skills'])
        probes, missing = [], []
        for candidate in candidates:
            skill = candidate['id']
            if skill in independent:
                continue
            families = [family for family, mapped in self.probe_fields.items() if skill in mapped]
            if personalized:
                families = [f for f in families
                            if self.curriculum.eligible_prerequisite(f, session['curriculumProfile'])
                            and (not row.get('dimensions') or 'unspecified' in row['dimensions'] or any(
                                field.get('diagnosticDimension') in row['dimensions']
                                and skill in q['_field_skills'][field['id']]
                                for v in range(4) for q in [build_question(f, v, 'probe')]
                                for field in q['fields']))]
            if not families:
                missing.append({'id': skill, 'title': self.graph.title(skill), 'reason': 'missing题库：无可评分探针题族'})
                continue
            family = next((f for f in families if f != row['rootFamily'] and
                           f not in session['excludedRoots'] and
                           not any(p['family'] == f for p in probes)), None)
            if family and len(probes) < (1 if personalized else 2):
                probe = {'family': family, 'skillId': skill, 'distance': candidate['distance']}
                if personalized:
                    probe['dimension'] = next((d for d in row.get('dimensions', []) if any(
                        field.get('diagnosticDimension') == d and skill in q['_field_skills'][field['id']]
                        for v in range(4) for q in [build_question(family, v, 'probe')]
                        for field in q['fields'])), None)
                probes.append(probe)
        return probes, missing

    def _queue_followup(self, session, result):
        skills = list(result['score']['wrongSkills'])
        if not skills:
            skills = list(dict.fromkeys(skill for row in result['score']['fieldResults'] for skill in row['skillIds']))
        row = {'rootFamily': result['rootFamily'], 'domain': FAMILIES[result['family']]['domain'],
               'instanceId': result['instanceId'], 'kind': 'error' if not result['score']['correct'] else 'assisted',
               'skills': skills, 'status': 'queued',
               'reason': '错误字段直接证据优先；图谱关系仅作待查候选。' if not result['score']['correct']
                         else '受助初答待独立验证，不从模型回复判断掌握。'}
        row['probes'], row['missing'] = self._followup_probes(session, row)
        session['followups'].append(row)

    def _focus_budget(self, session, family=None, phase='guided', *, candidate=None, root=None):
        """Reserve estimated work for this task and the minimum remaining sequence.

        Future variants use the largest bank estimate, not an invented 60s floor.
        Estimates are planning bounds, never a guarantee of a child's duration.
        """
        family = family or session['rootFamily']
        root = root or session['rootFamily']
        tails = {'probe': ('guided', 'verify', 'transfer'),
                 'teach': ('guided', 'verify', 'transfer'),
                 'guided': ('verify', 'transfer'), 'verify': ('transfer',),
                 'transfer': (), 'challenge': (), 'retention': ()}
        sequence = [(family, phase)] if phase != 'teach' else []
        sequence += [(root if phase == 'probe' else family, following)
                     for following in tails[phase]]
        seconds = 0
        for index, (target_family, target_phase) in enumerate(sequence):
            if index == 0 and candidate is not None:
                seconds += candidate['estimatedSeconds']
            else:
                generation = 'probe' if target_phase == 'guided' else target_phase
                start = session['variants'].get(target_family + ':' + target_phase, 0)
                seconds += max(build_question(target_family, start + offset, generation,
                                              min(2, session['level']))['estimatedSeconds']
                               for offset in range(4))
        return (session['taskLimit'] - session['answeredCount'] >= len(sequence)
                and session['budgetSeconds'] - self._elapsed(session) > seconds)

    def _close_focus_budget(self, session):
        session['nextReason'] = '剩余时间或题量不足本题预计时长及必要验证序列，保留队列，不强塞新题；预计时长不是保证。'
        return self._close(session, session['nextReason'])

    def _challenge_family(self, session):
        offered = set(session.get('challengedRoots', []))
        for result in reversed(self._main_results(session)):
            root = result['rootFamily']
            if (result['score']['correct'] and not result['assisted']
                    and result['family'] == root
                    and result['phase'] != 'challenge' and root not in offered
                    and root not in session['excludedRoots'] and root not in session.get('skippedRoots', [])
                    and any(row['correct'] and row['skillIds'] for row in result['score']['fieldResults'])):
                return root
        return None

    def _breadth_next(self, session, message=None):
        active = session.get('activeFollowup')
        if active is not None:
            row = session['followups'][active]
            if row['status'] == 'active':
                row['status'] = 'pending' if message else 'completed'
            session['activeFollowup'] = None
        session.update(repairQueue=[], repairTarget=None, repairRounds=0, awaitingNext=False)
        if self._limit_reached(session):
            return self._close(session, '本次预算已到；初筛与深查未完成队列保留。')
        if session['pendingRoots']:
            seen_domains = {FAMILIES[f]['domain'] for f in session['screenedRoots']}
            index = next((i for i, f in enumerate(session['pendingRoots'])
                          if FAMILIES[f]['domain'] not in seen_domains), 0)
            family = session['pendingRoots'].pop(index)
            session['nextReason'] = '优先尚未看过的领域根题；错误与受助先记入待查队列。'
            return self._issue(session, family, 'screen', root=family)
        session['diagnosisStage'] = 'focus'
        if not session['focusSelected']:
            for row in session['followups']:
                row['probes'], row['missing'] = self._followup_probes(session, row)
            ranked = sorted((i for i, row in enumerate(session['followups'])
                             if row['rootFamily'] not in session.get('skippedRoots', [])
                             and row['rootFamily'] not in session['excludedRoots']), key=lambda i: (
                session['followups'][i]['kind'] != 'error',
                not bool(session['followups'][i]['skills']),
                not bool(session['followups'][i]['probes']),
                -sum(any(child in mapped for mapped in self.family_fields.values())
                     for skill in session['followups'][i]['skills']
                     for child in self.graph.children.get(skill, [])), i))
            session['focusQueue'] = ranked[:1 if session['mode'] == 'lite' else 2]
            session['focusSelected'] = True
        if session['focusQueue']:
            index = session['focusQueue'][0]
            row = session['followups'][index]
            if not self._focus_budget(session, row['rootFamily'],
                                      'verify' if row['kind'] == 'assisted' else 'guided',
                                      root=row['rootFamily']):
                return self._close_focus_budget(session)
            session['focusQueue'].pop(0)
            row['status'] = 'active'
            session.update(activeFollowup=index, rootFamily=row['rootFamily'],
                           focusProbeCount=0, focusTeachCount=0)
            session['nextReason'] = row['reason']
            if row['kind'] == 'assisted':
                return self._issue(session, row['rootFamily'], 'verify', root=row['rootFamily'])
            return self._focus_probe_or_teach(session)
        eligible = self._challenge_family(session)
        if eligible and not session.get('challengeOffered') and self._focus_budget(session, eligible, 'challenge'):
            session['challengeOffered'] = True
            session.setdefault('challengedRoots', []).append(eligible)
            session['nextReason'] = '选最近有字段级独立正确证据且未挑战的根题，不固定分数族。'
            return self._issue(session, eligible, 'challenge', root=eligible)
        return self._close(session, '代表根题初筛与有限深查收束；其余候选仍待查，不是全图掌握结论。')

    def _focus_probe_or_teach(self, session):
        row = session['followups'][session['activeFollowup']]
        probes, missing = self._followup_probes(session, row)
        row['missing'] = missing
        used = {r['family'] for r in self._main_results(session)
                if r['rootFamily'] == row['rootFamily'] and r['phase'] == 'probe'}
        probe = next((p for p in probes if p['family'] not in used), None)
        if probe and session['focusProbeCount'] < 2:
            session['nextReason'] = '按错误字段与真实图谱找最近可测候选，跳过已独立正确先备；不是根因判定。'
            return self._issue(session, probe['family'], 'probe', root=row['rootFamily'],
                               target_skill=probe['skillId'])
        session['nextReason'] = '最多两次先备探针，只接回本根，不重学整条链。'
        return self._teach(session, row['rootFamily'])

    def _breadth_route(self, session, result):
        phase, family = result['phase'], result['family']
        independent_correct = result['score']['correct'] and not result['assisted']
        if phase in ('screen', 'challenge', 'retention'):
            return self._next_root(session)
        if phase == 'probe':
            if independent_correct:
                return self._teach(session, result['rootFamily'])
            active = session.get('activeFollowup')
            if active is not None:
                row = session['followups'][active]
                row['skills'] = list(dict.fromkeys(row['skills'] + result['score']['wrongSkills']))
            return self._focus_probe_or_teach(session)
        if phase == 'guided':
            if result['score']['correct']:
                return self._issue(session, family, 'verify')
            return self._teach(session, family)
        if phase in ('verify', 'transfer'):
            if independent_correct:
                if phase == 'verify':
                    return self._issue(session, family, 'transfer')
                return self._next_root(session)
            if result['score']['correct']:
                return self._issue(session, family, phase)
            return self._teach(session, family)

    def _bank_coverage(self):
        mapped = set().union(*self.family_fields.values()) & self.graph.nodes.keys()
        gaps = [{'id': key, 'title': node['title'], 'grade': node['grade']}
                for key, node in self.graph.nodes.items() if key not in mapped]
        return {'inventoryCount': len(self.graph.nodes), 'mappedNodeCount': len(mapped), 'gaps': gaps,
                'byGrade': {str(grade): {'inventoryCount': sum(n['grade'] == grade for n in self.graph.nodes.values()),
                                       'mappedNodeCount': sum(self.graph.nodes[k]['grade'] == grade for k in mapped),
                                       'gaps': [row for row in gaps if row['grade'] == grade]}
                            for grade in range(1, 6)},
                'notice': '仅题库可评分字段映射，涵盖各题族4变式各阶段；不是孩子测过或掌握。'}

    @staticmethod
    def _main_results(session):
        return [r for r in session['results'] if not r.get('branchId')]

    def _branch_report(self, session):
        results = [r for r in session['results'] if r.get('branchId')]
        records = [row for result in results for row in evidence_records(session, result)]
        return {'answeredCount': len(results), 'evidenceCount': len(records),
                'skills': summarize(records, self.graph, self.clock(), include_child_tasks=True),
                'results': [{'instanceId': r['instanceId'], 'branchId': r['branchId'],
                             'branchKind': r['branchKind'], 'family': r['family'],
                             'phase': r['phase'], 'assisted': r['assisted'],
                             'fieldResults': copy.deepcopy(r['score']['fieldResults'])} for r in results],
                'notice': '孩子确认的小测支线字段证据；不计主线初筛、主题验证或先备路由。'}

    def _report(self, session):
        branch_report = self._branch_report(session)
        session = {**session, 'results': self._main_results(session),
                   'tasks': [t for t in session['tasks'] if not t.get('branchId')]}
        evidence = {skill: [] for skill in self.graph.nodes}
        task_fields = {task['instanceId']: {field['id']: field['label'] for field in task['fields']}
                       for task in session['tasks']}
        for result in session['results']:
            for row in result['score']['fieldResults']:
                for skill in row['skillIds']:
                    evidence[skill].append({
                        'instanceId': result['instanceId'], 'family': result['family'],
                        'phase': result['phase'], 'correct': row['correct'],
                        'assisted': result['assisted'], 'representation': result['representation'],
                        'constructedCompanion': result['score']['correct'] and any(
                            field.get('evidenceKind') == 'constructed' and field['correct']
                            for field in result['score']['fieldResults']),
                        'field': row['id'], 'fieldLabel': task_fields.get(result['instanceId'], {}).get(row['id'], row['id']),
                        'taskTitle': FAMILIES[result['family']]['title'],
                        'received': row['received'], 'time': result['time'],
                    })
        skills = []
        for skill, rows in evidence.items():
            if not rows:
                continue
            independent = [row for row in rows if row['correct'] and not row['assisted']]
            verifications = [row for row in independent if row['phase'] in ('verify', 'transfer')]
            retained = [row for row in independent if row['phase'] == 'retention']
            validated = [row for row in verifications if row['constructedCompanion']]
            different = (len({row['representation'] for row in validated}) >= 2
                         and len({row['instanceId'] for row in validated}) >= 2)
            wrong = [row for row in rows if not row['correct']]
            supported = [row for row in rows if row['correct'] and row['assisted']]
            if retained:
                status, label = 'retention_evidence', ('有一次延后保持证据' if any(row['constructedCompanion'] for row in retained)
                                                       else '有一次延后选择正确 · 掌握仍待查')
            elif different:
                status, label = 'session_verified', '当次独立变式通过 · 保持待查'
            elif verifications:
                status, label = 'verification_started', ('已有构造性独立证据 · 还需再验' if validated
                                                         else '独立选择正确 · 还缺构造性验证')
            elif independent:
                status, label = 'initial_evidence', '单次独立正确 · 不签掌握'
            elif supported:
                status, label = 'assisted', '帮助后正确 · 还需独立做'
            else:
                status, label = 'needs_probe', '有错误线索 · 原因待查'
            last = rows[-1]
            if not last['correct'] and status in ('session_verified', 'initial_evidence'):
                status, label = 'inconsistent', '前后表现不一致 · 需要再查'
            skills.append({'id': skill, 'title': self.graph.title(skill),
                           'grade': self.graph.nodes[skill]['grade'], 'status': status, 'label': label,
                           'independentCount': len({row['instanceId'] for row in independent}),
                           'assistedCount': len({row['instanceId'] for row in supported}),
                           'wrongCount': len({row['instanceId'] for row in wrong}),
                           'evidence': rows, 'longTermMastery': False})
        measured = {row['id'] for row in skills}
        domains = []
        for domain, name in DOMAIN_NAMES.items():
            rows = [result for result in session['results'] if FAMILIES[result['family']]['domain'] == domain]
            label = ('初筛错误待查' if any(not row['score']['correct'] for row in rows) else
                     '受助待验证' if any(row['assisted'] for row in rows) else
                     '单次独立正确' if any(any(field['skillIds'] for field in row['score']['fieldResults'])
                                           for row in rows) else
                     '仅题目作答，节点未测' if rows else '未看')
            domains.append({'id': domain, 'name': name, 'measured': bool(rows),
                            'questions': len(rows), 'label': label})
        hypotheses = []
        for result in session['results']:
            if result['score']['correct']:
                continue
            meta = FAMILIES[result['family']]
            prerequisite = meta['prerequisite']
            tested = [row for row in session['results']
                      if prerequisite and row['family'] == prerequisite and row['rootFamily'] == result['rootFamily']]
            hypotheses.append({
                'family': result['family'], 'title': meta['title'],
                'wrongSkills': [self.graph.title(skill) for skill in result['score']['wrongSkills']],
                'evidence': '、'.join(f"{task_fields.get(result['instanceId'], {}).get(row['id'], row['id'])}：{row['received']}" for row in result['score']['fieldResults']
                                    if not row['correct'])[:220],
                'prerequisiteTitle': FAMILIES[prerequisite]['title'] if prerequisite else None,
                'prerequisiteStatus': ('对照小问正确，不能把前置标为薄弱' if tested and tested[-1]['score']['correct']
                                       else '对照小问也错，继续追查；仍不称唯一根因' if tested
                                       else '尚未直接检验，不从原题错误推断'),
                'percentage': None,
            })
        verified = [row for row in skills if row['status'] == 'session_verified']
        need = [row for row in skills if row['status'] in ('needs_probe', 'assisted', 'inconsistent')]
        next_title = need[0]['title'] if need else verified[0]['title'] if verified else '当前有限证据对应的独立变式'
        personalization = (self._personalization(session)
                           if session.get('diagnosisStrategy') == 'personalized' else None)
        return {
            'bankCoverage': self._bank_coverage(),
            **({'childTasks': branch_report} if branch_report['answeredCount'] else {}),
            **({'personalization': personalization, 'summary': copy.deepcopy(personalization['summary'])}
               if personalization is not None else {}),
            'unmeasuredByGrade': {str(grade): [{'id': key, 'title': node['title'], 'grade': grade}
                                             for key, node in self.graph.nodes.items()
                                             if node['grade'] == grade and key not in measured]
                                  for grade in range(1, 6)},
            'pending': [{key: value for key, value in row.items() if key != 'draft'}
                        for row in session.get('pending', [])],
            'excludedInstances': list(session.get('excludedInstances', [])),
            'skippedRoots': list(session.get('skippedRoots', [])),
            'inventoryCount': len(self.graph.nodes), 'directlyMeasured': len(measured),
            'unmeasuredCount': len(self.graph.nodes) - len(measured),
            'unmeasured': [{'id': key, 'title': node['title'], 'grade': node['grade']}
                           for key, node in self.graph.nodes.items() if key not in measured],
            'skills': skills, 'domains': domains, 'hypotheses': hypotheses[-8:],
            'verifiedThisSession': len(verified), 'reviewDueAt': session['dueAt'],
            'next': f'优先接回「{next_title}」，先无提示再做，不从次数推断掌握。',
            'notice': f'本地课程{len(self.graph.nodes)}节点索引；本次仅有直接作答证据。未知节点不判弱，概率未标定。',
            'thinkingNotice': '结构化关系和数值已核；自由口述、手写及开放推理未经可靠评分，不生成思维分。',
            'closeReason': session['closeReason'], 'reviewOf': session['reviewOf'],
            'excludedRoots': session['excludedRoots'],
            'excludedTitles': [FAMILIES[family]['title'] for family in session['excludedRoots'] if family in FAMILIES],
        }

    def _settled_action(self, identifier, token):
        with self.lock:
            was_closed = self._load(identifier, token)['closed']
            view = self.settle_expired(identifier, token)
            return view if not was_closed and view['closed'] else None

    def draft(self, identifier, token, payload):
        settled = self._settled_action(identifier, token)
        if settled:
            return settled
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            self._require_current(session, payload)
            answers = payload.get('answers', {})
            if not isinstance(answers, dict) or len(json.dumps(answers, ensure_ascii=False)) > 6000:
                raise TutorError('invalid_answers', '作答数据太长或格式不正确。')
            work = _clean_text(payload.get('workText', ''), 2400)
            strokes = payload.get('strokes', [])
            if not isinstance(strokes, list) or len(strokes) > 250 or len(json.dumps(strokes)) > 220000:
                raise TutorError('invalid_strokes', '笔迹容量已满；已有草稿保留，可以继续写文字。')
            for stroke in strokes:
                if not isinstance(stroke, list) or len(stroke) > 3000 or any(
                    not isinstance(point, list) or len(point) != 2 or any(
                        type(coordinate) not in (int, float) or not 0 <= coordinate <= 1
                        for coordinate in point) for point in stroke):
                    raise TutorError('invalid_strokes', '笔迹坐标无效；没有覆盖已有草稿。')
            current = session['current']
            if session.get('awaitingNext') or any(
                    result['instanceId'] == current['instanceId'] for result in session['results']):
                raise TutorError('already_answered', '初答已经提交；同题辅导不覆盖初答草稿。', 409)
            current.update(answers=copy.deepcopy(answers), workText=work, strokes=copy.deepcopy(strokes))
            self._event(session, 'draft_saved', {'instanceId': current['instanceId'], 'answers': answers,
                                                'workText': work, 'strokes': strokes})
            self._save(session)
            return {'saved': True, 'revision': session['revision']}

    def _require_current(self, session, payload):
        if session['closed'] or not session['current']:
            raise TutorError('session_closed', '今天的课堂已收束，原记录仍保留。', 409)
        if payload.get('instanceId') != session['current']['instanceId']:
            raise TutorError('stale_question', '题目已更新；没有把旧回答记到新题。', 409)
        if payload.get('revision', session['revision']) != session['revision']:
            raise TutorError('stale_revision', '页面版本已变化，请回到当前题。', 409)

    def answer(self, identifier, token, payload):
        settled = self._settled_action(identifier, token)
        if settled:
            return settled
        request_id = payload.get('requestId')
        if not isinstance(request_id, str) or not 8 <= len(request_id) <= 100:
            raise TutorError('invalid_request_id', '这次提交缺少唯一标识。')
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            previous = self.db.execute('SELECT result FROM requests WHERE session_id=? AND request_id=?',
                                       (identifier, request_id)).fetchone()
            if previous:
                cached = json.loads(previous[0])
                if session.get('answerFlow') == 'automatic' and cached.get('flowAction') == 'finish_coaching':
                    raise TutorError('request_id_conflict', 'requestId已用于结束辅导。', 409)
                return cached
            self._require_current(session, payload)
            if session.get('awaitingNext') or any(
                    result['instanceId'] == session['current']['instanceId'] for result in session['results']):
                raise TutorError('already_answered', '这一题已经交给老师；初答保留，请继续下一步。', 409)
            if session['paused']:
                raise TutorError('paused', '先继续课堂，再提交；草稿已经保留。', 409)
            if self._limit_reached(session):
                raise TutorError('budget_reached', '本次时间或题量已到；草稿保留，今天先收束。', 409)
            answers = payload.get('answers', {})
            if not isinstance(answers, dict) or len(json.dumps(answers)) > 6000:
                raise TutorError('invalid_answers', '作答格式不正确。')
            current = session['current']
            score = evaluate_question(current, answers)
            if score['missing']:
                return {**self._view(session), 'missingFields': score['missing'],
                        'message': '还没写完的地方先留在这里，不当成错误。'}
            current['answers'] = copy.deepcopy(answers)
            if 'workText' in payload:
                current['workText'] = _clean_text(payload['workText'], 2400)
            assisted = bool(current['helped'] or current['scaffolded'] or session['phase'] == 'guided')
            result = {'instanceId': current['instanceId'], 'family': current['family'],
                      'rootFamily': current['rootFamily'], 'phase': session['phase'],
                      'representation': current['representation'], 'signature': current['signature'],
                      'score': score, 'assisted': assisted, 'time': self.clock(),
                      'workText': current['workText'], 'strokes': current['strokes'],
                      'answers': copy.deepcopy(answers), 'stepEvents': copy.deepcopy(current['stepEvents']),
                      **({'toolEvents': copy.deepcopy(current['toolEvents'])}
                         if session.get('diagnosisStrategy') == 'personalized' else {})}
            session['results'].append(result)
            session['answeredCount'] += 1
            root_probe = (not session.get('teacherBranch') and session.get('diagnosisStrategy') == 'personalized'
                          and result['phase'] == 'probe' and result['family'] == result['rootFamily']
                          and session.get('activeFollowup') is None)
            if (result['phase'] == 'screen' or root_probe) and result['family'] not in session['screenedRoots']:
                session['screenedRoots'].append(result['family'])
            if not session.get('teacherBranch') and session.get('diagnosisStrategy') == 'breadth' and result['phase'] == 'screen':
                if not score['correct'] or assisted:
                    self._queue_followup(session, result)
                session['nextReason'] = '先记下字段证据；继续尚未看过的领域，不立即换低阶题。'
            session['feedback'] = {
                'correct': score['correct'], 'assisted': assisted,
                'title': '这一步对上了' if score['correct'] else '这一处值得一起看看',
                'text': ('有帮助的正确保留，下一题会移开提示。' if assisted and score['correct'] else
                         '记下一条独立作答证据，不只凭这一次签掌握。' if score['correct'] else
                         '我们用更小的问题分清卡点，不把整条前置链都判成不会。'),
                'fieldResults': score['fieldResults'],
            }
            if not session.get('teacherBranch') and session.get('diagnosisStrategy') == 'breadth' and result['phase'] == 'screen':
                session['feedback']['text'] = (
                    '受助初答先记下，待初筛后再独立验证；下一步看看另一领域。' if assisted else
                    '独立初答先记下，不签掌握；下一步看看另一领域。' if score['correct'] else
                    '错误字段先记入待查队列；下一步看看另一领域，不立即换更小题。')
            if not session.get('teacherBranch') and session.get('diagnosisStrategy') == 'personalized' and result['phase'] == 'screen':
                followup = self._personalized_followup(session, result)
                session['feedback']['text'] = ('计算与理由分开记录，稍后用一个未见对照核查。'
                    if followup and followup['kind'] == 'contrast' else
                    '先记录实际字段证据；继续已学单元组，独立验证不从单次正确推断。')
            if root_probe:
                followup = self._personalized_followup(session, result) if not session['progressNeedsConfirmation'] else None
                if followup:
                    followup.update(kind='prerequisite_probe', probes=[],
                        reason='先备最多追加一次未见独立对照；不据探测确认以前已学或解锁关联课程。')
                session['feedback']['text'] = '只记录先备字段证据；请显式确认以前已学，答对不自动解锁关联课程。'
            if session.get('teacherBranch'):
                result['branchId'] = session['teacherBranch']['id']
                result['branchKind'] = session['teacherBranch']['kind']
            self._event(session, 'answer_submitted', result)
            session['awaitingNext'] = True
            if session.get('teacherBranch'):
                result['branchId'] = session['teacherBranch']['id']
                result['branchKind'] = session['teacherBranch']['kind']
                session['teacherBranch']['status'] = 'review'
                session['revision'] += 1
            elif session.get('answerFlow') == 'automatic':
                self._automatic_advance(session, result)
            self._save(session)
            view = self._view(session)
            if session.get('answerFlow') == 'automatic' and not session.get('teacherBranch'):
                view['transition'] = copy.deepcopy(session['lastTransition'])
            self.db.execute('INSERT INTO requests VALUES(?,?,?)',
                            (identifier, request_id, json.dumps(view, ensure_ascii=False)))
            return view

    def _automatic_advance(self, session, result):
        """Called only inside the answer transaction, after the one immutable score."""
        if result['instanceId'] in session.setdefault('automaticHandled', []):
            return
        feedback = copy.deepcopy(session['feedback'])
        feedback['text'] = ('初答字段证据已记录，不凭整题正确签全部维度掌握。'
                            if result['score']['correct'] else
                            '保留这道题和你的初答，老师现在围绕这一处与你一起分析。')
        session['feedback'] = feedback
        session['coaching'] = None
        if not result['score']['correct']:
            self._teach(session, result['family'])
            kind = 'coach'
        else:
            session['awaitingNext'] = False
            if result['phase'] in ('verify', 'retention') and not result['assisted']:
                self._issue(session, result['rootFamily'], 'transfer', root=result['rootFamily'],
                            target_dimension=session['current'].get('targetDimension'))
            elif result['assisted']:
                self._issue(session, result['rootFamily'], 'verify', root=result['rootFamily'])
            else:
                self._personalized_next(session)
            kind = 'advanced'
        session['lastTransition'] = {
            'fromInstanceId': result['instanceId'], 'kind': kind, 'feedback': feedback,
            'toInstanceId': session['current']['instanceId'] if session['current'] and not session['closed'] else None,
            'phase': session['phase'], 'revision': session['revision'], 'closed': session['closed']}
        session['automaticHandled'].append(result['instanceId'])
        self._event(session, 'automatic_transition', session['lastTransition'])

    def _teach(self, session, family, queue=None):
        if session.get('answerFlow') == 'automatic':
            # Never restore a screen task: the most recent verify/transfer error is the anchor.
            current = session['current']
            submitted = next((r for r in reversed(session['results'])
                              if r['instanceId'] == current['instanceId']), None)
            if submitted is None or submitted['score']['correct']:
                raise TutorError('coaching_requires_error', '同题辅导必须绑定真实已提交错误。', 409)
            if (session.get('coaching') or {}).get('instanceId') == current['instanceId']:
                return
            active = session.get('activeFollowup')
            if active is None:
                active = next((i for i, row in enumerate(session['followups'])
                               if row['instanceId'] == submitted['instanceId']), None)
            if active is None:
                self._personalized_followup(session, submitted)
                active = len(session['followups']) - 1
            row = session['followups'][active]
            row.update(instanceId=submitted['instanceId'], kind='error', status='active', probes=[],
                       skills=list(submitted['score']['wrongSkills']),
                       dimensions=list(dict.fromkeys(r.get('diagnosticDimension', 'unspecified')
                           for r in submitted['score']['fieldResults'] if not r['correct'])))
            session.update(activeFollowup=active, rootFamily=submitted['rootFamily'],
                           repairTarget=submitted['rootFamily'], repairQueue=[], phase='teach',
                           diagnosisStage='focus', awaitingNext=False)
            current.update(helped=True, sameQuestion=True, initialAnswerLocked=True,
                           assistedInitial=submitted['assisted'])
            session['lesson'] = {'family': current['family'], 'title': current['title'],
                'sameQuestion': True, 'originalInstanceId': current['instanceId'],
                'initialAnswerLocked': True, 'providerRequired': True,
                'notice': '主线程TextProvider围绕当前题辅导；辅导对话不新增正确证据。'}
            session['teacher'] = '我们留在这道题，先看看你刚才是怎样想的。'
            session['revision'] += 1
            session['coaching'] = {'instanceId': current['instanceId'],
                'rootFamily': submitted['rootFamily'], 'evidencePhase': submitted['phase'],
                'revision': session['revision'], 'correctness': False,
                'assistedInitial': submitted['assisted'], 'initialAnswerLocked': True,
                'readyAction': 'finish_coaching'}
            self._event(session, 'teaching_started', copy.deepcopy(session['coaching']))
            return
        if session.get('diagnosisStrategy') == 'breadth' and not session.get('reviewOf'):
            if not self._focus_budget(session, family, 'teach'):
                return self._close_focus_budget(session)
            if session.get('focusTeachCount', 0) >= 2:
                return self._next_root(session, '本根补教循环已到，保留待查。')
            session['focusTeachCount'] = session.get('focusTeachCount', 0) + 1
            root = session['rootFamily']
            original = next((task for task in session['tasks']
                             if task['phase'] == 'screen' and task['family'] == root
                             and task['rootFamily'] == root), None)
            submitted = next((result for result in session['results']
                              if original and result['instanceId'] == original['instanceId']), None)
            if original and submitted:
                # Resume the real original instance, not a new question or a probe.
                restored = copy.deepcopy(original)
                restored.update(answers=copy.deepcopy(submitted['answers']),
                                workText=submitted['workText'], strokes=copy.deepcopy(submitted['strokes']),
                                stepEvents=copy.deepcopy(submitted['stepEvents']),
                                helped=submitted['assisted'])
                session['current'] = restored
        if session.get('diagnosisStrategy') == 'personalized':
            family = session['rootFamily']
            if not self._personalized_budget(session, family, 'teach', root=family):
                return self._next_root(session, '不足原题补教及必要独立验证预算，保留待查。')
            if session.get('focusTeachCount', 0) >= 2:
                return self._next_root(session, '原题补教循环已到，保留真实字段冲突。')
            active = session.get('activeFollowup')
            anchor = session['followups'][active]['instanceId'] if active is not None else None
            original = next((task for task in session['tasks'] if task['instanceId'] == anchor
                             and task['family'] == family and task['rootFamily'] == family), None)
            if original is None:
                original = next((task for task in reversed(session['tasks'])
                                 if task['family'] == family and task['rootFamily'] == family
                                 and task['phase'] in ('screen', 'retention')
                                 and any(r['instanceId'] == task['instanceId'] for r in session['results'])), None)
            submitted = next((r for r in session['results'] if original
                              and r['instanceId'] == original['instanceId']), None)
            if original is None or submitted is None:
                return self._next_root(session, '缺少已提交的原根题，不用先备题冒充原题辅导。')
            restored = copy.deepcopy(original)
            restored.update(answers=copy.deepcopy(submitted['answers']),
                            workText=submitted['workText'], strokes=copy.deepcopy(submitted['strokes']),
                            stepEvents=copy.deepcopy(submitted['stepEvents']),
                            toolEvents=copy.deepcopy(submitted.get('toolEvents', original.get('toolEvents', []))),
                            helped=True, sameQuestion=True, initialAnswerLocked=True)
            session['current'] = restored
            session['feedback'] = {'correct': submitted['score']['correct'],
                                   'assisted': submitted['assisted'],
                                   'title': '接回你的原题初答',
                                   'text': '原初答与草稿保持不变；现在辅导不新增评分证据。',
                                   'fieldResults': copy.deepcopy(submitted['score']['fieldResults'])}
            session['focusTeachCount'] = session.get('focusTeachCount', 0) + 1
        meta = FAMILIES[family]
        session['repairTarget'] = family
        session['repairQueue'] = list(queue or [])
        session['phase'] = 'teach'
        session['diagnosisStage'] = 'focus'
        session['lesson'] = {'family': family, 'title': meta['title'], 'text': meta['teaching'],
                             'hint': meta['hint'], 'skills': meta['skills'],
                             'prerequisiteTitle': FAMILIES[meta['prerequisite']]['title'] if meta['prerequisite'] else None,
                             'notice': '现在是辅导，不计独立掌握；随后会移开提示。',
                             'example': self._teaching_example(family)}
        if session.get('diagnosisStrategy') == 'personalized':
            session['lesson'].update(sameQuestion=True, originalInstanceId=session['current']['instanceId'],
                                     initialAnswerLocked=True)
        session['teacher'] = '刚才的小问帮我们缩小了范围。只补这一处，再交回给你。'
        session['revision'] += 1
        session['awaitingNext'] = False
        self._event(session, 'teaching_started', {'family': family, 'skills': meta['skills']})

    @staticmethod
    def _teaching_example(family):
        examples = {
            'fraction_compare': {
                'prompt': '辅导例子：同一整体的1/2与1/3，用同样大小的份比较。',
                'diagram': {'kind': 'ribbons', 'a': [3, 6], 'b': [2, 6], 'sameWhole': True},
                'explanation': '把一半切成3个六分之一，把三分之一切成2个六分之一。每份一样大，再比较份数；你也可以用数轴或自己的合理方法。'},
            'fraction_equal': {
                'prompt': '辅导例子：一条纸带的1/3，每份再平均分成2小份。',
                'diagram': {'kind': 'ribbons', 'a': [1, 3], 'b': [2, 6], 'sameWhole': True},
                'explanation': '整条变成6小份，原来选中的变成2小份，所以1/3与2/6同样多。不是只改变分母。'},
            'fraction_meaning': {
                'prompt': '辅导例子：一盒8颗珠子是整体，取出3颗。',
                'diagram': {'kind': 'table', 'headers': ['整体颗数', '取出颗数', '占整体'], 'rows': [[8, 3, '3/8']]},
                'explanation': '这里把整盒当成1，每颗是整盒的八分之一，3颗就是八分之三。换成不同整盒，实际颗数要另查。'},
            'sharing': {'prompt': '辅导例子：12块点心平均分给3人。',
                        'diagram': {'kind': 'table', 'headers': ['总数', '人数', '每人'], 'rows': [[12, 3, 4]]},
                        'explanation': '每个人一样多且全部分完：12÷3＝4。用3个人各4块检查，合起来仍是12。'},
            'decimal_compare': {'prompt': '辅导例子：0.4与0.35，比较相同数位。',
                                'diagram': {'kind': 'table', 'headers': ['写法', '对齐到百分位'], 'rows': [['0.4', '0.40'], ['0.35', '0.35']]},
                                'explanation': '0.4末尾补0，量没有改变。40个百分之一比35个百分之一多，不是数字写得长就更大。'},
            'decimal_place': {'prompt': '辅导例子：2.47里的4与7各表示什么？',
                              'diagram': {'kind': 'place', 'value': '2.47'},
                              'explanation': '4在十分位，表示0.4；7在百分位，表示0.07。同一个数字的位置决定它表示的量。'},
            'area_conversion': {'prompt': '辅导例子：1平方分米能铺多少1平方厘米的小格？',
                                'diagram': {'kind': 'grid', 'columns': 10, 'rows': 10, 'cellUnit': 'cm'},
                                'explanation': '边长1分米是10厘米。横向10格、纵向10格，共100格，所以面积换单位要同时考虑两个方向。'},
            'rectangle_area': {'prompt': '辅导例子：长4厘米、宽3厘米的长方形。',
                               'diagram': {'kind': 'grid', 'columns': 4, 'rows': 3, 'cellUnit': 'cm'},
                               'explanation': '每行4个单位小格，有3行，面积4×3＝12平方厘米。面积是铺满的多少，不是边界一圈。'},
            'equation': {'prompt': '辅导例子：2个同样盒子，加3支散装笔，共13支。',
                         'diagram': {'kind': 'equation', 'count': 2, 'offset': 3, 'total': 13},
                         'explanation': '先把两边都减去散装的3支，剩10支在两个盒子里。平均每盒5支，再代回2×5＋3＝13检查。'},
            'average': {'prompt': '辅导例子：3次读数是4、6、8。',
                        'diagram': {'kind': 'bars', 'values': [4, 6, 8]},
                        'explanation': '总量4＋6＋8＝18，平均分成3次，每次6。平均数不一定是每次都实际出现的数；合并不同人数先合总量。'},
            'perimeter_area': {'prompt': '辅导例子：长4厘米、宽3厘米；围边和铺面。',
                               'diagram': {'kind': 'grid', 'columns': 4, 'rows': 3, 'cellUnit': 'cm'},
                               'explanation': '周长4＋3＋4＋3＝14厘米，面积4×3＝12平方厘米。两者单位和含义不同。'},
            'remainder': {'prompt': '辅导例子：14颗珠子，每5颗装满一袋。',
                          'diagram': {'kind': 'table', 'headers': ['总颗数', '满袋', '剩下'], 'rows': [[14, 2, 4]]},
                          'explanation': '装满2袋用了10颗，还剩4颗，不能再装满一袋。余数必须比一袋所需的5颗少。'},
            'listing': {'prompt': '辅导例子：2件上衣和2种下装，怎样不漏？',
                        'diagram': {'kind': 'table', 'headers': ['固定上衣', '依次搭配下装'], 'rows': [['红衣', '短裤、长裤'], ['蓝衣', '短裤、长裤']]},
                        'explanation': '先固定红衣，把每种下装走一遍；再固定蓝衣重复。最后检查有没有重复、遗漏或违反条件。'},
        }
        return examples.get(family)

    def _next_root(self, session, message=None):
        if session.get('diagnosisStrategy') == 'personalized':
            return self._personalized_next(session, message)
        if session.get('diagnosisStrategy') == 'breadth' and not session.get('reviewOf'):
            return self._breadth_next(session, message)
        session['repairQueue'] = []
        session['repairTarget'] = None
        session['repairRounds'] = 0
        session['awaitingNext'] = False
        if self._limit_reached(session):
            return self._close(session, '本次时间或题量预算已到；还没测、还没验证的内容保留待查。')
        if session['pendingRoots']:
            family = session['pendingRoots'].pop(0)
            self._issue(session, family, 'retention' if session.get('reviewOf') else 'screen', root=family)
            if message:
                session['teacher'] = message
        else:
            eligible = next((result['rootFamily'] for result in self._main_results(session)
                             if not session.get('reviewOf') and result['score']['correct'] and not result['assisted']
                             and result['phase'] == 'screen'), None)
            if eligible and not session.get('challengeOffered'):
                session['challengeOffered'] = True
                self._issue(session, eligible, 'challenge', root=eligible)
            else:
                self._close(session, '代表领域已筛查；这是有限证据，不是全部知识点结论。')

    def next(self, identifier, token):
        settled = self._settled_action(identifier, token)
        if settled:
            return settled
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            if session['closed']:
                return self._view(session)
            if session.get('teacherBranch'):
                raise TutorError('teacher_return_required', '支线保留反馈，请返回原题或显式开启另一题。', 409)
            if session.get('answerFlow') == 'automatic':
                if session['phase'] == 'teach':
                    raise TutorError('finish_coaching_required', '准备好后请确认结束同题辅导，不能跳到简化题。', 409)
                return self._view(session)  # A legacy next click cannot advance twice.
            if session['paused']:
                raise TutorError('paused', '先继续课堂；不会丢掉当前步骤。', 409)
            if self._limit_reached(session):
                self._close(session, '本次预算已到，今天先收束；未完成内容原位保存。')
            elif session['phase'] == 'teach':
                self._issue(session, session['repairTarget'], 'guided')
            elif not session.get('awaitingNext'):
                raise TutorError('answer_first', '先把当前题交给老师；不需要全部答对才继续。', 409)
            else:
                result = next((r for r in reversed(self._main_results(session))
                               if r['instanceId'] == session['current']['instanceId']), None)
                if result is None:
                    raise TutorError('answer_first', '当前原题尚未提交，不能使用支线评分推进。', 409)
                session['awaitingNext'] = False
                family, phase, correct = result['family'], result['phase'], result['score']['correct']
                prerequisite = FAMILIES[family]['prerequisite']
                if session.get('diagnosisStrategy') == 'personalized':
                    self._personalized_route(session, result)
                elif session.get('diagnosisStrategy') == 'breadth' and not session.get('reviewOf'):
                    self._breadth_route(session, result)
                elif phase in ('screen', 'probe'):
                    if correct and phase == 'screen':
                        if result['assisted']:
                            self._issue(session, family, 'verify')
                        elif session['mode'] == 'pro' and family == 'fraction_compare':
                            self._issue(session, family, 'verify')
                        else:
                            self._next_root(session)
                    elif correct:
                        path = session['probePath']
                        target = path[-2] if len(path) > 1 else result['rootFamily']
                        queue = list(reversed(path[:-2]))
                        self._teach(session, target, queue)
                    elif family == 'fraction_compare' and all(
                        row['correct'] for row in result['score']['fieldResults'] if row['id'] == 'equivalent'):
                        self._teach(session, family)
                    elif prerequisite and len(session['probePath']) < (4 if session['mode'] == 'lite' else 7):
                        session['probePath'].append(prerequisite)
                        self._issue(session, prerequisite, 'probe')
                    else:
                        self._teach(session, family, list(reversed(session['probePath'][:-1])))
                elif phase == 'guided':
                    if correct:
                        self._issue(session, family, 'verify')
                    elif session['repairRounds'] < 2:
                        session['repairRounds'] += 1
                        self._teach(session, family, session['repairQueue'])
                    else:
                        self._next_root(session, '这一步还需要更多时间。记下真实卡点，今天先换一类问题。')
                elif phase in ('verify', 'transfer'):
                    if correct and not result['assisted']:
                        if phase == 'verify':
                            self._issue(session, family, 'transfer')
                        elif session['repairQueue']:
                            target = session['repairQueue'].pop(0)
                            self._teach(session, target, session['repairQueue'])
                        else:
                            self._next_root(session, '这条关系已有当次独立证据。隔天还要再验，现在看看另一类。')
                    elif correct:
                        self._issue(session, family, phase)
                    elif session['repairRounds'] < 2:
                        session['repairRounds'] += 1
                        self._teach(session, family, session['repairQueue'])
                    else:
                        self._next_root(session, '换情境后仍有卡点，保留待查；不把提示后的正确说成掌握。')
                elif phase in ('challenge', 'retention'):
                    self._next_root(session)
            self._save(session)
            return self._view(session)

    def _close(self, session, reason):
        if session['closed']:
            return
        active = session.get('activeFollowup')
        if active is not None and session['followups'][active]['status'] == 'active':
            session['followups'][active]['status'] = 'pending'
        session['elapsed'] = self._elapsed(session)
        session['closed'] = True
        session['paused'] = False
        session['phase'] = 'report'
        session['closeReason'] = reason
        session['dueAt'] = self.clock() + 24 * 3600
        session['teacher'] = '今天不是给你贴标签。我们记下做过什么、哪里有证据，下一次从这里接着。'
        session['revision'] += 1
        self._event(session, 'session_closed', {'reason': reason, 'reviewDueAt': session['dueAt']})

    def action(self, identifier, token, payload):
        settled = self._settled_action(identifier, token)
        if settled:
            return settled
        action = payload.get('action')
        if action == 'teacher_cancel':
            return self.cancel_teacher_request(identifier, token, payload)
        if action == 'teacher_return':
            return self.teacher_return(identifier, token, payload)
        if action in ('teacher_accept_task', 'teacher_decline_task'):
            return self.confirm_teacher_task(identifier, token, payload)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            if session.get('teacherBranch') and action in ('finish_coaching', 'skip_current', 'not_learned', 'harder', 'lower'):
                raise TutorError('teacher_return_required', '支线不会推进主线；请使用课堂动作或返回原题。', 409)
            if action == 'finish_coaching':
                request_id = payload.get('requestId')
                if not isinstance(request_id, str) or not 8 <= len(request_id) <= 100:
                    raise TutorError('invalid_request_id', '结束辅导须有唯一requestId。')
                previous = self.db.execute('SELECT result FROM requests WHERE session_id=? AND request_id=?',
                                           (identifier, request_id)).fetchone()
                if previous:
                    cached = json.loads(previous[0])
                    if cached.get('flowAction') != 'finish_coaching':
                        raise TutorError('request_id_conflict', 'requestId已用于其他操作。', 409)
                    return cached
                self._require_current(session, payload)
                coaching = session.get('coaching')
                if (session.get('answerFlow') != 'automatic' or session['phase'] != 'teach'
                        or not coaching or coaching['instanceId'] != payload.get('instanceId')
                        or type(payload.get('revision')) is not int
                        or payload.get('correctness') is not False or payload.get('ready') is not True):
                    raise TutorError('invalid_coaching_confirmation', '须绑定当前错误题、版本并确认准备独立验证，不自封已会。', 409)
                if session['paused']:
                    raise TutorError('paused', '先继续课堂，再确认独立验证。', 409)
                feedback = copy.deepcopy(session['feedback'])
                session['coaching'] = None
                self._event(session, 'coaching_finished', {**coaching, 'ready': True, 'masteryClaim': False})
                self._issue(session, coaching['rootFamily'], 'verify', root=coaching['rootFamily'])
                session['lastTransition'] = {'fromInstanceId': coaching['instanceId'], 'kind': 'advanced',
                    'feedback': feedback, 'toInstanceId': session['current']['instanceId'] if not session['closed'] else None,
                    'phase': session['phase'], 'revision': session['revision'], 'closed': session['closed']}
                self._event(session, 'automatic_transition', session['lastTransition'])
                self._save(session)
                view = {**self._view(session), 'transition': copy.deepcopy(session['lastTransition']),
                        'flowAction': 'finish_coaching'}
                self.db.execute('INSERT INTO requests VALUES(?,?,?)',
                                (identifier, request_id, json.dumps(view, ensure_ascii=False)))
                return view
            elif action == 'finish':
                self._close(session, '孩子主动结束；未测和未完成验证保留待查。')
            elif action == 'pause' and not session['closed']:
                if not session['paused']:
                    session['elapsed'] = self._elapsed(session)
                    session['paused'] = True
                    self._event(session, 'paused')
            elif action == 'resume' and not session['closed']:
                if session['paused']:
                    session['paused'] = False
                    session['activeSince'] = self.clock()
                    self._event(session, 'resumed')
            elif action == 'presentation':
                _keys(payload, ('action', 'instanceId', 'revision', 'presentation', 'resume'))
                self._require_current(session, payload)
                from harness import Harness, AUTOMATIC_POLICY_VERSION
                presentation = Harness.validate_presentation(payload['presentation'])
                if (session.get('answerFlow') != 'automatic'
                        or presentation.get('policyVersion') != AUTOMATIC_POLICY_VERSION
                        or type(payload.get('revision')) is not int
                        or type(payload['resume']) is not bool):
                    raise TutorError('invalid_presentation', '仅在同一自动课堂切换01、05、06，原题与草稿保留。')
                if session['paused'] and payload['resume']:
                    session['paused'] = False
                    session['activeSince'] = self.clock()
                    self._event(session, 'resumed')
                if session.get('presentation') != presentation:
                    session['presentation'] = presentation
                    # Returning from a teacher branch must not restore an older UI.
                    for original in session.get('teacherReturnStack', []):
                        original['presentation'] = copy.deepcopy(presentation)
                    session['revision'] += 1
                    self._event(session, 'presentation_changed', {**presentation, 'assessmentUnchanged': True})
            elif action == 'scheme' and payload.get('scheme') in ('desk', 'steps', 'lab'):
                session['scheme'] = payload['scheme']
                if (session.get('answerFlow') != 'automatic'
                        and session['scheme'] == 'steps' and session['current'] and not session['closed']
                        and not session.get('awaitingNext')
                        and session['phase'] in ('screen', 'probe', 'guided', 'challenge')):
                    session['current']['helped'] = True
                    session['current']['scaffolded'] = True
                    self._event(session, 'help', {'instanceId': session['current']['instanceId'], 'kind': 'scaffold'})
                self._event(session, 'presentation_changed', {'scheme': session['scheme']})
            elif action == 'consent':
                for name in ('onlineConsent', 'voiceConsent'):
                    if name in payload:
                        if type(payload[name]) is not bool:
                            raise TutorError('invalid_consent', '授权状态格式不正确。')
                        session[name] = payload[name]
                self._event(session, 'consent_changed', {'onlineConsent': session['onlineConsent'],
                                                       'voiceConsent': session['voiceConsent']})
            elif action == 'skip_current':
                self._require_current(session, payload)
                if (session.get('awaitingNext') or any(
                        result['instanceId'] == session['current']['instanceId'] for result in session['results'])) and not (
                        session.get('answerFlow') == 'automatic' and session['phase'] == 'teach'):
                    raise TutorError('already_answered', '初答已提交，不能再以跳过覆盖。', 409)
                if session['paused']:
                    raise TutorError('paused', '先继续课堂；跳过没有改变原草稿。', 409)
                if self._limit_reached(session):
                    raise TutorError('budget_reached', '预算已到；未跳过或继续发题。', 409)
                current = session['current']
                row = {'instanceId': current['instanceId'], 'family': current['family'],
                       'rootFamily': current['rootFamily'], 'phase': session['phase'],
                       'reason': '主动暂时不会／先记下，不记错', 'status': 'pending',
                       'draft': {'answers': copy.deepcopy(current['answers']),
                                 'workText': current['workText'], 'strokes': copy.deepcopy(current['strokes'])}}
                session['pending'].append(row)
                session['excludedInstances'].append(current['instanceId'])
                # Exclude from today's reissue, not from the child's curriculum.
                if current['rootFamily'] not in session['skippedRoots']:
                    session['skippedRoots'].append(current['rootFamily'])
                self._event(session, 'skipped_current', row)
                self._next_root(session, '这题暂时记下，不记错；先看下一根题。')
            elif action == 'not_learned':
                self._require_current(session, payload)
                self._event(session, 'not_learned', {'family': session['current']['family'],
                                                     'instanceId': session['current']['instanceId']})
                session['excludedRoots'].append(session['current']['family'])
                self._next_root(session, '这部分先记为尚未学过，不算薄弱。换一个你可以试的问题。')
            elif action in ('hint', 'lower', 'scaffold', 'tool', 'ai_help'):
                self._require_current(session, payload)
                if session['paused']:
                    raise TutorError('paused', '课堂已暂停；原过程保留，继续后才发起辅导。', 409)
                if self._limit_reached(session):
                    raise TutorError('budget_reached', '本次时间或题量已到，未继续辅导请求。', 409)
                current = session['current']
                current['helped'] = True
                if action == 'scaffold':
                    current['scaffolded'] = True
                    current['stepEvents'].append({'type': 'scaffold_opened', 'time': self.clock()})
                if action == 'tool':
                    current['toolEvents'].append({'name': _clean_text(payload.get('name', 'diagram'), 80),
                                                  'time': self.clock()})
                self._event(session, 'help', {'instanceId': current['instanceId'], 'kind': action})
                if (action == 'lower' and session.get('answerFlow') != 'automatic'
                        and session.get('diagnosisStrategy') == 'focused'
                        and not session.get('awaitingNext')):
                    prerequisite = FAMILIES[current['family']]['prerequisite']
                    if prerequisite:
                        session['probePath'].append(prerequisite)
                        self._issue(session, prerequisite, 'probe')
                    else:
                        self._teach(session, current['family'])
                elif action == 'hint':
                    session['teacher'] = FAMILIES[current['family']]['hint']
            elif action == 'harder':
                self._require_current(session, payload)
                if session['paused']:
                    raise TutorError('paused', '先继续课堂，再请求挑战。', 409)
                if self._limit_reached(session):
                    raise TutorError('budget_reached', '预算已到，未发新挑战。', 409)
                if session.get('diagnosisStrategy') == 'personalized':
                    session['teacher'] = '先完成当前已学单元和独立验证，不越范围临时加挑战。'
                    self._save(session)
                    return self._view(session)
                if session.get('diagnosisStrategy') == 'breadth':
                    if session.get('diagnosisStage') == 'sweep':
                        session['teacher'] = '先看完代表领域，再按独立证据挑挑战；不打断初筛。'
                        self._save(session)
                        return self._view(session)
                    eligible = self._challenge_family(session)
                    if eligible:
                        session.setdefault('challengedRoots', []).append(eligible)
                        session['nextReason'] = '选择最近字段级独立正确、尚未重复挑战的根题。'
                        self._issue(session, eligible, 'challenge', root=eligible)
                    else:
                        session['teacher'] = '先留下独立作答证据；不重复挑战或固定回到分数题。'
                    self._save(session)
                    return self._view(session)
                last = next((result for result in reversed(session['results'])
                             if result['rootFamily'] == session['rootFamily']
                             and result['score']['correct'] and not result['assisted']), None)
                if not last:
                    session['teacher'] = '先留下一次独立作答，再推荐挑战。你也可以继续试当前题。'
                else:
                    self._issue(session, session['rootFamily'], 'challenge')
            else:
                raise TutorError('invalid_action', '这个动作不在当前课堂范围内。')
            self._save(session)
            return self._view(session)

    def context(self, identifier, token, require_consent=True):
        with self.lock:
            session = self._load(identifier, token)
            if require_consent and not session['onlineConsent']:
                raise TutorError('consent_required', '启用在线老师前，先确认只发送当前题和必要过程。', 403)
            if require_consent and (session['closed'] or session['paused']):
                raise TutorError('session_inactive', '课堂已暂停或结束；未继续在线调用。', 409)
            if require_consent and session.get('answerFlow') != 'automatic' and self._limit_reached(session):
                raise TutorError('budget_reached', '本次课堂预算已到；未继续在线调用。', 409)
            question = public_question(session['current']) if session['current'] else None
            if question:
                question.pop('signature', None)
            current = session.get('current')
            scored = next((r for r in reversed(session['results'])
                           if current and r['instanceId'] == current['instanceId']), None)
            student_evidence = []
            if current:
                graded = {row['id']: row for row in scored['score']['fieldResults']} if scored else {}
                for field in current['fields']:
                    row = {'fieldId': field['id'], 'label': field['label'],
                           'skillIds': list(current['_field_skills'].get(field['id'], [])),
                           'source': 'scored' if scored else 'draft',
                           'received': copy.deepcopy((scored['answers'] if scored else current['answers']).get(field['id']))}
                    if session.get('diagnosisStrategy') == 'personalized':
                        row['diagnosticDimension'] = field.get('diagnosticDimension', 'unspecified')
                        if field['id'] in graded:
                            row['reason'] = copy.deepcopy(graded[field['id']].get('reason'))
                    if field['id'] in graded:
                        row['correct'] = graded[field['id']]['correct']
                        row['assisted'] = scored['assisted']
                    student_evidence.append(row)
            diagnostic_evidence = []
            if current and session.get('diagnosisStrategy') in ('breadth', 'personalized') and not session.get('reviewOf'):
                diagnostic_evidence = [
                    {'phase': result['phase'], 'family': result['family'],
                     'skillIds': list(row['skillIds']), 'received': copy.deepcopy(row['received']),
                     'correct': row['correct'], 'assisted': result['assisted'],
                     **({'diagnosticDimension': row.get('diagnosticDimension', 'unspecified'),
                         'reason': copy.deepcopy(row.get('reason'))}
                        if session.get('diagnosisStrategy') == 'personalized' else {})}
                    for result in session['results']
                    if not result.get('branchId') and result['rootFamily'] == current['rootFamily'] and result['phase'] == 'probe'
                    for row in result['score']['fieldResults']]
            dialogue = []
            records = self.db.execute("SELECT data FROM events WHERE session_id=? AND kind='model_reply' ORDER BY seq DESC",
                                      (identifier,)).fetchall()
            for record in records:
                data = json.loads(record[0])
                reply = data.get('reply')
                if not current or data.get('instanceId') != current['instanceId'] or not isinstance(reply, dict):
                    continue
                # Whitelist public dialogue only, never receipt, credentials or private reasoning.
                if not isinstance(reply.get('reply'), str):
                    continue
                valid = self._output_representation_valid(current, reply)
                notice = self._representation_notice()
                dialogue.append({'studentQuestion': str(data.get('studentQuestion', ''))[:2400],
                                 'reply': {'reply': reply['reply'][:6000] if valid else notice['reply'],
                                           'question': str(reply.get('question', ''))[:2400] if valid else notice['question']},
                                 **({} if valid else {'representationState': 'rejected',
                                     'representationCode': 'teacher_representation_mismatch'})})
                if len(dialogue) == 4:
                    break
            personalized = session.get('diagnosisStrategy') == 'personalized'
            extra = {}
            if personalized:
                profile = self._linked_profile(session)
                extra = {'curriculumProfile': copy.deepcopy(session['curriculumProfile']),
                         'scopeRole': current.get('scopeRole') if current else None,
                         'rootContext': copy.deepcopy(current.get('rootContext')) if current else None,
                         'priorProbe': bool(current and current.get('priorProbe')),
                         'priorProbeFlags': {'isPrerequisite': bool(current and current.get('priorProbe')),
                                             'targetSkill': current.get('targetSkill') if current else None,
                                             'targetDimension': current.get('targetDimension') if current else None},
                         'personalizedSummary': model_summary(profile['evidence'], self.graph, self.clock(),
                             current['skills'] if current else [])}
            if session.get('answerFlow') == 'automatic':
                extra.update(answerFlow='automatic', coaching=copy.deepcopy(session.get('coaching')),
                    sameQuestion=bool(session.get('coaching')),
                    assistedInitial=scored['assisted'] if scored else None,
                    evidencePhase=scored['phase'] if scored else current['phase'] if current else None)
            pending_task = session.get('pendingTeacherTask')
            if pending_task and current and pending_task['instanceId'] == current['instanceId']:
                extra['pendingTask'] = {k: copy.deepcopy(pending_task[k]) for k in ('id', 'family', 'kind', 'level', 'reason')}
            extra.update(availableFamilies=self._available_families(session),
                         board=self._public_board(session.get('teacherWorkspace', {}).get('boards', {}).get(
                             current['instanceId'] if current else None, {'revision': 0, 'blocks': []}), current))
            return {**extra, 'sessionId': session['id'], 'revision': session['revision'], 'phase': session['phase'],
                    'remainingSeconds': max(0, session['budgetSeconds'] - self._elapsed(session)),
                    'question': question, 'lesson': session['lesson'],
                    'diagnosis': self._diagnosis(session),
                    'currentAttempt': {'instanceId': current['instanceId'] if current else None,
                                       'familyPhaseCount': session.get('attempts', {}).get(
                                           current['family'] + ':' + current['phase'], 0) if current else 0,
                                       'submitted': bool(scored),
                                       'helped': bool(current and current['helped']),
                                       'workText': (scored['workText'] if scored else current['workText']) if current else ''},
                    'studentEvidence': student_evidence,
                    'diagnosticEvidence': diagnostic_evidence,
                    'recentTeacherDialogue': list(reversed(dialogue)),
                    'graph': self.graph.subgraph(question['skills'], 2) if question else {},
                    'recentEvidence': session['feedback'], 'teacher': session['teacher'],
                    'version': session['version'], 'graphVersion': session['graphVersion']}

    @staticmethod
    def _teacher_request_id(payload):
        key = payload.get('requestId')
        if not isinstance(key, str) or not 8 <= len(key) <= 100:
            raise TutorError('invalid_request_id', '课堂请求须有8至100字符的requestId。')
        return key

    def interrupt_teacher_requests(self):
        """Explicit host-start recovery only; DB readers must not cancel live work."""
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            for identifier, key, document in self.db.execute(
                    'SELECT session_id,request_id,document FROM teacher_requests').fetchall():
                record = json.loads(document)
                if record['state'] == 'pending':
                    record.update(state='failed', code='interrupted')
                    self._put_teacher_request(identifier, key, record)

    def _expire_teacher_requests(self, identifier):
        """A bounded lease tombstones, never reuses an old request or its late result."""
        now = self.clock()
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            for key, document in self.db.execute(
                    'SELECT request_id,document FROM teacher_requests WHERE session_id=?', (identifier,)).fetchall():
                record = json.loads(document)
                created = record.get('createdAt')
                if (record['state'] == 'pending' and type(created) in (int, float)
                        and now >= created and now - created >= 180):
                    record.update(state='failed', code='interrupted')
                    self._put_teacher_request(identifier, key, record)

    def _teacher_request(self, identifier, key):
        row = self.db.execute('SELECT document FROM teacher_requests WHERE session_id=? AND request_id=?',
                              (identifier, key)).fetchone()
        return json.loads(row[0]) if row else None

    def _put_teacher_request(self, identifier, key, record):
        self.db.execute('INSERT OR REPLACE INTO teacher_requests VALUES(?,?,?)',
                        (identifier, key, json.dumps(record, ensure_ascii=False)))

    def _accepted_teacher_response(self, record, session):
        """Refresh state, never rebind the immutable result/receipt to another question."""
        response = copy.deepcopy(record['response'])
        if 'result' in response and 'session' in response:
            accepted_instance = (response['session'].get('current') or {}).get('instanceId')
            response.setdefault('originInstanceId', record.get('instanceId', accepted_instance))
            response.setdefault('resultInstanceId', accepted_instance)
            accepted_current = response['session'].get('current')
            if not self._output_representation_valid(accepted_current, response['result']):
                response['result'].update(self._representation_notice(), actions=[])
            response['session'] = self._view(session)
        return response

    def teacher_request_replay(self, identifier, token, payload):
        key = self._teacher_request_id(payload)
        with self.lock:
            self._load(identifier, token)
            if not self.db.in_transaction:
                self._expire_teacher_requests(identifier)
            session = self._load(identifier, token)
            record = self._teacher_request(identifier, key)
            if record is None:
                return None
            if record['state'] == 'cancelled' and record.get('payloadHash') is None:
                raise TutorError('teacher_cancelled', '请求已提前取消；没有发起模型调用。', 409)
            if record['payloadHash'] != _fingerprint(payload):
                raise TutorError('request_id_conflict', '同一requestId不能用于不同内容。', 409)
            if record['state'] == 'accepted':
                return self._accepted_teacher_response(record, session)
            code = 'teacher_pending' if record['state'] == 'pending' else record.get('code', 'teacher_cancelled')
            raise TutorError(code, '此请求尚待完成或已取消／失败；没有再次付费或执行。', 409)

    def reserve_teacher_request(self, identifier, token, payload):
        key = self._teacher_request_id(payload)
        with self.lock:
            self._load(identifier, token)
            self._expire_teacher_requests(identifier)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            replay = self.teacher_request_replay(identifier, token, payload)
            if replay is not None:
                return replay
            session = self._load(identifier, token)
            context = self.context(identifier, token)
            self._require_current(session, payload)
            if type(payload.get('revision')) is not int:
                raise TutorError('stale_revision', '课堂动作须绑定明确版本。', 409)
            # The entire session has one outstanding teacher plan, across processes.
            rows = self.db.execute('SELECT document FROM teacher_requests WHERE session_id=?', (identifier,)).fetchall()
            if any(json.loads(row[0])['state'] == 'pending' for row in rows):
                raise TutorError('teacher_pending', '上一轮课堂动作尚未完成，请等待或取消。', 409)
            count = self.db.execute("SELECT COUNT(*) FROM events WHERE session_id=? AND kind='model_requested'",
                                    (identifier,)).fetchone()[0]
            limit = None if self.model_quota_policy == 'unlimited' else 12 if session['mode'] == 'lite' else 20
            if limit is not None and count >= limit:
                raise TutorError('model_limit', '本课堂模型调用预算已到。', 429)
            self._event(session, 'model_requested', {'instanceId': session['current']['instanceId'],
                                                    'requestId': key, 'limit': limit})
            # Requesting help affects only the currently unanswered instance, never immutable initial evidence.
            if not context['currentAttempt']['submitted']:
                session['current']['helped'] = True
                self._event(session, 'help', {'instanceId': session['current']['instanceId'], 'kind': 'ai_help'})
            record = {'state': 'pending', 'payloadHash': _fingerprint(payload),
                      'instanceId': session['current']['instanceId'], 'revision': session['revision'],
                      'binding': _fingerprint(session['current']), 'createdAt': self.clock()}
            self._put_teacher_request(identifier, key, record)
            self._save(session)
            return None

    def fail_teacher_request(self, identifier, token, payload, code):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            self._load(identifier, token)
            key = self._teacher_request_id(payload)
            record = self._teacher_request(identifier, key)
            if record and record['state'] == 'pending' and record['payloadHash'] == _fingerprint(payload):
                record.update(state='failed', code=code)
                self._put_teacher_request(identifier, key, record)

    def cancel_teacher_request(self, identifier, token, payload):
        _keys(payload, ('action', 'requestId'))
        key = self._teacher_request_id(payload)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            record = self._teacher_request(identifier, key)
            if record is None:
                record = {'state': 'pending', 'payloadHash': None, 'createdAt': self.clock()}
            if record['state'] == 'pending':
                record.update(state='cancelled', code='teacher_cancelled')
                self._put_teacher_request(identifier, key, record)
                self._event(session, 'teacher_cancelled', {'requestId': key})
                self._save(session)
            for job in self._motion_rows(identifier):
                if job['requestId'] == key and job['state'] in ('pending', 'running'):
                    self._motion_transition(session, job, 'cancelled', code='teacher_cancelled')
            self._save(session)
            return {**self._view(session), 'teacherRequest': {'requestId': key, 'state': record['state']}}

    @staticmethod
    def _motion_block_identity(block):
        return {k: copy.deepcopy(block[k]) for k in
                ('id', 'kind', 'title', 'text', 'data', 'graphRefs', 'graphEvidence', 'equationStatus') if k in block}

    @staticmethod
    def _representation_valid(current, block):
        """Check quantities against public givens, never computed/private answers or prose keywords."""
        kind = block.get('kind')
        if kind not in ('bars', 'groups'):
            return True
        try:
            validate_classroom_actions([{'type': 'board.write', 'mode': 'upsert',
                'block': {k: block[k] for k in ('id', 'kind', 'title', 'text', 'data', 'graphRefs')}}])
            if not current or current.get('family') != 'decimal_multiply':
                if kind == 'bars':
                    return True
                if current.get('family') in ('factors', 'grouping', 'sharing'):
                    import re
                    data = block['data']
                    total = next((int(value) for value in re.findall(r'\d+', current.get('prompt', ''))
                                  if int(value) > 0), None)
                    unit = next((word for word in ('颗', '个', '块', '本') if word in current.get('prompt', '')), '单位')
                    return (total is not None and data['count'] <= total and data['each'] == total // data['count']
                            and data['each'] * data['count'] == total and data['unit'] == unit)
                if current.get('family') == 'volume':
                    import re
                    prompt = current.get('prompt', '')
                    row_match = re.search(r'每层(\d+)行', prompt)
                    column_match = re.search(r'每行(\d+)个1立方厘米', prompt)
                    layer_match = re.search(r'共(\d+)层', prompt)
                    if not all((row_match, column_match, layer_match)):
                        return False  # A reverse question does not disclose its unknown layer count.
                    rows, columns, layers = (int(match[1]) for match in
                                             (row_match, column_match, layer_match))
                    data = block['data']
                    # Group complete layers, or rows within one/all layers. Each item
                    # is one of the given 1 cm³ cubes, never money or an invented unit.
                    return (data['unit'] in ('个', '立方厘米') and
                            (data['count'], data['each']) in {
                                (layers, rows * columns), (rows, columns), (layers * rows, columns)})
                return False  # Do not invent an unrelated repeated-group model.
            diagram = current.get('diagram', {})
            rows = diagram.get('rows', [])
            if diagram.get('kind') != 'table' or not rows or len(rows[0]) != 3 or rows[0][2] != '×':
                return False
            from fractions import Fraction
            first, second = (Fraction(str(value)) for value in rows[0][:2])
            if first <= 0 or second <= 0:
                return False
            data = block['data']
            # Units come from the original condition, not the answer field's private metadata.
            prompt = current.get('prompt', '')
            unit = '元' if '元' in prompt else '米' if '米' in prompt else '单位'
            if kind == 'groups':
                return (second.denominator == 1 and data['count'] == second
                        and Fraction(str(data['each'])) == first and data['unit'] == unit)
            whole = Fraction(str(data['whole']))
            selected = Fraction(data['selected'], data['parts'])
            # A unit ribbon can show either given decimal's place value, not the unknown product.
            if whole == 1 and data['unit'] == '单位' and selected in (first, second):
                return True
            if whole != first or data['unit'] != unit:
                return False
            # An unselected partition observes the given base; selected portions scale it only by <=1.
            return selected == 0 or (second <= 1 and selected == second)
        except (TutorError, KeyError, TypeError, ValueError, ZeroDivisionError, OverflowError):
            return False

    @staticmethod
    def _representation_notice():
        return {'representationState': 'rejected', 'blockedRepresentation': True,
                'representationCode': 'teacher_representation_mismatch',
                'reply': '这张图的整体、每份量或组数与原题条件不一致，已暂停展示。请先看原题条件。',
                'question': '原题给的是每份量，还是整体量？'}

    def _check_representations(self, current, blocks):
        if any(not self._representation_valid(current, block) for block in blocks):
            raise TutorError('teacher_representation_mismatch',
                '图的整体、每份量、组数或单位与原题条件不一致；整轮未采用，原题与学生稿保留。', 503)

    def _output_representation_valid(self, current, output):
        return all(self._representation_valid(current, action['block'])
                   for action in output.get('actions', []) if action.get('type') == 'board.write')

    def _motion_canonical(self, session, block):
        clean = self._motion_block_identity(block)
        validate_classroom_actions([{'type': 'board.write', 'mode': 'upsert',
            'block': {k: clean[k] for k in ('id', 'kind', 'title', 'text', 'data', 'graphRefs')}}])
        self._check_representations(session['current'], [clean])
        graph = self.graph.subgraph(session['current']['skills'], 2)
        if any(ref not in graph['nodes'] for ref in clean['graphRefs']):
            raise TutorError('teacher_graph_scope', '动画板块不属于当前真实子图。', 503)
        if self._output_reveals_answer(session, {'actions': [{'type': 'board.write', 'block': clean}]}):
            raise TutorError('answer_exposure', '动画包含未提交答案；整轮未采用。', 503)
        kind, data = clean['kind'], clean['data']
        canonical = {'kind': kind, 'title': clean['title'] or '课堂关系'}
        if kind == 'bars':
            canonical.update(kind='partition', **data)
        elif kind == 'groups':
            canonical.update(**data)
        elif kind in ('note', 'given', 'equation'):
            text = data['expression'] if kind == 'equation' else clean['text']
            if kind == 'given' and text not in session['current']['prompt']:
                _action_error()  # Given text quotes actual original conditions, never a fabricated figure.
            canonical['text'] = text
        elif kind == 'links':
            nodes, edges = data['nodes'], data['edges']
            if not 2 <= len(nodes) <= 3 or len(edges) != len(nodes) - 1:
                _action_error()
            if any(e['from'] != i or e['to'] != i + 1 for i, e in enumerate(edges)):
                _action_error()
            canonical.update(nodes=[{'id': f'n{i}', 'label': label} for i, label in enumerate(nodes)],
                edges=[{'from': f'n{i}', 'to': f'n{i+1}', 'label': edge['label'] or '→'} for i, edge in enumerate(edges)])
        elif kind == 'table':
            canonical.update(headers=data['headers'], rows=[[str(cell) for cell in row] for row in data['rows']])
        else:
            _action_error()
        try:
            return self.teacher_motion.validate_block(canonical)
        except Exception:
            _action_error()  # Reject, do not truncate valid longer board contents.

    def _motion_rows(self, identifier):
        return [json.loads(row[0]) for row in self.db.execute(
            'SELECT document FROM teacher_motion_jobs WHERE session_id=?', (identifier,)).fetchall()]

    def _motion_job(self, motion_id):
        row = self.db.execute('SELECT document FROM teacher_motion_jobs WHERE id=?', (motion_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def _validated_motion_artifact(self, job, artifact):
        """Host-only canonical and project metadata verification; never trust a pin checksum alone."""
        import base64
        source = artifact['html']
        match = re.search(r'<meta name="teacher-motion" content="([A-Za-z0-9+/=]+)">', source)
        rendered = json.loads(base64.b64decode(match[1], validate=True))
        if (artifact.get('engine') != 'OpenMotion' or artifact.get('notAnAssessment') is not True
                or hashlib.sha256(source.encode()).hexdigest() != artifact.get('contentSHA256')
                or artifact.get('scopeSHA256') != hashlib.sha256(job['scope'].encode()).hexdigest()
                or rendered != {'block': job['canonical'], 'duration': job['durationSeconds'],
                                'scopeSHA256': artifact['scopeSHA256']}
                or artifact.get('durationSeconds') != job['durationSeconds']
                or not isinstance(artifact.get('revision'), str)
                or not re.fullmatch(r'[a-f0-9]{64}', artifact['revision'])):
            raise ValueError('invalid artifact')
        for key in ('projectId', 'versionId'):
            if not isinstance(artifact.get(key), str) or str(uuid.UUID(artifact[key])) != artifact[key]:
                raise ValueError('invalid project metadata')
        return self.teacher_motion.playback_html(artifact)

    def _teacher_motion_current(self, session, block_id):
        """A missing pin means first creation; a corrupt/stale pin must never mean recreate."""
        instance = session['current']['instanceId']
        row = self.db.execute('SELECT document FROM teacher_motion_pins '
            'WHERE session_id=? AND instance_id=? AND block_id=?',
            (session['id'], instance, block_id)).fetchone()
        if row is None:
            if any(job['instanceId'] == instance and job['blockId'] == block_id and job.get('artifact')
                   for job in self._motion_rows(session['id'])):
                raise TutorError('teacher_motion_pin_invalid', '动画的私有版本绑定已失效；整轮未采用。', 409)
            return None
        try:
            pin = json.loads(row[0])
            origin = self._motion_job(pin['motionId'])
            scope = _fingerprint([session['id'], instance, block_id])
            if (pin['sessionId'] != session['id'] or pin['instanceId'] != instance
                    or pin['blockId'] != block_id or pin['questionBinding'] != _fingerprint(session['current'])
                    or not origin or origin['sessionId'] != session['id']
                    or origin['instanceId'] != instance or origin['blockId'] != block_id
                    or origin['questionBinding'] != pin['questionBinding'] or origin['scope'] != scope
                    or origin['state'] not in ('ready', 'cancelled')
                    or origin.get('artifact') != pin['artifact']):
                raise ValueError('invalid pin binding')
            self._validated_motion_artifact(origin, pin['artifact'])
            return copy.deepcopy(pin['artifact'])
        except Exception:
            raise TutorError('teacher_motion_pin_invalid', '动画的私有版本绑定已失效；整轮未采用。', 409) from None

    def _motion_valid(self, session, job):
        current = session.get('current')
        board = session.get('teacherWorkspace', {}).get('boards', {}).get(job['instanceId'], {})
        block = next((b for b in board.get('blocks', []) if b['id'] == job['blockId']), None)
        return bool(current and current['instanceId'] == job['instanceId']
            and not session['paused'] and not session['closed'] and session['onlineConsent']
            and not self._limit_reached(session)
            and _fingerprint(current) == job['questionBinding']
            and board.get('revision') == job['boardRevision'] and block
            and self._representation_valid(current, block)
            and _fingerprint(self._motion_block_identity(block)) == job['blockFingerprint']
            and block.get('motion', {}).get('id') == job['id'])

    def _motion_transition(self, session, job, state, *, code=None, srcdoc=None, artifact=None):
        expected = job['version']
        updated = {**job, 'state': state, 'version': expected + 1, 'updatedAt': self.clock()}
        if code:
            updated['code'] = code
        if srcdoc is not None:
            updated['srcdoc'] = srcdoc
        if artifact is not None:
            updated['artifact'] = copy.deepcopy(artifact)
        changed = self.db.execute('UPDATE teacher_motion_jobs SET state=?,version=?,document=? '
            'WHERE id=? AND state=? AND version=?',
            (state, expected + 1, json.dumps(updated, ensure_ascii=False), job['id'], job['state'], expected)).rowcount
        if not changed:
            return None
        board = session.get('teacherWorkspace', {}).get('boards', {}).get(job['instanceId'], {})
        block = next((b for b in board.get('blocks', []) if b['id'] == job['blockId']), None)
        if block and block.get('motion', {}).get('id') == job['id']:
            block['motion']['state'] = 'pending' if state == 'running' else state
        if state != 'running':
            session['revision'] += 1
            self._event(session, 'teacher_motion', {'motionId': job['id'], 'instanceId': job['instanceId'],
                'blockId': job['blockId'], 'state': state, 'notAnAssessment': True, **({'code': code} if code else {})})
        return updated

    def _invalidate_teacher_motions(self, session):
        for job in self._motion_rows(session['id']):
            if job['state'] in ('pending', 'running', 'ready') and not self._motion_valid(session, job):
                self._motion_transition(session, job, 'cancelled', code='binding_changed')

    def _queue_teacher_motion(self, session, request_id, action):
        board = self._board(session)
        block = next((b for b in board['blocks'] if b['id'] == action['blockId']), None)
        if block is None:
            _action_error()
        canonical = self._motion_canonical(session, block)
        current = self._teacher_motion_current(session, block['id'])
        motion_id = str(uuid.uuid4())
        block['motion'] = {'id': motion_id, 'state': 'pending', 'durationSeconds': action['durationSeconds'],
                           'engine': 'OpenMotion', 'notAnAssessment': True}
        job = {'id': motion_id, 'sessionId': session['id'], 'instanceId': session['current']['instanceId'],
               'blockId': block['id'], 'requestId': request_id, 'canonical': canonical,
               'blockFingerprint': _fingerprint(self._motion_block_identity(block)),
               'questionBinding': _fingerprint(session['current']), 'boardRevision': board['revision'],
               'durationSeconds': action['durationSeconds'], 'state': 'pending', 'version': 0,
               'scope': _fingerprint([session['id'], session['current']['instanceId'], block['id']]),
               'current': current, 'createdAt': self.clock()}
        self.db.execute('INSERT INTO teacher_motion_jobs VALUES(?,?,?,?,?,?)',
            (motion_id, session['id'], request_id, 'pending', 0, json.dumps(job, ensure_ascii=False)))

    def pending_teacher_motions(self, identifier, token, request_id=None):
        """Host-only atomic claims; never include these private jobs in session/context."""
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            self._invalidate_teacher_motions(session)
            jobs = []
            for job in self._motion_rows(identifier):
                if job['state'] == 'pending' and (request_id is None or job['requestId'] == request_id):
                    claimed = self._motion_transition(session, job, 'running')
                    if claimed:
                        jobs.append(claimed)
            self._save(session)
            return jobs

    def teacher_motion_check(self, identifier, token, motion_id, version):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            job = self._motion_job(motion_id)
            if not job or job['sessionId'] != identifier or job['version'] != version or job['state'] != 'running':
                return False
            if not self._motion_valid(session, job):
                self._motion_transition(session, job, 'cancelled', code='binding_changed')
                self._save(session)
                return False
            try:
                if self._teacher_motion_current(session, job['blockId']) != job.get('current'):
                    raise ValueError('pin changed')
            except Exception:
                self._motion_transition(session, job, 'failed', code='invalid_current')
                self._save(session)
                return False
            return True

    def complete_teacher_motion(self, identifier, token, motion_id, version, artifact):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            job = self._motion_job(motion_id)
            if not job or job['sessionId'] != identifier or job['version'] != version or job['state'] != 'running':
                return False
            if not self._motion_valid(session, job):
                self._motion_transition(session, job, 'cancelled', code='binding_changed')
                self._save(session)
                return False
            try:
                if self._teacher_motion_current(session, job['blockId']) != job.get('current'):
                    raise ValueError('pin changed')
                srcdoc = self._validated_motion_artifact(job, artifact)
                if job.get('current') is not None:
                    current = job['current']
                    if (artifact['projectId'] != current['projectId']
                            or artifact['revision'] == current['revision']
                            or artifact['versionId'] == current['versionId']):
                        raise ValueError('update did not advance the pinned project')
            except Exception:
                self._motion_transition(session, job, 'failed', code='invalid_artifact')
                self._save(session)
                return False
            if not self._motion_transition(session, job, 'ready', srcdoc=srcdoc, artifact=artifact):
                return False
            pin = {'sessionId': identifier, 'instanceId': job['instanceId'], 'blockId': job['blockId'],
                   'questionBinding': job['questionBinding'], 'motionId': job['id'],
                   'artifact': copy.deepcopy(artifact)}
            self.db.execute('INSERT INTO teacher_motion_pins(session_id,instance_id,block_id,document) '
                'VALUES(?,?,?,?) ON CONFLICT(session_id,instance_id,block_id) '
                'DO UPDATE SET document=excluded.document',
                (identifier, job['instanceId'], job['blockId'], json.dumps(pin, ensure_ascii=False)))
            self._save(session)  # Fresh DB session only; never save an old worker snapshot.
            return True

    def fail_teacher_motion(self, identifier, token, motion_id, version, *, cancelled=False, code='tool_failed'):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            job = self._motion_job(motion_id)
            if not job or job['sessionId'] != identifier or job['version'] != version or job['state'] not in ('pending', 'running'):
                return False
            safe_code = code if code in ('tool_failed', 'interrupted', 'worker_closed', 'not_available') else 'tool_failed'
            changed = self._motion_transition(session, job, 'cancelled' if cancelled else 'failed', code=safe_code)
            self._save(session)
            return bool(changed)

    def cancel_teacher_motion(self, identifier, token, motion_id, version):
        return self.fail_teacher_motion(identifier, token, motion_id, version, cancelled=True)

    def interrupt_teacher_motions(self):
        """Trusted server startup recovery, not each new DB connection."""
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            for (document,) in self.db.execute('SELECT document FROM sessions').fetchall():
                session = json.loads(document)
                for job in self._motion_rows(session['id']):
                    if job['state'] in ('pending', 'running'):
                        self._motion_transition(session, job, 'cancelled', code='interrupted')
                self._save(session)

    def teacher_motion_playback(self, identifier, token, payload):
        if not isinstance(payload, dict) or set(payload) != {'instanceId', 'blockId', 'motionId'} or any(
                not isinstance(value, str) for value in payload.values()):
            raise TutorError('invalid_motion_request', '播放仅接受当前题、板块与动画标识。', 422)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            job = self._motion_job(payload['motionId'])
            if (not job or job['sessionId'] != identifier or job['instanceId'] != payload['instanceId']
                    or job['blockId'] != payload['blockId']):
                raise TutorError('motion_forbidden', '动画不属于当前题与板块。', 403)
            self._invalidate_teacher_motions(session)
            self._save(session)
            job = self._motion_job(job['id'])
            state = job['state']
            result = {**payload, 'srcdoc': job.get('srcdoc'), 'sandbox': 'allow-scripts', 'notAnAssessment': True}
        if state != 'ready':
            raise TutorError('motion_pending' if state in ('pending', 'running') else 'motion_cancelled',
                             '动画尚未就绪或绑定已失效；原板书保留。', 409)
        # Rebuild from validated canonical authoring using the current exact CSP.
        # Persisted HTML remains history, not a trusted/current playback program.
        try:
            result['srcdoc'] = self._validated_motion_artifact(job, job.get('artifact'))
        except Exception:
            # Adapter errors must remain sanitized at the host API boundary.
            raise TutorError('motion_cancelled', '图解版本无法核实；原板书保留。', 409) from None
        # File validation runs outside the DB lock; recheck the exact job before
        # returning. A draft/consent/board change must not revive the old player.
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            current = self._load(identifier, token)
            self._invalidate_teacher_motions(current)
            self._save(current)
            latest = self._motion_job(job['id'])
            valid = bool(latest and latest == job and latest['state'] == 'ready'
                         and self._motion_valid(current, latest))
        if not valid:
            raise TutorError('motion_cancelled', '图解绑定已变化；原题和板书保留。', 409)
        return result

    @staticmethod
    def _public_board(board, current=None):
        result = {k: copy.deepcopy(board[k]) for k in ('revision', 'focusField') if k in board}
        result['blocks'] = []
        for block in board.get('blocks', []):
            if current and not TutorStore._representation_valid(current, block):
                notice = TutorStore._representation_notice()
                result['blockedRepresentation'] = True
                result['blocks'].append({'id': block['id'], 'kind': 'note', 'title': '图示已暂停',
                    'text': notice['reply'], 'data': {}, 'graphRefs': copy.deepcopy(block.get('graphRefs', [])),
                    **{k: notice[k] for k in ('representationState', 'blockedRepresentation', 'representationCode')}})
                continue
            public = TutorStore._motion_block_identity(block)
            for key in ('graphEvidence', 'equationStatus'):
                if key in block:
                    public[key] = copy.deepcopy(block[key])
            if 'motion' in block:
                public['motion'] = {k: copy.deepcopy(block['motion'][k]) for k in
                    ('id', 'state', 'durationSeconds', 'engine', 'notAnAssessment') if k in block['motion']}
            result['blocks'].append(public)
        return result

    @staticmethod
    def _workspace(session):
        return session.setdefault('teacherWorkspace', {'boards': {}, 'teachers': {}})

    def _board(self, session):
        workspace = self._workspace(session)
        instance = session['current']['instanceId']
        return workspace['boards'].setdefault(instance, {'revision': 0, 'blocks': []})

    def _classroom_view(self, session):
        workspace = session.get('teacherWorkspace', {})
        current = session.get('current')
        instance = current['instanceId'] if current else None
        stack = session.get('teacherReturnStack', [])
        result = {'version': CLASSROOM_VERSION,
                  'board': self._public_board(workspace.get('boards', {}).get(instance, {'revision': 0, 'blocks': []}), current),
                  'branch': copy.deepcopy(session.get('teacherBranch')), 'canReturn': bool(stack)}
        pending = session.get('pendingTeacherTask')
        if pending and pending['instanceId'] == instance:
            result['pendingTask'] = {k: copy.deepcopy(pending[k]) for k in ('id', 'family', 'kind', 'level', 'reason')}
        teacher = workspace.get('teachers', {}).get(instance)
        if pending and pending['instanceId'] == instance:
            result['teacher'] = {'reply': pending['originOutput']['reply'],
                                 'question': pending['originOutput']['question'],
                                 'receipt': copy.deepcopy(pending['originReceipt'])}
        elif teacher:
            result['teacher'] = copy.deepcopy(teacher)
        if result['board'].get('blockedRepresentation'):
            result['teacher'] = {**self._representation_notice(),
                'receipt': copy.deepcopy((result.get('teacher') or {}).get('receipt', {}))}
        if stack:
            parent = stack[-1]['current']
            question = public_question(parent)
            question.pop('signature', None)
            result.update(returnTitle=FAMILIES[parent['family']]['title'], returnQuestion=question)
            parent_teacher = workspace.get('teachers', {}).get(parent['instanceId'])
            if parent_teacher:
                parent_board = self._public_board(workspace.get('boards', {}).get(parent['instanceId'], {}), parent)
                result['parentTeacher'] = ({**self._representation_notice(),
                    'receipt': copy.deepcopy(parent_teacher.get('receipt', {}))}
                    if parent_board.get('blockedRepresentation') else copy.deepcopy(parent_teacher))
        return result

    def _available_families(self, session):
        current = session.get('current')
        if not current:
            return []
        ancestors = {row['id'] for row in self.graph.nearest_prerequisites(current['skills'])}
        necessary = set(current['skills']) | ancestors
        rows = []
        for family, meta in FAMILIES.items():
            prerequisite = set(meta['skills']).issubset(necessary)
            if session.get('diagnosisStrategy') == 'personalized':
                role = self.curriculum.role_for(family, session['curriculumProfile'])
                allowed = role == 'current_learned' or (role == 'prerequisite' and prerequisite)
            else:
                # Legacy sessions have no explicit completed-unit authority: only current necessary skills.
                role = 'prerequisite'
                allowed = prerequisite
            if allowed:
                rows.append({'family': family, 'title': meta['title'], 'role': role})
        return rows

    def _propose_teacher_task(self, session, action, output, receipt):
        if len(session.get('teacherReturnStack', [])) >= 4:
            raise TutorError('teacher_stack_limit', '最多保留四层原题；请先返回。', 409)
        if self._limit_reached(session) or session['budgetSeconds'] - self._elapsed(session) < 180:
            raise TutorError('budget_reached', '本课已不足新题及反馈预算，原题保留。', 409)
        if session.get('pendingTeacherTask'):
            raise TutorError('teacher_proposal_pending', '已有小测提议等待孩子确认或拒绝。', 409)
        if action['family'] not in {r['family'] for r in self._available_families(session)}:
            raise TutorError('teacher_scope', '提议不在已学或当前必要先备内。', 409)
        session['pendingTeacherTask'] = {**{k: action[k] for k in ('family', 'kind', 'level', 'reason')},
            'id': str(uuid.uuid4()), 'instanceId': session['current']['instanceId'],
            'originOutput': copy.deepcopy(output), 'originReceipt': copy.deepcopy(receipt)}
        self._event(session, 'teacher_task_proposed', {k: session['pendingTeacherTask'][k]
                    for k in ('id', 'instanceId', 'family', 'kind', 'level', 'reason')})

    def confirm_teacher_task(self, identifier, token, payload):
        _keys(payload, ('action', 'instanceId', 'revision', 'requestId', 'proposalId'))
        key = self._teacher_request_id(payload)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            record = self._teacher_request(identifier, key)
            if record:
                if record.get('payloadHash') is None and record['state'] == 'cancelled':
                    raise TutorError('teacher_cancelled', '此请求已取消。', 409)
                if record['payloadHash'] != _fingerprint(payload):
                    raise TutorError('request_id_conflict', '确认标识不能复用于不同内容。', 409)
                if record['state'] != 'accepted':
                    raise TutorError('teacher_pending', '请求尚未完成。', 409)
                return self._view(session)
            self._require_current(session, payload)
            if type(payload['revision']) is not int:
                raise TutorError('stale_revision', '确认小测须绑定明确版本。', 409)
            proposal = session.get('pendingTeacherTask')
            if (not proposal or proposal['id'] != payload['proposalId']
                    or proposal['instanceId'] != session['current']['instanceId']):
                raise TutorError('teacher_proposal_missing', '此提议已失效或不属于当前题。', 409)
            if session['paused']:
                raise TutorError('paused', '先继续课堂再确认。', 409)
            if payload['action'] == 'teacher_decline_task':
                session.pop('pendingTeacherTask', None)
                session['revision'] += 1
                self._event(session, 'teacher_task_declined', {'proposalId': proposal['id']})
            else:
                origin = session['current']['instanceId']
                session.pop('pendingTeacherTask', None)
                self._open_teacher_task(session, proposal)
                # A source proposal is never silently reused as the new task's explanation/voice.
                if self._output_reveals_answer(session, proposal['originOutput']):
                    raise TutorError('answer_exposure', '提议对白泄露新小测答案；确认整轮回滚。', 503)
                safe = {'reply': '已按你的确认打开小测试。原题和草稿保留，请独立作答。',
                        'question': '准备好就写下你的办法。', 'suggestedAction': 'stay',
                        'targetFamily': session['current']['family'], 'actions': []}
                receipt = {'id': str(uuid.uuid4()), 'state': 'success', 'provider': 'server_transition',
                           'requestId': key, 'evaluated': False}
                self._workspace(session)['teachers'][session['current']['instanceId']] = {
                    'reply': safe['reply'], 'question': safe['question'], 'receipt': receipt}
                self._event(session, 'model_reply', {'receipt': receipt, 'reply': safe,
                    'instanceId': session['current']['instanceId'], 'originInstanceId': origin,
                    'phase': session['phase'], 'revision': session['revision'], 'studentQuestion': ''})
            self._save(session)
            response = self._view(session)
            self._put_teacher_request(identifier, key, {'state': 'accepted',
                'payloadHash': _fingerprint(payload), 'response': response})
            return response

    def _open_teacher_task(self, session, action):
        stack = session.setdefault('teacherReturnStack', [])
        if len(stack) >= 4:
            raise TutorError('teacher_stack_limit', '最多保留四层原题；请先返回。', 409)
        roles = {row['family']: row['role'] for row in self._available_families(session)}
        family = action['family']
        if family not in roles:
            raise TutorError('teacher_scope', '此题不在显式已学或当前必要先备内。', 409)
        phase = {'assessment': 'verify', 'practice': 'probe', 'challenge': 'challenge'}[action['kind']]
        key = family + ':' + phase
        if session.get('attempts', {}).get(key, 0) >= 4:
            raise TutorError('teacher_variant_exhausted', '此题族本阶段的未见变式已用完。', 409)
        chosen = None
        variant = session['variants'].get(key, 0)
        for offset in range(4):
            candidate = build_question(family, variant + offset, phase, action['level'])
            signature = _fingerprint({k: candidate[k] for k in ('prompt', 'fields', 'diagram')})
            if signature not in session['seenQuestions']:
                chosen = candidate
                break
        if chosen is None:
            raise TutorError('teacher_variant_exhausted', '没有未见题，不重复题面或伪称独立测试。', 409)
        if (self._limit_reached(session) or session['taskLimit'] - session['answeredCount'] < 1
                or session['budgetSeconds'] - self._elapsed(session) < chosen['estimatedSeconds'] + 180):
            raise TutorError('budget_reached', '不足新题及反馈预算；原题保留。', 409)
        # Snapshot every route/coaching key; only cumulative evidence/budgets/workspaces stay live.
        cumulative = {'id', 'seq', 'tasks', 'results', 'answeredCount', 'variants', 'attempts', 'seenQuestions',
                      'teacherWorkspace', 'teacherReturnStack', 'elapsed', 'activeSince', 'paused', 'closed',
                      'onlineConsent', 'voiceConsent', 'dueAt', 'closeReason'}
        snapshot = {k: copy.deepcopy(v) for k, v in session.items() if k not in cumulative}
        stack.append(snapshot)
        parent_id = session['current']['instanceId']
        chosen.update(instanceId=str(uuid.uuid4()), phase=phase, signature=signature, helped=False, scaffolded=False,
                      answers={}, workText='', strokes=[], toolEvents=[], stepEvents=[], issuedAt=self.clock(),
                      rootFamily=snapshot['rootFamily'], ordinal=session['answeredCount'] + 1,
                      scopeRole=roles[family])
        if session.get('diagnosisStrategy') == 'personalized':
            chosen['rootContext'] = self.curriculum.root_context(family, session['curriculumProfile'])
        branch_id = str(uuid.uuid4())
        chosen.update(branchId=branch_id, branchKind=action['kind'])
        session.update(current=chosen, phase=phase, awaitingNext=False, feedback=None, lesson=None,
                       coaching=None, revision=session['revision'] + 1,
                       teacherBranch={'id': branch_id, 'kind': action['kind'], 'parentInstanceId': parent_id,
                                      'reason': action['reason'], 'status': 'answering'})
        session['teacher'] = self._teacher_for(session, phase)
        session['variants'][key] = variant + offset + 1
        session.setdefault('attempts', {})[key] = session.get('attempts', {}).get(key, 0) + 1
        session['seenQuestions'].append(signature)
        session['tasks'].append(copy.deepcopy(chosen))
        self._board(session)
        self._event(session, 'teacher_task_opened', {**session['teacherBranch'], 'instanceId': chosen['instanceId'],
                                                   'family': family, 'phase': phase, 'helped': False})

    def _return_teacher_task(self, session):
        stack = session.get('teacherReturnStack', [])
        if not stack:
            raise TutorError('teacher_no_parent', '当前没有可返回的原题。', 409)
        revision = session['revision'] + 1
        branch = copy.deepcopy(session.get('teacherBranch'))
        snapshot = stack.pop()
        # A root snapshot predates teacherBranch; explicitly clear absent optional route state.
        session.pop('teacherBranch', None)
        session.update(snapshot)
        session['revision'] = revision
        self._event(session, 'teacher_task_returned', {'branch': branch, 'instanceId': session['current']['instanceId']})

    def teacher_return(self, identifier, token, payload):
        _keys(payload, ('action', 'instanceId', 'revision', 'requestId'))
        key = self._teacher_request_id(payload)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            previous = self._teacher_request(identifier, key)
            if previous:
                if previous['state'] == 'cancelled' and previous.get('payloadHash') is None:
                    raise TutorError('teacher_cancelled', '返回请求已提前取消。', 409)
                if previous['payloadHash'] != _fingerprint(payload):
                    raise TutorError('request_id_conflict', '返回标识已用于不同内容。', 409)
                return self._view(session)
            self._require_current(session, payload)
            if type(payload['revision']) is not int:
                raise TutorError('stale_revision', '返回须绑定版本。', 409)
            session.pop('pendingTeacherTask', None)
            self._return_teacher_task(session)
            self._save(session)
            response = self._view(session)
            self._put_teacher_request(identifier, key, {'state': 'accepted', 'payloadHash': _fingerprint(payload),
                                                       'response': response})
            return response

    def accept_teacher_plan(self, identifier, token, payload, output, receipt):
        if payload.get('classroomActions') is not True:
            raise TutorError('invalid_classroom_flag', '动作执行必须显式启用课堂协议。')
        key = self._teacher_request_id(payload)
        actions = validate_classroom_actions(output['actions'])
        with self.lock:
            self._load(identifier, token)
            self._expire_teacher_requests(identifier)
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            record = self._teacher_request(identifier, key)
            if record and record['state'] == 'cancelled' and record.get('payloadHash') is None:
                raise TutorError('teacher_cancelled', '请求已提前取消。', 409)
            if not record or record['payloadHash'] != _fingerprint(payload):
                raise TutorError('request_id_conflict', '课堂请求绑定不一致。', 409)
            if record['state'] == 'accepted':
                return self._accepted_teacher_response(record, session)
            if record['state'] != 'pending':
                raise TutorError('teacher_cancelled', '请求已取消或失败，迟到动作未执行。', 409)
            self.context(identifier, token)  # Recheck consent, pause and budget inside the write transaction.
            if (not session.get('current') or session['current']['instanceId'] != record['instanceId']
                    or session['revision'] != record['revision']
                    or _fingerprint(session['current']) != record['binding']):
                raise TutorError('reply_stale', '题目、版本或草稿已变；整轮动作未采用。', 409)
            if self.reply_reveals_answer(identifier, token, output):
                raise TutorError('answer_exposure', '回复或板书包含未交题答案；整轮未采用。', 503)
            # Validate each proposed figure and the final visible board before any write/routing/job.
            candidate = copy.deepcopy(session.get('teacherWorkspace', {}).get('boards', {}).get(
                session['current']['instanceId'], {}).get('blocks', []))
            for action in actions:
                if action['type'] != 'board.write':
                    continue
                self._check_representations(session['current'], [action['block']])
                if action['mode'] == 'replace':
                    candidate = []
                candidate = [b for b in candidate if b['id'] != action['block']['id']] + [action['block']]
            self._check_representations(session['current'], candidate)
            workspace = self._workspace(session)
            # Legacy accepted dialogue can be the parent's last teacher too.
            if record['instanceId'] not in workspace['teachers']:
                rows = self.db.execute("SELECT data FROM events WHERE session_id=? AND kind='model_reply' ORDER BY seq DESC",
                                       (identifier,)).fetchall()
                for row in rows:
                    previous = json.loads(row[0])
                    if previous.get('instanceId') == record['instanceId'] and previous.get('receipt', {}).get('state') == 'success':
                        workspace['teachers'][record['instanceId']] = {
                            'reply': previous['reply']['reply'], 'question': previous['reply']['question'],
                            'receipt': copy.deepcopy(previous['receipt'])}
                        break
            routing = [a for a in actions if a['type'].startswith('task.')]
            if len(routing) > 1 or (routing and actions[-1] is not routing[0]):
                _action_error()  # Board evidence belongs to the origin; route only once, last.
            if routing and session.get('pendingTeacherTask'):
                raise TutorError('teacher_proposal_pending', '等待孩子确认时不执行另一题目动作。', 409)
            if routing and (re.search(r'\d|答案|应(?:该)?填|正确选项', output['reply'] + output['question'])):
                raise TutorError('teacher_route_text', '提议或返回只说明动线，不猜目标题数字或答案。', 503)
            motions = [a for a in actions if a['type'] == 'board.animate']
            if motions and (self.teacher_motion is None or not self.teacher_motion.status().get('available')):
                raise TutorError('teacher_motion_unavailable', '本机动画工具未就绪；整轮未采用。', 503)
            # All typed writes/focus are immediate; animation binds the final board, never a branch return.
            for action in [a for a in actions if a['type'] != 'board.animate']:
                if action['type'] == 'board.write':
                    block = copy.deepcopy(action['block'])
                    graph = self.graph.subgraph(session['current']['skills'], 2)
                    if any(ref not in graph['nodes'] for ref in block['graphRefs']):
                        raise TutorError('teacher_graph_scope', '板书引用不属于当前真实子图。', 503)
                    block['graphEvidence'] = [{'id': ref, 'title': graph['nodes'][ref]['title'],
                                              'source': graph['nodes'][ref].get('sourceLocator', '')}
                                             for ref in block['graphRefs']]
                    if block['kind'] == 'equation':
                        block['equationStatus'] = _equation(block['data']['expression'])
                    board = self._board(session)
                    blocks = [] if action['mode'] == 'replace' else board['blocks']
                    existing = next((i for i, b in enumerate(blocks) if b['id'] == block['id']), None)
                    if existing is None:
                        blocks.append(block)
                    else:
                        blocks[existing] = block
                    if len(blocks) > 8:
                        raise TutorError('teacher_board_limit', '老师板书最多八块。', 503)
                    board.update(blocks=blocks, revision=board['revision'] + 1)
                elif action['type'] == 'board.focus':
                    if action['fieldId'] not in {field['id'] for field in session['current']['fields']}:
                        raise TutorError('teacher_field_scope', '焦点不是当前题的真实字段。', 503)
                    board = self._board(session)
                    board.update(focusField=action['fieldId'], revision=board['revision'] + 1)
                elif action['type'] == 'task.open':
                    # Intent is the model's structured reading of explicit student text, not keyword routing.
                    if not payload['text'].strip():
                        _action_error()
                    self._propose_teacher_task(session, action, output, receipt)
                elif action['type'] == 'task.return':
                    self._return_teacher_task(session)
                    if self._output_reveals_answer(session, output):
                        raise TutorError('answer_exposure', '返回对白包含目标题答案；整轮未采用。', 503)
            if motions:
                self._queue_teacher_motion(session, key, motions[0])
            if not routing or routing[0]['type'] == 'task.open':
                session['revision'] += 1
            teacher = {'reply': output['reply'], 'question': output['question'], 'receipt': copy.deepcopy(receipt)}
            # Preserve the previous parent's teacher on return; the accepted return turn stays in events.
            if not routing:
                self._workspace(session)['teachers'][session['current']['instanceId']] = teacher
            self._event(session, 'model_reply', {'receipt': receipt, 'reply': output,
                'instanceId': session['current']['instanceId'], 'originInstanceId': record['instanceId'],
                'revision': session['revision'], 'phase': session['phase'], 'studentQuestion': payload['text']})
            self._save(session)
            response = {'result': copy.deepcopy(output), 'receipt': copy.deepcopy(receipt),
                        'originInstanceId': record['instanceId'],
                        'resultInstanceId': session['current']['instanceId'], 'session': self._view(session)}
            record.update(state='accepted', response=response)
            self._put_teacher_request(identifier, key, record)
            return response

    def reserve_model_call(self, identifier, token, instance, request_id):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            self.context(identifier, token)
            if session['current']['instanceId'] != instance:
                raise TutorError('stale_question', '题目已变，未开始新的在线请求。', 409)
            count = self.db.execute("SELECT COUNT(*) FROM events WHERE session_id=? AND kind='model_requested'",
                                    (identifier,)).fetchone()[0]
            limit = None if self.model_quota_policy == 'unlimited' else 12 if session['mode'] == 'lite' else 20
            if limit is not None and count >= limit:
                raise TutorError('model_limit', f'这份课堂已到{limit}次在线请求上限；离线学习仍可继续。', 429)
            self._event(session, 'model_requested', {'instanceId': instance, 'requestId': request_id,
                                                    'limit': limit})
            self._save(session)

    def reply_reveals_answer(self, identifier, token, output):
        with self.lock:
            return self._output_reveals_answer(self._load(identifier, token), output)

    def _output_reveals_answer(self, session, output):
        # Works on the transaction's newly generated/restored current, not stale DB state.
        from questions import parse_number
        with self.lock:
            if session.get('awaitingNext') or session['phase'] in ('teach', 'guided'):
                return False
            current = session['current']
            text = str(output.get('reply', '')) + ' ' + str(output.get('question', ''))
            text += ' ' + ' '.join(_action_strings(output.get('actions', [])))
            for action in output.get('actions', []):
                if action.get('type') == 'board.write':
                    block = action['block']
                    text += ' ' + block['title'] + ' ' + block['text'] + ' ' + json.dumps(block['data'], ensure_ascii=False)
                    if block['kind'] == 'equation':
                        expression = block['data']['expression']
                        text += ' ' + expression
                        # Any numeric RHS giving a currently expected value exposes that answer.
                        rhs = expression.replace('＝', '=').split('=')[-1].strip()
                        if '=' in expression.replace('＝', '=') and parse_number(rhs) is not None and any(
                                parse_number(rhs) == parse_number(v) for v in current['_expected'].values()
                                if type(v) in (str, int, float)):
                            return True
            normalized = text.replace('＝', '=').replace('＞', '>').replace('＜', '<').replace(' ', '')
            expected_numbers = [parse_number(value) for value in current['_expected'].values()
                                if type(value) in (str, int, float)]
            answer_segments = [str(output.get('reply', '')), str(output.get('question', ''))]
            for action in output.get('actions', []):
                if action.get('type') != 'board.write':
                    continue
                block = action['block']
                answer_segments.append(block['title'] + ' ' + block['text'])
                data = block['data']
                if block['kind'] == 'table':
                    # A header licenses only its own column, never an unrelated given-value cell.
                    for row in data['rows']:
                        answer_segments.extend(str(header) + ' ' + str(cell)
                                               for header, cell in zip(data['headers'], row))
                elif block['kind'] == 'links':
                    answer_segments.append(' '.join(data['nodes']))
                    for edge in data['edges']:
                        answer_segments.append(data['nodes'][edge['from']] + ' ' + edge['label'] + ' '
                                               + data['nodes'][edge['to']])
                elif block['kind'] == 'equation':
                    answer_segments.append(data['expression'])
            if any(value in expected_numbers for segment in answer_segments
                   for value in _explicit_answer_values(segment)):
                return True
            # Reject valid equations which fill a current numeric placeholder or compare the current fractions.
            for left, symbol, right in re.findall(r'(\d+(?:\.\d+)?(?:/\d+)?)([=<>])(\d+(?:\.\d+)?(?:/\d+)?)', normalized):
                a, b = parse_number(left), parse_number(right)
                if symbol == '=' and a is not None and b is not None and a == b:
                    if any(a == expected for expected in expected_numbers if expected is not None):
                        return True
                diagram = current.get('diagram', {})
                if diagram.get('kind') == 'ribbons' and symbol in ('>', '<'):
                    from fractions import Fraction
                    values = [Fraction(*diagram[key]) for key in ('a', 'b')]
                    if a in values and b in values and a != b:
                        return True
            # Multi-choice exposure needs explicit answer language. Merely discussing
            # a condition or quoting an option must remain allowed.
            for field in current['fields']:
                if field.get('kind') != 'multi':
                    continue
                expected = current['_expected'].get(field['id'], [])
                if not isinstance(expected, (list, tuple, set)) or not expected:
                    continue
                match = re.search(r'(?:答案(?:是|为)|应(?:该)?选|所以选|正确选项(?:是|为))[:：]?([^。！？?！\n]+)', text)
                if match:
                    answer_text = match.group(1).strip()
                    values = [str(value) for value in expected]
                    if all((re.search(r'(?<![\d.])' + re.escape(value) + r'(?![\d.])', answer_text)
                            if re.fullmatch(r'\d+(?:\.\d+)?', value) else value in answer_text)
                           for value in values):
                        return True
                    if all(re.fullmatch(r'[A-Za-z]', value) for value in values):
                        letters = set(re.findall(r'[A-Z]', answer_text.upper()))
                        if letters == {value.upper() for value in values}:
                            return True
            relation = current['_expected'].get('relation')
            if relation in ('A', 'B') and re.search(re.escape(relation) + r'(?:彩带|绳子|部分|段)?(?:更长|更大|大于|长于)', normalized):
                return True
            return False

    def response_for_speech(self, identifier, token, response_id, instance):
        with self.lock:
            session = self._load(identifier, token)
            self.context(identifier, token)
            if not session['current'] or session['current']['instanceId'] != instance:
                raise TutorError('reply_stale', '旧题回复不能播放到当前题。', 409)
            rows = self.db.execute("SELECT data FROM events WHERE session_id=? AND kind='model_reply' ORDER BY seq DESC",
                                   (identifier,)).fetchall()
            for row in rows:
                record = json.loads(row[0])
                if (record.get('receipt', {}).get('id') == response_id
                        and record.get('receipt', {}).get('state') == 'success'
                        and record.get('instanceId') == instance
                        and record.get('phase', session['phase']) == session['phase']):
                    output = record['reply']
                    self._check_representations(session['current'], [action['block']
                        for action in output.get('actions', []) if action.get('type') == 'board.write'])
                    text = output['reply'] + ' ' + output['question']
                    return {'answer': output['reply'], 'steps': [], 'connections': [],
                            'nextQuestion': output['question'], 'narration': text}
            raise TutorError('response_missing', '回复标识不属于本题已完成模型回执，未播放客户端文字。', 409)

    def model_event(self, identifier, token, data):
        with self.lock, self.db:
            if not self.db.in_transaction:
                self.db.execute('BEGIN IMMEDIATE')
            session = self._load(identifier, token)
            self._event(session, 'model_reply', data)
            self._save(session)

    def events(self, identifier, token):
        with self.lock:
            self._load(identifier, token)
            rows = self.db.execute('SELECT seq,kind,created_at,data FROM events WHERE session_id=? ORDER BY seq',
                                   (identifier,)).fetchall()
            return [{'seq': seq, 'kind': kind, 'time': created, 'data': json.loads(data)}
                    for seq, kind, created, data in rows]

    def review(self, identifier, token):
        with self.lock:
            previous = self._load(identifier, token)
            if not previous['closed'] or self.clock() < previous['dueAt']:
                raise TutorError('review_not_due', '还没到隔天复查时间；立即重做不能记为延后保持。', 409)
            if previous.get('diagnosisStrategy') == 'personalized':
                raise TutorError('profile_review_start',
                                 '请用学习档案凭据调用start；下一课堂会安排到期独立复查。', 422)
            targets = [row['family'] for row in self._main_results(previous)
                       if row['phase'] in ('verify', 'transfer') and row['score']['correct'] and not row['assisted']]
            targets = list(dict.fromkeys(targets))[:3]
            if not targets:
                raise TutorError('review_no_evidence', '还没有需要延后验证的独立变式证据；先继续补练。', 409)
        created = self.start({'mode': 'lite', 'scheme': previous['scheme'], 'minutes': 10,
                              'diagnosisStrategy': previous.get('diagnosisStrategy', 'focused')})
        with self.lock, self.db:
            session = self._load(created['id'], created['token'])
            session['reviewOf'] = identifier
            session['diagnosisStage'] = 'review'
            session['roots'] = targets[:]
            session['screenedRoots'] = []
            session['pendingRoots'] = targets[1:]
            session['seenQuestions'] = previous['seenQuestions'][:]
            self._issue(session, targets[0], 'retention', root=targets[0])
            self._event(session, 'retention_started', {'originalSession': identifier,
                                                     'elapsedSinceClose': self.clock() - (previous['dueAt'] - 86400)})
            self._save(session)
            return {**self._view(session), 'token': created['token']}

    def close(self):
        with self.lock:
            self.db.close()
