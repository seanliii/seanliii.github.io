"""Versioned runtime contract, read-only build inspection and owner-only selection."""
from __future__ import annotations

import copy
import hashlib
import math
from html.parser import HTMLParser
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tempfile
import threading
from urllib.parse import urlsplit

TEACHER_TOOLS = {'OpenMotion': {'source': 'https://github.com/nexu-io/openmotion',
    'commit': '58812fe15d78eb43fa5642d520c9655b926f645d', 'scope': 'currentTeacherTools',
    'limits': 'existing-consent-and-service-budgets-no-override',
    'actions': ['board.write', 'board.focus', 'board.animate'], 'notAnAssessment': True}}

VERSION = '0.3.0'
AUTOMATIC_POLICY_VERSION = 'automatic-1'
AUTOMATIC_VIEWS = ('01', '05', '06')
VIEW_IDS = tuple(f'{index:02}' for index in range(1, 11))
COMPONENTS = ['Theme', 'Button', 'TextInput', 'TextArea', 'Card', 'SegmentedControl',
              'ProgressBar', 'Dialog', 'Chat', 'Drawer']
INSPECT_COMPONENTS = COMPONENTS + ['Selector', 'CheckboxInput', 'Stack', 'Layout', 'LayoutContent',
                                  'LayoutHeader', 'Heading', 'HStack', 'VStack', 'Text', 'SegmentedControlItem']
INTERACTION_TYPES = ('select-question-part', 'diagram-segment', 'diagram-data', 'explore-length',
                     'ribbon-cut', 'co-write-demonstration', 'link-representations',
                     'compare-method', 'draft-stroke', 'open-operation-model')
OPERATION_VIEWS = {'workbench': '03', 'ribbon-shop': '05',
                   'dual-representation': '07', 'method-comparison': '08'}
THEMES = [f'@astryxdesign/theme-{name}' for name in ('neutral', 'butter', 'matcha')]
RUNTIME_VERSIONS = {'react': '19.2.1', 'react-dom': '19.2.1',
                    '@stylexjs/stylex': '0.19.0', 'vite': '7.3.8'}
POLICIES = ('sameQuestion', 'unseenVerify', 'firstConfirmReason', 'oneCurrentFocus',
            'noAssumedMisconception', 'recordExposure', 'gradeNotMastery')
DIMENSIONS = ['concept', 'procedure', 'representation', 'application', 'reasoning']
ASSET_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]*\.(?:js|css|woff2?|ttf|otf|svg)\Z')
SELECTION_PATH = '.runtime/harness-selection.json'
THEME_CHECK_COMMAND = 'astryx doctor --built build --json'


class HarnessError(ValueError):
    def __init__(self, code, message, status=422):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def _fail(message, code='invalid_harness', status=422):
    raise HarnessError(code, message, status)


def relative_path(value):
    """No normalization of unsafe spelling, including missing-file paths."""
    if (not isinstance(value, str) or not value or '\\' in value or '\x00' in value
            or value.startswith('/') or ':' in value
            or any(part in ('', '.', '..') for part in value.split('/'))):
        _fail('路径必须是项目内严格相对路径。', 'unsafe_path')
    return PurePosixPath(value).parts


FRONTEND_SOURCE_FILES = ('studio.html', 'vite.config.ts', 'tsconfig.json', 'package.json', 'package-lock.json')


def _decode(data):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda _value: (_ for _ in ()).throw(ValueError('nonfinite')))


class _EntryParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.references = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' and attrs.get('src'):
            self.references.append(attrs['src'])
        if tag == 'link' and attrs.get('rel') in ('stylesheet', 'modulepreload', 'preload'):
            if attrs.get('href'):
                self.references.append(attrs['href'])


class Harness:
    def __init__(self, root, config_path='harness.json', *, build_root='build', shared_reader=None):
        # Keep the lexical root so a symlink is never silently resolved into authority.
        self.root = Path(os.path.abspath(root))
        relative_path(build_root)
        self.build_root = build_root
        self.check_path(build_root)
        self.shared_reader = shared_reader
        self.theme_check_command = f'astryx doctor --built {build_root} --json'
        self.lock = threading.RLock()
        self._coverage_bank = None
        self._coverage_results = {}
        self.config = self.read_json(config_path)
        try:
            self.validate(self.config)
        except (TypeError, KeyError, AttributeError):
            _fail('Harness字段类型或结构不正确。')
        for path in (self.config['designSystem']['agentRulesPath'],
                     self.build_path('assets'), self.build_path('studio.html'),
                     SELECTION_PATH):
            self.check_path(path)

    def build_path(self, relative):
        relative_path(relative)
        path = self.build_root + '/' + relative
        self.check_path(path)
        return path

    def frontend_source_hashes(self):
        """Only registered frontend inputs; no runtime, credentials or owner inventory."""
        paths = list(FRONTEND_SOURCE_FILES)
        source_root = self.check_path('src')
        if source_root.is_dir():
            for parent, dirs, files in os.walk(source_root, followlinks=False):
                dirs[:] = sorted(name for name in dirs if not (Path(parent) / name).is_symlink())
                for name in sorted(files):
                    if Path(name).suffix in ('.ts', '.tsx', '.js', '.mjs', '.css'):
                        paths.append((Path(parent) / name).relative_to(self.root).as_posix())
        hashes = {}
        for path in sorted(paths):
            try:
                hashes[path] = hashlib.sha256(self.read_bytes(path)).hexdigest()
            except (OSError, HarnessError):
                pass
        return hashes

    def frontend_bytes(self, request_path):
        if request_path in ('/learning.js', '/learning.css'):
            if self.shared_reader is None:
                _fail('共享学习资源未绑定同源读取器。', 'not_found', 404)
            try:
                _target, content = self.shared_reader(request_path)
            except Exception:
                _fail('共享学习资源无法安全读取。', 'not_found', 404)
            return 'shared/' + request_path.removeprefix('/'), content
        target = self.asset_path(request_path).relative_to(self.root).as_posix()
        return target, self.read_bytes(target)

    def check_path(self, relative):
        parts = relative_path(relative)
        current = Path(self.root.anchor)
        for part in self.root.parts[1:] + parts:
            current /= part
            if current.is_symlink():
                _fail('拒绝符号链接路径。', 'unsafe_path')
        return self.root.joinpath(*parts)

    def _open(self, relative):
        """Walk every directory using no-follow descriptors; don't race path checks."""
        parts = relative_path(relative)
        self.check_path(relative)
        descriptor = os.open(self.root.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for part in self.root.parts[1:] + parts[:-1]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                dir_fd=descriptor)
                os.close(descriptor)
                descriptor = child
            result = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=descriptor)
            if not stat.S_ISREG(os.fstat(result).st_mode):
                os.close(result)
                _fail('只接受常规文件。', 'unsafe_path')
            return result
        finally:
            os.close(descriptor)

    def read_bytes(self, relative, limit=8 * 1024 * 1024):
        descriptor = self._open(relative)
        with os.fdopen(descriptor, 'rb') as source:
            data = source.read(limit + 1)
        if len(data) > limit:
            _fail('文件超过运行时读取上限。', 'file_too_large')
        return data

    def read_json(self, relative):
        try:
            value = _decode(self.read_bytes(relative, 4 * 1024 * 1024))
        except (ValueError, UnicodeDecodeError) as error:
            if isinstance(error, HarnessError):
                raise
            _fail('运行时JSON无效。')
        if not isinstance(value, dict):
            _fail('运行时JSON必须是对象。')
        return value

    @staticmethod
    def validate(config):
        required = {'version', 'designSystem', 'teachingPolicy', 'privacy', 'limits',
                    'tokens', 'defaultView', 'registry'}
        if not required <= set(config) or set(config) - required - {'teacherTools'} or config['version'] != VERSION:
            _fail('不支持的Harness结构或版本。')
        if 'teacherTools' in config and config['teacherTools'] != TEACHER_TOOLS:
            _fail('老师工具仅接受固定来源、当前课堂作用域与既有预算。')
        design = config['designSystem']
        expected = {
            'package': '@astryxdesign/core', 'version': '0.7.16',
            'cli': {'package': '@astryxdesign/cli', 'version': '0.7.16'},
            'source': 'https://github.com/meta/astryx', 'docs': 'https://astryx.atmeta.com',
            'agentRulesPath': '.astryx/agent.rules',
            'agentRulesRole': 'official-generated-agent-rules-not-teaching-prompt',
            'baseCSS': '@astryxdesign/core/astryx.css', 'themePackages': THEMES,
            'actualComponents': COMPONENTS, 'builtEntry': '/studio.html',
            'assetRoot': 'build/assets', 'runtimeVersions': RUNTIME_VERSIONS,
        }
        declared = design.get('actualComponents') if isinstance(design, dict) else None
        if (not isinstance(declared, list) or any(not isinstance(name, str) or name not in INSPECT_COMPONENTS for name in declared)
                or len(set(declared)) != len(declared)
                or any(design.get(key) != value for key, value in expected.items()
                       if key != 'actualComponents')):
            _fail('设计系统版本、组件或路径不在已知契约内。')
        # Extension metadata is optional for older 0.3.0 consumers, not a frozen theme set.
        for key in ('appThemeModule', 'evidenceReportPath'):
            if key in design:
                relative_path(design[key])
        themes = design.get('themes', {})
        if not isinstance(themes, dict):
            _fail('主题绑定必须是对象。')
        for slug, binding in themes.items():
            if (not isinstance(slug, str) or not re.fullmatch(r'[a-z][a-z0-9-]{0,63}', slug)
                    or not isinstance(binding, dict)
                    or set(binding) != {'source', 'generatedJS', 'generatedCSS', 'parentPackage'}
                    or binding['parentPackage'] not in design['themePackages']):
                _fail('主题绑定结构不正确。')
            for key in ('source', 'generatedJS', 'generatedCSS'):
                relative_path(binding[key])
        if 'defaultTheme' in design and design['defaultTheme'] not in themes:
            _fail('默认主题必须在绑定中。')
        if 'fontPolicy' in design and design['fontPolicy'] != 'system_only_no_remote_fonts':
            _fail('课堂不得加载远程字体。')
        workflow = design.get('agentWorkflow')
        if workflow is not None and (not isinstance(workflow, dict)
                or workflow.get('stage') != 'design-generation'
                or workflow.get('readGuideBeforeGeneration') is not True
                or workflow.get('readMethod') != 'read_file'
                or workflow.get('ideAutoDiscovery') is not False
                or ('skillName' in workflow and workflow['skillName'] != 'astryx-design-system')
                or ('hostEntry' in workflow and workflow['hostEntry'] != '@astryxdesign/cli/host')
                or not isinstance(workflow.get('directive'), str)):
            _fail('设计生成必须显式读取官方指南。')
        policy = config['teachingPolicy']
        if (not isinstance(policy, dict) or set(policy) != set(POLICIES) | {'dimensions'}
                or any(policy.get(key) is not True for key in POLICIES)
                or policy.get('dimensions') != DIMENSIONS):
            _fail('教学策略必须保留同题、独立验证与证据约束。')
        if (config['privacy'] != {'microphone': 'explicit', 'strokesUpload': False,
                                  'selectionScope': 'local-owner-not-learner'}
                or config['privacy']['strokesUpload'] is not False):
            _fail('隐私约束不可放宽。')
        if config['limits'] != {'modelCallsPerProcess': 30,
                               'voice': 'existing-consent-and-service-budgets-no-override'}:
            _fail('不得覆盖既有模型或语音预算。')
        if type(config['limits']['modelCallsPerProcess']) is not int:
            _fail('模型预算须为整数。')
        tokens = config['tokens']
        if (not isinstance(tokens, dict) or set(tokens) != {'roles', 'preferences'}
                or not isinstance(tokens['roles'], dict)
                or set(tokens['roles']) != {'question', 'teacher', 'draft', 'secondary'}
                or any(not isinstance(text, str) or not 1 <= len(text) <= 100
                       for text in tokens['roles'].values())):
            _fail('阅读角色格式不正确。')
        preferences = tokens['preferences']
        fixed = {'normalChineseFont': True, 'questionFontRangePx': [20, 36],
                 'numericFontAdjustment': True, 'singleFocus': True,
                 'noOversizedEmptyHeader': True, 'noCardWall': True}
        if (not isinstance(preferences, dict)
                or set(preferences) != set(fixed) | {'fontFamily', 'questionFontPx'}
                or any(preferences.get(key) != value for key, value in fixed.items())
                or any(preferences.get(key) is not True for key in fixed if key != 'questionFontRangePx')
                or type(preferences['questionFontPx']) is not int
                or not 20 <= preferences['questionFontPx'] <= 36
                or preferences['fontFamily'] != 'system-ui, PingFang SC, Microsoft YaHei, sans-serif'):
            _fail('须保留正常中文字体、可调题面字号与单焦点。')
        registry = config['registry']
        if (not isinstance(registry, list) or len(registry) != 10
                or any(not isinstance(view, dict) for view in registry)
                or [view.get('id') for view in registry] != list(VIEW_IDS)
                or config['defaultView'] not in VIEW_IDS):
            _fail('选型必须是固定01至10，不是模型列表。')
        for view in registry:
            if set(view) != {'id', 'name', 'layout', 'primaryAction', 'teacherPresence',
                            'draftMode', 'focusSequence', 'differentiation'}:
                _fail('方案字段不完整或含未知字段。')
            for key in ('name', 'layout', 'primaryAction', 'teacherPresence', 'draftMode'):
                if not isinstance(view[key], str) or not 1 <= len(view[key]) <= 120:
                    _fail('方案文字不正确。')
            for key in ('focusSequence', 'differentiation'):
                if (not isinstance(view[key], list) or not 2 <= len(view[key]) <= 8
                        or any(not isinstance(text, str) or not 1 <= len(text) <= 120 for text in view[key])):
                    _fail('方案须有聚焦序列与真实差异。')
        if len({view['layout'] for view in registry}) != 10:
            _fail('十方案须有不同布局机制。')

    def _exists(self, relative):
        try:
            descriptor = self._open(relative)
            os.close(descriptor)
            return True
        except (OSError, HarnessError):
            return False

    def package_manifest(self):
        design = self.config['designSystem']
        versions = {design['package']: design['version'], design['cli']['package']: design['cli']['version'],
                    **dict.fromkeys(THEMES, '0.7.16'), **RUNTIME_VERSIONS}
        try:
            packages = self.read_json('package-lock.json').get('packages', {})
            if not isinstance(packages, dict):
                packages = {}
        except (OSError, HarnessError):
            packages = {}
        result = []
        for name, expected in versions.items():
            actual, source, installed = None, None, False
            try:
                package = self.read_json(f'node_modules/{name}/package.json')
                if package.get('name') == name and isinstance(package.get('version'), str):
                    actual, source, installed = package['version'], 'node_modules', True
            except (OSError, HarnessError):
                pass
            locked = packages.get(f'node_modules/{name}', {})
            lock_version = locked.get('version') if isinstance(locked, dict) else None
            if actual is None and isinstance(lock_version, str):
                actual, source = lock_version, 'package-lock'
            result.append({'package': name, 'expectedVersion': expected, 'actualVersion': actual,
                           'source': source, 'installed': installed,
                           'lockedVersion': lock_version, 'matches': actual == expected})
        return result

    def asset_path(self, request_path):
        if request_path == '/studio.html':
            return self.check_path(self.build_path('studio.html'))
        if not request_path.startswith('/assets/'):
            _fail('资源不在公开白名单。', 'not_found', 404)
        name = request_path[len('/assets/'):]
        if not ASSET_NAME.fullmatch(name) or '..' in name:
            _fail('资源名不在编译文件白名单。', 'not_found', 404)
        return self.check_path(self.build_path('assets/' + name))

    def static_bytes(self, request_path):
        target = self.asset_path(request_path)
        try:
            return target, self.read_bytes(target.relative_to(self.root).as_posix())
        except FileNotFoundError:
            _fail('前端构建尚未生成此资源。', 'not_found', 404)
        except OSError:
            _fail('资源无法安全读取。', 'not_found', 404)

    @staticmethod
    def _compiled_references(source, suffix):
        """Read emitted literal imports, not arbitrary strings mentioning asset names."""
        if suffix == '.css':
            clean = re.sub(r'/\*[\s\S]*?\*/', '', source)
            result = re.findall(r'@import\s+[\'"]([^\'"]+)[\'"]', clean)
            for quoted, bare in re.findall(r'url\(\s*(?:[\'"]([^\'"]+)[\'"]|([^\s)]+))\s*\)', clean):
                reference = quoted or bare
                if not reference.startswith(('data:', '#')):
                    result.append(reference)
            return result
        # Keep quoted strings as tokens, discard comments and templates as whole tokens.
        tokens = re.findall(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`|[A-Za-z_$][\w$]*|[^\s]', source)
        tokens = [token for token in tokens if not token.startswith(('//', '/*'))]
        result = []
        for index, token in enumerate(tokens):
            if token not in ('import', 'export') or (index and tokens[index - 1] == '.'):
                continue
            following = tokens[index + 1:]
            if token == 'import' and following:
                if following[0].startswith(('"', "'")):
                    result.append(following[0][1:-1])
                    continue
                if len(following) >= 3 and following[0] == '(' and following[1].startswith(('"', "'")) and following[2] == ')':
                    result.append(following[1][1:-1])
                    continue
            # Only import/export declarations can have a from clause.
            if not following or following[0] not in ('{', '*') and not (token == 'import' and re.fullmatch(r'[A-Za-z_$][\w$]*', following[0]) and following[0] != 'meta'):
                continue
            for offset, item in enumerate(following[:256]):
                if item == ';':
                    break
                if item == 'from' and offset + 1 < len(following) and following[offset + 1].startswith(('"', "'")):
                    result.append(following[offset + 1][1:-1])
                    break
        # Vite's generated preload table carries lazy CSS dependencies too.
        for table in re.findall(r'__vite__mapDeps[\s\S]{0,300}?\.f\s*\|\|\s*\([^=]*=\s*\[([^\]]*)\]', source):
            result.extend('/' + value.removeprefix('./') for value in re.findall(r'[\'"](assets/[^\'"]+)[\'"]', table))
        return result

    def frontend_manifest(self):
        entry = self._exists(self.build_path('studio.html'))
        assets, shared, references, missing = set(), set(), [], []
        queue = []

        def include(reference, parent):
            try:
                parsed = urlsplit(reference)
                path = parsed.path
                if parsed.scheme or parsed.netloc or not path or '\\' in path or '%' in path:
                    raise ValueError('nonlocal reference')
                if not path.startswith('/'):
                    path = str(PurePosixPath(parent).parent).rstrip('/') + '/' + path.removeprefix('./')
                if path in ('/learning.js', '/learning.css'):
                    self.frontend_bytes(path)
                    if path not in shared:
                        shared.add(path)
                        queue.append(path)
                    return
                if not path.startswith('/assets/') or not ASSET_NAME.fullmatch(path.removeprefix('/assets/')) or '..' in path:
                    raise ValueError('unsafe asset reference')
                target = self.asset_path(path).relative_to(self.root).as_posix()
                if not self._exists(target):
                    raise ValueError('missing asset')
                if path not in assets:
                    assets.add(path)
                    queue.append(path)
            except (OSError, ValueError, HarnessError):
                if reference not in missing:
                    missing.append(reference)

        if entry:
            try:
                parser = _EntryParser()
                parser.feed(self.read_bytes(self.build_path('studio.html')).decode('utf-8'))
                references = parser.references
                for reference in references:
                    include(reference, '/studio.html')
                while queue:
                    asset = queue.pop(0)
                    suffix = PurePosixPath(asset).suffix
                    if suffix not in ('.js', '.css'):
                        continue
                    try:
                        source = self.frontend_bytes(asset)[1].decode('utf-8')
                        for reference in self._compiled_references(source, suffix):
                            include(reference, asset)
                    except (OSError, ValueError, HarnessError):
                        if asset not in missing:
                            missing.append(asset)
            except (OSError, ValueError, UnicodeDecodeError):
                missing.append('/studio.html')
        built = entry and bool(references) and any(urlsplit(ref).path.endswith('.js') for ref in references) and not missing
        build_hashes = {}
        for asset in ['/studio.html', *sorted(assets | shared)]:
            try:
                target, content = self.frontend_bytes(asset)
                build_hashes[target] = hashlib.sha256(content).hexdigest()
            except (OSError, ValueError, HarnessError):
                pass
        source_hashes = self.frontend_source_hashes()
        try:
            identity = self.read_json(self.build_path('frontend-source.json'))
        except (OSError, HarnessError):
            identity = {}
        valid_identity = (isinstance(identity, dict) and identity.get('schema') == 1
                          and isinstance(identity.get('mode'), str)
                          and isinstance(identity.get('sourceSHA256'), dict)
                          and bool(identity['sourceSHA256'])
                          and all(isinstance(key, str) and isinstance(value, str)
                                  and re.fullmatch(r'[a-f0-9]{64}', value)
                                  for key, value in identity['sourceSHA256'].items()))
        compiled_source = identity['sourceSHA256'] if valid_identity else None
        artifact_hashes = identity.get('artifactSHA256') if valid_identity else None
        expected_artifacts = {key.removeprefix(self.build_root + '/'): value
                              for key, value in build_hashes.items() if key.startswith(self.build_root + '/')}
        artifacts_current = (bool(expected_artifacts) and isinstance(artifact_hashes, dict)
                             and all(artifact_hashes.get(key) == value for key, value in expected_artifacts.items()))
        return {'entry': '/studio.html', 'entryExists': entry, 'assets': sorted(assets),
                'sharedAssets': sorted(shared), 'buildRoot': self.build_root,
                'mode': identity['mode'] if valid_identity else None,
                'sourceSHA256': source_hashes, 'compiledSourceSHA256': compiled_source,
                'sourceCurrent': compiled_source == source_hashes and artifacts_current if valid_identity else None,
                'artifactCurrent': artifacts_current if valid_identity else None,
                'buildSHA256': build_hashes,
                'entryReferences': references, 'missingReferences': missing, 'built': bool(built),
                'evidence': 'literal-entry-dependency-closure-only-not-browser-or-component-usage-verification'}

    def local_theme_manifest(self):
        # Editor-created local themes are source evidence, not installed npm packages or DOM proof.
        result = []
        for slug, stem in (('classroom', 'classroomTheme'), ('classroom-butter', 'classroomButterTheme'),
                           ('classroom-matcha', 'classroomMatchaTheme')):
            paths = {'authoring': f'themes/{slug}/{slug}.theme.ts',
                     'source': f'src/themes/{slug}/{stem}.ts',
                     'editorDocument': f'src/themes/{slug}/{stem}.doc.mjs'}
            files = {key: self._exists(path) for key, path in paths.items()}
            if any(files.values()):
                result.append({'slug': slug, 'paths': paths, 'files': files,
                               'state': 'source-available' if files['source'] else 'authoring-only',
                               'browserProof': 'not_observed', 'selectionPersisted': False})
        return result

    def _inspection_text(self, path):
        try:
            return self.read_bytes(path).decode('utf-8')
        except (OSError, HarnessError, UnicodeDecodeError):
            return ''

    def theme_binding_manifest(self, frontend):
        design = self.config['designSystem']
        module_path = design.get('appThemeModule')
        module = self._inspection_text(module_path) if module_path else ''
        record_match = re.search(r'@astryx-theme-record\s+(\{[^\n]+\})', module)
        record = {}
        if record_match:
            try:
                record = _decode(record_match.group(1))
                if not isinstance(record, dict):
                    record = {}
            except ValueError:
                pass
        generated = record.get('themes', {})
        generated = generated if isinstance(generated, dict) else {}
        default_match = re.search(r'export\s+const\s+defaultThemeSlug\s*=\s*[\'\"]([^\'\"]+)', module)
        default = default_match.group(1) if default_match else None
        imports = re.findall(r'\bimport\s+(?:[^;\n]*?\s+from\s+)?[\'\"]([^\'\"]+)[\'\"]', module)
        imports = {path.removeprefix('./') for path in imports}
        rows, hashes = [], {}
        if module:
            hashes[module_path] = hashlib.sha256(module.encode()).hexdigest()
        for slug, binding in design.get('themes', {}).items():
            files = {key: self._exists(binding[key]) for key in ('source', 'generatedJS', 'generatedCSS')}
            js, css = (self._inspection_text(binding[key]) for key in ('generatedJS', 'generatedCSS'))
            for key in files:
                text = self._inspection_text(binding[key])
                if text:
                    hashes[binding[key]] = hashlib.sha256(text.encode()).hexdigest()
            versions = {}
            for label, package in (('CLI', '@astryxdesign/cli'), ('Core', '@astryxdesign/core')):
                match = re.search(rf'{label}:\s*{re.escape(package)}@([^\s*]+)', js)
                versions[label.lower()] = match.group(1) if match else None
            fonts = {}
            for role in ('body', 'heading', 'code'):
                values = re.findall(rf'--font-family-{role}:\s*([^;\n]+);', css)
                fonts[role] = sorted(set(values))
            remote = bool(re.search(r'fonts\.(?:googleapis|gstatic)\.com|@import\b|@font-face\b', js + css, re.I))
            allowed_fonts = {'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif',
                             'ui-monospace', 'SF Mono', 'Menlo', 'Consolas', 'monospace',
                             'PingFang SC', 'Microsoft YaHei'}
            system = all(fonts[role] and all(
                value.startswith('ui-monospace' if role == 'code' else 'system-ui')
                and all(name.strip().strip('\"\'') in allowed_fonts for name in value.split(','))
                for value in fonts[role]) for role in fonts)
            linked = slug in generated and all(binding[key] in imports for key in ('generatedJS', 'generatedCSS'))
            compiled = (all(files.values()) and linked and '@generated' in js and '__built: true' in js
                        and f"'{binding['parentPackage']}/built'" in js
                        and f'data-astryx-theme="{slug}"' in css)
            rows.append({'slug': slug, 'paths': copy.deepcopy(binding), 'files': files,
                         'moduleLinked': linked, 'state': 'sourcecompiled' if compiled else 'configured',
                         'generatedVersions': versions,
                         'fonts': {'families': fonts, 'remoteFontImports': remote,
                                   'status': 'source_checked' if system and not remote else 'not_confirmed',
                                   'evidence': 'generated-css-only-not-browser'},
                         'browserProof': 'not_observed'})
        binding_matches = (set(generated) == set(design.get('themes', {}))
                           and default == record.get('defaultThemeSlug') == design.get('defaultTheme')
                           and bool(rows) and all(row['moduleLinked'] for row in rows))
        build_hashes = copy.deepcopy(frontend['buildSHA256'])
        try:
            report = self.read_json(design.get('evidenceReportPath', '验收/交付状态.json'))
        except (OSError, HarnessError):
            report = {}
        evidence = report.get('designSystem', {}) if report.get('version') == VERSION else {}
        evidence = evidence if isinstance(evidence, dict) else {}
        receipts = evidence.get('browserEvidence', [])
        receipts = receipts if isinstance(receipts, list) else []
        entries = []
        for view in VIEW_IDS:
            screenshot = f'验收/Astryx-方案{view}-主图.png'
            row = {'view': view, 'screenshot': '/' + screenshot,
                   'screenshotExists': self._exists(screenshot), 'status': 'not_observed'}
            receipt = next((item for item in receipts if isinstance(item, dict) and item.get('view') == view), {})
            # A screenshot's presence or a source check is never DOM evidence.
            if (receipt.get('version') == VERSION and isinstance(receipt.get('theme'), str)
                    and receipt['theme'] in generated and binding_matches and frontend['built']
                    and receipt.get('buildSHA256', evidence.get('buildSHA256')) == build_hashes and bool(build_hashes)
                    and receipt.get('entry') == design['builtEntry']
                    and receipt.get('domRendered') is True and receipt.get('browser') == 'Ego Lite'
                    and isinstance(receipt.get('observedAt'), str) and receipt['observedAt']
                    and receipt.get('sourceSHA256', evidence.get('sourceSHA256')) == hashes and bool(hashes)
                    and row['screenshotExists']):
                try:
                    digest = hashlib.sha256(self.read_bytes(screenshot)).hexdigest()
                    if digest == receipt.get('screenshotSHA256'):
                        row.update(status='reported_browserproof', theme=receipt['theme'],
                                   observedAt=receipt['observedAt'], evidence='per-entry-report-not-harness-browser-run')
                except (OSError, HarnessError):
                    pass
            entries.append(row)
        check = evidence.get('themeCheck', {})
        check = check if isinstance(check, dict) else {}
        # Defaults apply only to absent keys; explicit invalid values never fall back.
        check = {**{field: evidence.get(field) for field in ('sourceSHA256', 'buildSHA256')}, **check}
        # Read a version-bound CLI receipt only; Harness does not execute the CLI.
        check_valid = (check.get('identityType') == 'cliReceipt'
                       and check.get('command') == self.theme_check_command
                       and check.get('sourceSHA256') == hashes and bool(hashes)
                       and check.get('buildSHA256') == build_hashes and bool(build_hashes)
                       and frontend['built']
                       and all(type(check.get(field)) is int
                               for field in ('passes', 'warnings', 'failures', 'exitCode'))
                       and check['passes'] >= 0 and check['warnings'] == 0
                       and check['failures'] == 0 and check['exitCode'] == 0
                       and isinstance(check.get('observedAt'), str) and bool(check['observedAt'].strip()))
        cli_check = {'status': 'reported_pass' if check_valid else 'not_observed',
                     'evidencePath': design.get('evidenceReportPath', '验收/交付状态.json'),
                     'executedHere': False, 'evidence': 'receipt-file-not-harness-cli-execution'}
        if check_valid:
            cli_check.update({field: copy.deepcopy(check[field]) for field in
                              ('identityType', 'command', 'passes', 'warnings', 'failures',
                               'exitCode', 'sourceSHA256', 'buildSHA256', 'observedAt')})
        rules = self._inspection_text(design['agentRulesPath'])
        rules_version = re.search(r'Astryx v([^\s·]+)', rules)
        all_compiled = bool(rows) and all(row['state'] == 'sourcecompiled' for row in rows)
        all_browser = all_compiled and all(row['status'] == 'reported_browserproof' for row in entries)
        return {'themeBinding': {'state': 'browserproof' if all_browser and binding_matches else
                                 'sourcecompiled' if binding_matches and all_compiled
                                 else 'configured',
                                 'generatedDefaultTheme': default, 'generatedThemes': list(generated),
                                 'bindingMatches': binding_matches, 'themes': rows,
                                 'sourceSHA256': hashes, 'buildSHA256': build_hashes,
                                 'frontendBuilt': frontend['built'],
                                 'evidence': 'generated-source-artifacts-not-app-bundle-or-dom'},
                'fonts': {'policy': design.get('fontPolicy'),
                          'themes': {row['slug']: row['fonts'] for row in rows}, 'cliThemeCheck': cli_check},
                'evidenceContract': {'reportVersion': VERSION, 'reportObject': 'designSystem',
                                     'browserEntriesField': 'browserEvidence',
                                     'sharedHashFields': ['sourceSHA256', 'buildSHA256'],
                                     'hashReferencePolicy': 'entries omit use top, supplied values own authoritative',
                                     'hashValidation': 'effective hashes must equal current themeBinding hashes and be nonempty',
                                     'browserRequiredEntryFields': ['view', 'version', 'theme', 'entry', 'browser',
                                                                    'domRendered', 'observedAt', 'screenshotSHA256'],
                                     'themeCheckRequiredEntryFields': ['identityType', 'command', 'passes', 'warnings',
                                                                      'failures', 'exitCode', 'observedAt'],
                                     'requiredFieldsBasis': 'effective values after absent-key-only shared hash resolution',
                                     'browserRequiredFields': ['view', 'version', 'theme', 'entry', 'browser',
                                                               'domRendered', 'observedAt', 'sourceSHA256',
                                                               'buildSHA256', 'screenshotSHA256'],
                                     'browserIdentity': 'Ego Lite', 'themeCheckField': 'themeCheck',
                                     'themeCheckRequiredFields': ['identityType', 'command', 'passes', 'warnings',
                                                                 'failures', 'exitCode', 'sourceSHA256',
                                                                 'buildSHA256', 'observedAt'],
                                     'themeCheckCommand': self.theme_check_command,
                                     'themeCheck': {
                                         'expectedCommand': self.theme_check_command, 'identityType': 'cliReceipt',
                                         'fieldTypes': {'identityType': 'string', 'command': 'string',
                                                        'passes': 'integer', 'warnings': 'integer',
                                                        'failures': 'integer', 'exitCode': 'integer',
                                                        'sourceSHA256': 'object<relative-path,sha256>',
                                                        'buildSHA256': 'object<relative-path,sha256>',
                                                        'observedAt': 'nonempty-string'},
                                         'hashBasis': 'themeBinding.sourceSHA256-and-themeBinding.buildSHA256',
                                         'success': {'passes': 'nonnegative', 'warnings': 0,
                                                     'failures': 0, 'exitCode': 0},
                                         'info': 'not-a-pass-warning-or-failure-count',
                                         'executedHere': False, 'successStatus': 'reported_pass'},
                                     'boundary': 'reported-evidence-not-independently-observed'},
                'browserEvidence': {'reportPath': design.get('evidenceReportPath', '验收/交付状态.json'),
                                    'entries': entries, 'status': 'reported_browserproof' if all_browser else 'not_observed'},
                'agentGuide': {'path': design['agentRulesPath'], 'exists': bool(rules),
                               'sourceVersion': rules_version.group(1) if rules_version else None,
                               'ideAutoDiscovery': False, 'readBeforeGeneration': True,
                               'readMethod': 'read_file', 'evidence': 'file-inspection-not-agent-or-cli-execution'}}

    def public(self):
        packages = self.package_manifest()
        frontend = self.frontend_manifest()
        installed = all(item['installed'] and item['matches'] for item in packages)
        rules = self._exists(self.config['designSystem']['agentRulesPath'])
        contract = copy.deepcopy(self.config)
        contract['designSystem']['declaredComponents'] = contract['designSystem']['actualComponents']
        components = self.component_manifest()
        contract['designSystem']['assetRoot'] = self.build_path('assets')
        contract['designSystem']['actualComponents'] = components['sourceLinked']
        contract['designSystem']['componentStatus'] = components['usageState']
        contract['designSystem'].update(self.theme_binding_manifest(frontend))
        return {**contract, 'configState': 'loaded',
                'state': 'ready' if installed and frontend['built'] and rules else 'installed' if installed else 'configured',
                'packages': packages, 'agentRules': {'exists': rules, 'role': 'agent-not-model-prompt'},
                'frontend': frontend, 'selection': self.selection(),
                'components': components, 'localThemes': self.local_theme_manifest(),
                'interactionContract': {'types': list(INTERACTION_TYPES),
                                        'neutralTypes': ['draft-stroke', 'select-question-part'],
                                        'allOtherTypesRecordHelp': True,
                                        'revisionRequired': True,
                                        'operationModels': dict(OPERATION_VIEWS),
                                        'operationBindingRequired': True},
                'consumption': {'server': True, 'model': 'trusted-context-policy',
                                'ui': components['consumer'], 'browserProof': 'not_observed'}}

    def selection(self):
        with self.lock:
            if not self.check_path(SELECTION_PATH).exists():
                return {'view': self.config['defaultView'], 'persisted': False, 'scope': 'local-owner'}
            value = self.read_json(SELECTION_PATH)
            self.validate_selection(value)
            return {**value, 'persisted': True, 'scope': 'local-owner'}

    @staticmethod
    def validate_selection(payload):
        if not isinstance(payload, dict) or set(payload) != {'view'} or payload['view'] not in VIEW_IDS:
            _fail('仅接受JSON对象view，值为01至10。', 'invalid_selection')

    @staticmethod
    def authorize_selection(host, origin, client_address, fetch_site, server_origin):
        parsed = urlsplit(server_origin)
        if (parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost')
                or parsed.path or parsed.query or parsed.fragment or parsed.username or parsed.password
                or client_address not in ('127.0.0.1', '::1') or host != parsed.netloc
                or origin != server_origin or fetch_site not in (None, 'same-origin')):
            _fail('选型写入只接受本机当前页面显式发起的同源操作。', 'selection_origin_blocked', 403)

    def persist_selection(self, payload, *, host, origin, client_address, fetch_site, server_origin):
        self.authorize_selection(host, origin, client_address, fetch_site, server_origin)
        self.validate_selection(payload)
        with self.lock:
            destination = self.check_path(SELECTION_PATH)
            directory = destination.parent
            directory.mkdir(mode=0o700, exist_ok=True)
            descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            temporary = None
            try:
                info = os.fstat(descriptor)
                if info.st_uid != os.getuid():
                    _fail('选型目录须由本机用户拥有。', 'unsafe_selection', 403)
                os.fchmod(descriptor, 0o700)
                if destination.exists():
                    info = destination.lstat()
                    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
                        _fail('选型文件不安全。', 'unsafe_selection', 403)
                fd, temporary = tempfile.mkstemp(prefix='.harness-selection-', suffix='.tmp', dir=directory)
                with os.fdopen(fd, 'wb') as output:
                    # Verify temporary creation against the opened directory before writing any data.
                    created = os.fstat(output.fileno())
                    check = os.stat(Path(temporary).name, dir_fd=descriptor, follow_symlinks=False)
                    if (check.st_ino, check.st_dev) != (created.st_ino, created.st_dev):
                        _fail('选型目录在创建期间变化。', 'unsafe_selection', 409)
                    os.fchmod(output.fileno(), 0o600)
                    output.write(json.dumps({'view': payload['view']}, ensure_ascii=False).encode())
                    output.flush()
                    os.fsync(output.fileno())
                    temp_info = os.fstat(output.fileno())
                check = os.stat(Path(temporary).name, dir_fd=descriptor, follow_symlinks=False)
                if (check.st_ino, check.st_dev) != (temp_info.st_ino, temp_info.st_dev):
                    _fail('选型目录在写入期间变化。', 'unsafe_selection', 409)
                os.replace(Path(temporary).name, destination.name, src_dir_fd=descriptor, dst_dir_fd=descriptor)
                temporary = None
                os.fsync(descriptor)
                return self.selection()
            finally:
                if temporary:
                    try:
                        os.unlink(Path(temporary).name, dir_fd=descriptor)
                    except FileNotFoundError:
                        # A replaced directory may no longer contain the temporary name.
                        pass
                os.close(descriptor)

    def component_manifest(self):
        """Export availability is not proof that a React page renders a component."""
        try:
            exports = self.read_bytes('node_modules/@astryxdesign/core/dist/index.d.ts').decode('utf-8')
        except (OSError, ValueError, UnicodeDecodeError):
            exports = ''
        def value_export(text, name):
            # Type-only names do not constitute runtime component exports.
            return bool(re.search(r'\bexport\s+\{[^}]*\b' + name + r'\b[^}]*\}', text))

        available = []
        for name in INSPECT_COMPONENTS:
            if value_export(exports, name):
                available.append(name)
                continue
            folder = ('theme' if name == 'Theme' else 'Stack' if name in ('HStack', 'VStack')
                      else 'Text' if name == 'Heading' else 'SegmentedControl' if name == 'SegmentedControlItem'
                      else 'Layout' if name in ('LayoutHeader', 'LayoutContent') else name)
            if not re.search(r"export\s+\*\s+from\s+['\"]\./" + folder + r"/index\.js['\"]", exports):
                continue
            try:
                submodule = self.read_bytes(f'node_modules/@astryxdesign/core/dist/{folder}/index.d.ts').decode('utf-8')
            except (OSError, ValueError, UnicodeDecodeError):
                continue
            if value_export(submodule, name):
                available.append(name)
        try:
            chat_barrel = self.read_bytes('node_modules/@astryxdesign/core/dist/Chat/index.d.ts').decode('utf-8')
        except (OSError, ValueError, UnicodeDecodeError):
            chat_barrel = ''
        chat_exports = [name for name in ('ChatLayout', 'ChatComposer', 'ChatComposerInput',
                        'ChatMessageList', 'ChatMessage', 'ChatMessageBubble', 'ChatComposerDrawer')
                        if value_export(chat_barrel, name)]
        source = self.source_component_references(available)
        declared = self.config['designSystem']['actualComponents']
        return {'declared': declared.copy(), 'availableExports': available,
                **source,
                'componentGroups': {'Chat': {'exports': chat_exports,
                                            'notice': 'Chat是组合组件组，不冒称存在单一Chat组件。'}},
                'unconfirmedExports': [name for name in declared if name not in available],
                'actualUsed': source['sourceLinked'], 'renderedComponents': [],
                'usageState': 'source-linked' if source['sourceLinked'] else 'not_runtime_verified',
                'evidence': 'source-import-and-jsx-references-not-browser-render-proof'}

    def source_component_references(self, available):
        """Bounded, read-only reachable-source inspection; never executes TS/JS or claims DOM proof."""
        queue, seen, linked, records = ['src/main.tsx'], set(), set(), []
        consumer, qa_marker = False, False
        while queue and len(seen) < 32:
            relative = queue.pop(0)
            if relative in seen:
                continue
            seen.add(relative)
            try:
                raw = self.read_bytes(relative, limit=1024 * 1024)
                text = raw.decode('utf-8')
            except (OSError, ValueError, UnicodeDecodeError):
                continue
            # Limited source reference evidence, not a TypeScript parser or build attestation.
            clean = re.sub(r'/\*[\s\S]*?\*/|(?m:^\s*//[^\n]*)', '', text)
            imports = {}
            for match in re.finditer(r"import\s*\{([^}]+)\}\s*from\s*['\"]@astryxdesign/core['\"]", clean):
                for item in match[1].split(','):
                    part = item.strip()
                    if part.startswith('type '):
                        continue
                    names = re.fullmatch(r'(\w+)(?:\s+as\s+(\w+))?', part)
                    if names and names[1] in available:
                        imports[names[2] or names[1]] = names[1]
            used = sorted({original for alias, original in imports.items()
                           if re.search(r'<\s*' + re.escape(alias) + r'(?=[\s/>])', clean)})
            linked.update(used)
            records.append({'source': relative, 'sha256': hashlib.sha256(raw).hexdigest(),
                            'imports': sorted(imports.values()), 'jsxReferences': used})
            consumer = consumer or '/api/harness' in clean
            qa_marker = qa_marker or 'STUDIO_QA' in clean
            for module in re.findall(r"\bfrom\s*['\"](\./[^'\"]+)['\"]", clean):
                # Do not normalize traversal, cross-project references, or expose arbitrary source.
                if '..' in module.split('/') or '\\' in module:
                    continue
                base = PurePosixPath(relative).parent / module.removeprefix('./')
                candidates = [str(base)] if base.suffix in ('.tsx', '.ts') else [str(base) + '.tsx', str(base) + '.ts']
                for candidate in candidates:
                    if candidate.startswith('src/') and self._exists(candidate):
                        queue.append(candidate)
                        break
        compiled = []
        frontend = self.frontend_manifest()
        for path in frontend['assets']:
            if not path.endswith('.js'):
                continue
            try:
                raw = self.read_bytes(self.build_path('assets/' + path.removeprefix('/assets/')), limit=8 * 1024 * 1024)
            except (OSError, ValueError):
                continue
            compiled.append({'asset': path, 'sha256': hashlib.sha256(raw).hexdigest(),
                             'harnessEndpointReference': b'/api/harness' in raw,
                             'qaMarkerReference': b'STUDIO_QA' in raw})
        return {'sourceLinked': sorted(linked), 'sourceReferences': records,
                'consumer': 'source-linked /api/harness' if consumer else 'not_source_linked',
                'qaMarkerDeclared': qa_marker, 'browserProof': 'not_observed',
                'compiledEvidence': {'builtEntryExists': frontend['entryExists'],
                                     'built': frontend['built'], 'references': compiled,
                                     'notice': '源码引用不证明产物新鲜、分支被执行或DOM已渲染。'}}

    @staticmethod
    def public_projection(value):
        """Defense in depth for registered public metadata, never expose raw inventories."""
        blocked = {'scoredFields', 'localEvidence', 'localFile', 'path', 'ocrJSON',
                   'rawEvidence', 'rawOCR', 'readingStatus', 'extractionMethod'}
        if isinstance(value, dict):
            return {key: Harness.public_projection(item) for key, item in value.items()
                    if isinstance(key, str) and not key.startswith('_') and key not in blocked}
        if isinstance(value, (list, tuple)):
            return [Harness.public_projection(item) for item in value]
        return copy.deepcopy(value)

    def curriculum(self, store):
        if store is None:
            _fail('课程服务尚未初始化。', 'curriculum_unavailable', 503)
        document = store.curriculum.public()
        public = self.public_projection(document)
        public['integrationStatus'] = 'active_store_http'
        # Evidence files are fixed internal inputs, never selected by a URL/query.
        try:
            bundled_evidence = self.read_json(self.build_path('data/curriculum-clauses.json'))
        except FileNotFoundError:
            bundled_evidence = {}
        try:
            local_evidence = self.read_json('.runtime/curriculum-research/source-clauses.json')
        except FileNotFoundError:
            local_evidence = {}

        def clause_rows(evidence):
            clauses = evidence.get('clauses', [])
            if not isinstance(clauses, list):
                _fail('来源条款结构不正确。', 'invalid_source_clauses')
            result = {}
            for row in clauses:
                if isinstance(row, dict) and isinstance(row.get('id'), str):
                    if row['id'] in result:
                        _fail('来源条款ID重复。', 'invalid_source_clauses')
                    result[row['id']] = row
            return result

        # Merge per registered ID: reviewed local evidence wins; missing local
        # entries can use the fixed built public subset, never arbitrary files.
        bundled_by_id = clause_rows(bundled_evidence)
        local_by_id = clause_rows(local_evidence)
        by_id = {**bundled_by_id, **local_by_id}
        known_urls = {row.get('sourceURL') for row in public.get('sources', {}).values()
                      if isinstance(row, dict)}
        for registered in public.get('sourceClauses', []):
            identifier = registered.get('id')
            row = by_id.get(identifier, {})
            bundled = identifier in bundled_by_id and identifier not in local_by_id
            url = row.get('sourceURL')
            page = row.get('physicalPage')
            if (url in known_urls and isinstance(url, str) and url.startswith('https://')
                    and type(page) is int and page in (30, 31, 32, 40, 41, 47, 96, 97)
                    and page == registered.get('physicalPage')
                    and row.get('printedPage') == registered.get('printedPage')):
                registered['sourceURL'] = url
                registered['sourceLink'] = url.split('#', 1)[0] + f'#page={page}'
                for key, limit in (('quote', 600 if bundled else 3000), ('section', 200 if bundled else 600)):
                    text = row.get(key)
                    if isinstance(text, str) and 0 < len(text) <= limit:
                        registered[key] = text
        for source_id, source in public.get('sources', {}).items():
            originals = document.get('sources', {}).get(source_id, {}).get('imageEvidence', [])
            source['imageEvidence'] = []
            for image in originals:
                if not isinstance(image, dict):
                    continue
                name = image.get('path', '').removeprefix('验收/')
                if (name in ('人教五上-实际目录-p6.jpg', '人教五上-实际目录-p7.jpg',
                             '人教五下-实际目录-p6.jpg', '人教五下-实际目录-p7.jpg')
                        and image.get('physicalPage') in (6, 7)):
                    source['imageEvidence'].append({
                        'url': '/验收/' + name, 'physicalPage': image['physicalPage'],
                        'pageIdentity': image.get('pageIdentity'),
                        'available': self._exists('验收/' + name)})
        return public

    def curriculum_coverage(self, store, payload):
        from questions import FAMILIES, build_question
        if store is None:
            _fail('课程服务尚未初始化。', 'curriculum_unavailable', 503)
        if (not isinstance(payload, dict) or set(payload) != {'curriculumProfile'}
                or not isinstance(payload['curriculumProfile'], dict)):
            _fail('仅接受curriculumProfile对象，不接受身份、答案或字段覆盖。', 'invalid_curriculum_profile')
        curriculum = store.curriculum
        try:
            profile = curriculum.normalize_profile(payload['curriculumProfile'])
        except (ValueError, TypeError):
            _fail('课程范围不合法，请核对教材版本、学期与已学单元。', 'invalid_curriculum_profile')
        # Cache bounded public results and actual questions, keyed by active content and registry.
        content = (id(store), store.content_version, curriculum.version, tuple(FAMILIES), id(build_question))
        profile_key = json.dumps(profile, sort_keys=True, ensure_ascii=False)
        with self.lock:
            if self._coverage_bank is None or self._coverage_bank[0] != content:
                questions = {family: [build_question(family, variant, phase)
                             for phase in ('screen', 'probe', 'verify', 'transfer', 'challenge')
                             for variant in range(4)] for family in FAMILIES}
                self._coverage_bank = (content, questions)
                self._coverage_results.clear()
            if profile_key not in self._coverage_results:
                result = self.public_projection(curriculum.coverage(profile, self._coverage_bank[1]))
                result['contentVersion'] = store.content_version
                result['supportBasis'] = {'familyCount': len(FAMILIES), 'variants': 4,
                                          'phases': ['screen', 'probe', 'verify', 'transfer', 'challenge'],
                                          'questionCount': len(FAMILIES) * 20,
                                          'kind': 'actual_scored_field_bindings_not_learner_results'}
                if len(self._coverage_results) >= 32:
                    self._coverage_results.pop(next(iter(self._coverage_results)))
                self._coverage_results[profile_key] = result
            return copy.deepcopy(self._coverage_results[profile_key])

    @staticmethod
    def design_example(query):
        from questions import build_question, public_question
        topics = ('decimal_multiply', 'parallelogram_area', 'fraction_add', 'line_charts')
        if (set(query) != {'topic', 'state'} or any(len(values) != 1 for values in query.values())
                or query['topic'][0] not in topics or query['state'][0] not in ('think', 'coach', 'verify')):
            _fail('预览仅接受四个topic与think/coach/verify状态。', 'invalid_design_example')
        topic, state = query['topic'][0], query['state'][0]
        # think/coach share the exact original; verify is a distinct real bank representation.
        phase = 'verify' if state == 'verify' else 'screen'
        question = public_question(build_question(topic, variant=0, phase=phase))
        for key in ('instanceId', 'id', 'token', 'signature', 'answers', 'scoredFields'):
            question.pop(key, None)
        explanations = {
            'decimal_multiply': ('把乘数看作取原数量的几倍，先想缩放关系，不急着列竖式。', '你把第二个数理解成怎样的一份？'),
            'parallelogram_area': ('看图中的底和与它垂直的距离，尝试想象剪移后这两条长度如何对应。', '你认为图中哪条长度和所选的底对应，为什么？'),
            'fraction_add': ('先看两部分是不是同一个整体，再用同样大小的单位份表示，不先代算。', '你准备怎样让两部分的一份一样大？'),
            'line_charts': ('先看纵轴起点与每格单位，再沿相邻两天的点比较；未记录的天不能当作已有事实。', '你读第二天的点时，怎样使用纵轴刻度？'),
        }
        result = {'kind': 'design_example', 'live': False, 'question': question,
                  'preview': {'state': state, 'phase': phase, 'persisted': False,
                              'notice': '匿名界面预览，不是学习会话；未调用AI，不记录作答或掌握。'}}
        if state == 'coach':
            reply, ask = explanations[topic]
            result['teacher'] = {'kind': 'preview_explanation', 'ai': False, 'reply': reply, 'question': ask}
        return result

    @staticmethod
    def validate_presentation(value):
        if (not isinstance(value, dict) or set(value) not in
                ({'view', 'version'}, {'view', 'version', 'policyVersion'})
                or value['view'] not in VIEW_IDS or value['version'] != VERSION):
            _fail('呈现绑定仅接受01至10与Harness版本0.3.0。', 'invalid_presentation')
        if 'policyVersion' in value and (value['view'] not in AUTOMATIC_VIEWS
                or value['policyVersion'] != AUTOMATIC_POLICY_VERSION):
            _fail('自动策略版本仅支持automatic-1及01、05、06。', 'invalid_presentation')
        return copy.deepcopy(value)

    def start_session(self, store, payload, *, owner=None, check_capacity=None):
        if not isinstance(payload, dict):
            _fail('课堂参数须为对象。', 'invalid_payload')
        request = copy.deepcopy(payload)
        presentation = self.validate_presentation(request.pop('presentation')) if 'presentation' in request else None
        if 'completeLive' in request or ('answerFlow' in request and request['answerFlow'] != 'automatic'):
            _fail('仅接受answerFlow=automatic，旧客户端省略该字段。', 'invalid_answer_flow')
        automatic = request.get('answerFlow') == 'automatic'
        if automatic and (presentation is None or presentation.get('policyVersion') != AUTOMATIC_POLICY_VERSION):
            _fail('自动流须显式绑定01、05、06与已知policyVersion。', 'automatic_presentation_required')
        if not automatic and presentation is not None and 'policyVersion' in presentation:
            _fail('自动策略版本须同时显式启用answerFlow。', 'invalid_answer_flow')
        if presentation is not None:
            request['presentation'] = presentation
        # One durable creation transaction also binds the presentation and owner.
        # A lost HTTP response can safely replay the same requestId and capability.
        return store.start_request(request, owner=owner, check_capacity=check_capacity)

    @staticmethod
    def session_view(store, identifier, token, operation=None):
        with store.lock:
            result = operation() if operation else store.view(identifier, token)
            session = store._load(result.get('id', identifier), result.get('token', token))
            if 'presentation' in session:
                result = {**result, 'presentation': Harness.validate_presentation(session['presentation'])}
            return result

    @staticmethod
    def _interaction_value(kind, value, question):
        def exact(keys):
            if not isinstance(value, dict) or set(value) != set(keys):
                _fail('交互值包含未知字段或结构无效。', 'invalid_interaction')

        def number(number, minimum=0, maximum=10000):
            return type(number) in (int, float) and math.isfinite(number) and minimum <= number <= maximum

        if kind == 'draft-stroke':
            exact(('strokeCount',))
            if type(value['strokeCount']) is not int or not 0 <= value['strokeCount'] <= 1000:
                _fail('笔迹事件只接受有限笔数，不接收笔迹坐标。', 'invalid_interaction')
        elif kind == 'select-question-part':
            if isinstance(value, str):
                if not 1 <= len(value.strip()) <= 120:
                    _fail('批注须为1至120字。', 'invalid_interaction')
                return value
            exact(('text', 'index', 'questionId', 'prompt', 'selectionStart', 'selectionEnd'))
            start, end = value['selectionStart'], value['selectionEnd']
            if (value['questionId'] != question['instanceId'] or value['prompt'] != question['prompt']
                    or type(start) is not int or type(end) is not int
                    or not 0 <= start < end <= len(question['prompt'])
                    or type(value['index']) is not int or not 0 <= value['index'] <= 1000
                    or not isinstance(value['text'], str) or not 1 <= len(value['text']) <= 120
                    or question['prompt'][start:end] != value['text']):
                _fail('批注必须绑定当前题真实片段。', 'invalid_interaction')
            return value['text']
        elif kind in ('explore-length', 'ribbon-cut'):
            exact(('length', 'target') if kind == 'explore-length' else ('length',))
            if not number(value['length'], 0, 100) or (kind == 'explore-length' and not number(value['target'], 0, 100)):
                _fail('长度超出已登记操作范围。', 'invalid_interaction')
            if question['family'] != 'decimal_multiply':
                _fail('当前题未登记长度操作模型。', 'invalid_interaction')
            rows = question.get('diagram', {}).get('rows', [])
            if (not rows or not isinstance(rows[0], list) or len(rows[0]) < 2
                    or not number(float(rows[0][1]), 0, 100)):
                _fail('当前题没有实际长度目标。', 'invalid_interaction')
            target = float(rows[0][1])
            if kind == 'explore-length' and value['target'] != target:
                _fail('操作目标必须来自当前题给定量。', 'invalid_interaction')
            if kind == 'ribbon-cut' and (target > 1 or value['length'] not in (1, target)):
                _fail('彩带操作仅接受当前目标或放回整条。', 'invalid_interaction')
        elif kind == 'open-operation-model':
            exact(('tool', 'questionId'))
            if (not isinstance(value['tool'], str) or value['tool'] not in OPERATION_VIEWS
                    or value['questionId'] != question['instanceId']):
                _fail('操作模型须为已登记工具并绑定当前题。', 'invalid_interaction')
        elif kind == 'co-write-demonstration':
            exact(('questionId',))
            if value['questionId'] != question['instanceId']:
                _fail('示范不属于当前题。', 'invalid_interaction')
        elif kind == 'link-representations':
            exact(('linked',))
            if type(value['linked']) is not bool:
                _fail('图式连接状态须为布尔值。', 'invalid_interaction')
        elif kind == 'compare-method':
            exact(('method',))
            methods = ('按位计算', '取一半', '图中找关系') if question['family'] == 'decimal_multiply' else ('符号推理', '图中找关系')
            if value['method'] not in methods:
                _fail('方法未在当前题的讨论选项登记。', 'invalid_interaction')
            if value['method'] == '取一半':
                rows = question.get('diagram', {}).get('rows', [])
                if not rows or len(rows[0]) < 2 or str(rows[0][1]) != '0.5':
                    _fail('当前题乘数不是一半，不采用该方法标签。', 'invalid_interaction')
        elif kind == 'diagram-data':
            exact(('series', 'x', 'y'))
            spec = question.get('diagram', {}).get('renderSpec', {})
            diagram = question.get('diagram', {})
            points = spec.get('points', [])
            if diagram.get('kind') == 'bars':
                points = [[i + 1, value] for i, value in enumerate(diagram.get('values', []))]
            series = spec.get('series') or [{'points': points}]
            index = value['series']
            if (type(index) is not int or not 0 <= index < len(series)
                    or not number(value['x'], -10000) or not number(value['y'], -10000)
                    or [value['x'], value['y']] not in series[index].get('points', [])):
                _fail('数据点须来自当前题实际图表。', 'invalid_interaction')
        elif kind == 'diagram-segment':
            if not isinstance(value, dict):
                _fail('图段格式无效。', 'invalid_interaction')
            subtype = value.get('kind')
            if subtype == 'ribbon':
                exact(('kind', 'row', 'part', 'guided'))
                diagram = question.get('diagram', {})
                row = value['row']
                fractions = [diagram.get('a'), diagram.get('b')]
                if (type(row) is not int or row not in (0, 1) or diagram.get('kind') != 'ribbons'
                        or not isinstance(fractions[row], list) or len(fractions[row]) != 2
                        or type(value['part']) is not int or not 1 <= value['part'] <= fractions[row][1]
                        or type(value['guided']) is not bool):
                    _fail('图段不属于当前题。', 'invalid_interaction')
            elif subtype in ('layer', 'scene-part'):
                exact(('kind', 'id'))
                if type(value['id']) is not int or not 1 <= value['id'] <= 100:
                    _fail('图段编号无效。', 'invalid_interaction')
                spec = question.get('diagram', {}).get('renderSpec', {})
                if subtype == 'layer':
                    diagram = question.get('diagram', {})
                    height = spec.get('height') if spec.get('kind') == 'solid' else None
                    if diagram.get('meaning') == 'volume_layer':
                        match = re.search(r'共(\d+)层', question['prompt'])
                        height = int(match[1]) if match else None
                    if not number(height, 1, 100) or value['id'] > height:
                        _fail('图层必须来自当前题实际高度。', 'invalid_interaction')
                if subtype == 'scene-part' and (question['family'] != 'decimal_multiply' or value['id'] > 2):
                    _fail('当前题没有该生活分段模型。', 'invalid_interaction')
            else:
                _fail('未登记的图段类型。', 'invalid_interaction')
        return copy.deepcopy(value)

    def _authorize_operation_model(self, session, value):
        presentation = session.get('presentation')
        if presentation is None:
            _fail('请从已绑定呈现方案的课堂打开模型。', 'operation_presentation_required', 403)
        presentation = self.validate_presentation(presentation)
        if presentation['view'] != OPERATION_VIEWS[value['tool']]:
            _fail('操作模型不属于当前课堂绑定方案。', 'operation_view_mismatch', 403)
        question = session['current']
        if value['tool'] in ('workbench', 'ribbon-shop'):
            if question['family'] != 'decimal_multiply':
                _fail('当前题未登记这个小数操作模型。', 'operation_model_unavailable')
            rows = question.get('diagram', {}).get('rows', [])
            try:
                row = rows[0]
                if not isinstance(row, list) or len(row) < 3 or row[2] != '×':
                    raise ValueError()
                first, second = float(row[0]), float(row[1])
                if (isinstance(row[0], bool) or isinstance(row[1], bool)
                        or not math.isfinite(first) or not math.isfinite(second)
                        or not 0 < first <= 10000 or not 0 < second <= 100):
                    raise ValueError()
            except (ValueError, TypeError, IndexError, OverflowError):
                _fail('当前题没有可核对的乘法给定量，不生成虚构模型。', 'operation_model_unavailable')
    def interaction(self, store, identifier, token, payload):
        if (not isinstance(payload, dict) or set(payload) != {'instanceId', 'revision', 'type', 'value'}
                or not isinstance(payload['type'], str) or payload['type'] not in INTERACTION_TYPES
                or type(payload['revision']) is not int):
            _fail('交互须含当前instanceId、整数revision、已登记type与value。', 'invalid_interaction')
        with store.lock, store.db:
            if not store.db.in_transaction:
                store.db.execute('BEGIN IMMEDIATE')
            session = store._load(identifier, token)
            store._require_current(session, payload)
            if session['paused'] or store._limit_reached(session):
                _fail('课堂暂停或预算已到，未记录交互。', 'session_inactive', 409)
            question = session['current']
            if session.get('awaitingNext') or any(row['instanceId'] == question['instanceId'] for row in session['results']):
                _fail('答案已提交，交互不能追溯更改独立评分。', 'already_answered', 409)
            kind = payload['type']
            value = self._interaction_value(kind, payload['value'], question)
            if kind == 'open-operation-model':
                self._authorize_operation_model(session, value)
            assisted = kind not in ('draft-stroke', 'select-question-part')
            if assisted:
                question['helped'] = True
                question.setdefault('toolEvents', []).append({'name': kind, 'time': store.clock()})
                store._event(session, 'help', {'instanceId': question['instanceId'], 'kind': 'tool', 'name': kind})
            if kind == 'select-question-part':
                question['annotation'] = value
            store._event(session, 'interaction', {'instanceId': question['instanceId'],
                         'type': kind, 'value': value, 'assisted': assisted, 'trust': 'UNTRUSTED'})
            # Invalidate racing answer/model payloads after every accepted interaction.
            session['revision'] += 1
            store._save(session)
            result = store._view(session)
            if 'presentation' in session:
                result['presentation'] = self.validate_presentation(session['presentation'])
            return result

    def model_store(self, store):
        harness = self

        class PolicyStore:
            def __getattr__(self, name):
                return getattr(store, name)

            def context(self, *args, **kwargs):
                # context and binding must be read under one lock to avoid mixing question generations.
                with getattr(store, 'lock', harness.lock):
                    context = copy.deepcopy(store.context(*args, **kwargs))
                    if hasattr(store, '_load'):
                        identifier = args[0] if args else kwargs.get('identifier')
                        token = args[1] if len(args) > 1 else kwargs.get('token')
                        session = store._load(identifier, token)
                        presentation = session.get('presentation')
                        context['currentPresentation'] = {
                            'view': harness.validate_presentation(presentation)['view'] if presentation else None,
                            'version': VERSION, 'explicitlyScaffolded': bool((session.get('current') or {}).get('helped')),
                            **({'policyVersion': AUTOMATIC_POLICY_VERSION}
                               if session.get('answerFlow') == 'automatic' else {})}
                        question = context.get('question')
                        if question:
                            for key in ('strokes', 'toolEvents', 'stepEvents', 'signature'):
                                question.pop(key, None)
                            annotation = question.pop('annotation', None)
                            if isinstance(annotation, str):
                                context['studentAnnotation_UNTRUSTED'] = annotation[:120]
                adapter = getattr(store, 'teacher_motion', None)
                context['teacherToolContract'] = {
                    'version': 'teacher-actions-1', 'actions': ['board.write', 'board.focus', 'board.animate'],
                    'currentTeacherTools': copy.deepcopy(harness.config.get('teacherTools', TEACHER_TOOLS)),
                    'productionAdapter': adapter.status() if adapter else {'engine': 'OpenMotion', 'available': False},
                    'animate': {'maxPerTurn': 1, 'durationSeconds': [4, 12],
                        'existingOrWrittenBlockOnly': True, 'noTaskRoutingSameTurn': True,
                        'noHTMLCodeURL': True, 'notAnAssessment': True},
                    'instruction': '动画只更新当前孩子同一黑板，不另开产品。先写安全板书，异步完成后才就绪。'
                                   '不能根据动画播放、工具成功或模型自评推断掌握。'}
                context['harnessTeachingPolicy'] = {
                    'version': VERSION, 'classroomActionVersion': 'teacher-actions-1',
                    'classroomActionPolicy': '仅显式classroomActions启用结构化执行；task.open仅待确认提议，'
                                             'pendingTask等待孩子确认，不执行另一task动作；仅显式HTTP确认开支线，'
                                             '真实题族／子图／预算由服务端复核，原实例初答与支线证据分开。',
                    **copy.deepcopy(harness.config['teachingPolicy']),
                    'instruction': '留在当前原题；先确认理由，不假设错因；每轮只围绕一个焦点。'
                                   '受助与答案暴露必须记证据；评分不是掌握，须未见题独立验证。'
                                   '不声称看懂未上传笔迹，不以界面方案或设计规则替代教学证据。',
                    'privacy': copy.deepcopy(harness.config['privacy']),
                    'limits': copy.deepcopy(harness.config['limits']),
                }
                return context

        return PolicyStore()
