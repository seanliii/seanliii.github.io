"""A source-labelled view of the existing local primary maths curriculum."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

SOURCE = Path(__file__).resolve().parent.parent / '产品原型/data/lower-curriculum.json'


class GraphIndex:
    def __init__(self, source: Path | None = None):
        self.source = Path(source or SOURCE)
        raw = self.source.read_bytes()
        document = json.loads(raw)
        self.version = hashlib.sha256(raw).hexdigest()[:16]
        self.nodes = {
            key: dict(value) for key, value in document.items()
            if value.get('stage') == '小学'
            and type(value.get('grade')) is int and 1 <= value['grade'] <= 5
        }
        self.excluded = [key for key, value in document.items()
                         if value.get('stage') == '小学' and not (
                             type(value.get('grade')) is int and 1 <= value['grade'] <= 5)]
        self.edges = []
        self.missing = []
        for target, node in self.nodes.items():
            for prerequisite in node.get('prerequisites', []):
                if prerequisite not in self.nodes:
                    self.missing.append({'source': prerequisite, 'target': target})
                    continue
                self.edges.append({
                    'source': prerequisite, 'target': target, 'type': 'registered_prerequisite',
                    'status': '本地课程登记关系；不是已验证的错误原因或群体概率',
                    'sourceLocator': node.get('sourceLocator', ''),
                })
        self.children = {key: [] for key in self.nodes}
        for edge in self.edges:
            self.children[edge['source']].append(edge['target'])
        self._validate()

    def _validate(self):
        visiting, visited = set(), set()

        def visit(key):
            if key in visiting:
                raise ValueError('课程先备图有环，不能据此路由')
            if key in visited:
                return
            visiting.add(key)
            for prerequisite in self.nodes[key].get('prerequisites', []):
                if prerequisite in self.nodes:
                    visit(prerequisite)
            visiting.remove(key)
            visited.add(key)

        for key in self.nodes:
            visit(key)

    def public(self):
        return {
            'version': self.version, 'nodeCount': len(self.nodes), 'edgeCount': len(self.edges),
            'grades': {str(grade): sum(node['grade'] == grade for node in self.nodes.values())
                       for grade in range(1, 6)},
            'nodes': self.nodes, 'edges': self.edges, 'missingReferences': self.missing,
            'source': '复用既有本地课程设计；来源定位保留，不是官方教材逐字图谱',
            'notice': '登记不等于全覆盖，前置关系不等于错误原因；未测节点不判断掌握。',
            'excludedNotice': '六年级内容和异常学段标签不进入本次五年级诊断。',
        }

    def subgraph(self, skills, depth=2):
        selected = set()

        def collect(key, remaining):
            if key not in self.nodes or key in selected:
                return
            selected.add(key)
            if remaining:
                for previous in self.nodes[key].get('prerequisites', []):
                    collect(previous, remaining - 1)

        for skill in skills:
            collect(skill, depth)
        return {
            'nodes': {key: self.nodes[key] for key in self.nodes if key in selected},
            'edges': [edge for edge in self.edges
                      if edge['source'] in selected and edge['target'] in selected],
        }

    def nearest_prerequisites(self, skills):
        """Breadth-first registered ancestors; distance is not an error probability."""
        seen = set(skills)
        frontier = list(skills)
        rows, distance = [], 0
        while frontier:
            distance += 1
            following = []
            for skill in frontier:
                for previous in self.nodes.get(skill, {}).get('prerequisites', []):
                    if previous in self.nodes and previous not in seen:
                        seen.add(previous)
                        following.append(previous)
                        rows.append({'id': previous, 'distance': distance})
            frontier = following
        return rows

    def title(self, skill):
        return self.nodes.get(skill, {}).get('title', skill)
