"""Private public-math runtime: strict config, hashed sessions and atomic budgets."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import threading
import time
from http.cookies import SimpleCookie

from engine import TutorError

COOKIE_NAME = '__Secure-xiaomei-math'
DEVICE_COOKIE_NAME = '__Secure-xiaomei-math-device'
PUBLIC_ORIGIN = 'https://play.vortexsean.com'
PREFIX = '/xiaomei-math/'
VIEWS = ('01', '05', '06')


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate key')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))


def no_links(path):
    path = Path(os.path.abspath(path))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        if current.is_symlink():
            raise ValueError('unsafe private path')
    return path


def private_file(path, limit=16384):
    path = no_links(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1
                or not 0 < info.st_size <= limit):
            raise ValueError('unsafe private file')
        raw = os.read(fd, limit + 1)
        if len(raw) > limit:
            raise ValueError('private file limit')
        return raw
    finally:
        os.close(fd)


def private_directory(path):
    path = no_links(path)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = path.stat()
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) != 0o700):
        raise ValueError('unsafe private directory')
    return path


def load_config(path, runtime_root):
    """Strict runtime contract, including explicit nullable unlimited budgets."""
    try:
        path = no_links(path)
        value = strict_json(private_file(path))
        root = no_links(runtime_root)
        if set(value) != {'schema', 'publicOrigin', 'prefix', 'runtimeRoot', 'auth', 'budget', 'credentials'}:
            raise ValueError()
        if (type(value['schema']) is not int or value['schema'] != 1
                or value['publicOrigin'] != PUBLIC_ORIGIN or value['prefix'] != PREFIX
                or value['runtimeRoot'] != str(root)):
            raise ValueError()
        if str(root) == '/var/lib/xiaomei-math' and path != Path('/etc/xiaomei-math/settings.json'):
            raise ValueError()
        auth = value['auth']
        if (not isinstance(auth, dict)
                or set(auth) not in ({'algorithm', 'iterations', 'salt', 'passwordHash', 'cookieName'},
                                    {'algorithm', 'iterations', 'salt', 'passwordHash', 'cookieName', 'accessMode'})
                or auth.get('accessMode', 'password') not in ('anonymous', 'password')
                or auth['algorithm'] != 'pbkdf2-sha256' or type(auth['iterations']) is not int
                or not 600000 <= auth['iterations'] <= 2000000
                or not isinstance(auth['salt'], str) or not re.fullmatch('[a-f0-9]{32,64}', auth['salt'])
                or len(auth['salt']) % 2 or not isinstance(auth['passwordHash'], str)
                or not re.fullmatch('[a-f0-9]{64}', auth['passwordHash'])
                or auth['cookieName'] != COOKIE_NAME):
            raise ValueError()
        budget = value['budget']
        legacy_keys = {'ledger', 'maxModelCalls', 'voicePolicy'}
        daily_keys = legacy_keys | {'policy', 'windowSeconds', 'deviceModelCalls',
                                    'maxServiceModelCalls', 'maxCredits'}
        unlimited_keys = legacy_keys | {'policy'}
        if (not isinstance(budget, dict) or set(budget) not in (legacy_keys, daily_keys, unlimited_keys)
                or budget['ledger'] != str(root / 'budget.sqlite3')):
            raise ValueError()
        if set(budget) == unlimited_keys:
            if (budget['policy'] != 'unlimited' or budget['maxModelCalls'] is not None
                    or budget['voicePolicy'] != 'unlimited'):
                raise ValueError()
        elif (type(budget['maxModelCalls']) is not int or not 0 < budget['maxModelCalls'] <= 30
                or budget['voicePolicy'] != 'existing-no-override'):
            raise ValueError()
        if set(budget) == daily_keys and (
                budget['policy'] != 'daily-device-v1'
                or type(budget['windowSeconds']) is not int or budget['windowSeconds'] != 86400
                or type(budget['deviceModelCalls']) is not int or not 1 <= budget['deviceModelCalls'] <= 30
                or type(budget['maxServiceModelCalls']) is not int
                or not budget['deviceModelCalls'] <= budget['maxServiceModelCalls'] <= 120
                or type(budget['maxCredits']) not in (int, float)
                or not math.isfinite(budget['maxCredits']) or not 0 < budget['maxCredits'] <= 5):
            raise ValueError()
        credentials = value['credentials']
        if set(credentials) != {'kie', 'doubao'}:
            raise ValueError()
        private_directory(path.parent / 'credentials')
        for key, name in (('kie', 'kie-api-key'), ('doubao', 'doubao-realtime.json')):
            if credentials[key] != str(path.parent / 'credentials' / name):
                raise ValueError()
            private_file(credentials[key])
        if str(root) == '/var/lib/xiaomei-math':
            parent_info = path.parent.stat()
            if (parent_info.st_uid != 0 or parent_info.st_gid != os.getgid()
                    or stat.S_IMODE(parent_info.st_mode) != 0o750):
                raise ValueError()
        private_directory(root)
        return value
    except (OSError, ValueError, TypeError, KeyError):
        raise ValueError('public-math private configuration is not ready') from None


def private_database(path):
    path = no_links(path)
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
            raise ValueError('unsafe private database')
    finally:
        os.close(fd)
    for suffix in ('-journal', '-wal', '-shm'):
        sidecar = no_links(str(path) + suffix)
        if sidecar.exists():
            info = sidecar.stat()
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) != 0o600):
                raise ValueError('unsafe database sidecar')
    db = sqlite3.connect(path, timeout=5, check_same_thread=False)
    db.execute('PRAGMA busy_timeout=5000')
    return db


def cookie_values(header):
    """Reject ambiguous repeated cookie names; only expected opaque tokens are used."""
    if not isinstance(header, str) or len(header) > 4096:
        return None
    result = {}
    for item in header.split(';'):
        if '=' not in item:
            return None
        key, value = item.strip().split('=', 1)
        if key in result:
            return None
        result[key] = value
    return result


class CloudRuntime:
    def __init__(self, config_path, runtime_root, clock=None):
        self.config = load_config(config_path, runtime_root)
        self.root = Path(self.config['runtimeRoot'])
        self.clock = clock or time.time
        self.lock = threading.RLock()
        self.db = private_database(self.root / 'access.sqlite3')
        info = (self.root / 'access.sqlite3').stat()
        self._access_identity = (info.st_dev, info.st_ino)
        columns = {row[1] for row in self.db.execute('PRAGMA table_info(access_sessions)')}
        if columns and 'owner' not in columns:
            # Old owner-per-auth tokens cannot be safely attributed to a device.
            self.db.execute('ALTER TABLE access_sessions ADD COLUMN owner TEXT')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS access_sessions(token_hash TEXT PRIMARY KEY, expires REAL NOT NULL, owner TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS devices(token_hash TEXT PRIMARY KEY, expires REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS bindings(owner TEXT NOT NULL, kind TEXT NOT NULL, resource TEXT NOT NULL,
                PRIMARY KEY(kind,resource));
            CREATE TABLE IF NOT EXISTS login_attempts(scope TEXT PRIMARY KEY, started REAL NOT NULL, attempts INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS anonymous_tokens(owner TEXT PRIMARY KEY, nonce TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS access_owner ON access_sessions(owner);
        ''')
        self.db.commit()
        self.ledger = private_database(self.config['budget']['ledger'])
        self.ledger.executescript('''
            CREATE TABLE IF NOT EXISTS model_calls(id INTEGER PRIMARY KEY, created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS kie_usage(id INTEGER PRIMARY KEY CHECK(id=1), credits REAL NOT NULL, tasks INTEGER NOT NULL);
            INSERT OR IGNORE INTO kie_usage VALUES(1,0,0);
        ''')
        self.ledger.commit()
        self._migrate_budget()
        private_database(self.root / 'sessions.sqlite3').close()
        private_directory(self.root / 'voice')

    @staticmethod
    def digest(token):
        return hashlib.sha256(token.encode()).hexdigest()

    @property
    def anonymous(self):
        return self.config['auth'].get('accessMode', 'password') == 'anonymous'

    def valid_db(self):
        """Fail closed if the access file or its private metadata was replaced."""
        try:
            path = no_links(self.root / 'access.sqlite3')
            info = path.stat()
            if (info.st_dev, info.st_ino) != self._access_identity:
                return False
            probe = private_database(path)
            probe.close()
            info = path.stat()
            return (info.st_dev, info.st_ino) == self._access_identity
        except (OSError, ValueError, sqlite3.Error):
            return False

    def authenticate(self, header):
        if cookie_values(header) is None or not self.valid_db():
            return None
        try:
            cookie = SimpleCookie()
            cookie.load(header)
            token = cookie[COOKIE_NAME].value
            device = cookie[DEVICE_COOKIE_NAME].value
            if not all(re.fullmatch(r'[A-Za-z0-9_-]{43}', value or '') for value in (token, device)):
                return None
        except (KeyError, ValueError):
            return None
        auth_hash = self.digest(token)
        owner = self.digest(device)
        with self.lock:
            row = self.db.execute('SELECT expires,owner FROM access_sessions WHERE token_hash=?', (auth_hash,)).fetchone()
            device_row = self.db.execute('SELECT expires FROM devices WHERE token_hash=?', (owner,)).fetchone()
        return owner if (row and row[0] > self.clock() and row[1] == owner
                         and device_row and device_row[0] > self.clock()) else None

    def login(self, payload, cookie_header=None):
        if set(payload) != {'password'} or not isinstance(payload['password'], str) or not 1 <= len(payload['password']) <= 256:
            raise TutorError('invalid_access', '请输入访问密码。', 422)
        now = self.clock()
        # All proxy traffic is loopback: use a global persistent bucket, not spoofable forwarded IPs.
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.db.execute("SELECT started,attempts FROM login_attempts WHERE scope='global'").fetchone()
            started, count = row if row and now - row[0] < 600 else (now, 0)
            if count >= 8:
                raise TutorError('access_throttled', '尝试次数较多，请十分钟后再试。', 429)
            self.db.execute("INSERT OR REPLACE INTO login_attempts VALUES('global',?,?)", (started, count + 1))
        auth = self.config['auth']
        actual = hashlib.pbkdf2_hmac('sha256', payload['password'].encode(), bytes.fromhex(auth['salt']), auth['iterations']).hex()
        if not hmac.compare_digest(actual, auth['passwordHash']):
            raise TutorError('access_denied', '访问密码不正确。', 401)
        token = secrets.token_urlsafe(32)
        device = (cookie_values(cookie_header) or {}).get(DEVICE_COOKIE_NAME)
        if not device or not re.fullmatch(r'[A-Za-z0-9_-]{43}', device):
            device = None
        with self.lock, self.db:
            owner = self.digest(device) if device else None
            device_row = (self.db.execute('SELECT expires FROM devices WHERE token_hash=?', (owner,)).fetchone()
                          if owner else None)
            if not device_row or device_row[0] <= now:
                device = secrets.token_urlsafe(32)
                owner = self.digest(device)
            self.db.execute('DELETE FROM access_sessions WHERE expires<=?', (now,))
            if self.db.execute('SELECT COUNT(*) FROM access_sessions').fetchone()[0] >= 128:
                raise TutorError('access_capacity', '当前访问较多，请稍后再试。', 429)
            self.db.execute('INSERT INTO access_sessions VALUES(?,?,?)', (self.digest(token), now + 21600, owner))
            self.db.execute('INSERT OR REPLACE INTO devices VALUES(?,?)', (owner, now + 2592000))
        return token, device

    @staticmethod
    def _anonymous_token(device, nonce):
        # Only a hash and a nonce are persisted, never a usable cookie.
        raw = hmac.new(device.encode(), ('anonymous:' + nonce).encode(), hashlib.sha256).digest()
        return base64.urlsafe_b64encode(raw).decode().rstrip('=')

    def open_anonymous(self, cookie_header, client_scope=None):
        """Explicit bootstrap only; return (access token, stable device token).

        client_scope is an optional server-trusted rate bucket, not an identity or
        bot defence. Do not invoke this for unauthenticated assets or general APIs.
        """
        if not self.anonymous:
            raise TutorError('access_required', '请输入访问密码。', 403)
        if not self.valid_db():
            raise TutorError('access_required', '课堂访问无法核验，请稍后再试。', 403)
        if client_scope is not None and (not isinstance(client_scope, str) or not 1 <= len(client_scope) <= 256):
            raise TutorError('invalid_access', '访问请求无法核验。', 422)
        values = cookie_values(cookie_header) or {}
        device = values.get(DEVICE_COOKIE_NAME, '')
        if not re.fullmatch(r'[A-Za-z0-9_-]{43}', device):
            device = ''
        now = self.clock()
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            owner = self.digest(device) if device else None
            row = self.db.execute('SELECT expires FROM devices WHERE token_hash=?', (owner,)).fetchone()
            if not row or row[0] <= now:
                device = ''
                owner = None
            if device:
                token = values.get(COOKIE_NAME, '')
                if re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
                    row = self.db.execute('SELECT expires FROM access_sessions WHERE token_hash=? AND owner=?',
                                          (self.digest(token), owner)).fetchone()
                    if row and row[0] > now:
                        return token, device
                seed = self.db.execute('SELECT nonce FROM anonymous_tokens WHERE owner=?', (owner,)).fetchone()
                if seed:
                    token = self._anonymous_token(device, seed[0])
                    row = self.db.execute('SELECT expires FROM access_sessions WHERE token_hash=? AND owner=?',
                                          (self.digest(token), owner)).fetchone()
                    if row and row[0] > now:
                        return token, device
            # Bounded cleanup never deletes bindings or reassigns their owner.
            self.db.execute('DELETE FROM access_sessions WHERE token_hash IN '
                            '(SELECT token_hash FROM access_sessions WHERE expires<=? LIMIT 256)', (now,))
            self.db.execute('DELETE FROM anonymous_tokens WHERE owner IN '
                            '(SELECT token_hash FROM devices WHERE expires<=? LIMIT 256)', (now,))
            self.db.execute('DELETE FROM devices WHERE token_hash IN '
                            '(SELECT token_hash FROM devices WHERE expires<=? LIMIT 256)', (now,))
            active = self.db.execute('SELECT COUNT(*) FROM access_sessions WHERE expires>? AND owner!=?',
                                     (now, owner or '')).fetchone()[0]
            if active >= 4096 or (not device and self.db.execute('SELECT COUNT(*) FROM devices').fetchone()[0] >= 8192):
                raise TutorError('access_capacity', '当前访问较多，请稍后再试。', 429)
            scopes = [('anonymous:global', 512)]
            if owner:
                scopes.append(('anonymous:device:' + owner, 12))
            if client_scope is not None:
                scopes.append(('anonymous:client:' + self.digest(client_scope), 60))
            self.db.execute('DELETE FROM login_attempts WHERE scope IN '
                            "(SELECT scope FROM login_attempts WHERE scope LIKE 'anonymous:%' AND started<=? LIMIT 256)",
                            (now - 60,))
            for scope, limit in scopes:
                row = self.db.execute('SELECT started,attempts FROM login_attempts WHERE scope=?', (scope,)).fetchone()
                started, count = row if row and now - row[0] < 60 else (now, 0)
                if count >= limit:
                    raise TutorError('access_throttled', '当前访问较多，请稍后再试。', 429)
                self.db.execute('INSERT OR REPLACE INTO login_attempts VALUES(?,?,?)', (scope, started, count + 1))
            if not device:
                device = secrets.token_urlsafe(32)
                owner = self.digest(device)
            nonce = secrets.token_urlsafe(32)
            token = self._anonymous_token(device, nonce)
            self.db.execute('DELETE FROM access_sessions WHERE owner=?', (owner,))
            self.db.execute('INSERT OR REPLACE INTO anonymous_tokens VALUES(?,?)', (owner, nonce))
            self.db.execute('INSERT INTO access_sessions VALUES(?,?,?)', (self.digest(token), now + 21600, owner))
            self.db.execute('INSERT OR REPLACE INTO devices VALUES(?,?)', (owner, now + 2592000))
            return token, device

    @staticmethod
    def cookie(token='', clear=False):
        return (f'{COOKIE_NAME}={token}; Path={PREFIX}; Max-Age={0 if clear else 21600}; '
                'HttpOnly; Secure; SameSite=Strict')

    @staticmethod
    def device_cookie(token):
        return (f'{DEVICE_COOKIE_NAME}={token}; Path=/; Max-Age=2592000; '
                'HttpOnly; Secure; SameSite=Strict')

    def check_capacity(self, owner, kind):
        with self.lock:
            total = self.db.execute('SELECT COUNT(*) FROM bindings WHERE kind=?', (kind,)).fetchone()[0]
            personal = self.db.execute('SELECT COUNT(*) FROM bindings WHERE kind=? AND owner=?', (kind, owner)).fetchone()[0]
        if total >= 2048 or personal >= 64:
            raise TutorError('record_capacity', '保存记录已到上限，请继续当前课堂。', 429)

    def bind(self, owner, kind, resource):
        with self.lock, self.db:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.db.execute('SELECT expires FROM devices WHERE token_hash=?', (owner,)).fetchone()
            if not row or row[0] <= self.clock():
                raise TutorError('access_required', '课堂访问已过期，请重新进入。', 401)
            existing = self.db.execute('SELECT owner FROM bindings WHERE kind=? AND resource=?',
                                       (kind, resource)).fetchone()
            if existing:
                if not hmac.compare_digest(existing[0], owner):
                    raise TutorError('access_scope', '请使用当前浏览器自己的课堂记录。', 403)
                return
            self.check_capacity(owner, kind)
            self.db.execute('INSERT INTO bindings VALUES(?,?,?)', (owner, kind, resource))

    def require_binding(self, owner, kind, resource):
        with self.lock:
            row = self.db.execute('SELECT owner FROM bindings WHERE kind=? AND resource=?', (kind, resource)).fetchone()
        if not row or not hmac.compare_digest(row[0], owner):
            raise TutorError('access_scope', '请使用当前浏览器自己的课堂记录。', 403)

    def logout(self, owner, cookie_header=None):
        token = (cookie_values(cookie_header) or {}).get(COOKIE_NAME, '')
        with self.lock, self.db:
            # Re-entry needs a password only in password mode; device bindings survive.
            self.db.execute('DELETE FROM access_sessions WHERE token_hash=? AND owner=?',
                            (self.digest(token), owner))

    @property
    def daily_budget(self):
        return self.config['budget'].get('policy') == 'daily-device-v1'

    @property
    def unlimited_budget(self):
        return self.config['budget'].get('policy') == 'unlimited'

    @property
    def scoped_budget(self):
        return self.daily_budget or self.unlimited_budget

    def _migrate_budget(self):
        # One write transaction across connections; no historical rows are reassigned or deleted.
        with self.lock, self.ledger:
            self.ledger.execute('BEGIN IMMEDIATE')
            columns = {row[1] for row in self.ledger.execute('PRAGMA table_info(model_calls)')}
            for name, kind in (('owner', 'TEXT'), ('request_id', 'TEXT'),
                               ('credit_hold', 'REAL NOT NULL DEFAULT 0'),
                               ('settled', 'INTEGER NOT NULL DEFAULT 0')):
                if name not in columns:
                    self.ledger.execute(f'ALTER TABLE model_calls ADD COLUMN {name} {kind}')
            self.ledger.execute('CREATE UNIQUE INDEX IF NOT EXISTS model_call_request ON model_calls(request_id) WHERE request_id IS NOT NULL')
            self.ledger.execute('CREATE INDEX IF NOT EXISTS model_call_window ON model_calls(created,owner)')
            self.ledger.execute('CREATE TABLE IF NOT EXISTS kie_usage_events('
                                'id INTEGER PRIMARY KEY, created REAL NOT NULL, credits REAL NOT NULL, '
                                'tasks INTEGER NOT NULL, request_id TEXT UNIQUE, legacy INTEGER NOT NULL DEFAULT 0)')
            self.ledger.execute('CREATE TABLE IF NOT EXISTS budget_migrations('
                                'policy TEXT PRIMARY KEY, created REAL NOT NULL)')
            policy = self.config['budget'].get('policy')
            if self.scoped_budget and not self.ledger.execute(
                    'SELECT 1 FROM budget_migrations WHERE policy=?', (policy,)).fetchone():
                total = self._usage_total()
                accounted = self.ledger.execute('SELECT COALESCE(SUM(credits),0),COALESCE(SUM(tasks),0) FROM kie_usage_events').fetchone()
                credits, tasks = total['credits'] - accounted[0], total['tasks'] - accounted[1]
                if credits < -1e-9 or tasks < 0:
                    raise TutorError('invalid_usage', '费用历史与累计账本不一致；未继续调用。', 503)
                now = self.clock()
                if credits > 0 or tasks > 0:
                    self.ledger.execute('INSERT INTO kie_usage_events(created,credits,tasks,legacy) VALUES(?,?,?,1)',
                                        (now, max(0, credits), tasks))
                self.ledger.execute('INSERT INTO budget_migrations VALUES(?,?)', (policy, now))

    def _usage_total(self):
        row = self.ledger.execute('SELECT credits,tasks FROM kie_usage WHERE id=1').fetchone()
        if (not row or type(row[0]) not in (int, float) or not math.isfinite(row[0])
                or row[0] < 0 or type(row[1]) is not int or row[1] < 0):
            raise TutorError('invalid_usage', '私有用量账本无法核验；未继续调用。', 503)
        return {'credits': row[0], 'tasks': row[1]}

    def _require_budget_owner(self, owner):
        if not isinstance(owner, str) or not re.fullmatch(r'[a-f0-9]{64}', owner):
            raise TutorError('budget_owner_required', '每日额度须绑定服务器核验的当前设备；未调用。', 403)
        with self.lock:
            row = self.db.execute('SELECT expires FROM devices WHERE token_hash=?', (owner,)).fetchone()
        if not row or row[0] <= self.clock():
            raise TutorError('budget_owner_required', '当前设备额度身份已失效，请重新进入原课堂。', 403)

    @staticmethod
    def _budget_request_id(request_id):
        if not isinstance(request_id, str) or not 8 <= len(request_id) <= 160:
            raise TutorError('invalid_request_id', '每日调用须有服务器绑定的唯一请求标识。', 422)
        return request_id

    def _window_usage(self, request_id=None):
        cutoff = self.clock() - self.config['budget'].get('windowSeconds', 86400)
        credits, tasks = self.ledger.execute(
            'SELECT COALESCE(SUM(credits),0),COALESCE(SUM(tasks),0) FROM kie_usage_events WHERE created>?', (cutoff,)).fetchone()
        holds = self.ledger.execute(
            'SELECT COALESCE(SUM(credit_hold),0) FROM model_calls WHERE created>? AND settled=0 '
            'AND (request_id IS NULL OR request_id!=?)', (cutoff, request_id or '')).fetchone()[0]
        if not math.isfinite(credits + holds) or credits < 0 or holds < 0:
            raise TutorError('invalid_usage', '窗口费用无法核验；未继续调用。', 503)
        return credits, tasks, holds

    def _check_budget(self, owner=None, request_id=None):
        budget = self.config['budget']
        if not self.scoped_budget:
            count = self.ledger.execute('SELECT COUNT(*) FROM model_calls').fetchone()[0]
            if count >= budget['maxModelCalls']:
                raise TutorError('model_limit', '在线辅导已到累计次数上限，仍可继续离线做题。', 429)
            return
        self._budget_request_id(request_id)
        if self.ledger.execute('SELECT 1 FROM model_calls WHERE request_id=?', (request_id,)).fetchone():
            raise TutorError('model_request_replayed', '此请求已占用额度；请查询原结果，不重复付费。', 409)
        if self.unlimited_budget:
            self._usage_total()  # Unlimited is not permission to accept a corrupt ledger.
            return
        cutoff = self.clock() - budget['windowSeconds']
        service, device = self.ledger.execute(
            'SELECT COUNT(*),COALESCE(SUM(CASE WHEN owner=? THEN 1 ELSE 0 END),0) '
            'FROM model_calls WHERE created>?', (owner, cutoff)).fetchone()
        if service >= budget['maxServiceModelCalls']:
            raise TutorError('service_model_limit', '全站过去24小时对话次数已到上限；到期后可继续，原课堂与离线做题保留。', 429)
        if device >= budget['deviceModelCalls']:
            raise TutorError('device_model_limit', '当前设备过去24小时对话次数已到上限；重开课不重置，请到期继续或离线做题。', 429)
        self._usage_total()
        credits, _, holds = self._window_usage()
        if credits + holds >= budget['maxCredits'] - 1e-9:
            raise TutorError('service_credit_limit', '全站过去24小时费用已到上限或仍有未知账单占用；请等待结算或额度到期，原题保留。', 429)

    def check_budget(self, owner=None, request_id=None):
        """Read-only preflight; the reservation transaction is still authoritative."""
        if self.scoped_budget:
            self._require_budget_owner(owner)
        with self.lock:
            self._check_budget(owner, request_id)

    def check_model_budget(self, owner=None, request_id=None):
        """Compatibility name for server-side budget preflight."""
        return self.check_budget(owner, request_id)

    def reserve_model_call(self, owner=None, request_id=None):
        if self.scoped_budget:
            self._require_budget_owner(owner)
        with self.lock, self.ledger:
            self.ledger.execute('BEGIN IMMEDIATE')
            self._check_budget(owner, request_id)
            hold = 0
            if self.daily_budget:
                credits, _, holds = self._window_usage()
                # No price quote is available. Serialize paid work by holding the remaining
                # envelope until a trusted bill arrives. Unknown submissions are never refunded.
                hold = max(0, self.config['budget']['maxCredits'] - credits - holds)
            self.ledger.execute('INSERT INTO model_calls(created,owner,request_id,credit_hold) VALUES(?,?,?,?)',
                                (self.clock(), owner if self.scoped_budget else None,
                                 request_id if self.scoped_budget else None, hold))

    def kie_usage(self, request_id=None):
        with self.lock:
            total = self._usage_total()
            if self.unlimited_budget:
                credits, tasks, holds = self._window_usage(request_id)
                return {**total, 'totalCredits': total['credits'], 'totalTasks': total['tasks'],
                        'billedCredits': total['credits'], 'reservedCredits': holds,
                        'dailyCredits': credits, 'dailyTasks': tasks,
                        'policy': 'unlimited', 'maxCredits': None}
            if not self.daily_budget:
                return total
            credits, tasks, holds = self._window_usage(request_id)
            return {'credits': credits + holds, 'tasks': tasks, 'billedCredits': credits,
                    'reservedCredits': holds, 'totalCredits': total['credits'], 'totalTasks': total['tasks'],
                    'policy': 'daily-device-v1', 'windowSeconds': 86400}

    def record_kie_usage(self, credits, request_id=None):
        if type(credits) not in (int, float) or not math.isfinite(credits) or credits < 0:
            raise TutorError('invalid_usage', '提供方用量无法核验；未继续调用。', 503)
        with self.lock, self.ledger:
            self.ledger.execute('BEGIN IMMEDIATE')
            self._usage_total()
            if request_id is not None:
                self._budget_request_id(request_id)
                previous = self.ledger.execute('SELECT credits FROM kie_usage_events WHERE request_id=?', (request_id,)).fetchone()
                if previous:
                    if previous[0] != credits:
                        raise TutorError('usage_conflict', '同一请求的费用结算不一致；未覆盖旧账单。', 503)
                    return self.kie_usage(request_id)
                if not self.ledger.execute('SELECT 1 FROM model_calls WHERE request_id=?', (request_id,)).fetchone():
                    raise TutorError('invalid_usage', '费用没有对应的调用预留；未改写账本。', 503)
            self.ledger.execute('INSERT INTO kie_usage_events(created,credits,tasks,request_id) VALUES(?,?,1,?)',
                                (self.clock(), credits, request_id))
            self.ledger.execute('UPDATE kie_usage SET credits=credits+?,tasks=tasks+1 WHERE id=1', (credits,))
            if request_id is not None:
                self.ledger.execute('UPDATE model_calls SET settled=1 WHERE request_id=?', (request_id,))
        return self.kie_usage(request_id)

    def budget_status(self, owner=None):
        if self.scoped_budget and owner is not None:
            self._require_budget_owner(owner)
        with self.lock:
            budget = self.config['budget']
            usage = self.kie_usage()
            if self.unlimited_budget:
                calls = self.ledger.execute('SELECT COUNT(*) FROM model_calls').fetchone()[0]
                service, device = self.ledger.execute(
                    'SELECT COUNT(*),COALESCE(SUM(CASE WHEN owner=? THEN 1 ELSE 0 END),0) '
                    'FROM model_calls WHERE created>?', (owner, self.clock() - 86400)).fetchone()
                return {'policy': 'unlimited', 'voicePolicy': 'unlimited',
                        'maxModelCalls': None, 'deviceModelCalls': None,
                        'maxServiceModelCalls': None, 'maxCredits': None,
                        'remainingServiceCalls': None, 'remainingDeviceCalls': None,
                        'serviceCalls': calls, 'dailyServiceCalls': service,
                        'deviceCalls': device if owner else None,
                        'windowSeconds': None, 'resetAt': None, 'retryAfter': None,
                        'code': None, 'canAsk': owner is not None, 'usage': usage,
                        'nextAction': 'ask' if owner else 'restore_access'}
            if not self.daily_budget:
                calls = self.ledger.execute('SELECT COUNT(*) FROM model_calls').fetchone()[0]
                return {'policy': 'lifetime-v1', 'serviceCalls': calls, 'maxModelCalls': budget['maxModelCalls'],
                        'maxCredits': 5, 'windowSeconds': None, 'resetAt': None,
                        'canAsk': calls < budget['maxModelCalls'] and usage['credits'] < 5,
                        'usage': usage, 'nextAction': 'continue_offline' if calls >= budget['maxModelCalls'] or usage['credits'] >= 5 else 'ask'}
            cutoff = self.clock() - budget['windowSeconds']
            service, device = self.ledger.execute(
                'SELECT COUNT(*),COALESCE(SUM(CASE WHEN owner=? THEN 1 ELSE 0 END),0) FROM model_calls WHERE created>?',
                (owner, cutoff)).fetchone()
            blocked = ('service_model_limit' if service >= budget['maxServiceModelCalls'] else
                       'device_model_limit' if owner and device >= budget['deviceModelCalls'] else
                       'service_credit_limit' if usage['credits'] >= budget['maxCredits'] - 1e-9 else None)
            expiries = []
            if blocked == 'service_model_limit' or blocked == 'device_model_limit':
                rows = self.ledger.execute('SELECT created FROM model_calls WHERE created>? '
                                          'AND (? IS NULL OR owner=?) ORDER BY created',
                                          (cutoff, owner if blocked == 'device_model_limit' else None,
                                           owner if blocked == 'device_model_limit' else None)).fetchall()
                limit = budget['deviceModelCalls'] if blocked == 'device_model_limit' else budget['maxServiceModelCalls']
                expiries = [rows[len(rows) - limit][0] + 86400]
            elif blocked == 'service_credit_limit':
                rows = self.ledger.execute('SELECT created,credits FROM kie_usage_events WHERE created>? '
                                          'UNION ALL SELECT created,credit_hold FROM model_calls WHERE created>? AND settled=0 ORDER BY 1',
                                          (cutoff, cutoff)).fetchall()
                remaining = usage['credits']
                for created, amount in rows:
                    remaining -= amount
                    if remaining < budget['maxCredits'] - 1e-9:
                        expiries = [created + 86400]
                        break
            return {'policy': 'daily-device-v1', 'windowSeconds': 86400,
                    'maxModelCalls': budget['maxModelCalls'], 'deviceModelCalls': budget['deviceModelCalls'],
                    'maxServiceModelCalls': budget['maxServiceModelCalls'], 'maxCredits': budget['maxCredits'],
                    'serviceCalls': service, 'deviceCalls': device if owner else None,
                    'remainingServiceCalls': max(0, budget['maxServiceModelCalls'] - service),
                    'remainingDeviceCalls': max(0, budget['deviceModelCalls'] - device) if owner else None,
                    'usage': usage, 'code': blocked, 'canAsk': owner is not None and blocked is None,
                    'resetAt': max(expiries) if expiries else None,
                    'retryAfter': max(0, math.ceil(max(expiries) - self.clock())) if expiries else None,
                    'nextAction': 'wait_or_continue_offline' if blocked else 'ask' if owner else 'restore_access'}

    def close(self):
        self.db.close()
        self.ledger.close()
