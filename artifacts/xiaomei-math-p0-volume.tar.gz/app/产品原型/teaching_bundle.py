"""Read-only frozen teaching slices and trusted teacher presets; no worker/listener."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re

SCHEMA_VERSION = '0.3.0'
BUNDLE_REF = {'namespace': 'teaching', 'id': 'math18', 'version': SCHEMA_VERSION}
BUNDLE_VERSIONS = ('0.3.0', '0.4.0')
_BUNDLE_FILES = {version: f'data/teaching-bundles/math18/{version}.json' for version in BUNDLE_VERSIONS}
_PROFILES = (
    {'id': 'warm', 'version': '0.3.0', 'name': '温和老师',
     'description': '温和耐心，用清楚的小步解释，留出思考时间。'},
    {'id': 'witty', 'version': '0.3.0', 'name': '幽默老师',
     'description': '轻松有趣，用克制的生活比喻激发好奇，不嘲笑学生。'},
    {'id': 'rigorous', 'version': '0.3.0', 'name': '严谨老师',
     'description': '条理清晰，明确对象、条件、推理和回查。'},
)
_STYLE = {
    'warm': '陪学生一起观察。先指认眼前一段线或一个变化，解释一个小台阶；回答错时减小问题而不是批评。语气温和，留出思考停顿。',
    'witty': '用实验里的小挑战与意外变化激发好奇，先让学生预测，再比较结果；轻巧幽默，不另编一群角色，也不每轮加类比声明。',
    'rigorous': '先分清固定量、变化量与目标，给有依据的连续推理，再用一个反例或回查检验。语言简洁自然，不堆术语，不说教。',
}
_ORIGINALS = (
    ('assets/originals/math-2025-national1-source.pdf', [4], '题卷物理页'),
    ('assets/originals/math-2025-national1-reference.pdf', [25, 26, 27], '第三方解析物理页'),
)


class BundleError(ValueError):
    def __init__(self, code, message, http_status=409):
        super().__init__(message)
        self.code, self.http_status = code, http_status


def public_teacher_profiles(version=SCHEMA_VERSION):
    profiles = copy.deepcopy(list(_PROFILES))
    if version == '0.4.0':
        for profile in profiles:
            profile['version'] = version
        profiles[0]['description'] = '一起观察，一次给一小步，答错时先帮你找到眼前那条线。'
        profiles[1]['description'] = '从一个小挑战开始，让你的预测决定下一步，幽默来自实验本身。'
        profiles[2]['description'] = '先分清已知、变化和要证的事，再用反例与回查检验结论。'
    return profiles


def validated_teacher_profile(identifier=None):
    identifier = 'warm' if identifier is None else identifier
    if not isinstance(identifier, str) or identifier not in _STYLE:
        raise BundleError('invalid_teacher_profile', 'teacherProfile只接受warm、witty或rigorous preset', 422)
    return identifier


def teacher_instructions(identifier=None):
    identifier = validated_teacher_profile(identifier)
    return ('\n可信老师风格：' + _STYLE[identifier] +
            '风格只改变表达，不改变事实、判题、提示与答案保密政策；作者公式和板书不改写。\n')


def teacher_speech_instruction(identifier=None):
    identifier = validated_teacher_profile(identifier)
    return '自然中文老师，语速适中，不要夸张播音腔。' + _STYLE[identifier] + '准确朗读作者文字，不添加或改变教学事实。'


def validated_bundle_ref(value=None, unit_id='math18'):
    if unit_id != 'math18':
        raise BundleError('invalid_bundle_ref', '当前仅登记math18教学切片', 422)
    value = BUNDLE_REF if value is None else value
    if (not isinstance(value, dict) or set(value) != set(BUNDLE_REF)
            or value.get('namespace') != 'teaching' or value.get('id') != unit_id
            or value.get('version') not in BUNDLE_VERSIONS):
        raise BundleError('invalid_bundle_ref', 'bundleRef须为已登记teaching/math18版本对象，不接受路径或URL', 422)
    return copy.deepcopy(value)


MOMENT_VERSION = 'progressive-20261119'
LEGACY_MOMENT_VERSIONS = frozenset({'progressive-20261117'})
# A presentation slice over the frozen lesson: short, server-authored turns.
# The frozen source, full reasoning and old narration are not overwritten.
_CLASSROOM_MOMENTS = (
    (
        ('一根绳，能画出什么？', '两桩固定，笔尖把绳拉紧。', '', '拖动笔尖，画一段线。', '绳子的两端固定在木桩上。先别猜形状，拖动笔尖，看看它走过哪里。绳子要拉紧，我们比较的才是两段直线距离。', ()),
        ('哪一个长度没变？', '一段变长，另一段变短。', '左段 ＋ 右段 = 10米', '再拖一次，比较两段的和。', '你刚移动了笔尖。到左桩的一段和到右桩的一段都能改变，但拉紧后加起来始终十米。所有满足这个距离和的位置连成椭圆，木桩代表焦点。', ()),
        ('桩拉远，会怎样？', '绳长不变，只把两桩拉开。', '两段和仍是10米', '先选一个，再比较6米与8米。', '现在只改变木桩间距，绳长仍是十米。先预测边线更圆还是更扁，再比较最上端的高度。距离和必须大于桩距；相等只剩两桩间的线段。', ()),
    ),
    (
        ('先找到高度 b', '中心O到最高点的竖直线，叫半短轴b。', '', '点亮竖直线，认清量的是什么。', '先找两桩正中间的O。从O竖直到最高点的这段高度，命名为b，叫半短轴。短轴是上下的整段，长度是二b，不是一b。', ('O', 'b')),
        ('顶端两段为什么相等？', '顶端左右对称，两段各长a。', 'a = 绳长的一半', '中心到木桩的距离叫c。', '最高点在两桩的中垂线上，所以到两桩等距。两段合起来是二a，每段才各为a。中心到一桩叫c；这条水平边和高度b互相垂直。', ('a', 'c')),
        ('高度怎样算？', 'b与c是直角边，a是斜边。', 'b² ＋ c² = a²', '把c调到3米，再算a为5米时的高度。', '这三条边围成直角三角形，所以用勾股，不是直接五减三。a等于五米、c等于三米时，b的平方是二十五减九，开方得到四米。拉开木桩后c增加，高度就降低。', ()),
    ),
    (
        ('经过喷泉，多走多少？', '金线直达，浅线经过喷泉。', 'PM ≤ PN ＋ NM', '拖花圃M，比较两条路。', '入口是P，喷泉是N，花圃是M。直达的距离是PM，经过喷泉是PN加NM。直线距离不会比绕路更长，这是三角不等式。拖动花圃，比较差多少。', ('P', 'N', 'M')),
        ('共线就一定不绕路吗？', '喷泉要在入口和花圃之间。', '等号：N在线段PM上', '试一次折返，再试一次不折返。', '三个点排成一直线仍可能折返。只有喷泉N位于P和M之间，经过喷泉才和直达一样长。原题找最远距离时，也必须检查这个等号条件。', ()),
    ),
    (
        ('原题先给了什么？', '离心率2√2/3；相邻顶点间距√10。', 'A：下顶点　B：右顶点', '看AB与两条半轴。', '回到原题，这些不是花坛的十米参数。A是下顶点，B是右顶点，AB是连接相邻顶点的线段。先用离心率定比例，再用AB的长度定大小。', ('e', 'A', 'B', 'x', 'y')),
        ('比例怎样确定形状？', '由e=c/a，再结合半轴关系。', 'b² = a²/9', '还缺大小，继续看AB。', '离心率是c除以a，故c平方是九分之八的a平方。结合a平方等于b平方加c平方，得到b平方等于九分之一的a平方。比例有了，但大小还没确定。', ()),
        ('距离怎样确定大小？', 'AB² = a²＋b² = 10。', 'x²/9 ＋ y² = 1', '相邻顶点形成一个直角三角形。', 'AB是斜边，水平和竖直两边分别长a和b。把b平方等于a平方除以九代入，得到a平方九、b平方一，写出标准方程。不能把AB当成一条轴。', ()),
    ),
    (
        ('R可以到反向吗？', '射线AP从A朝P延伸，R是待确定的点。', 'A → R → P，或A → P → R', '点图里的方向，说明你的选择。', '射线AP有起点A和朝向P的方向。R是我们要找的点。长度积只管长度，不管方向；所以还要保留正向条件。试着指出反向位置，看看它为什么不是射线上的R。', ('R',)),
        ('把方向写成比例', 'P=(m,n)；D=|AP|²；λ是从A到R的比例。', 'R=A＋λ(P−A)，λ=3/D>0', '同一方向，比例必须为正。', '用m、n记P的横、纵坐标，用D记AP长度的平方，λ记从A到R相对AP的比例。正比例保持朝向P。长度积给出λD等于三，故λ等于三除以D。m不等于零保证D大于零，正向和长度都要满足。', ('m', 'n', 'D', 'λ')),
    ),
    (
        ('斜率条件带来什么？', '把R坐标代回kOR=3kOP。', 'D = 3−6n', '分母m必须非零。', '先用上一段的R坐标写OR斜率，再与三倍OP斜率相等。保留m不等于零的前提后化简，得到D等于三减六n，不能先消元再忘掉分母。', ('kOR', 'kOP')),
        ('P的轨迹是一整圈吗？', '配成圆后，还要保留原限制。', 'm²＋(n＋4)² = 18', '点图上的两个空心点，检查能否取。', '把D的表达式代回并配方，得到一个圆。但圆上纵轴的两个点有m等于零，原斜率无定义，要删掉。得到候选轨迹后还须回查射线与斜率。', ()),
    ),
    (
        ('先找一个不动的点', 'P在圆上，圆心N=(0,−4)。', 'PN = 3√2', '拖M，看看NM怎样变化。', 'P可以沿圆移动，但到圆心N的距离固定。于是PM不超过PN加NM，第一段已经定住。要找整体上界，接下来只研究N到椭圆点M的距离。', ()),
        ('M在哪里离N最远？', '把NM的平方配成一块平方。', 'NM²=27−8(y−½)²', 'y在[−1,1]；最远时平方项为零。', '椭圆给出x平方等于九乘一减y平方。代入NM平方并配方，得到二十七减八倍y减二分之一的平方。平方非负，y等于二分之一又在允许范围内，所以上界能取到。', ()),
    ),
    (
        ('先看这条线：P、N、M', 'P在圆上，M在椭圆上。N在P和M中间。', 'PM = PN ＋ NM', '先指一指P、N、M，再看两段怎样接成一段。', '先别管最后的答案。左边的P在圆上，右上方的M在椭圆上，N是圆心。现在N正好在P和M中间，所以从P到N，再从N到M，两段接起来就是PM。', ('P', 'N', 'M')),
        ('两段各到最长，会怎样？', 'PN最长3√2，NM最长3√3。', 'PM = 3√2 ＋ 3√3', 'N仍在中间，两段才能直接相加。', 'PN是圆的半径，固定为三倍根号二。NM最长能到三倍根号三。像图上这样让N留在P和M中间，两段刚好接成PM，所以PM能达到三倍根号二加三倍根号三。', ()),
        ('这两个位置真的存在吗？', 'M的高度取½；P取在N的另一侧。', 'PM最大值 = 3(√2＋√3)', '完整坐标与原条件回查，保留在课程资料里。', '光写不能超过，还不算找到最大值。我们确实能找到这样的M和P：M的高度是二分之一，P在N的另一侧，而且符合原题条件。两段都达到最长，又能接成一条线，最大值才是三倍根号二加根号三的和。', ()),
    ),
)


# Each pair leads the same small question differently, without changing its proof.
_CLASSROOM_MOMENT_PROFILE_PAIRS = {
    (0, 0): (
        '猜一猜：笔尖随手走，还是会被绳子拉回一条边线？先拖一小段看看。两端仍固定在同样的木桩上，笔尖要把绳拉紧，比较的才是两段直线距离。绳子可不接受松松垮垮的答案。先看走过的痕迹，形状的名字等观察后再说。',
        '固定的是两根木桩和绳长，变化的是笔尖位置。现在要观察拉紧时笔尖能走到哪里。拉紧后，两桩到笔尖分别形成直线段，才可比较它们的距离。拖动一小段作检查：若绳松了，这个位置就不能作为本次画线的依据。'),
    (0, 1): (
        '挑战一下：左段变长，能不能偷偷让总长也长一点？拖动笔尖，盯住右段的变化。绳长十米不变，一段变长时，另一段得让出长度，两段和仍是十米。它们配合得倒很默契。满足这个距离和的位置连成椭圆，两根木桩就是焦点。',
        '两桩和十米绳长固定，笔尖移动使左右两段长度变化。要找的是两段中哪个量保持不变。拉紧后，两段恰好组成整条绳，所以左段加右段等于十米；满足这一距离和的轨迹是椭圆，两桩为焦点。换一个位置，检查的是和，而非某一段。'),
    (0, 2): (
        '先押一个猜想：桩距从六米变八米，边线会更圆还是更扁？十米绳长可不会跟着加班。比较两次最上端的高度，并看看横向最远处。两段和仍是十米，桩距却增大了。距离和必须大于桩距；相等时只剩两桩之间的线段，不能围出花坛。',
        '固定绳长十米，只把桩距从六米改为八米；要比较边线的形状。先作预测，再对照最上端高度与横向最远位置，不能同时改绳长。距离和大于桩距才有非退化椭圆。检查边界：若桩距也为十米，等号只允许两桩间的线段。'),
    (1, 0): (
        '猜一猜，眼前这段高度是从地面量，还是从中心量？先找到两桩正中间的O，再看它到最高点的竖直线。这段叫半短轴b。名字里有个“半”，可不是客气话：上下整段短轴才长二b。指一指上下整段，再回来认准我们现在量的这一半。',
        '先固定高度的起点和终点：起点是两桩正中间的O，终点是最高点；要认清的量是这段竖直距离b，称半短轴。它不是上下整段的长度。椭圆上下关于O对称，整条短轴由两段b组成。检查一次：从最低点到最高点应长二b。'),
    (1, 1): (
        '最高点到两桩的绳段，谁能多分一点？先看最高点正对两桩中间，两边对称，谁也没有近路可抄。因此两段等长，总长二a，每段各为a。现在把中心到一桩的水平距离叫c，它和竖直高度b垂直。指一指斜绳与水平边，别让两种长度串位。',
        '两桩固定，最高点位于两桩的中垂线上；要说明的是两段斜绳为何各长a。中垂线上到两桩等距，总绳长二a，所以每段为a。再定义中心到一桩的水平距离c，它与高度b垂直。检查对象：a量的是斜绳，c量的是水平距离，不是整段桩距。'),
    (1, 2): (
        '五米和三米放进直角三角形，高度会是五减三的两米吗？先别让减法抢答。把c调到三米，认清斜边a为五米，直角边是b和c。勾股给出b平方等于二十五减九，所以高度四米。用四平方加三平方检查，正好是五平方；绳长不变时，c越大，高度越低。',
        '固定斜边a为五米，把水平直角边c调到三米，要求竖直高度b。因b与c垂直，b平方加c平方等于a平方，故b平方等于二十五减九，b为四米。检查四平方加三平方等于五平方。保持a不变而增大c，b平方减小，高度才会降低。'),
    (2, 0): (
        '猜猜看，经过喷泉的路能比直达还短吗？入口是P，喷泉是N，花圃是M。先拖动M，比较金线PM与浅线PN加NM。绕一下可没有距离折扣：三角不等式保证PM不大于PN加NM。再找一处两条路接近一样长的位置，留意喷泉在哪边。',
        '入口P与喷泉N固定，花圃M可移动；要比较直达与经过喷泉的距离。直达为PM，分段路程为PN加NM，三角不等式给出PM不大于两段之和。拖动M检查时，始终比较这同一对路线，不能把差值当成总长；等号位置还需另看三点顺序。'),
    (2, 1): (
        '排成一条直线就算近路？给这个猜想出道小难题：先看P、M、N的顺序，经过喷泉还得折回来，直线也会绕路。再看P、N、M，两段正好接成直达。喷泉要站在中间，不是只负责排整齐。原题取等也要检查N在线段PM上。',
        '固定直达路线的两端P、M，比较喷泉N在直线上的不同位置；要证的是何时PM等于PN加NM。若N在线段外，分段路线含折返，长度更大；若N在P与M之间，两段恰好组成PM。用P、M、N的顺序作一次反例检查：共线本身不足以取等。'),
    (3, 0): (
        '回到原题，能直接把花坛的十米拿来算吗？先别让旧数字搭便车。这次已知离心率二倍根号二除以三，相邻顶点距离根号十；A在下端，B在右端。看AB连接的两点：先用离心率定半轴比例，再用这段距离定大小，原题没有沿用十米绳长。',
        '固定原题给出的两个条件：离心率为二倍根号二除以三，AB长根号十；要确定的是椭圆形状和大小。A为下顶点，B为右顶点，AB连接相邻顶点。离心率约束半轴比例，AB的距离约束尺度。检查题面：这两个条件不能替换成花坛的十米参数。'),
    (3, 1): (
        '只知道离心率，能猜中椭圆到底多大吗？把同一形状放大，比例可不会露馅。由e等于c除以a，得c平方是a平方的九分之八；再用a平方等于b平方加c平方，剩下b平方为a平方的九分之一。现在认准这条比例，大小还得等AB来定。',
        '固定离心率e为二倍根号二除以三，半轴尺度仍未知；要推出b与a的比例。由e等于c除以a，得到c平方等于八倍a平方除以九。代入a平方等于b平方加c平方，得b平方等于a平方除以九。检查：这只定比例，不能单独得出a的具体值。'),
    (3, 2): (
        'AB长根号十，它就是一条轴吗？先看看A在下端、B在右端：这条斜线可没走轴的老路。横向差a、竖向差b，勾股给出AB平方等于a平方加b平方，即十。代入刚才的比例，得a平方九、b平方一，方程为x平方除以九加y平方等于一。',
        '固定AB平方为十、b平方为a平方除以九，要确定两条半轴。相邻顶点的横向差为a、竖向差为b，因此a平方加b平方等于十。联立得a平方九、b平方一，标准方程是x平方除以九加y平方等于一。检查原距离：九加一为十，AB不是整条长轴。'),
    (4, 0): (
        '一个点长度都算对了，却站在A的反向，能算我们要找的R吗？先沿A朝P的箭头看方向。R可以在A与P之间，也可以越过P，但不能走到A的另一侧。长度积像只看里程、不看朝向的账本；所以指出反向位置时，要说明它缺的是射线方向。',
        '固定射线的起点A和朝向P的方向，R的位置待定；要判断反向点是否合题意。共线与长度积只约束位置关系和距离，不能区分A的两侧。射线AP还要求R在朝P的一侧。检查反例：一个反向点即使满足长度积，也因方向不符而不能作为R。'),
    (4, 1): (
        '沿对方向走，比例能是负数吗？负号会让箭头掉头。先用m、n记P的横、纵坐标，D记AP长度的平方，λ记从A到R相对AP的比例。正向要求λ大于零；长度积给出λD等于三，所以λ等于三除以D。m非零使D为正，两项一起检查才不会走反。',
        '记P坐标为m、n，D为AP长度的平方，λ为从A到R相对AP的比例；要同时表达方向和长度。R等于A加λ倍P减A，正向要求λ大于零。长度积给出λD等于三，故λ等于三除以D。检查前提：m非零保证D大于零，这个比例确为正。'),
    (5, 0): (
        '三倍斜率，是不是把图上的角度乘三？先让角度歇一歇，我们比较的是坐标比。用R坐标写OR斜率，再令它等于三倍OP斜率，保留m不等于零，化简得到D等于三减六n。这里m若为零，除法就没了依据；算完再看一次分母，别把它约没了。',
        '固定斜率条件kOR等于三倍kOP，P坐标与R坐标相联系；要推出D和n的关系。先由R坐标写OR斜率，再与三倍OP斜率相等，在m非零的前提下化简得D等于三减六n。检查运算条件：m为零时OP斜率无定义，不能纳入这次消元。'),
    (5, 1): (
        '方程画出一整圈，圆上的点就全都合格吗？先看看纵轴上的两个空心点：它们的m为零，斜率会在这里卡住。配方得到m平方加n加四的平方等于十八，这是候选圆。圆画得圆，不代表条件都过关；删掉这两点后，还要回代射线与原斜率。',
        '固定D的定义及D等于三减六n，要确定P的合法轨迹。代入并配方，得到m平方加n加四的平方等于十八，同时保留m非零。圆与纵轴的两个交点因此排除。检查剩余点时还须回代射线和原斜率，只有必要方程成立不能直接认定全部合法。'),
    (6, 0): (
        'P沿圆跑，哪段距离能一直不动？先猜PM，再和PN比较。圆心N坐标是零、负四，PN恒为三倍根号二；P再忙也跑不出这个半径。由PM不大于PN加NM，第一段已经定住。拖动M时盯住NM，接下来要找的变化就在这一段，不必追着P乱跑。',
        '固定圆心N为零、负四及半径三倍根号二，P可沿合法圆轨迹变化，M在椭圆上变化；要寻找PM的上界。三角不等式给出PM不大于PN加NM，而PN恒定。检查分工：拖动M只改变NM，所以下一步最大化NM，取等仍需检查P的位置。'),
    (6, 1): (
        '椭圆最高点就一定离N最远吗？给眼睛的猜想做一次计算。用x平方等于九乘一减y平方，代入并配方，NM平方等于二十七减八倍y减二分之一的平方。这个负号可不奖励大平方。平方取零时y为二分之一，落在负一到一之间，才有对应的椭圆点。',
        '固定椭圆方程与N坐标，变化的是M的纵坐标y，要最大化NM平方。用x平方等于九乘一减y平方消去x，再配得二十七减八倍y减二分之一的平方。平方非负，故不超过二十七。检查取等条件：y为二分之一在负一到一内，对应x平方为二十七除以四。'),
    (7, 0): (
        '先不跟公式捉迷藏。找一找圆上的P、椭圆上的M，再找到圆心N。现在N站在P和M中间，两段路手牵手，正好接成PM。先认清这条线，再来谈它能有多长。',
        '先识别对象：P在合法圆轨迹上，M在椭圆上，N是圆心。当前构型中N在线段PM上，故PN加NM等于PM。这里只确认点的身份与分段关系，后续再讨论长度。'),
    (7, 1): (
        '两段都想拿最长，还得愿意接成一段才行。PN固定为三倍根号二，NM最长三倍根号三。只要N还站在P和M中间，它们就不会各走各的，PM正好等于这两个长度的和。',
        'PN为固定半径三倍根号二，NM的上界为三倍根号三。当前N在线段PM上，两段可直接相加，所以PM能达到三倍根号二加三倍根号三；下一小步核验这个位置确实满足原条件。'),
    (7, 2): (
        '最后别只颁奖不验票。M取高度二分之一，P放到N的另一侧，而且符合原题条件。两个最长都真的站到了图上，还能接成PM，这才把“不能超过”变成“确实能够达到”。',
        '取M的纵坐标二分之一，并在N的另一侧取满足原条件的P，可使NM等于三倍根号三、PN等于三倍根号二，且N在线段PM上。上界与可达构型同时成立，最大值为三倍根号二加根号三的和。'),
}


def classroom_moments(unit, version='0.4.0'):
    """Public short turns; full frozen lesson text remains accessible separately."""
    if version != '0.4.0' or unit.get('id') != 'math18':
        return []
    result = []
    for board_index, entries in enumerate(_CLASSROOM_MOMENTS):
        row = unit['blackboardSteps'][board_index]
        moments = []
        for index, (title, line, formula, hint, speech, introduced) in enumerate(entries):
            witty, rigorous = _CLASSROOM_MOMENT_PROFILE_PAIRS[board_index, index]
            variants = {'warm': speech, 'witty': witty, 'rigorous': rigorous}
            check = copy.deepcopy(row.get('reflectionCheck')) if index == (0 if board_index == 4 else len(entries)-1) else None
            if check and board_index == 4 and index == 0:
                # Keep the gate identity and positive-ray meaning, before notation.
                check.update({
                    'choices': ['能，长度对就行', '不能，还必须从A朝P'],
                    'correctChoice': '不能，还必须从A朝P',
                    'feedback': '共线与长度积不区分A的两侧；原题指定从A朝P的射线，反向点不能作为R。',
                    'repair': '看A两侧的候选点，按从A朝P的箭头排除反向点，再说明缺少的方向条件。',
                    'answerSource': '当前小步的射线正反方向与长度积条件；五步原题推理第1步。',
                })
            if check and board_index == 1 and index == 2:
                check['repair'] = '把c调到3米，保持a为5米；先指斜边a与直角边b、c，再用平方差开方并回查。'
            if check and board_index == 7:
                check.update({
                    'question': '为什么这两段能直接相加？',
                    'choices': ['N在P和M之间', '因为这两个数很大'],
                    'correctChoice': 'N在P和M之间',
                    'feedback': '对。N在线段PM上，所以PN和NM接起来正好是PM。',
                    'repair': '先不计算，沿图从P走到N，再从N走到M；这两段正好接成PM。',
                })
            moments.append({'title': title, 'lines': [line], 'formula': formula, 'hint': hint,
                'boardIndex': board_index, 'momentIndex': index, 'momentVersion': MOMENT_VERSION,
                'introducedSymbols': list(introduced), 'diagram': row['diagram'], 'stage': row['stage'],
                'stepIndex': row['stepIndex'], 'spokenText': speech,
                'narrationVariants': variants, 'reflectionCheck': check})
        result.append(moments)
    return result


def classroom_moment_for_context(context, board_index, moment_index):
    if context.get('bundleRef', {}).get('version') != '0.4.0':
        raise BundleError('invalid_moment', '短段讲述须绑定新版作者课单', 422)
    if type(board_index) is not int or not 0 <= board_index < len(_CLASSROOM_MOMENTS):
        raise BundleError('invalid_moment', '课堂段号无效', 422)
    if type(moment_index) is not int or not 0 <= moment_index < len(_CLASSROOM_MOMENTS[board_index]):
        raise BundleError('invalid_moment', '当前小步不属于这段课堂', 422)
    row = classroom_moments(context['authorLesson'])[board_index][moment_index]
    profile = validated_teacher_profile(context.get('teacherProfile'))
    return {**row, 'origin': 'authored_moment', 'spokenText': row['narrationVariants'][profile]}


def _validate_teaching_design(unit):
    rows = unit['blackboardSteps']
    glossary = unit.get('symbolGlossary')
    graph = unit.get('prerequisiteGraph')
    if not isinstance(glossary, list) or not isinstance(graph, dict) or not graph.get('nodes') or not graph.get('edges') or not unit.get('definitions'):
        raise BundleError('bundle_teaching', '新版课程须有定义、符号对应与先备关系')
    known = set()
    for index, row in enumerate(rows):
        for symbol in row.get('introducedSymbols', []):
            if symbol not in {entry.get('symbol') for entry in glossary}:
                raise BundleError('bundle_teaching', '板书引入了未登记的符号')
            known.add(symbol)
        used = row.get('usesSymbols', [])
        if any(symbol not in known for symbol in used):
            raise BundleError('bundle_teaching', '先解释符号所量对象，再在板书中使用')
        variants = row.get('narrationVariants', {})
        if set(variants) != set(_STYLE) or len(set(variants.values())) != 3:
            raise BundleError('bundle_teaching', '每段须有三种不同的教学带领文字')
        if len(row.get('lines', [])) > 3 or any(len(line) > 110 for line in row.get('lines', [])):
            raise BundleError('bundle_teaching', '板书保留关键关系，不把完整对白写满黑板')
        check = row.get('reflectionCheck')
        if check and (check.get('correctChoice') not in check.get('choices', []) or not check.get('skill')):
            raise BundleError('bundle_teaching', '教学检查须有合法判断与对应关系')
    if not any(entry.get('symbol') == 'b' and entry.get('introducedAt') == 1 for entry in glossary):
        raise BundleError('bundle_teaching', 'b必须在高度这一段明确引入')


def validate_scene_context(value, context):
    """Validate a reported board, recompute geometry, never accept client course facts."""
    allowed = {'schemaVersion', 'revision', 'boardIndex', 'diagram', 'surface', 'presentation',
               'parameters', 'focus', 'visibleBoard', 'introducedSymbols', 'pendingQuestion', 'teacherSpeech', 'momentIndex', 'momentVersion'}
    if not isinstance(value, dict) or set(value) - allowed or value.get('schemaVersion') != 1:
        raise BundleError('invalid_scene_context', '课堂现场结构无效', 422)
    unit = context.get('authorLesson')
    if not isinstance(unit, dict) or unit.get('id') != 'math18':
        raise BundleError('invalid_scene_context', '现场必须绑定同一节椭圆课', 422)
    rows = unit.get('blackboardSteps', [])
    index, revision = value.get('boardIndex'), value.get('revision')
    if type(index) is not int or not 0 <= index < len(rows) or type(revision) is not int or not 0 <= revision <= 1000000000:
        raise BundleError('invalid_scene_context', '现场段号或修订号无效', 422)
    moment = None
    if 'momentIndex' in value:
        if value.get('momentVersion') != MOMENT_VERSION:
            raise BundleError('invalid_scene_context', '课堂小步版本失配', 422)
        moment = classroom_moment_for_context(context, index, value['momentIndex'])
    elif 'momentVersion' in value:
        raise BundleError('invalid_scene_context', '课堂小步身份缺失', 422)
    diagram = value.get('diagram')
    allowed_diagrams = {'rope', 'apex', 'route', 'exam', 'ray', 'circle', 'bound', 'attain', 'video', 'practice', '3d'}
    if diagram not in allowed_diagrams or value.get('surface') not in ('lesson', 'practice') or value.get('presentation') not in ('2d', '3d', 'video'):
        raise BundleError('invalid_scene_context', '课堂视图无效', 422)
    if value['surface'] == 'practice' and diagram != 'practice':
        raise BundleError('invalid_scene_context', '独立练习保留题面而非另一幅图', 422)
    def text(item, maximum):
        if not isinstance(item, str) or len(item) > maximum or any(ord(c) < 32 and c not in '\n\r\t' for c in item):
            raise BundleError('invalid_scene_context', '现场文字无效或过长', 422)
        return item
    parameters = value.get('parameters')
    if not isinstance(parameters, dict) or set(parameters) != {'a', 'c', 'theta', 'garden', 'angles'}:
        raise BundleError('invalid_scene_context', '现场参数无效', 422)
    def number(item, low, high):
        if type(item) not in (int, float) or not math.isfinite(item) or not low <= item <= high:
            raise BundleError('invalid_scene_context', '现场数值无效', 422)
        return item
    a, c, theta = number(parameters['a'], 5, 5), number(parameters['c'], 0, 4.7), number(parameters['theta'], -10000, 10000)
    garden, angles = parameters['garden'], parameters['angles']
    if not isinstance(garden, dict) or set(garden) != {'x', 'y'} or not isinstance(angles, dict) or set(angles) != {'m', 'p'}:
        raise BundleError('invalid_scene_context', '现场点参数无效', 422)
    garden = {'x': number(garden['x'], -1, 9), 'y': number(garden['y'], -2, 5)}
    angles = {key: number(angles[key], -10000, 10000) for key in ('m', 'p')}
    b = math.sqrt(a*a-c*c)
    row = rows[index]
    kind = 'apex' if diagram in ('apex', '3d') and row.get('diagram') == 'ellipse_triangle' else diagram
    x, y = (0, b) if kind == 'apex' else (a*math.cos(theta), b*math.sin(theta))
    if kind in ('rope', 'apex', '3d'):
        geometry = {'kind': kind, 'unit': '米', 'fixed': {'leftStake': [-c, 0], 'rightStake': [c, 0], 'ropeTotal': 2*a},
                    'pen': [x, y], 'distances': {'left': math.hypot(x+c,y), 'right': math.hypot(x-c,y), 'total': 2*a},
                    'measurements': {'halfWidth': a, 'heightFromCenter': b, 'halfFocusGap': c}}
        if kind == 'apex' and c > 0:
            geometry['rightTriangle'] = {
                'vertices': {'center': [0, 0], 'stake': [c, 0], 'top': [0, b]},
                'rightAngleAt': 'center',
                'segments': [
                    {'symbol': 'b', 'from': 'center', 'to': 'top', 'length': b, 'role': 'leg'},
                    {'symbol': 'c', 'from': 'center', 'to': 'stake', 'length': c, 'role': 'leg'},
                    {'symbol': 'a', 'from': 'stake', 'to': 'top', 'length': math.hypot(c, b), 'role': 'hypotenuse'},
                ],
            }
    elif kind == 'route':
        p, n, m = [0, 0], [4.2, 1.2], [garden['x'], garden['y']]
        geometry = {'kind': kind, 'unit': '米', 'P': p, 'N': n, 'M': m,
                    'distances': {'PM': math.hypot(*m), 'PN': math.hypot(*n), 'NM': math.dist(n,m)}}
    elif kind == 'exam':
        geometry = {'kind': 'exam', 'unit': '坐标单位', 'axes': {'a': 3, 'b': 1, 'c': 2*math.sqrt(2)},
                    'O': [0, 0], 'A': [0, -1], 'B': [3, 0], 'ABSquared': 10,
                    'identity': '原题已求得的参数图，不是花坛10米例子'}
    elif kind == 'ray':
        p, origin = [2.1, 1.4], [0, -1]
        d = p[0]*p[0] + (p[1]+1)**2
        ratio = 3/d
        geometry = {'kind': 'ray', 'unit': '坐标单位', 'A': origin, 'P': p,
                    'R': [ratio*p[0], -1+ratio*(p[1]+1)], 'D': d, 'lambda': ratio,
                    'identity': '仅示意正向射线与长度积，尚未加入原题斜率关系'}
    elif kind in ('circle', 'bound', 'attain'):
        m = [3*math.cos(angles['m']), math.sin(angles['m'])]
        p = [3*math.sqrt(2)*math.cos(angles['p']), -4+3*math.sqrt(2)*math.sin(angles['p'])]
        n = [0, -4]
        geometry = {'kind': kind, 'unit': '坐标单位', 'M': m, 'P': p, 'N': n,
                    'distances': {'PM': math.dist(p,m), 'PN': math.dist(p,n), 'NM': math.dist(n,m)}, 'PAllowed': abs(p[0]) > 1e-8}
    else:
        geometry = {'kind': kind, 'unit': '坐标单位', 'note': '题面与条件来自当前绑定公题；不补隐含图像事实'}
    symbols = value.get('introducedSymbols', [])
    if not isinstance(symbols, list) or len(symbols) > 24:
        raise BundleError('invalid_scene_context', '符号列表无效', 422)
    symbols = [text(item, 24) for item in symbols]
    pending = value.get('pendingQuestion')
    if pending is not None:
        if not isinstance(pending, dict) or set(pending) != {'id', 'text', 'source'} or pending['source'] not in ('author', 'dialogue'):
            raise BundleError('invalid_scene_context', '待答问题无效', 422)
        pending = {'id': text(pending['id'], 100), 'text': text(pending['text'], 400), 'source': pending['source']}
    speech = value.get('teacherSpeech', {})
    if not isinstance(speech, dict) or set(speech) - {'text', 'positionSeconds', 'phase', 'speechId'}:
        raise BundleError('invalid_scene_context', '当前讲述无效', 422)
    speech = {'text': text(speech.get('text', ''), 1800), 'positionSeconds': number(speech.get('positionSeconds', 0), 0, 3600),
              'phase': text(speech.get('phase', 'paused'), 40), 'speechId': text(speech.get('speechId', ''), 100)}
    result = {'schemaVersion': 1, 'revision': revision, 'boardIndex': index, 'diagram': diagram, 'surface': value['surface'],
              'presentation': value['presentation'], 'parameters': {'a': a, 'c': c, 'theta': theta, 'garden': garden, 'angles': angles},
              'focus': text(value.get('focus', ''), 160), 'visibleBoard': text(value.get('visibleBoard', ''), 2400),
              'introducedSymbols': symbols, 'pendingQuestion': pending, 'teacherSpeech': speech,
              'geometry': geometry, 'source': 'reported_scene_with_recomputed_geometry', 'imageProvided': False,
              **({'momentIndex': moment['momentIndex'], 'momentVersion': MOMENT_VERSION} if moment else {})}
    if len(_encoded(result)) > 16000:
        raise BundleError('invalid_scene_context', '课堂现场超过预算', 422)
    return result


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _digest(value):
    return hashlib.sha256(_encoded(value)).hexdigest()


def _relative(root, value):
    if not isinstance(value, str) or not value or '\\' in value or '\x00' in value or '?' in value or '#' in value:
        raise BundleError('bundle_path', '发行文件路径无效')
    path = Path(value)
    if path.is_absolute():
        try:
            value = path.relative_to(root).as_posix()
        except ValueError:
            raise BundleError('bundle_path', '发行文件不在工程根内') from None
    parts = PurePosixPath(value).parts
    if not parts or any(p in ('..', '.') for p in parts) or ':' in value or value != '/'.join(parts):
        raise BundleError('bundle_path', '发行文件须为规范根内相对路径')
    path = root
    for part in parts:
        path = path / part
        if path.is_symlink():
            raise BundleError('bundle_path', '发行路径不能包含符号链接')
    if not path.resolve().is_relative_to(root):
        raise BundleError('bundle_path', '发行文件路径越界')
    return value


def _read(root, relative, maximum=128 * 1024 * 1024):
    from local_lesson import _read_bytes
    return _read_bytes(root / _relative(root, relative), maximum)


_MEDIA_SUFFIXES = frozenset({'.wav', '.mp3', '.m4a', '.ogg', '.mp4'})


def _narration_entries(unit):
    rows = unit.get('narrationAssets', {})
    if not isinstance(rows, dict) or not all(isinstance(u.get('blackboardSteps'), list) and len(u['blackboardSteps']) == 8
            for u in [unit]):
        raise BundleError('bundle_format', 'narrationAssets须按老师preset及段号登记')
    for profile, entries in rows.items():
        validated_teacher_profile(profile)
        if not isinstance(entries, dict) or not entries:
            raise BundleError('bundle_format', 'narrationAssets老师映射不完整')
        for index, entry in entries.items():
            if (not index.isdigit() or not 0 <= int(index) < 8
                    or not isinstance(entry, dict) or set(entry) != {'file', 'durationSeconds'}):
                raise BundleError('bundle_format', 'narrationAssets只接受作者file/durationSeconds')
            row = unit['blackboardSteps'][int(index)]
            text = row.get('narrationVariants', {}).get(profile, row['spokenText'])
            yield profile, int(index), entry, text


def _media_entries(root, unit):
    for profile, index, entry, text in _narration_entries(unit):
        yield entry, entry['file'], 'narration', {'profile': profile, 'boardIndex': index, 'text': text}
    variants = unit.get('mediaVariants', {})
    if not isinstance(variants, dict):
        raise BundleError('bundle_format', 'mediaVariants结构失配')
    for name, entry in variants.items():
        if name not in ('intro', 'video') or not isinstance(entry, dict) or 'file' not in entry:
            raise BundleError('bundle_format', 'mediaVariants只接受intro/video作者登记')
        if 'durationSeconds' not in entry:
            raise BundleError('bundle_format', 'mediaVariants须登记durationSeconds')
        yield entry, entry['file'], 'video', {'variant': name}


def _asset_entries(root, unit):
    entries = {}
    for metadata, path, kind, detail in _media_entries(root, unit):
        relative = _relative(root, path)
        if relative in entries:
            raise BundleError('bundle_format', '同一媒体不能以不同身份重复登记')
        entries[relative] = {'metadata': metadata, 'kind': kind, 'detail': detail}
    return entries


def _assets(root, unit):
    # sourceScope.files are evidence references, not runtime teaching assets.
    paths = set(_asset_entries(root, unit))
    originals = {path for path, _pages, _role in _ORIGINALS}
    paths.update(originals)
    for index, row in enumerate(unit.get('blackboardSteps', [])):
        if 'audio' in row:
            paths.add(row['audio'])
    for path in sorted(paths):
        if path not in originals and Path(path).suffix.lower() not in _MEDIA_SUFFIXES:
            raise BundleError('bundle_path', '受保护媒体须为wav/mp3/m4a/ogg/mp4')
        _relative(root, path)
    return sorted(paths)


def _sanitized_unit(root, unit):
    value = copy.deepcopy(unit)
    scope = value.get('sourceScope', {})
    for path in scope.get('files', []):
        if isinstance(path, dict) and 'path' in path:
            path['path'] = _relative(root, path['path'])
    for metadata, _, _, _ in _media_entries(root, value):
        metadata['file'] = _relative(root, metadata['file'])
    for row in value.get('blackboardSteps', []):
        if 'audio' in row:
            row['audio'] = _relative(root, row['audio'])
    return value


def _duration(path, suffix, metadata):
    expected = metadata.get('durationSeconds')
    if type(expected) not in (int, float) or not 0 < expected <= 3600:
        raise BundleError('bundle_media', '媒体durationSeconds无效')
    import subprocess
    from shutil import which
    ffprobe = which('ffprobe')
    if suffix == '.wav':
        import wave
        try:
            with wave.open(str(path), 'rb') as audio:
                if (audio.getnchannels() not in (1, 2) or audio.getframerate() <= 0
                        or audio.getsampwidth() not in (1, 2, 3, 4)):
                    raise ValueError()
                duration = audio.getnframes() / audio.getframerate()
        except (wave.Error, EOFError, ValueError):
            raise BundleError('bundle_media', '作者WAV无法解码') from None
        actual = {'container': 'wav', 'duration': duration}
    elif ffprobe:
        result = subprocess.run([ffprobe, '-v', 'error', '-show_entries',
            'format=duration,format_name', '-of', 'json', str(path)],
            capture_output=True, text=True, timeout=20)
        if result.returncode:
            raise BundleError('bundle_media', '作者音视频无法解码')
        actual = json.loads(result.stdout)['format']
        duration = float(actual['duration'])
    else:
        raise BundleError('bundle_media', '缺少ffprobe，未把未验证容器当成已核媒体', 503)
    if abs(duration - expected) > 0.1:
        raise BundleError('bundle_media', '作者登记时长与实际媒体不符')
    return {'actualDurationSeconds': duration, 'formatChecked': True,
            'format': actual.get('format_name', 'wav')}


def _receipt_binding(root, profile, index, path, text, units_sha, authorized_sha=None):
    filename = Path(path).name + '.receipt.json'
    candidates = [Path(path).with_name(filename), Path(path).with_suffix('').with_name(Path(path).stem + '.receipt.json')]
    receipt_path = next((root / _relative(root, item.as_posix()) for item in candidates
                         if (root / item).is_file()), None)
    if receipt_path is None:
        raise BundleError('bundle_media', '旁白缺少服务端公开回执，拒绝猜测文本关联')
    from local_lesson import _loads
    receipt = _loads(_read(root, receipt_path.relative_to(root).as_posix(), 256 * 1024).decode())
    selected_hash = hashlib.sha256(text.encode()).hexdigest()
    structured = receipt.get('jobId') is not None
    legacy = (profile == 'witty' and index == 0 and receipt.get('schemaVersion') == 1
              and receipt.get('authorIdentity') == 'current'
              and receipt.get('payload') == {'action': 'narrate', 'paper': 'math-2025-national1',
                  'number': 18, 'topic': 'm-ellipse', 'boardIndex': 0, 'teacherProfile': 'witty'}
              and receipt.get('text') == text and receipt.get('textSHA256') == selected_hash
              and receipt.get('audioVerified') is False)
    if not structured and not legacy:
        raise BundleError('bundle_media', '既有旁白公开回执缺少可核作者文字/身份关联')
    if structured and (receipt.get('fileHash') != _digest_bytes(_read(root, path))
            or receipt.get('teacherProfile') != profile or receipt.get('boardIndex') != index
            or receipt.get('spokenText') != text or receipt.get('textSha256') != selected_hash
            or receipt.get('audioVerified') is not False or receipt.get('realtime') is not False
            or receipt.get('provider') != 'local' or not isinstance(receipt.get('model'), dict)
            or receipt.get('teacherProfileVersion') not in BUNDLE_VERSIONS
            or receipt.get('authorIdentity', {}).get('unitId') != 'math18'):
        raise BundleError('bundle_media', '旁白回执与作者选中文字、老师或文件不对应')
    if legacy and (receipt.get('authorFileSHA256') != authorized_sha
                   or not isinstance(receipt.get('model'), dict)):
        raise BundleError('bundle_media', '既有旁白公开回执老师版本失配')
    expected_source = _digest(text)
    if structured and receipt.get('authorUnitsSha256') not in (None, units_sha, authorized_sha):
        raise BundleError('bundle_media', '旁白回执授权作者快照不匹配')
    source_author = receipt.get('authorSourceFactsSha256', receipt.get('authorUnitsSha256', receipt.get('authorFileSHA256')))
    return {'profile': profile, 'boardIndex': index, 'file': path,
            'receiptFile': receipt_path.relative_to(root).as_posix(),
            'receiptSha256': _digest_bytes(_read(root, receipt_path.relative_to(root).as_posix())),
            'textSha256': receipt.get('textSha256', selected_hash), 'authorSourceFactsSha256': source_author,
            'selectedTextSha256': expected_source, 'provider': 'local', 'model': receipt['model'],
            'audioVerified': False, 'realtime': False}


def _digest_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def _validate_snapshot(value, ref):
    if not isinstance(value, dict) or value.get('schemaVersion') != SCHEMA_VERSION or value.get('bundleRef') != ref:
        raise BundleError('bundle_format', '教学包格式或固定版本不符')
    unit, context = value.get('unit'), value.get('context')
    if (not isinstance(unit, dict) or unit.get('id') != ref['id']
            or unit.get('paperId') != 'math-2025-national1' or unit.get('entryNumber') != 18
            or unit.get('numbers') != [18] or unit.get('mainConceptId') != 'm-ellipse'
            or not isinstance(context, dict) or context.get('authorLesson') != unit
            or context.get('paper') != unit['paperId'] or context.get('unitId') != unit['id']
            or context.get('number') != 18 or context.get('mainConceptId') != unit['mainConceptId']
            or context.get('topic') != unit.get('topic')):
        raise BundleError('bundle_identity', '教学包与作者单元身份失配')
    demands = context.get('question', {}).get('knowledgeDemands')
    skills = value.get('canonicalSkills')
    if (not isinstance(demands, list) or len(demands) != 6 or skills != demands
            or any(not isinstance(d, dict) or not all(isinstance(d.get(k), str) and d[k] for k in
                   ('id', 'label', 'requirement', 'localPointId')) for d in demands)
            or len({d['id'] for d in demands}) != 6):
        raise BundleError('bundle_skills', '教学包须保留六条实际knowledgeDemands')
    rows = unit.get('blackboardSteps')
    if not isinstance(rows, list) or len(rows) != 8:
        raise BundleError('bundle_format', '首条椭圆课须有8段作者黑板')
    from doubao_realtime import blackboard_plan_for_context
    for index in range(len(rows)):
        blackboard_plan_for_context(context, index)
    if ref['version'] == '0.4.0':
        _validate_teaching_design(unit)
    if value.get('practice') != unit.get('practice') or not isinstance(value.get('practice'), dict):
        raise BundleError('bundle_format', '练习描述须为作者快照，不含另签新题或隐藏答案')
    expected_relations = _relations(unit, demands)
    if value.get('relations') != expected_relations:
        raise BundleError('bundle_format', '教学关系须保留作者解释与需求映射')
    if value.get('sources') != [dict(path=p, pages=pages, role=role) for p, pages, role in _ORIGINALS]:
        raise BundleError('bundle_format', '原件物理页登记不符')
    if value.get('scope') != {'unitIds': [ref['id']], 'questionNumbers': [18],
                               'coverage': unit.get('sourceScope', {}).get('coverage', '')}:
        raise BundleError('bundle_format', '教学切片范围失配')
    # Local current-compiler schema checks never mark media/audio as verified.
    if 'narrationBindings' in value and not isinstance(value['narrationBindings'], list):
        raise BundleError('bundle_format', '旁白绑定清单结构失配')
    release = value.get('releaseStatus')
    expected_release = _release_status()
    if (not isinstance(release, dict) or release != expected_release
            or any(release.get(key) is not expected for key, expected in expected_release.items()
                   if type(expected) is bool)):
        raise BundleError('bundle_format', '未审核及未云发布声明缺失')
    content = {k: v for k, v in value.items() if k != 'contentSha256'}
    if value.get('contentSha256') != _digest(content):
        raise BundleError('bundle_integrity', '冻结包内容摘要不一致')


def _relations(unit, demands):
    return ([{'type': 'requires', 'from': unit['id'], 'to': d['id'],
              'explanation': d['requirement'], 'evidence': d.get('evidence', '')} for d in demands] +
            [{'type': 'mapped_to', 'from': d['id'], 'to': d['localPointId'],
              'explanation': d['label']} for d in demands] +
            [{'type': 'author_connection', 'from': unit['id'], 'title': c['title'],
              'relationLabel': c['relation'], 'explanation': c['explanation'],
              'example': c.get('example', '')} for c in unit['connections']])


def _release_status():
    return {'localOnly': True, 'teacherReviewed': False, 'audioVerified': False,
            'cloudPublished': False, 'childValidated': False,
            'notice': '仅本机math18切片；尚未教师审核、听感验收、真实儿童验证或云发布。关系是作者解释与本地需求映射，不虚构七源支持。'}


def register_lesson_units(root):
    """Trusted author build only: update just classroomFiles.units, never question facts."""
    from local_lesson import LocalLessonService, _loads, _save
    root = Path(root).resolve()
    reader = LocalLessonService.__new__(LocalLessonService)
    reader.root = root
    catalog = reader._catalog()
    raw = _read(root, 'data/lesson-units.json', 4 * 1024 * 1024)
    document = _loads(raw.decode('utf-8'))
    if not isinstance(document, dict) or not isinstance(document.get('units'), list):
        raise BundleError('bundle_format', '作者课单须为units数组')
    updated = copy.deepcopy(catalog)
    updated.setdefault('classroomFiles', {})['units'] = {
        'file': 'data/lesson-units.json', 'sha256': hashlib.sha256(raw).hexdigest()}
    reader._checked_units(updated)
    targets = []
    for relative, data in (
            ('data/catalog.json', json.dumps(updated, ensure_ascii=False, allow_nan=False)),
            ('data/catalog.js', 'window.RESEARCH_DATA=' + json.dumps(updated, ensure_ascii=False, allow_nan=False) + ';\n')):
        _relative(root, relative)
        if relative.endswith('.js') or (root / relative).exists():
            targets.append((relative, data.encode('utf-8')))
    # Existing indexes with direct catalog registrations are updated narrowly;
    # semantic seven-source delivery versions do not depend on lesson units.
    indexes = []
    for relative in ('data/three-paper-delivery.json', 'data/index.json'):
        if not (root / relative).exists():
            continue
        index = _loads(_read(root, relative, 64 * 1024 * 1024).decode('utf-8'))
        changed = False
        def update(node):
            nonlocal changed
            if isinstance(node, dict):
                for path, data in targets:
                    if node.get('file') == path and 'sha256' in node:
                        node['sha256'] = hashlib.sha256(data).hexdigest()
                        changed = True
                for child in node.values():
                    update(child)
            elif isinstance(node, list):
                for child in node:
                    update(child)
        update(index)
        if changed:
            indexes.append((relative, index))
    for relative, data in targets:
        path = root / relative
        if path.exists() and _read(root, relative, 64 * 1024 * 1024) == data:
            continue
        # Existing atomic file primitives; catalog.js stays a data wrapper, never executed.
        temporary = path.with_name('.catalog-' + os.urandom(8).hex())
        from local_lesson import _write
        try:
            _write(temporary, data)
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
    for relative, index in indexes:
        _save(root / relative, index)
    return copy.deepcopy(updated['classroomFiles']['units'])


def compile_teaching_bundle(root, unit_id='math18', version='0.3.0'):
    ref = validated_bundle_ref({'namespace': 'teaching', 'id': unit_id, 'version': version}, unit_id)
    root = Path(root).resolve()
    from local_lesson import LocalLessonService
    reader = LocalLessonService.__new__(LocalLessonService)
    reader.root = root
    catalog = reader._catalog()
    document, units_sha = reader._checked_units(catalog)
    matches = [u for u in document['units'] if u.get('id') == unit_id]
    if len(matches) != 1:
        raise BundleError('bundle_identity', '作者单元缺失或重复')
    unit = copy.deepcopy(matches[0])
    context = reader._context({'action': 'ask', 'paper': unit['paperId'], 'number': unit['entryNumber'],
                               'topic': unit['mainConceptId']})
    if context['_binding']['unitsSha256'] != units_sha or context['authorLesson'] != unit:
        raise BundleError('bundle_integrity', '编译期间作者课单发生变化，拒绝冻结')
    # Bind narration to the original author snapshot before source-path sanitization.
    authorized_sha = None
    first_receipt = root / '验收/11.12-Skill试用-椭圆微讲解/teacher-harness-warm-0.wav.receipt.json'
    if first_receipt.is_file():
        from local_lesson import _loads
        try:
            candidate = _loads(_read(root, first_receipt.relative_to(root).as_posix(), 256 * 1024).decode())
            if candidate.get('authorUnitsSha256') == 'befda04d83aa97032748b3498362b71042ae11230a932499401df63afce0a64d':
                authorized_sha = candidate['authorUnitsSha256']
        except ValueError:
            pass
    bindings = []
    for metadata, path, kind, detail in _media_entries(root, unit):
        relative = _relative(root, path)
        _duration(root / relative, Path(relative).suffix.lower(), metadata)
        if kind == 'narration':
            bindings.append(_receipt_binding(root, detail['profile'], detail['boardIndex'], relative, detail['text'], units_sha, authorized_sha))
    unit = _sanitized_unit(root, unit)
    context['authorLesson'] = copy.deepcopy(unit)
    context.pop('_binding', None)
    files = []
    for path in _assets(root, unit):
        raw = _read(root, path)
        files.append({'path': path, 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    demands = copy.deepcopy(context['question'].get('knowledgeDemands'))
    value = {'schemaVersion': SCHEMA_VERSION, 'bundleRef': ref, 'unit': unit, 'context': context,
             'narrationBindings': bindings,
             'canonicalSkills': demands, 'relations': _relations(unit, demands or []),
             'practice': copy.deepcopy(unit.get('practice')),
             'sources': [dict(path=p, pages=pages, role=role) for p, pages, role in _ORIGINALS],
             'files': files, 'scope': {'unitIds': [unit_id], 'questionNumbers': [18],
                                      'coverage': unit.get('sourceScope', {}).get('coverage', '')},
             'releaseStatus': _release_status(),
             'provenance': {'unitsSha256': units_sha, 'narrationAuthorizedUnitsSha256': authorized_sha,
                            'catalogSha256': _digest(catalog)}}
    value['contentSha256'] = _digest(value)
    _validate_snapshot(value, ref)
    relative = _BUNDLE_FILES[ref['version']]
    _relative(root, relative)
    target = root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = _encoded(value) + b'\n'
    try:
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    except FileExistsError:
        if _read(root, relative, 8 * 1024 * 1024) != raw:
            raise BundleError('bundle_exists', '固定版本已有不同字节，拒绝覆盖；请审核后另登记版本') from None
    else:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    return load_teaching_bundle(root, unit_id, ref)


def load_teaching_bundle(root, unit_id='math18', bundle_ref=None):
    ref = validated_bundle_ref(bundle_ref, unit_id)
    root = Path(root).resolve()
    from local_lesson import _loads
    try:
        raw = _read(root, _BUNDLE_FILES[ref['version']], 8 * 1024 * 1024)
        value = _loads(raw.decode('utf-8'))
        _validate_snapshot(value, ref)
        files = value.get('files')
        required = _assets(root, value['unit'])
        if (not isinstance(files, list) or any(not isinstance(f, dict) or set(f) != {'path', 'size', 'sha256'} for f in files)
                or sorted(f['path'] for f in files) != required or len(files) != len(required)):
            raise BundleError('bundle_integrity', '受保护发行文件清单缺失、重复或越界')
        for profile, index, entry, text in _narration_entries(value['unit']):
            path = _relative(root, entry['file'])
            _duration(root / path, Path(path).suffix.lower(), entry)
            binding = _receipt_binding(root, profile, index, path, text,
                                       value.get('provenance', {}).get('unitsSha256'),
                                       value.get('provenance', {}).get('narrationAuthorizedUnitsSha256'))
            matches = [row for row in value.get('narrationBindings', [])
                       if row.get('profile') == profile and row.get('boardIndex') == index]
            if len(matches) != 1 or matches[0] != binding:
                raise BundleError('bundle_media', '固定旁白绑定与媒体/回执/作者选中文字不一致')
        for name, entry in value['unit'].get('mediaVariants', {}).items():
            path = _relative(root, entry['file'])
            _duration(root / path, Path(path).suffix.lower(), entry)
        for item in files:
            if (type(item['size']) is not int or item['size'] < 0
                    or not isinstance(item['sha256'], str) or not re.fullmatch(r'[0-9a-f]{64}', item['sha256'])):
                raise BundleError('bundle_format', '发行文件摘要格式不符')
            current = _read(root, item['path'])
            if len(current) != item['size'] or hashlib.sha256(current).hexdigest() != item['sha256']:
                raise BundleError('bundle_integrity', '受保护发行资产已变更，拒绝装载')
        return value
    except FileNotFoundError:
        raise BundleError('bundle_missing', '本机固定教学包或受保护资产尚未生成/已缺失', 404) from None
    except BundleError:
        raise
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
        raise BundleError('bundle_format', '教学包或受保护资产未通过格式/完整性检查') from None


class _EvidenceError(ValueError):
    """Only bounded validation messages may cross the evidence API boundary."""


_EVIDENCE_IDS = tuple('S%02d' % i for i in range(1, 8))
_EVIDENCE_STATUS = {
    'direct': '这一动作有原文支持', 'partial': '提供部分基础',
    'transfer': '可借用的方法', 'locator': '只找到教材位置',
    'absent': '未找到对应说明', 'out_of_scope': '本次资料不含此学科',
    'uncertain': '现有说明尚不能确定',
}
_BODY_KEYS = frozenset(('definition', 'description', 'formula', 'evidence',
    'mastery_criteria', 'learningObjectives', 'examples', 'aliases', 'volume',
    'chapter', 'assessmentPrompt'))


def _evidence_text(value):
    """Allow prose and public entity identifiers, never local paths/signed URLs."""
    if (not isinstance(value, str) or not value or len(value) > 20000
            or re.search(r'(?:/(?:Users|home|private|tmp|var|etc|opt|Volumes|Applications)/|~/|file:|(?:^|[\s(])[A-Za-z]:[\\\\/]|'
                         r'https?://[^\s]*\?|(?:token|signature|credential|api[_-]?key)\s*[=:])',
                         value, re.I)):
        raise _EvidenceError('证据展示字段含无效文本或私有位置')
    return value


def _body_value(value):
    # Flatten only primitive display values, not arbitrary nested metadata.
    if isinstance(value, str):
        return _evidence_text(value)
    if type(value) in (bool, int, float):
        if type(value) is float and not math.isfinite(value):
            raise _EvidenceError('证据正文数值无效')
        return value
    if isinstance(value, list):
        return [_body_value(item) for item in value if not isinstance(item, dict)]
    return None


def _public_body(body):
    if not isinstance(body, dict):
        raise _EvidenceError('来源正文结构不符')
    result = {}
    for key in _BODY_KEYS:
        if key not in body:
            continue
        value = body[key]
        if key == 'learningObjectives' and isinstance(value, dict):
            value = value.get('value')
        value = _body_value(value)
        if value is not None:
            result[key] = {'value': value} if key == 'learningObjectives' else value
    return result


def _bounded_public_json(value, depth=0, budget=None):
    """Preserve bounded JSON values without leaking imported private locations."""
    budget = [512] if budget is None else budget
    if depth > 8 or budget[0] < 1:
        raise _EvidenceError('来源原位置JSON超出展示边界')
    budget[0] -= 1
    if value is None or type(value) in (bool, int):
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise _EvidenceError('来源原位置JSON数值无效')
        return value
    if isinstance(value, str):
        return _evidence_text(value) if value else value
    if isinstance(value, list):
        return [_bounded_public_json(item, depth + 1, budget) for item in value]
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if not isinstance(key, str) or len(key) > 200:
                raise _EvidenceError('来源原位置JSON键无效')
            result[_evidence_text(key) if key else key] = _bounded_public_json(item, depth + 1, budget)
        return result
    raise _EvidenceError('来源原位置JSON类型无效')


def _public_locator(value):
    """Return a bounded object; imported filesystem paths are never exposed."""
    if isinstance(value, dict):
        return _bounded_public_json(value)
    if not isinstance(value, str) or len(value) > 20000:
        raise _EvidenceError('来源原位置缺失')
    if '#/' in value:
        position = value.split('#/', 1)[1]
        if re.fullmatch(r'[\w\-]+(?:/[\w\-]+)*', position):
            pointer = '/' + position
            return {'kind': 'jsonPointer', 'value': pointer,
                    'label': '原来源记录 · JSON位置 ' + pointer}
    if '#RDF-subject=' in value:
        entity = value.split('#RDF-subject=', 1)[1]
        _evidence_text(entity)
        return {'kind': 'rdfEntity', 'value': entity,
                'label': '原来源记录 · RDF实体 ' + entity}
    # Already-authored descriptive positions, not an imported path or URL.
    if not value.startswith(('/', '~')) and '://' not in value:
        text = _evidence_text(value)
        return {'kind': 'description', 'value': text, 'label': text}
    raise _EvidenceError('来源原位置不能安全展示')


def _public_evidence_node(identifier, source_nodes, sid, version, catalog,
                          not_current_decision=False):
    node = source_nodes.get(identifier)
    if (not isinstance(node, dict) or node.get('id') != identifier
            or node.get('sourceId') != sid or node.get('sourceVersion') != version):
        raise _EvidenceError('绑定的原知识节点缺失或身份版本不一致')
    edges = node.get('nativePrerequisites')
    if not isinstance(edges, list):
        raise _EvidenceError('原生直接先备关系结构不符')
    public_edges = []
    for edge in edges:
        if (edge.get('sourceId') != sid or edge.get('sourceVersion') != version
                or edge.get('target') != identifier
                or not str(edge.get('source', '')).startswith(sid + ':')):
            raise _EvidenceError('原生直接边端点或身份版本不一致')
        public = {k: _evidence_text(edge[k]) for k in ('id', 'source', 'target', 'label')}
        for endpoint in ('source', 'target'):
            endpoint_node = source_nodes.get(edge[endpoint], {})
            label = (endpoint_node.get('label') or catalog.get('sourceRelationLabels', {}).get(edge[endpoint])
                     or catalog.get('stageCurriculum', {}).get(edge[endpoint], {}).get('title')
                     or catalog['sourceCoverage'].get('localNodes', {}).get(edge[endpoint], {}).get('title'))
            public[endpoint + 'Label'] = _evidence_text(label or edge[endpoint])
        public_edges.append(public)
    return {'id': identifier, 'label': _evidence_text(node['label']),
        'bodyEvidence': _public_body(node.get('bodyEvidence')),
        'nativePrerequisites': public_edges, 'sourceLocator': _public_locator(node.get('sourceLocator')),
        'boundSource': {'sourceId': sid, 'sourceVersion': version},
        'notCurrentDecision': bool(not_current_decision)}


# These are citations explicitly named by existing S02 reasons, never added to
# the catalog's current-decision nodeIds. A missing full ID is resolved only by
# a unique suffix plus matching node content; no substitute or common root.
_EVIDENCE_CITATIONS = {
    'S02': (
        {'demandId': 'math2025-q18-d01', 'reference': 'cpt61', 'concept': '离心率',
         'reasonTerms': ('cpt61', '离心率'), 'nodeId': 'S02:math_xzxbx1_rjb_cpt61'},
        {'demandId': 'math2025-q18-d02', 'reference': 'cpt41', 'concept': '参数方程',
         'reasonTerms': ('cpt41', '参数'), 'nodeId': 'S02:math_bx2_rjb_cpt41'},
        {'demandId': 'math2025-q18-d03', 'reference': 'cpt32', 'concept': '斜率',
         'reasonTerms': ('cpt32', '斜率')},
    ),
}


def _additional_citation(request, source_nodes, sid, version, catalog, current_ids):
    identifier = request.get('nodeId')
    if identifier and identifier not in source_nodes:
        return None, 'not_in_source_nodes'
    candidates = [identifier] if identifier else sorted(
        key for key in source_nodes
        if isinstance(key, str) and key.startswith(sid + ':')
        and key.rsplit('_', 1)[-1] == request['reference'])
    if not candidates:
        return None, 'not_in_source_nodes'
    candidates = [candidate for candidate in candidates if candidate not in current_ids]
    if not candidates:
        return None, None
    matches = []
    for candidate in candidates:
        try:
            node = source_nodes.get(candidate)
            searchable = json.dumps({k: node.get(k) for k in ('label', 'aliases', 'bodyEvidence')},
                                    ensure_ascii=False, allow_nan=False)
            if request['concept'] not in searchable:
                continue
            matches.append(_public_evidence_node(candidate, source_nodes, sid, version, catalog,
                                                 not_current_decision=True))
        except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
            continue
    if len(matches) == 1:
        return matches[0], None
    return None, 'ambiguous_citation_node' if matches else 'citation_node_not_verified'


def _source_evidence(root, meta, demands, catalog):
    from local_lesson import _loads
    sid = meta['sourceId']
    if (meta.get('file') != 'data/graph-coverage/' + sid + '.json'
            or not isinstance(meta.get('sha256'), str)
            or not re.fullmatch(r'[0-9a-f]{64}', meta['sha256'])):
        raise _EvidenceError('来源文件登记或摘要格式不符')
    raw = _read(root, meta['file'], 64 * 1024 * 1024)
    if hashlib.sha256(raw).hexdigest() != meta['sha256']:
        raise _EvidenceError('来源文件摘要与当前登记不一致')
    record = _loads(raw.decode('utf-8'))
    version = _evidence_text(meta['sourceVersion'])
    if record.get('sourceId') != sid or record.get('sourceVersion') != version:
        raise _EvidenceError('来源身份或固定版本不一致')
    papers = [p for p in record['papers'] if p.get('paperId') == 'math-2025-national1']
    if len(papers) != 1:
        raise _EvidenceError('来源原卷记录缺失或重复')
    expected = {d['id'] for d in demands}
    rows = [r for r in papers[0]['requirements']
            if r.get('number') == 18 or r.get('demandId') in expected]
    if len(rows) != 6 or {r['demandId'] for r in rows} != expected:
        raise _EvidenceError('来源Q18六项需求缺失、重复或混入其他题')
    decisions, node_ids = [], []
    for demand in demands:
        original = next(r for r in rows if r['demandId'] == demand['id'])
        if (type(original.get('number')) is not int or original['number'] != 18
                or any(original.get(k) != demand.get(k) for k in
                       ('label', 'requirement', 'role', 'localPointId'))):
            raise _EvidenceError('来源需求字段与固定Q18不一致')
        # Legacy rows may omit these fields; registration metadata is not a
        # substitute. Once present, bind the whole value to the fixed demand.
        for key in ('sourcePages', 'evidence'):
            if key in original and (key not in demand or original[key] != demand[key]):
                raise _EvidenceError('来源需求' + key + '字段与固定Q18不一致')
        decision = demand['sourceReviews'][sid]
        if any(original.get(k) != decision.get(k) for k in ('status', 'nodeIds', 'reason', 'uncovered')):
            raise _EvidenceError('来源逐项判定与当前catalog不一致')
        status = decision['status']
        if status not in _EVIDENCE_STATUS or not isinstance(decision['nodeIds'], list):
            raise _EvidenceError('来源判定状态或节点清单无效')
        public_node_ids = [_evidence_text(i) for i in decision['nodeIds']]
        decisions.append({'demandId': demand['id'], 'label': _evidence_text(demand['label']),
            'status': status, 'statusLabel': _EVIDENCE_STATUS[status],
            'reason': _evidence_text(decision['reason']),
            'uncovered': _evidence_text(decision['uncovered']) if decision['uncovered'] else '',
            'nodeIds': copy.deepcopy(public_node_ids), 'citationNodes': []})
        node_ids.extend(public_node_ids)
    source_nodes = record['sourceNodes']
    nodes = [_public_evidence_node(identifier, source_nodes, sid, version, catalog)
             for identifier in dict.fromkeys(node_ids)]
    citation_issues = []
    current_ids = frozenset(node_ids)
    for decision in decisions:
        for request in _EVIDENCE_CITATIONS.get(sid, ()):
            if (request['demandId'] != decision['demandId']
                    or not all(term in decision['reason'] for term in request['reasonTerms'])):
                continue
            try:
                citation, issue_code = _additional_citation(
                    request, source_nodes, sid, version, catalog, current_ids)
            except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
                citation, issue_code = None, 'citation_node_not_verified'
            if citation is not None:
                decision['citationNodes'].append(citation)
            elif issue_code:
                issue = {'demandId': decision['demandId'], 'reference': request['reference'],
                    'concept': request['concept'], 'code': issue_code, 'notReadFailure': True,
                    'message': '理由提及的额外引用未能在本来源同版本sourceNodes中安全核对；'
                               '这不是来源读取失败，未补造正文或改变当前判定。'}
                if request.get('nodeId'):
                    issue['nodeId'] = request['nodeId']
                citation_issues.append(issue)
    return {'id': sid, 'name': _evidence_text(meta['name']),
            'kind': _evidence_text(meta['evidenceKind']), 'version': version,
            'status': 'verified', 'decisions': decisions, 'nodes': nodes,
            'additionalCitationIssue': citation_issues,
            'identity': {'sourceId': sid, 'sourceVersion': version, 'exactRecordVerified': True},
            'boundary': _evidence_text(meta['evidenceBoundary'])}


def course_evidence(root, bundle):
    """Read only seven existing Q18 records; verified means binding, not pedagogy.

    No cache, model, author-unit reload, research, or frozen-package mutation.
    SHA-256 is checked internally and deliberately omitted from display payloads.
    """
    result = {'status': 'unavailable', 'sources': [],
        'notice': '原来源辅助，版本分别校验，不改固定教案',
        'boundary': '仅核对本题已有记录的身份、版本和六项需求，不拼合各源支持；'
                    '不是新的教研验证、教师审校或学生掌握证明。读取失败不等于没有支持。'}
    try:
        from local_lesson import LocalLessonService
        root = Path(root).resolve()
        context = bundle['context']
        if context.get('paper') != 'math-2025-national1' or context.get('number') != 18:
            raise _EvidenceError('固定教学包不是登记的Q18')
        frozen = context['question']['knowledgeDemands']
        if (not isinstance(frozen, list) or len(frozen) != 6
                or len({d['id'] for d in frozen}) != 6):
            raise _EvidenceError('固定教学包六项需求缺失或重复')
        reader = LocalLessonService.__new__(LocalLessonService)
        reader.root = root
        catalog = reader._catalog()
        coverage = catalog['sourceCoverage']
        demands = coverage['papers']['math-2025-national1']['questions']['18']
        if (len(demands) != 6 or len({d['id'] for d in demands}) != 6
                or {d['id'] for d in demands} != {d['id'] for d in frozen}):
            raise _EvidenceError('当前catalog的Q18需求ID与固定教学包不一致')
        demands = [next(d for d in demands if d['id'] == f['id']) for f in frozen]
        for fixed, current in zip(frozen, demands):
            if {k: v for k, v in current.items() if k not in ('localReview', 'sourceReviews')} != fixed:
                raise _EvidenceError('当前catalog的Q18核心需求字段与固定教学包不一致')
        questions = catalog['papers']['math-2025-national1']['analysis']['questions']
        current_questions = [q for q in questions if q.get('number') == 18]
        if len(current_questions) != 1 or current_questions[0].get('knowledgeDemands') != frozen:
            raise _EvidenceError('当前原题Q18的knowledgeDemands与固定教学包不一致')
        metas = coverage['sources']
        if not isinstance(metas, list):
            raise _EvidenceError('七源登记结构不符')
    except _EvidenceError as error:
        result['reason'] = str(error) + '；来源辅助暂不可用，不改固定教案。'
        return result
    except (OSError, ValueError, TypeError, KeyError, AttributeError, StopIteration, RecursionError):
        # Do not return exception paths or raw parser contents to the client.
        result['reason'] = '当前Q18需求或catalog无法读取或结构不符；来源辅助暂不可用，不改固定教案。'
        return result
    for sid in _EVIDENCE_IDS:
        try:
            matches = [m for m in metas if m.get('sourceId') == sid]
            if len(matches) != 1:
                raise _EvidenceError('来源登记缺失或重复')
            source = _source_evidence(root, matches[0], demands, catalog)
        except FileNotFoundError:
            source = {'id': sid, 'status': 'unavailable', 'reason': '来源证据文件缺失；读取失败不等于没有支持。', 'decisions': [], 'nodes': [], 'additionalCitationIssue': []}
        except _EvidenceError as error:
            source = {'id': sid, 'status': 'unavailable', 'reason': str(error) + '；读取失败不等于没有支持。', 'decisions': [], 'nodes': [], 'additionalCitationIssue': []}
        except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
            source = {'id': sid, 'status': 'unavailable', 'reason': '来源记录未能安全读取或结构不符；读取失败不等于没有支持。', 'decisions': [], 'nodes': [], 'additionalCitationIssue': []}
        if source['status'] == 'unavailable':
            # Metadata is a registration, not verified evidence; never substitute
            # a different record when this source cannot be bound.
            source.update({'name': sid, 'kind': 'unavailable', 'version': None})
            if len(matches) == 1:
                for output, key in (('name', 'name'), ('kind', 'evidenceKind'), ('version', 'sourceVersion')):
                    try:
                        source[output] = _evidence_text(matches[0].get(key))
                    except _EvidenceError:
                        pass
        result['sources'].append(source)
    if all(s['status'] == 'verified' for s in result['sources']):
        result['status'] = 'verified'
    else:
        result['reason'] = '部分来源未通过当前记录绑定校验；已核对来源分别保留，不补造支持。'
    return result


def frozen_context(root, payload):
    value = load_teaching_bundle(root, bundle_ref=payload['bundleRef'])
    unit = value['unit']
    if (payload['paper'] != unit['paperId'] or payload['number'] != unit['entryNumber']
            or payload['topic'] not in (unit['topic'], unit['mainConceptId'])):
        raise BundleError('bundle_identity', '请求题目或topic不属于固定教学包', 422)
    context = copy.deepcopy(value['context'])
    context['bundleRef'] = copy.deepcopy(value['bundleRef'])
    context['teacherProfileVersion'] = value['bundleRef']['version']
    context['_binding'] = {'bundleSha256': value['contentSha256']}
    return context
