"""Kie.ai media provider for the classroom (image + speech), stdlib only.

Protocol verified against official docs (2026-11-12):
  POST https://api.kie.ai/api/v1/jobs/createTask  -> data.taskId
  GET  https://api.kie.ai/api/v1/jobs/recordInfo?taskId=...
       -> data.state in waiting/queuing/generating/success/fail,
          data.resultJson = '{"resultUrls": [...]}', data.creditsConsumed.

Privacy / cost rules:
  - The API key is read from the 0600 user credential file, never logged,
    never written into job folders, receipts or public payloads.
  - Signed result URLs are downloaded immediately and are NOT persisted.
  - A cumulative credits budget is checked BEFORE every paid task. Exceeding
    it refuses the call; there is no automatic provider fallback.
  - Receipts record provider/model/taskId/credits only, next to the artifact.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

API_ROOT = 'https://api.kie.ai'
CREATE_TASK = API_ROOT + '/api/v1/jobs/createTask'
RECORD_INFO = API_ROOT + '/api/v1/jobs/recordInfo'
KEY_PATH = Path.home() / '.config' / 'legion' / 'credentials' / 'kie-api-key'
IMAGE_MODEL = 'minimax-h3/text-to-image'
# ElevenLabs multilingual-v2 failed twice with Kie "Internal Error" and
# gemini-3-1-flash-tts timed out twice (verified 2026-11-12). gemini-2-5-pro-tts
# succeeded in 11s and returns 24kHz 16-bit mono WAV, no transcode needed.
SPEECH_MODEL = 'google/gemini-2-5-pro-tts'
DEFAULT_VOICE = 'Fenrir'  # Gemini speaker voice_name
# Synchronous chat (no task polling). Verified 2026-11-12: 3.8-6.3s with
# reasoning disabled, 0.01 credits per call, valid JSON Chinese output.
CHAT_MODEL = 'deepseek-v4-1-flash'
CHAT_ENDPOINT = API_ROOT + '/openai/v1/responses'
POLL_SECONDS = 2.5
MAX_DOWNLOAD_BYTES = 24 * 1024 * 1024
RECEIPT_SUFFIX = '.kie-receipt.json'


class KieError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _key_path():
    return Path(os.environ.get('CLASSROOM_KIE_KEY_PATH', str(KEY_PATH)))


def configured():
    """True when the selected private credential exists and is non-empty."""
    try:
        return _key_path().is_file() and _key_path().stat().st_size > 0
    except OSError:
        return False


def _api_key():
    try:
        path=_key_path()
        info=path.lstat()
        if path.is_symlink() or info.st_uid!=os.getuid() or info.st_mode&0o077:
            raise KieError('kie_key_invalid','Kie凭据权限异常；未发起付费调用')
        key = path.read_text(encoding='utf-8').strip()
    except OSError as exc:
        raise KieError('kie_key_unavailable', 'Kie凭据不可读；未发起任何付费调用') from exc
    if not key or len(key) > 200 or any(c in key for c in '\r\n\t '):
        raise KieError('kie_key_invalid', 'Kie凭据格式异常；未发起任何付费调用')
    return key


class KieClient:
    def __init__(self, usage_path, *, budget_credits=None, voice=None, timeout=180):
        self.usage_path = Path(os.environ.get('CLASSROOM_KIE_USAGE_PATH', str(usage_path)))
        self.budget = budget_credits if budget_credits is not None else int(
            os.environ.get('CLASSROOM_KIE_BUDGET_CREDITS', '1000'))
        self.voice = voice or os.environ.get('CLASSROOM_KIE_VOICE', DEFAULT_VOICE)
        self.timeout = float(timeout)
        self._key = None

    # ---- budget -----------------------------------------------------------
    def usage(self):
        try:
            data = json.loads(self.usage_path.read_text(encoding='utf-8'))
            if isinstance(data, dict) and isinstance(data.get('credits'), (int, float)):
                return {'credits': max(0.0, float(data['credits'])),
                        'tasks': int(data.get('tasks', 0))}
        except (OSError, ValueError):
            pass
        return {'credits': 0.0, 'tasks': 0}

    def _record_usage(self, credits, model):
        current = self.usage()
        record = {'credits': round(current['credits'] + max(0.0, float(credits or 0)), 4),
                  'tasks': current['tasks'] + 1, 'lastModel': model,
                  'updatedAt': time.strftime('%Y-%m-%dT%H:%M:%S%z')}
        self.usage_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.usage_path.with_name(self.usage_path.name + '.tmp')
        tmp.write_text(json.dumps(record, ensure_ascii=False), encoding='utf-8')
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.usage_path)
        return record

    def _check_budget(self):
        used = self.usage()['credits']
        if used >= self.budget:
            raise KieError('kie_budget_exceeded',
                           f'Kie累计额度已达上限（{used:g}/{self.budget} credits）；'
                           '已拒绝本次付费调用，未切换其他模型')

    # ---- HTTP -------------------------------------------------------------
    def _request(self, url, *, payload=None, envelope=True):
        if self._key is None:
            self._key = _api_key()
        body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
        request = urllib.request.Request(url, data=body, method='POST' if body else 'GET', headers={
            'Authorization': 'Bearer ' + self._key,
            'Content-Type': 'application/json',
            'Accept': 'application/json'})
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                raw = response.read(1024 * 1024)
        except urllib.error.HTTPError as exc:
            raise KieError('kie_http', f'Kie接口HTTP {exc.code}；未自动重试或切换') from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise KieError('kie_network', 'Kie网络请求失败；未自动重试或切换') from exc
        try:
            data = json.loads(raw.decode('utf-8'))
        except (ValueError, UnicodeDecodeError) as exc:
            raise KieError('kie_protocol', 'Kie返回不是有效JSON') from exc
        if not isinstance(data, dict):
            raise KieError('kie_protocol', 'Kie返回不是JSON对象')
        if not envelope:
            if data.get('error') or (isinstance(data.get('code'), int) and data['code'] != 200):
                raise KieError('kie_api', 'Kie返回错误：' + str(
                    data.get('msg') or data.get('error') or data.get('code'))[:200])
            return data
        if data.get('code') != 200:
            raise KieError('kie_api', 'Kie返回错误：' + str(data.get('msg') or data.get('code'))[:200])
        return data.get('data') or {}

    def _create_task(self, model, input_payload):
        data = self._request(CREATE_TASK, payload={'model': model, 'input': input_payload})
        task_id = data.get('taskId')
        if not isinstance(task_id, str) or not task_id:
            raise KieError('kie_protocol', 'Kie未返回taskId')
        return task_id

    def _await_result(self, task_id, deadline, check):
        while True:
            if check is not None:
                check()
            if time.monotonic() >= deadline:
                raise KieError('kie_timeout', 'Kie任务超过课堂总时限；未自动重试')
            data = self._request(RECORD_INFO + '?' + urllib.parse.urlencode({'taskId': task_id}))
            state = data.get('state')
            if state == 'success':
                try:
                    result = json.loads(data.get('resultJson') or '{}')
                except ValueError as exc:
                    raise KieError('kie_protocol', 'Kie resultJson不是有效JSON') from exc
                urls = result.get('resultUrls')
                if not isinstance(urls, list) or not urls or not all(
                        isinstance(u, str) and u.startswith('https://') for u in urls):
                    raise KieError('kie_protocol', 'Kie成功任务缺少https结果地址')
                return {'urls': urls, 'credits': float(data.get('creditsConsumed') or 0),
                        'model': data.get('model') or '', 'costTime': data.get('costTime')}
            if state == 'fail':
                raise KieError('kie_failed', 'Kie任务失败：' + str(data.get('failMsg') or data.get('failCode'))[:200])
            if state not in ('waiting', 'queuing', 'generating'):
                raise KieError('kie_protocol', 'Kie任务状态未知：' + str(state)[:60])
            time.sleep(POLL_SECONDS)

    def _download(self, url, target):
        request = urllib.request.Request(url, headers={'Accept': '*/*'})
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                chunks, size = [], 0
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_DOWNLOAD_BYTES:
                        raise KieError('kie_download', 'Kie结果文件超过大小上限')
                    chunks.append(chunk)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            if isinstance(exc, KieError):
                raise
            raise KieError('kie_download', 'Kie结果下载失败') from exc
        target = Path(target)
        tmp = target.with_name(target.name + '.partial-' + uuid.uuid4().hex[:8])
        tmp.write_bytes(b''.join(chunks))
        os.chmod(tmp, 0o600)
        os.replace(tmp, target)
        if target.stat().st_size < 100:
            raise KieError('kie_download', 'Kie结果文件为空或无效')

    def _run(self, model, input_payload, target, deadline, check):
        self._check_budget()
        task_id = self._create_task(model, input_payload)
        result = self._await_result(task_id, deadline, check)
        self._download(result['urls'][0], target)
        # Even a later download failure is not retried or rerouted; credits
        # are recorded on success so the cumulative budget cannot drift.
        record = self._record_usage(result['credits'], model)
        receipt = {'provider': 'kie', 'model': model, 'taskId': task_id,
                   'state': 'success', 'creditsConsumed': result['credits'],
                   'creditsTotal': record['credits'], 'budgetCredits': self.budget,
                   'costTime': result['costTime'],
                   'completedAt': time.strftime('%Y-%m-%dT%H:%M:%S%z')}
        target = Path(target)
        receipt_path = target.with_name(target.name + RECEIPT_SUFFIX)
        receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=1), encoding='utf-8')
        os.chmod(receipt_path, 0o600)
        return receipt

    # ---- public operations -------------------------------------------------
    def _stream_chat(self, payload, deadline, check, on_text):
        """One bounded Responses SSE request, same model, account and usage ledger."""
        if self._key is None:
            self._key = _api_key()
        request = urllib.request.Request(CHAT_ENDPOINT, data=json.dumps(payload, ensure_ascii=False).encode(),
            headers={'Authorization': 'Bearer ' + self._key, 'Content-Type': 'application/json',
                     'Accept': 'text/event-stream'})
        text, completion, total = '', None, 0
        try:
            with urllib.request.urlopen(request, timeout=min(30, max(1, deadline-time.monotonic()))) as response:
                if 'text/event-stream' not in (response.headers.get('Content-Type') or ''):
                    raise KieError('kie_protocol', 'Kie未返回流式事件；未重试或切换')
                data_lines = []
                for raw_line in response:
                    if check is not None:
                        check()
                    if time.monotonic() >= deadline:
                        raise KieError('kie_timeout', 'Kie讲解超过课堂总时限；未自动重试')
                    total += len(raw_line)
                    if len(raw_line) > 256*1024 or total > 1024*1024:
                        raise KieError('kie_protocol', 'Kie流式事件超过大小限制')
                    line = raw_line.decode('utf-8').strip()
                    if line.startswith('data:'):
                        data_lines.append(line[5:].strip())
                        continue
                    if line or not data_lines:
                        continue
                    event = json.loads('\n'.join(data_lines)); data_lines = []
                    if not isinstance(event, dict):
                        raise KieError('kie_protocol', 'Kie流式事件不是对象')
                    kind = event.get('type')
                    if event.get('error') or kind in ('error', 'response.failed', 'response.incomplete'):
                        raise KieError('kie_incomplete', 'Kie流式回答失败或截断；未记为完成')
                    if kind == 'response.output_text.delta':
                        delta = event.get('delta')
                        if not isinstance(delta, str) or len(text)+len(delta) > 20000:
                            raise KieError('kie_protocol', 'Kie流式文字无效或超过大小限制')
                        text += delta
                        on_text(text)
                    elif kind == 'response.completed':
                        completion = event.get('response')
                        break
        except urllib.error.HTTPError as exc:
            raise KieError('kie_http', f'Kie接口HTTP {exc.code}；未重试或切换') from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise KieError('kie_network', 'Kie流式网络请求未完成；未重试或切换') from exc
        except (ValueError, UnicodeDecodeError) as exc:
            raise KieError('kie_protocol', 'Kie流式事件不是有效JSON') from exc
        if not isinstance(completion, dict) or completion.get('status') != 'completed':
            raise KieError('kie_incomplete', 'Kie流式回答未完整结束；未记为完成')
        final_text = '\n'.join(part['text'] for item in completion.get('output', [])
            if isinstance(item, dict) and item.get('type') == 'message'
            for part in item.get('content', []) if isinstance(part, dict)
            and part.get('type') == 'output_text' and isinstance(part.get('text'), str))
        if not final_text or text and final_text != text:
            raise KieError('kie_protocol', 'Kie完整回答与已送文字不一致；未记成功')
        return completion

    def chat(self, prompt, *, deadline, check=None, on_text=None, output_schema=None):
        """One synchronous explanation call; never retried or rerouted."""
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= 60000:
            raise KieError('kie_input', '讲解提示词为空或过长')
        self._check_budget()
        if check is not None:
            check()
        if time.monotonic() >= deadline:
            raise KieError('kie_timeout', 'Kie讲解超过课堂总时限；未自动重试')
        output_format = {'type': 'json_object'}
        if output_schema is not None:
            if not isinstance(output_schema, dict):
                raise KieError('kie_input', '讲解输出约束必须是JSON Schema对象')
            output_format = {'type': 'json_schema', 'name': 'classroom_explanation',
                             'strict': True, 'schema': output_schema}
        payload = {
            'model': CHAT_MODEL, 'stream': on_text is not None,
            'reasoning': {'effort': 'none'},
            'text': {'format': output_format},
            'input': [{'role': 'user', 'content': [{'type': 'input_text', 'text': prompt}]}],
        }
        data = (self._stream_chat(payload, deadline, check, on_text) if on_text is not None else
                self._request(CHAT_ENDPOINT, payload=payload, envelope=False))
        if check is not None:
            check()
        if data.get('status') != 'completed':
            raise KieError('kie_incomplete', 'Kie讲解未完成或截断，未记为完成')
        texts = [part.get('text', '') for item in data.get('output', [])
                 if isinstance(item, dict) and item.get('type') == 'message'
                 for part in item.get('content', [])
                 if isinstance(part, dict) and part.get('type') == 'output_text']
        text = '\n'.join(t for t in texts if isinstance(t, str) and t.strip())
        if not text.strip():
            raise KieError('kie_protocol', 'Kie讲解没有文本输出')
        credits = float(data.get('credits_consumed') or 0)
        record = self._record_usage(credits, CHAT_MODEL)
        return {'text': text, 'credits': credits, 'creditsTotal': record['credits'],
                'budgetCredits': self.budget, 'model': CHAT_MODEL,
                'usage': data.get('usage') or {}}

    def image(self, prompt, target, *, deadline, check=None):
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= 4000:
            raise KieError('kie_input', '图像提示词为空或过长')
        # Verified on 2026-11-12: H3 otherwise paints garbled captions and
        # invented mathematical labels into the scene. Never a math figure.
        guard = ('Strictly no text, letters, numbers, captions, labels, mathematical '
                 'symbols or diagrams anywhere in the picture. Real-world objects '
                 'and scenery only, photographed naturally. ')
        return self._run(IMAGE_MODEL, {
            'prompt': guard + prompt, 'aspect_ratio': '3:2', 'resolution': '1K',
            'output_format': 'png', 'expand_prompt': True,
        }, target, deadline, check)

    def speech(self, text, target, *, deadline, check=None):
        if not isinstance(text, str) or not 1 <= len(text) <= 1600:
            raise KieError('kie_input', '配音文本为空或过长')
        return self._run(SPEECH_MODEL, {
            'temperature': 0.8,
            'scene': '安静的高中课堂，老师耐心地给学生讲解',
            'sample_context': '清晰、温和、克制的中文讲解，语速适中，像耐心的老师',
            'speakers': [{'speaker_id': 'Speaker 1', 'voice_name': self.voice,
                          'audio_profile': '温和耐心的老师'}],
            'dialogue_turns': [{'speaker_id': 'Speaker 1', 'text': text}],
        }, target, deadline, check)
