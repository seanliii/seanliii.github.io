'use strict';
/* Local capture only: average-resample mono to 16k, 20ms/int16 little endian.
   The host starts this processor only after an explicit microphone gesture. */
class ClassroomPCMInput extends AudioWorkletProcessor {
    constructor() {
        super();
        this.ratio = sampleRate / 16000;
        this.remaining = this.ratio;
        this.weighted = 0;
        this.frame = new ArrayBuffer(640);
        this.view = new DataView(this.frame);
        this.offset = 0;
        this.energy = 0;
        this.running = true;
        this.port.onmessage = event => {
            if (event.data === 'stop') this.running = false;
        };
    }
    append(sample) {
        const value = Math.max(-1, Math.min(1, sample));
        this.view.setInt16(this.offset * 2, Math.round(value * (value < 0 ? 32768 : 32767)), true);
        this.energy += value * value;
        this.offset++;
        if (this.offset === 320) {
            this.port.postMessage({frame: this.frame, rms: Math.sqrt(this.energy / 320)}, [this.frame]);
            this.frame = new ArrayBuffer(640);
            this.view = new DataView(this.frame);
            this.offset = 0;
            this.energy = 0;
        }
    }
    process(inputs) {
        if (!this.running) return false;
        const channels = inputs[0];
        if (!channels?.length || !channels[0]?.length) return true;
        for (let i = 0; i < channels[0].length; i++) {
            let value = 0;
            for (const channel of channels) value += channel[i] || 0;
            value /= channels.length;
            let available = 1;
            while (available > 1e-9) {
                const weight = Math.min(available, this.remaining);
                this.weighted += value * weight;
                this.remaining -= weight;
                available -= weight;
                if (this.remaining < 1e-9) {
                    this.append(this.weighted / this.ratio);
                    this.weighted = 0;
                    this.remaining = this.ratio;
                }
            }
        }
        return true;
    }
}
registerProcessor('classroom-pcm-input', ClassroomPCMInput);
