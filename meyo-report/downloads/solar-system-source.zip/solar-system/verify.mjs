import { chromium } from 'playwright';
import path from 'node:path';
import fs from 'node:fs';
const root=path.resolve('.'), url='file://'+path.join(root,'index.html'), errors=[], evidence={};
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:1});
page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('pageerror',e=>errors.push(e.message));
await page.goto(url);await page.waitForFunction(()=>window.__SOLAR_READY__===true);await page.waitForTimeout(700);
const baseline=await page.evaluate(()=>({count:__PLANET_COUNT__,planets:__PLANETS__.map(p=>({id:p.id,zh:p.zh,orbit:p.orbitDays,rotation:p.rotationHours})),ready:__SOLAR_READY__}));
if(baseline.count!==8)throw Error(`Expected 8 planets, got ${baseline.count}`);
for(let i=1;i<baseline.planets.length;i++)if(!(baseline.planets[i-1].orbit<baseline.planets[i].orbit))throw Error('Orbital periods not strictly increasing');
if(baseline.planets.find(p=>p.id==='venus').rotation>=0||baseline.planets.find(p=>p.id==='uranus').rotation>=0)throw Error('Retrograde signs lost');
const cards=[];for(const p of baseline.planets){await page.evaluate(id=>__SOLAR_TEST__.selectPlanet(id),p.id);const got=await page.evaluate(()=>({id:__SOLAR_TEST__.selectedId,name:__SOLAR_TEST__.cardName,open:document.querySelector('#card').classList.contains('open'),stats:document.querySelectorAll('#stats div').length}));if(got.id!==p.id||!got.name.includes(p.zh)||!got.open||got.stats!==6)throw Error(`Card failed: ${p.id}`);cards.push(got)}
await page.click('#pause');await page.waitForTimeout(80);const before=await page.evaluate(()=>__SOLAR_TEST__.simDays);await page.waitForTimeout(300);const during=await page.evaluate(()=>__SOLAR_TEST__.simDays);if(Math.abs(during-before)>.02)throw Error('Pause drift');await page.click('#pause');await page.waitForTimeout(180);const resumed=await page.evaluate(()=>__SOLAR_TEST__.simDays);if(!(resumed>during))throw Error('Resume failed');
await page.selectOption('#speed','60');if(await page.evaluate(()=>__SOLAR_TEST__.speed)!==60)throw Error('Unified speed selection failed');
await page.screenshot({path:'render-desktop.png'});await page.mouse.move(720,450);await page.mouse.down();await page.mouse.move(830,510,{steps:8});await page.mouse.up();await page.mouse.wheel(0,-450);await page.waitForTimeout(350);await page.screenshot({path:'render-interaction.png'});
await page.setViewportSize({width:390,height:844});await page.reload();await page.waitForFunction(()=>window.__SOLAR_READY__);await page.evaluate(()=>__SOLAR_TEST__.selectPlanet('saturn'));await page.waitForTimeout(350);await page.screenshot({path:'render-mobile.png'});
evidence.ready=baseline.ready;evidence.planetCount=baseline.count;evidence.cardChecks=cards;evidence.orbitalOrder=baseline.planets.map(p=>p.id);evidence.retrograde=['venus','uranus'];evidence.pauseDrift=+(during-before).toFixed(5);evidence.resumeDelta=+(resumed-during).toFixed(5);evidence.speedAfterChange=60;evidence.consoleErrors=errors;evidence.fileUrl=url;evidence.screenshots=['render-desktop.png','render-interaction.png','render-mobile.png'];
fs.writeFileSync('verification.json',JSON.stringify(evidence,null,2));await browser.close();if(errors.length)throw Error(errors.join('\n'));console.log(JSON.stringify(evidence,null,2));
