# 许可范围

本交付包不是所有文件统一套用一个 MIT 标签。

- Three.js r149（含 Water 算法来源）：MIT，全文 `assets/THREE-LICENSE.txt`。
- Bruno Simon folio-2019 车体/车轮：源仓库 MIT，全文 `assets/BRUNO-LICENSE.txt`。本包只实际复用 SOURCES.md 指明的两个 GLB，保留源文件与转换后的几何。不泛化授权到网站其他美术/声音。
- Draco 构建用解码器：随附声明在 `assets/DRACO-LICENSE.txt`；仅用于已有源模型的离线转换。运行 index.html 不加载解码器。
- `original/` 是用户交付的原工程，原样保留；未获得的上游权利不由本次交付重新授权。
- 本轮 `src/pacenotes.js`、`src/journey.js`、`src/coast.js`、`src/settlements.js` 与其他原创增量是为本项目生成的代码、程序化模型和纹理，无新增第三方媒体素材。未通过一份根许可证擅自改变用户原工程的权利范围。
- 参考官网截图只作评审证据，不是游戏素材，不授予其再发布权。源码包不包含 Bruno 官网参考截图。

详细来源、版本、路径与研究边界见 `SOURCES.md`。运行无需请求任何外部素材。
