'use strict';
// Authored coastal architecture. All geometry/textures are generated locally.
// Local coordinates: front = -Z; keep batched static geometry and shared materials.
function buildTidelineSettlements(api){
 const {THREE,scene,staticMesh,mat,terrainHeight,nearest,HALF,obstacles,canvasTexture,settlementPaths,DEPOT}=api;
 const V=THREE.Vector3,up=new V(0,1,0),animated=[];
 const palette={wall:mat('#d6c9a7'),wood:mat('#70533c'),trim:mat('#eee0bb'),roof:mat('#526f72',.72,.16),iron:mat('#344347',.63,.3),brick:mat('#a86643'),glass:mat('#233e48',.22,.25),rope:mat('#ac9065'),pot:mat('#ab6344'),leaf:mat('#476447'),rubber:mat('#243136')};
 const glow=new THREE.MeshStandardMaterial({color:'#ffe4a5',emissive:'#ffb557',emissiveIntensity:1.1,roughness:.45});
 function place(x,z,angle,fn,baseY=null){
  const y=baseY===null?terrainHeight(x,z)+.10:baseY,c=Math.cos(angle),s=Math.sin(angle);
  const point=(a,b,d)=>new V(x+c*a+s*d,y+b,z-s*a+c*d);
  function shape(g,m,a,b,d,rx=0,ry=0,rz=0){const local=new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(rx,ry,rz));local.setPosition(a,b,d);const world=new THREE.Matrix4().makeRotationY(angle);world.setPosition(x,y,z);g.applyMatrix4(world.multiply(local));staticMesh(g,m);}
  const block=(w,h,d,m,a,b,e,rx=0,ry=0,rz=0)=>shape(new THREE.BoxGeometry(w,h,d),m,a,b,e,rx,ry,rz);
  const cylinder=(r1,r2,h,m,a,b,d,rx=0,rz=0)=>shape(new THREE.CylinderGeometry(r1,r2,h,10),m,a,b,d,rx,0,rz);
  const beam=(a,b,r,m)=>{const A=point(...a),B=point(...b),dir=B.clone().sub(A),g=new THREE.CylinderGeometry(r,r,dir.length(),7);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(up,dir.clone().normalize()));g.translate(...A.lerp(B,.5).toArray());staticMesh(g,m)};
  const collide=(a,d,r)=>{const p=point(a,0,d);if(nearest(p.x,p.z).dist>HALF+r+1)obstacles.push({x:p.x,z:p.z,r})};
  function label(text,a,b,d,w=3){const map=canvasTexture(512,128,c=>{c.fillStyle='#253f43';c.fillRect(0,0,512,128);c.strokeStyle='#c2ab76';c.lineWidth=5;c.strokeRect(9,9,494,110);c.fillStyle='#ecdfb6';c.textAlign='center';c.font='bold 44px sans-serif';const size=Math.min(44,44*464/Math.max(1,c.measureText(text).width));c.font='bold '+size+'px sans-serif';c.fillText(text,256,64+size*.35)});shape(new THREE.PlaneGeometry(w,w/4),new THREE.MeshStandardMaterial({map,roughness:.8}),a,b,d,0,Math.PI);}
  function crate(a,b,d,size=.65){block(size,size,size,palette.wood,a,b+size/2,d);for(let k=0;k<4;k++)block(size+.025,.025,size+.025,palette.trim,a,b+.08+k*size/4,d);block(.06,size,.035,palette.iron,a-size*.33,b+size/2,d-size/2-.02);block(.06,size,.035,palette.iron,a+size*.33,b+size/2,d-size/2-.02)}
  function barrel(a,b,d){cylinder(.33,.33,.83,palette.wood,a,b+.42,d);for(const h of[.12,.68])cylinder(.345,.345,.055,palette.iron,a,b+h,d);cylinder(.30,.30,.025,palette.wood,a,b+.855,d)}
  function lamp(a,b,d){beam([a,b,d+.2],[a,b,d-.17],.035,palette.iron);block(.29,.43,.23,palette.iron,a,b-.19,d-.20);block(.22,.32,.25,glow,a,b-.18,d-.20);block(.32,.04,.29,palette.iron,a,b+.035,d-.20);block(.32,.04,.29,palette.iron,a,b-.41,d-.20)}
  function planter(a,b,d,w=1.35){block(w,.35,.40,palette.wood,a,b+.17,d);for(let k=0;k<7;k++){const u=(k-3)*w/8;shape(new THREE.IcosahedronGeometry(.17,0),palette.leaf,a+u,b+.45,d);shape(new THREE.IcosahedronGeometry(.065,0),k%2?palette.trim:palette.pot,a+u,b+.61,d-.03)}}
  function window(a,b,d,w=1.25){block(w+.2,1.48,.12,palette.trim,a,b,d);block(w,1.27,.13,palette.glass,a,b,d-.07);block(.06,1.3,.05,palette.trim,a,b,d-.16);block(w,.06,.05,palette.trim,a,b,d-.16);for(const side of[-1,1]){block(.30,1.46,.13,palette.roof,a+side*(w/2+.27),b,d);for(let k=0;k<5;k++)block(.26,.035,.035,palette.trim,a+side*(w/2+.27),b-.5+k*.23,d-.08)}planter(a,b-.96,d-.25,w+.35)}
  function cabin(w,kind){
   const h=3.3,depth=4.8,rise=1.3,half=w/2+.5,slope=Math.atan2(rise,half),roofLen=Math.hypot(half,rise);
   // Foundation follows actual terrain at each support, no floating slabs.
   block(w+.2,.28,depth+.3,palette.iron,0,.14,0);
   for(const a of[-w/2+.25,w/2-.25])for(const d of[-2.1,2.1]){const p=point(a,0,d),bottom=terrainHeight(p.x,p.z)-y;block(.42,Math.max(.35,.28-bottom),.42,palette.brick,a,(bottom+.28)/2,d)}
   block(w,h,depth,palette.wall,0,h/2+.28,0);
   // Narrow clapboard reveal lines, corner boards, wall-to-roof gable closure.
   for(let k=0;k<11;k++)block(w+.035,.035,depth+.025,palette.wood,0,.46+k*.28,0);
   for(const a of[-w/2,w/2])for(const d of[-depth/2,depth/2])block(.16,h+.08,.16,palette.trim,a,h/2+.29,d);
   const gable=new THREE.BufferGeometry();gable.setAttribute('position',new THREE.Float32BufferAttribute([w/2,h+.28,-depth/2,-w/2,h+.28,-depth/2,0,h+.28+rise,-depth/2,-w/2,h+.28,depth/2,w/2,h+.28,depth/2,0,h+.28+rise,depth/2],3));gable.computeVertexNormals();shape(gable,palette.wood,0,0,0);
   for(const side of[-1,1]){block(roofLen,.16,depth+1,palette.roof,side*half/2,h+.35+rise/2,0,0,0,-side*slope);for(let k=0;k<13;k++)block(roofLen,.055,.035,palette.iron,side*half/2,h+.45+rise/2,-2.75+k*.46,0,0,-side*slope);block(.15,.20,depth+1.1,palette.trim,side*half,h+.36,0)}
   block(.24,.15,depth+1.15,palette.iron,0,h+.42+rise,0);
   for(const d of[-2.93,2.93])for(const side of[-1,1])block(roofLen+.05,.19,.12,palette.trim,side*half/2,h+.35+rise/2,d,0,0,-side*slope);
   cylinder(.18,.22,1.35,palette.iron,w*.3,h+rise+.15,1.1);cylinder(.30,.30,.10,palette.iron,w*.3,h+rise+.86,1.1);
   // Front veranda with open centre aisle; steps and open railing.
   for(let k=0;k<11;k++)block(w+1,.12,.21,palette.wood,0,.28,-2.55-k*.23);
   for(const a of[-w/2-.2,w/2+.2]){block(.13,2.7,.13,palette.trim,a,1.58,-4.55);block(.15,.14,2.0,palette.trim,a,1.30,-3.55);for(let k=0;k<5;k++)block(.065,1.0,.065,palette.wood,a,.79,-2.7-k*.38)}
   block(w+1,.14,2.6,palette.roof,0,2.98,-3.65,-.13);
   for(const a of[-w/2-.2,w/2+.2])beam([a,2.65,-4.5],[a,2.96,-3.8],.055,palette.wood);
   for(let k=0;k<3;k++)block(1.7,.12, .42,palette.wood,0,.2-k*.1,-4.98-k*.33);
   block(1.15,2.3,.12,palette.trim,0,1.45,-2.46);block(.97,2.13,.14,palette.glass,0,1.44,-2.54);block(.89,.85,.055,palette.wood,0,.86,-2.63);cylinder(.04,.04,.07,palette.trim,.32,1.4,-2.67,Math.PI/2);
   window(-w*.30,1.85,-2.47,w*.18);window(w*.30,1.85,-2.47,w*.18);
   label(kind,0,3.37,-2.53,Math.min(3.0,w*.53));lamp(-.84,2.66,-2.65);lamp(.84,2.66,-2.65);
   barrel(-w/2-.7,.35,-3.7);crate(w/2+.8,0,-2.0,.72);crate(w/2+.8,.72,-2.0,.56);crate(w/2+1.5,0,-1.8,.6);
   // Picnic bench, folded chart and pottery outside the building silhouette.
   block(1.65,.10,.64,palette.wood,-w/2-1.4,.87,-.1);for(const a of[-w/2-1.95,-w/2-.85])block(.10,.83,.48,palette.iron,a,.42,-.1);
   block(1.85,.10,.29,palette.wood,-w/2-1.4,.44,-.82);block(.48,.012,.35,palette.trim,-w/2-1.5,.932,-.1);
   cylinder(.15,.11,.25,palette.pot,-w/2-1,.995,-.1);
   collide(0,0,w*.56);collide(w/2+1,-2,.8);collide(-w/2-1.4,-.15,1.0);
  }
  fn({shape,block,cylinder,beam,label,crate,barrel,lamp,planter,window,cabin,point,collide,y});
 }
 // Gravel approaches make the locations discoverable from the actual circuit.
 // They follow rendered terrain; asphalt, bridges and race physics are unchanged.
 const gravel=canvasTexture(128,256,(c,w,h)=>{const fade=c.createLinearGradient(0,0,w,0);fade.addColorStop(0,'rgba(145,131,103,0)');fade.addColorStop(.14,'rgba(145,131,103,.9)');fade.addColorStop(.86,'rgba(145,131,103,.9)');fade.addColorStop(1,'rgba(145,131,103,0)');c.fillStyle=fade;c.fillRect(0,0,w,h);for(let i=0;i<1200;i++){const x=(i*71.37)%w,y=(i*39.17)%h;c.fillStyle=i%2?'rgba(44,48,38,.12)':'rgba(232,220,183,.14)';if(x>16&&x<w-16)c.fillRect(x,y,1.2,1.2)}});
 gravel.wrapT=THREE.RepeatWrapping;
 const pathMat=new THREE.MeshStandardMaterial({map:gravel,vertexColors:true,transparent:true,depthWrite:false,roughness:1,polygonOffset:true,polygonOffsetFactor:-1,envMapIntensity:.1});
 function groundPatch(p,apron=false){
  const dx=p.tx-p.fx,dz=p.tz-p.fz,len=Math.hypot(dx,dz),nx=-dz/len,nz=dx/len,N=Math.max(8,Math.ceil((apron?4:len)/.25)),C=16,pos=[],uv=[],colors=[],indices=[];
  for(let j=0;j<=N;j++)for(let k=0;k<=C;k++){
   const t=j/N,side=2*k/C-1,width=apron?2.8*Math.sqrt(Math.max(0,1-Math.pow(2*t-1,2))):2.22+.17*Math.sin(t*11+p.x);
   const along=apron?(t-.5)*4:t*len,x=p.fx+dx/len*along+nx*side*width,z=p.fz+dz/len*along+nz*side*width;
   pos.push(x,terrainHeight(x,z)+.035,z);uv.push(k/C,along/4);
   // Non-repeating vertex alpha: dissolve ONLY the actual ends, not each UV repeat.
   const fade=apron?Math.min(1,t*8,(1-t)*8):Math.min(1,t*len/.85,(1-t)*len/.85);
   colors.push(1,1,1,Math.max(0,fade));
  }
  for(let j=0;j<N;j++)for(let k=0;k<C;k++){const a=j*(C+1)+k;indices.push(a,a+1,a+C+1,a+1,a+C+2,a+C+1)}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,4));g.setIndex(indices);g.computeVertexNormals();const m=new THREE.Mesh(g,pathMat);m.receiveShadow=true;m.name=apron?'settlement-landing':'settlement-approach';scene.add(m);
 }
 for(const p of settlementPaths){
  if(!p.depot){groundPatch(p);groundPatch(p,true);continue}
  // The depot ramp shares EXACT endpoints/heights with groundHeight's support surface.
  const r=DEPOT.ramp,dx=r.tx-r.fx,dz=r.tz-r.fz,len=Math.hypot(dx,dz),nx=-dz/len,nz=dx/len,N=Math.ceil(len/.28),pos=[],ids=[];
  for(let j=0;j<=N;j++)for(const side of[-1,1])pos.push(r.fx+dx*j/N+nx*side*1.95,DEPOT.y+(r.endY-DEPOT.y)*j/N,r.fz+dz*j/N+nz*side*1.95);
  for(let j=0;j<N;j++){const a=2*j;ids.push(a,a+1,a+2,a+1,a+3,a+2)}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setIndex(ids);g.computeVertexNormals();const mesh=new THREE.Mesh(g,palette.wood);mesh.name='settlement-approach';mesh.receiveShadow=true;scene.add(mesh);
  for(let j=0;j<=N;j++){const t=j/N,bar=new THREE.BoxGeometry(3.9,.025,.04);bar.rotateY(-Math.atan2(nz,nx));bar.translate(r.fx+dx*t,DEPOT.y+(r.endY-DEPOT.y)*t+.012,r.fz+dz*t);staticMesh(bar,palette.trim)}
 }
 // One roadside repair pier replaces the hidden identical cabin. Open bay, not another car.
 place(DEPOT.x,DEPOT.z,DEPOT.angle,o=>{
  const roof=mat('#a85f43',.82,.08),concrete=mat('#aea78c'),lift=mat('#c06b42',.72,.2);
  // Actual supported deck: its top is exactly DEPOT.y, not a decorative floating slab.
  o.block(9.4,.22,7.2,palette.wood,0,-.11,-.2);
  for(let k=0;k<32;k++)o.block(9.36,.008,.024,palette.iron,0,.004,-3.74+k*.226);
  for(const a of[-4.35,0,4.35])for(const d of[-3.35,2.95]){const p=o.point(a,0,d),bottom=Math.min(terrainHeight(p.x,p.z),-.15)-DEPOT.y,height=-.2-bottom;o.cylinder(.20,.29,height,palette.iron,a,bottom+height/2,d);o.cylinder(.38,.44,.25,concrete,a,bottom+.05,d)}
  for(const a of[-4.3,4.3])o.beam([a,-.35,-3.35],[a,-2.3,2.95],.10,palette.iron);
  // Narrow enclosed service office; two-thirds of the facade stays truly open.
  o.block(2.1,2.75,4.7,palette.wall,-3.25,1.375,.35);
  for(let k=0;k<10;k++)o.block(2.12,.025,4.72,palette.wood,-3.25,.18+k*.27,.35);
  o.window(-3.25,1.70,-2.05,1.05);o.label('SERVICE',-3.25,2.8,-2.09,1.8);
  o.block(6.1,2.7,.16,palette.wood,.75,1.35,2.76);
  // Higher front fascia shows the work area beneath a single sloped rust-red roof.
  for(const a of[-4.3,-2.10,4.3])for(const d of[-2.7,2.8]){const h=3.70-Math.tan(.095)*d-.075/Math.cos(.095);o.block(.16,h,.16,palette.trim,a,h/2,d);o.beam([a,h-.8,d],[a+(a<0?.65:-.65),h-.08,d],.055,palette.iron);o.collide(a,d,.17)}
  o.block(9.25,.15,6.2,roof,0,3.70,0,.095);
  for(let k=0;k<20;k++)o.block(.045,.065,6.21,palette.brick,-4.4+k*.46,3.79,0,.095);
  o.block(9.25,.28,.14,palette.trim,0,3.995,-3.08);
  o.label('COASTAL WORKS',.4,3.99,-3.17,4.5);
  o.lamp(-1.75,3.50,-2.8);o.lamp(3.85,3.50,-2.8);
  // Full-height tyre rack is readable from the road, with empty working space ahead.
  for(const a of[1.0,3.65])o.block(.10,2.3,.10,palette.iron,a,1.15,2.15);
  for(const b of[.48,1.55]){o.block(2.85,.1,.70,palette.iron,2.33,b,2.15);for(let k=0;k<3;k++)o.shape(new THREE.TorusGeometry(.34,.14,8,20),palette.rubber,1.38+k*.93,b+.47,2.06)}
  o.block(1.15,.96,.70,lift,-.65,.48,2.15);for(let k=0;k<5;k++)o.block(.92,.025,.04,palette.trim,-.65,.18+k*.15,1.77);
  o.block(1.5,.09,.85,palette.iron,-.65,1.03,2.08);
  for(const a of[-.6,1.2]){o.block(.12,2.6,.12,lift,a,1.3,.55);o.block(.80,.12,.17,palette.iron,a+.2,.23,.3)}
  o.label('01',2.1,2.75,2.64,.8);
  // Perimeter barriers leave the central 4 m entrance free; physical circles match them.
  for(const a of[-4.55,4.55]){o.beam([a,.75,-3.45],[a,.75,3.25],.055,palette.iron);for(let k=0;k<10;k++){const z=-3.45+k*.744;o.block(.09,.85,.09,palette.iron,a,.42,z);o.collide(a,z,.20)}}
  for(let a=-4.4;a<=4.4;a+=.55)o.collide(a,3.15,.22);
  o.beam([-4.55,.75,3.25],[4.55,.75,3.25],.055,palette.iron);
  o.collide(-3.25,.2,1.35);o.collide(2.35,2.2,1.1);o.collide(-.65,2.1,.65);o.collide(-.6,.55,.15);o.collide(1.2,.55,.15);
 },DEPOT.y);
 place(settlementPaths[1].x,settlementPaths[1].z,settlementPaths[1].angle,o=>{o.cabin(6,'PINE BAY / STORES');o.barrel(-4.8,0,1);o.barrel(-4.2,0,1.5);
  // Fishing-net drying frame, thin actual ropes (not an opaque panel).
  for(const a of[-3.5,3.5])o.block(.10,2.8,.10,palette.wood,a,1.4,4.3);
  for(let k=0;k<15;k++){const a=-3.5+k*.5;o.beam([a,.55,4.3],[a,2.6,4.3],.012,palette.rope)}
  for(let k=0;k<6;k++)o.beam([-3.5,.55+k*.39,4.3],[3.5,.55+k*.39,4.3],.012,palette.rope);
 });
 place(settlementPaths[2].x,settlementPaths[2].z,settlementPaths[2].angle,o=>{o.cabin(5,'CAPE / SIGNAL 03');
  o.block(.13,8,.13,palette.trim,4,4,1);o.beam([4,7.7,1],[5.4,7.7,1],.035,palette.iron);
  // Windsock is cloth rings plus ribs, animated only above the building, away from cars.
  const root=new THREE.Group(),p=o.point(5.35,7.7,1);root.position.copy(p);root.rotation.z=-Math.PI/2;
  for(let k=0;k<5;k++){const g=new THREE.CylinderGeometry(.32-k*.045,.365-k*.045,.31,10,1,true);const m=new THREE.MeshStandardMaterial({color:k%2?'#e9dabc':'#b75d3f',side:THREE.DoubleSide,roughness:.9});const part=new THREE.Mesh(g,m);part.position.y=k*.30;root.add(part)}scene.add(root);animated.push(root);
 });
 return {update(t){animated.forEach((g,i)=>{g.rotation.x=.13*Math.sin(t*1.6+i);g.rotation.z=-Math.PI/2+.10*Math.sin(t*.9+i)})}};
}
