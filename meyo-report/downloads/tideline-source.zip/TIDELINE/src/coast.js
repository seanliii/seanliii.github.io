/* Authored coastal silhouettes / route furniture.
 * Original mesh generation: no stock cones, downloaded textures, or hidden roads.
 * Scenic islands are outside the playable shore. Track and collision mesh stay intact.
 */
function buildTidelineCoast({THREE,scene,staticMesh,mat,sampleAt,routeLength,HALF,canvasTexture,bends}) {
 const TAU=Math.PI*2;
 const ridgeMaterial=new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,flatShading:false,envMapIntensity:.13,side:THREE.DoubleSide});
 const ridgeGeometries=[];
 // Low, long headlands: a sampled height field, not radial fans converging on
 // a cone. Several uneven summits, a tidal shelf and darker cliff strata make
 // the profile legible without turning the sea into a mountain basin.
 function ridge({x,z,rx,rz,height,seed,color,angle=0}) {
  const positions=[],indices=[],colors=[],nx=62,nz=24;
  const grass=new THREE.Color(color),rock=new THREE.Color('#858585'),sand=new THREE.Color('#b8a397');
  function shape(u,v){
   const edge=1+.07*Math.sin(u*8+seed)+.045*Math.cos(u*17-seed);
   const r=Math.sqrt(u*u+v*v/(edge*edge));
   const land=1-Math.pow(Math.min(1,r),3.2);
   const spine=.48+.30*Math.exp(-Math.pow((u+.42)*3.8,2))+.23*Math.exp(-Math.pow((u-.24)*5.1,2))+.12*Math.exp(-Math.pow((u-.73)*8.,2));
   const transverse=Math.max(0,1-v*v);
   const erosion=Math.sin(u*23+v*11+seed)*Math.sin(v*14-u*7)*.19;
   let y=height*land*spine*transverse+erosion*land;
   if(r>.87)y+=(1-Math.min(1,(r-.87)/.13))*.9;
   return -.56+Math.max(0,y);
  }
  for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++){
   const u=i/nx*2-1,v=j/nz*2-1,y=shape(u,v),lx=u*rx,lz=v*rz,c=Math.cos(angle),sn=Math.sin(angle);
   positions.push(x+lx*c+lz*sn,y,z-lx*sn+lz*c);
   const slope=Math.abs(shape(u+.02,v)-shape(u-.02,v))+Math.abs(shape(u,v+.035)-shape(u,v-.035));
   const pigment=grass.clone().lerp(rock,Math.min(.72,slope*.8));
   if(y<1.1)pigment.lerp(sand,Math.max(0,1-y/1.1)*.65);
   const band=.965+Math.sin(y*3.4+u*4)*.028;
   pigment.multiplyScalar(band);colors.push(pigment.r,pigment.g,pigment.b);
  }
  for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){
   const a=j*(nx+1)+i,b=a+nx+1;
   indices.push(a,b,a+1,a+1,b,b+1);
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();
  ridgeGeometries.push(g.toNonIndexed());g.dispose();
 }
 [
  {x:112,z:292,rx:100,rz:38,height:17,seed:2.1,color:'#6c7c78',angle:.18},
  {x:-54,z:348,rx:90,rz:27,height:14,seed:1.1,color:'#838792',angle:-.24},
  {x:-275,z:93,rx:79,rz:36,height:18,seed:3.7,color:'#777e83',angle:.94},
  {x:-194,z:-252,rx:99,rz:34,height:20,seed:4.9,color:'#7b8590',angle:.12},
  {x:42,z:-262,rx:103,rz:30,height:15,seed:1.7,color:'#818c8d',angle:-.28},
  {x:294,z:33,rx:99,rz:32,height:17,seed:5.3,color:'#76837c',angle:1.25},
  {x:195,z:409,rx:96,rz:25,height:22,seed:6.7,color:'#9d989d',angle:.28}
 ].forEach(ridge);
 // One draw for the distant landform layer; no per-island shadow-map work.
 const merged=new THREE.BufferGeometry();
 for(const attr of ['position','normal','color']){
  const count=ridgeGeometries.reduce((sum,g)=>sum+g.attributes[attr].array.length,0),values=new Float32Array(count);let at=0;
  for(const g of ridgeGeometries){values.set(g.attributes[attr].array,at);at+=g.attributes[attr].array.length}
  merged.setAttribute(attr,new THREE.BufferAttribute(values,3));
 }
 for(const g of ridgeGeometries)g.dispose();
 const horizon=new THREE.Mesh(merged,ridgeMaterial);horizon.name='tideline-low-headlands';scene.add(horizon);
 // No collision-bearing objects added inside the driving envelope. Chevrons are
 // mounted beyond the existing rails and face the approach, never mirrored backs.
 const ink=mat('#324b50'),post=mat('#e7d4ac'),warm=mat('#d6784e');
 const chevron=canvasTexture(128,128,c=>{
  c.fillStyle='#e5d9b9';c.fillRect(0,0,128,128);c.fillStyle='#b95736';
  c.beginPath();c.moveTo(27,16);c.lineTo(60,16);c.lineTo(105,64);c.lineTo(60,112);c.lineTo(27,112);c.lineTo(73,64);c.closePath();c.fill();
 });
 const signMaterial=new THREE.MeshStandardMaterial({map:chevron,roughness:.85});
 for(const bend of bends){
  if(bend.peak<.035)continue;
  const side=bend.sign>0?-1:1;
  // Begin on the outer shoulder before the geometric apex. Shared route bends
  // keep environmental arrows and pace-note directions in agreement.
  for(let j=0;j<3;j++){
   const t=(bend.start+4+j*4.5)/routeLength,s=sampleAt(t),p=s.p.clone().addScaledVector(s.n,side*(HALF+1.1));
   const rotation=Math.atan2(-s.v.x,-s.v.z);
   staticMesh(new THREE.CylinderGeometry(.045,.06,1.35,6),ink,[p.x,p.y+.65,p.z]);
   staticMesh(new THREE.PlaneGeometry(.9,.84),signMaterial,[p.x,p.y+1.45,p.z],[0,rotation,bend.sign<0?Math.PI:0]);
  }
 }
 // Thin reflective road studs give the nightfall drive scale and optic flow.
 for(let i=0;i<160;i++) {
  const s=sampleAt(i/160);
  for(const side of[-1,1]) {
   const p=s.p.clone().addScaledVector(s.n,side*(HALF-.48));
   staticMesh(new THREE.BoxGeometry(.16,.025,.10),i%4===0?warm:post,[p.x,p.y+.036,p.z],[0,-Math.atan2(s.v.z,s.v.x),0]);
  }
 }
 // Swallows animate in coherent coastal flocks, never in the driver's path.
 const wingGeometry=new THREE.BufferGeometry();
 wingGeometry.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,-.72,.18,-.17,-.18,0,.23,0,0,0,.72,.18,-.17,.18,0,.23],3));
 wingGeometry.computeVertexNormals();
 const birdMaterial=new THREE.MeshBasicMaterial({color:'#495466',side:THREE.DoubleSide});
 const birds=new THREE.InstancedMesh(wingGeometry,birdMaterial,14),bird=new THREE.Object3D();
 birds.frustumCulled=false;scene.add(birds);
 return {update(time){
  for(let i=0;i<14;i++){
   const t=time*.06+i*.08;
   bird.position.set(70+Math.cos(t)*35+i%3*2,17+Math.sin(t*.8)*2+i*.12,36+Math.sin(t)*24);
   bird.rotation.y=-t;bird.scale.y=.45+Math.sin(time*5+i)*.36;
   bird.updateMatrix();birds.setMatrixAt(i,bird.matrix);
  }
  birds.instanceMatrix.needsUpdate=true;
 }};
}
