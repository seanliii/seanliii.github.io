'use strict';
// Decode authored sRGB pigments into linear working space before illumination.
// r149 defaults to legacyMode=true; retaining that here washed colored assets to white.
THREE.ColorManagement.legacyMode=false;
// TIDELINE — revision of the original Field Notes island-driving project.
// The original Three.js r149 engine, seeded world and five-island field are retained.
// Vehicle mesh: Bruno Simon folio-2019 (MIT). No runtime fetches or persistent storage.
const $=id=>document.getElementById(id), clamp=THREE.MathUtils.clamp, lerp=THREE.MathUtils.lerp;
const TAU=Math.PI*2, V3=THREE.Vector3;
function mulberry32(a){return function(){let t=(a+=0x6D2B79F5);t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
const rng=mulberry32(1337),rand=(a,b)=>a+rng()*(b-a);
function fbm(x,z){function vn(ix,iz){const a=Math.sin(ix*12.9898+iz*78.233)*43758.5453;return a-Math.floor(a)}let amp=1,freq=1,sum=0,norm=0;for(let o=0;o<4;o++){const fx=x*freq,fz=z*freq,ix=Math.floor(fx),iz=Math.floor(fz),tx=fx-ix,tz=fz-iz,a=vn(ix,iz),b=vn(ix+1,iz),c=vn(ix,iz+1),d=vn(ix+1,iz+1),sx=tx*tx*(3-2*tx),sz=tz*tz*(3-2*tz);sum+=((a*(1-sx)+b*sx)*(1-sz)+(c*(1-sx)+d*sx)*sz)*amp;norm+=amp;amp*=.5;freq*=2}return sum/norm}
const ISLANDS=[{x:0,z:0,r:38,peak:6.5,name:'起点岛'},{x:-78,z:55,r:30,peak:5.5,name:'松风湾'},{x:68,z:-42,r:26,peak:4.5,name:'灯塔岛'},{x:92,z:88,r:25,peak:5,name:'远岬'},{x:-110,z:-70,r:18,peak:3,name:'雾岛'}];
function islandHeight(x,z){let h=-3;for(const isl of ISLANDS){const d=Math.hypot(x-isl.x,z-isl.z),t=Math.max(0,1-d/(isl.r*1.6)),f=t*t*(3-2*t);if(t>0){const noise=fbm((x+isl.x*7.3)*.05,(z+isl.z*11.1)*.05);h=Math.max(h,(isl.peak+1.5)*f-1.5+(noise-.5)*f*1.2)}}return h}
const routePoints=[[12,-22],[28,-11],[30,14],[47,38],[77,61],[108,77],[112,99],[93,113],[68,100],[33,81],[-9,71],[-49,71],[-77,81],[-98,70],[-108,48],[-88,32],[-51,26],[-20,16],[-23,-7],[-8,-27]];
const curve=new THREE.CatmullRomCurve3(routePoints.map(p=>new V3(p[0],0,p[1])),true,'centripetal');curve.arcLengthDivisions=2400;curve.updateArcLengths();
// Coastal depot: one shared definition for structure, supports, approach and planting.
const DEPOT={x:32,z:-24,angle:2.43,y:3.70,halfWidth:4.7,front:-3.8,back:3.4,ramp:null};
function depotSupport(x,z){const dx=x-DEPOT.x,dz=z-DEPOT.z,c=Math.cos(DEPOT.angle),s=Math.sin(DEPOT.angle),lx=c*dx-s*dz,lz=s*dx+c*dz;let h=Math.abs(lx)<=DEPOT.halfWidth&&lz>=DEPOT.front&&lz<=DEPOT.back?DEPOT.y:-Infinity;const r=DEPOT.ramp;if(r){const vx=r.tx-r.fx,vz=r.tz-r.fz,len2=vx*vx+vz*vz,t=((x-r.fx)*vx+(z-r.fz)*vz)/len2;if(t>=0&&t<=1&&Math.hypot(x-r.fx-vx*t,z-r.fz-vz*t)<1.95)h=Math.max(h,lerp(DEPOT.y,r.endY,t))}return h}
const BODY_HALF_LENGTH=1.80,BODY_HALF_WIDTH=.98;
const ROAD_WIDTH=11,HALF=ROAD_WIDTH/2,SEG=960,routeLength=curve.getLength(),samples=[];
for(let i=0;i<SEG;i++){const t=i/SEG,p=curve.getPointAt(t),v=curve.getTangentAt(t).normalize();p.y=3.9+Math.sin(t*TAU*2)*.8+Math.sin(t*TAU*3+.7)*.32;samples.push({p,v,n:new V3(-v.z,0,v.x),bridge:islandHeight(p.x,p.z)<.7,t})}
function sampleAt(t){return samples[((Math.round(t*SEG)%SEG)+SEG)%SEG]}
function nearest(x,z){let best=Infinity,idx=0,f=0;for(let i=0;i<SEG;i++){const a=samples[i].p,b=samples[(i+1)%SEG].p,dx=b.x-a.x,dz=b.z-a.z,t=clamp(((x-a.x)*dx+(z-a.z)*dz)/(dx*dx+dz*dz),0,1),dist=(x-a.x-dx*t)**2+(z-a.z-dz*t)**2;if(dist<best){best=dist;idx=i;f=t}}const a=samples[idx],b=samples[(idx+1)%SEG],cx=lerp(a.p.x,b.p.x,f),cz=lerp(a.p.z,b.p.z,f);return{index:idx,t:(idx+f)/SEG,dist:Math.sqrt(best),side:(x-cx)*a.n.x+(z-cz)*a.n.z,height:lerp(a.p.y,b.p.y,f),sample:a,cx,cz}}
function gradedTerrainHeight(x,z,road){const h=islandHeight(x,z),r=road||nearest(x,z);if(r.dist<HALF+.6)return r.height;if(h>.2&&r.dist<HALF+4){const f=clamp((r.dist-HALF-.6)/3.4,0,1);return lerp(r.height-.12,h,f*f*(3-2*f))}return h}
// Exact O(1) barycentric sampling of the rendered terrain, not a second analytic ground.
function terrainHeight(x,z){
 const gx=(x+220)/2,gz=(z+180)/2,ix=Math.floor(gx),iz=Math.floor(gz);
 if(ix<0||ix>=220||iz<0||iz>=195)return islandHeight(x,z);
 const u=gx-ix,v=gz-iz,p=terrainGeo.attributes.position,a=ix+221*iz,b=a+221,d=a+1,c=b+1;
 return u+v<=1?p.getY(a)*(1-u-v)+p.getY(b)*v+p.getY(d)*u:p.getY(b)*(1-u)+p.getY(d)*(1-v)+p.getY(c)*(u+v-1);
}
function groundHeight(x,z,road){
 const r=road||nearest(x,z),terrain=Math.max(terrainHeight(x,z),depotSupport(x,z));
 if(r.dist<=HALF)return Math.max(r.height,terrain);
 if(r.dist<=HALF+(r.side<0?.12:.26))return Math.max(r.height+.014,terrain); // visible curb ribbon
 const deck=samples[Math.floor(r.index/5)*5].bridge;
 if(deck&&r.dist<=HALF+.6)return Math.max(r.height-.10,terrain);
 return terrain;
}
$('route-length').innerHTML=(routeLength/1000).toFixed(2)+' km<small>海岛环线</small>';
const routeBends=buildTidelineBends(sampleAt,routeLength);
const scene=new THREE.Scene();scene.background=new THREE.Color('#c7a49b');scene.fog=new THREE.Fog('#bda7a6',125,470);
const SUN_OFFSET=new V3(88,18,112),SUN_DIRECTION=SUN_OFFSET.clone().normalize();
const camera=new THREE.PerspectiveCamera(52,innerWidth/innerHeight,.1,900);
let renderer;try{renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance',alpha:false})}catch(e){$('loading').innerHTML='<p>浏览器未能创建 WebGL。请在支持硬件加速的现代浏览器中打开。</p>';throw e}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.98;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;$('app').appendChild(renderer.domElement);renderer.domElement.tabIndex=0;renderer.domElement.setAttribute?.('aria-label','驾驶区域：WASD或方向键，空格手刹，Esc暂停');
const sun=new THREE.DirectionalLight('#ffd1a1',1.9);sun.position.copy(SUN_OFFSET);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-48,right:48,top:48,bottom:-48,near:1,far:260});sun.shadow.bias=-.00035;sun.shadow.normalBias=.045;scene.add(sun,sun.target);
scene.add(new THREE.HemisphereLight('#b3c9da','#8d6961',.70));const fill=new THREE.DirectionalLight('#c2c4d5',.46);fill.position.set(-65,35,-85);scene.add(fill);
const sky=new THREE.Mesh(new THREE.SphereGeometry(650,24,16),new THREE.ShaderMaterial({
 side:THREE.BackSide,depthWrite:false,uniforms:{sunDirection:{value:SUN_DIRECTION}},
 vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:`uniform vec3 sunDirection;varying vec3 vP;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
 void main(){vec3 dir=normalize(vP);float h=dir.y;float facing=dot(dir,sunDirection);
 vec3 horizon=mix(vec3(.47,.34,.38),vec3(1.0,.53,.28),pow(max(facing,0.),3.));
 vec3 color=mix(horizon,vec3(.115,.24,.37),smoothstep(-.04,.64,h));
 float cloud=noise(dir.xz/max(.14,h+.26)*vec2(3.5,14.));
 cloud+=noise(dir.xz/max(.14,h+.26)*vec2(8.,30.))*.36;
 float veil=smoothstep(.70,.98,cloud)*smoothstep(.01,.12,h)*(1.-smoothstep(.18,.43,h));
 color=mix(color,mix(vec3(.54,.42,.44),vec3(1.,.68,.45),pow(max(facing,0.),3.)),veil*.36);
 color+=vec3(.58,.22,.075)*pow(max(facing,0.),36.);
 color=mix(color,vec3(3.8,2.5,1.1),smoothstep(.99935,.99965,facing));
 gl_FragColor=vec4(color,1.);
 #include <tonemapping_fragment>
 #include <encodings_fragment>
 }`
}));scene.add(sky);
// An authored sky reflection probe: actual cubemap, not a fake chrome tint.
// Small canvas faces are compiled by Three to the PBR environment map at first render.
const envFaces=[];const envSize=64;for(let face=0;face<6;face++){
 const canvas=document.createElement('canvas');canvas.width=canvas.height=envSize;const ctx=canvas.getContext('2d');
 for(let y=0;y<envSize;y++)for(let x=0;x<envSize;x++){
  const a=2*(x+.5)/envSize-1,b=2*(y+.5)/envSize-1;
  const dirs=[[1,-b,-a],[-1,-b,a],[a,1,b],[a,-1,-b],[a,-b,1],[-a,-b,-1]];
  const dir=new V3(...dirs[face]).normalize(),height=clamp(dir.y*.7+.35,0,1),warm=Math.pow(Math.max(dir.dot(SUN_DIRECTION),0),18);
  const c=new THREE.Color('#c39b91').lerp(new THREE.Color('#9eb8ce'),height).lerp(new THREE.Color('#ffbe7d'),warm*.85);
  c.convertLinearToSRGB();ctx.fillStyle=`rgb(${Math.round(c.r*255)},${Math.round(c.g*255)},${Math.round(c.b*255)})`;ctx.fillRect(x,y,1,1);
 }envFaces.push(canvas);
}
const skyProbe=new THREE.CubeTexture(envFaces);skyProbe.encoding=THREE.sRGBEncoding;skyProbe.needsUpdate=true;scene.environment=skyProbe;
const ocean=createTidelineOcean(THREE,{scene,sunDirection:SUN_DIRECTION,skyTexture:skyProbe}),water=ocean.mesh;
const foliageTarget=new V3();
function canopyMaterial(color){
 const m=new THREE.MeshStandardMaterial({color,roughness:1,envMapIntensity:.17,flatShading:true});
 m.onBeforeCompile=shader=>{
  shader.uniforms.foliageTarget={value:foliageTarget};
  shader.vertexShader='varying vec3 vFoliageWorld;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <project_vertex>',`#include <project_vertex>
   vec4 foliageWorld=vec4(transformed,1.);
   #ifdef USE_INSTANCING
   foliageWorld=instanceMatrix*foliageWorld;
   #endif
   vFoliageWorld=(modelMatrix*foliageWorld).xyz;
  `);
  shader.fragmentShader='uniform vec3 foliageTarget;varying vec3 vFoliageWorld;\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
   vec3 line=foliageTarget-cameraPosition;float lineLength2=max(dot(line,line),.01);
   float t=dot(vFoliageWorld-cameraPosition,line)/lineLength2;
   float radius=length(vFoliageWorld-(cameraPosition+line*t));
   float cut=(1.-smoothstep(1.25,2.05,radius))*smoothstep(0.,.08,t)*(1.-smoothstep(.94,1.,t));
   float screenDoor=fract(dot(gl_FragCoord.xy,vec2(.754877666,.569840296)));
   if(cut>.999||screenDoor>1.-cut)discard;
  `);
 };
 m.customProgramCacheKey=()=> 'tideline-canopy-cutaway-v1';return m;
}
const materials={},batch=new Map();function mat(color,rough=.85,metal=0){const k=color+','+rough+','+metal;return materials[k]||(materials[k]=new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal,envMapIntensity:.24}))}
function mesh(g,m,pos,parent=scene,shadow=true){const o=new THREE.Mesh(g,m);if(pos)o.position.set(...pos);o.castShadow=shadow;o.receiveShadow=true;parent.add(o);return o}
function box(w,h,d,m,x,y,z,parent=scene){return mesh(new THREE.BoxGeometry(w,h,d),m,[x,y,z],parent)}
function staticMesh(g,m,pos,rot,scale){const dummy=new THREE.Object3D();if(pos)dummy.position.set(...pos);if(rot)dummy.rotation.set(...rot);if(scale)dummy.scale.set(...scale);dummy.updateMatrix();g=g.clone().applyMatrix4(dummy.matrix);if(g.index)g=g.toNonIndexed();const arr=batch.get(m)||[];arr.push(g);batch.set(m,arr)}
function staticBox(w,h,d,m,x,y,z,ry=0){staticMesh(new THREE.BoxGeometry(w,h,d),m,[x,y,z],[0,ry,0])}
function flushBatch(){for(const [m,parts]of batch){const count=parts.reduce((n,g)=>n+g.attributes.position.count,0),geo=new THREE.BufferGeometry();for(const key of ['position','normal','uv']){const size=key==='uv'?2:3,a=new Float32Array(count*size);let off=0;for(const g of parts){if(g.attributes[key])a.set(g.attributes[key].array,off*size);off+=g.attributes.position.count}geo.setAttribute(key,new THREE.BufferAttribute(a,size))}mesh(geo,m,null);parts.forEach(g=>g.dispose())}batch.clear()}
// Original SDF terrain, now graded to the same contact surface as the asphalt.
const terrainGeo=new THREE.PlaneGeometry(440,390,220,195);terrainGeo.rotateX(-Math.PI/2);terrainGeo.translate(0,0,15);const tp=terrainGeo.attributes.position,colors=new Float32Array(tp.count*3),sand=new THREE.Color('#beab86'),grass=new THREE.Color('#78835b'),rock=new THREE.Color('#847568');for(let i=0;i<tp.count;i++){const x=tp.getX(i),z=tp.getZ(i),r=nearest(x,z),raw=islandHeight(x,z),h=lerp(raw,gradedTerrainHeight(x,z,r),THREE.MathUtils.smoothstep(raw,.1,1.1));tp.setY(i,h-.1);const c=h<.45?sand.clone():h>4.7?rock.clone():grass.clone();const noise=fbm(x*.35,z*.35);c.multiplyScalar(.83+noise*.3);if(r.dist>HALF+.7&&r.dist<HALF+2.1)c.lerp(sand,.8);colors.set([c.r,c.g,c.b],i*3)}terrainGeo.setAttribute('color',new THREE.BufferAttribute(colors,3));terrainGeo.computeVertexNormals();mesh(terrainGeo,new THREE.MeshStandardMaterial({vertexColors:true,roughness:1,flatShading:false,envMapIntensity:.22}));
function canvasTexture(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;t.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());return t}
ocean.setDepth(terrainHeight);
const soil=canvasTexture(128,128,(c,w,h)=>{c.fillStyle='#ddddca';c.fillRect(0,0,w,h);for(let y=0;y<h;y+=2)for(let x=0;x<w;x+=2){const n=fbm(x*.08,y*.08);c.fillStyle=`rgba(58,48,40,${.04+n*.15})`;c.fillRect(x,y,2,2)}});soil.wrapS=soil.wrapT=THREE.RepeatWrapping;soil.repeat.set(110,98);const groundMaterial=scene.children.find(o=>o.geometry===terrainGeo).material;groundMaterial.map=soil;groundMaterial.roughness=1;
const asphalt=canvasTexture(256,256,(c,w,h)=>{c.fillStyle='#414b49';c.fillRect(0,0,w,h);for(let i=0;i<12000;i++){const v=Math.floor(rand(80,150));c.fillStyle=`rgba(${v},${v},${v},.13)`;c.fillRect(rand(0,w),rand(0,h),1,1)}});asphalt.wrapS=asphalt.wrapT=THREE.RepeatWrapping;
function ribbon(lo,hi,y,material,start=0,end=SEG){const p=[],uv=[],ix=[];for(let j=start;j<=end;j++){const s=samples[j%SEG];for(const w of[lo,hi]){p.push(s.p.x+s.n.x*w,s.p.y+y,s.p.z+s.n.z*w);uv.push((w-lo)/(hi-lo),j*routeLength/SEG/6)}}for(let j=0;j<end-start;j++){const n=j*2;ix.push(n,n+1,n+2,n+1,n+3,n+2)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(ix);g.computeVertexNormals();if(material.map===asphalt)return mesh(g,material,null,scene,false);const parts=batch.get(material)||[];parts.push(g.toNonIndexed());batch.set(material,parts);g.dispose();return null}
ribbon(-HALF,HALF,0,new THREE.MeshStandardMaterial({map:asphalt,roughness:.98,side:THREE.DoubleSide}));const edge=mat('#d9d4b9'),coral=mat('#af5337'),dark=mat('#293d40'),stone=mat('#847567');for(const s of[-1,1]){ribbon(s*(HALF-.28)-.06,s*(HALF-.28)+.06,.012,edge);for(let i=0;i<SEG;i+=8){const m=Math.floor(i/8)%2?edge:coral;ribbon(s*HALF-.12,s*HALF+.26,.014,m,i,Math.min(i+8,SEG))}}
// Broken centre line. Geometry follows the road instead of hovering or cutting through it.
for(let i=8;i<SEG;i+=18)ribbon(-.055,.055,.016,edge,i,i+7);
// Low bridge edges; poles and railings live OUTSIDE the 11 m driving surface.
const rails=[],obstacles=[];
for(let i=0;i<SEG;i+=5){const a=samples[i],b=samples[(i+5)%SEG];if(!a.bridge)continue;for(const side of[-1,1]){const x=a.p.x+a.n.x*(HALF+.55)*side,z=a.p.z+a.n.z*(HALF+.55)*side;staticBox(.14,1.1,.14,edge,x,a.p.y+.45,z);const mid=a.p.clone().lerp(b.p,.5).addScaledVector(a.n,(HALF+.55)*side),ang=-Math.atan2(b.p.z-a.p.z,b.p.x-a.p.x);staticBox(a.p.distanceTo(b.p)+.1,.14,.16,stone,mid.x,mid.y+.82,mid.z,ang);rails.push(i)}const deckMid=a.p.clone().lerp(b.p,.5),deckAng=-Math.atan2(b.p.z-a.p.z,b.p.x-a.p.x);staticBox(a.p.distanceTo(b.p)+.1,.3,ROAD_WIDTH+1.2,dark,deckMid.x,deckMid.y-.25,deckMid.z,deckAng);if(i%20===0)staticMesh(new THREE.CylinderGeometry(.65,.85,a.p.y+.7,7),stone,[a.p.x,(a.p.y-.7)/2,a.p.z])}
// Reserve complete building footprints and their walk/drive approaches before planting.
const settlementSites=[{...DEPOT,fx:DEPOT.x-Math.sin(DEPOT.angle)*3.0,fz:DEPOT.z-Math.cos(DEPOT.angle)*3.0,r:6.5,depot:true},{x:-77,z:56,angle:Math.PI,fx:-77,fz:62,r:7},{x:90,z:89,angle:-Math.PI/2,fx:96,fz:89,r:6.7}];
const settlementPaths=settlementSites.map(s=>{const n=nearest(s.fx,s.fz),dx=s.fx-n.cx,dz=s.fz-n.cz,d=Math.hypot(dx,dz);return{...s,tx:n.cx+dx/d*(HALF+.28),tz:n.cz+dz/d*(HALF+.28)}});
function settlementClear(x,z,margin=0){return settlementPaths.some(s=>{if(Math.hypot(x-s.x,z-s.z)<s.r+margin)return true;const dx=s.tx-s.fx,dz=s.tz-s.fz,t=clamp(((x-s.fx)*dx+(z-s.fz)*dz)/(dx*dx+dz*dz),0,1);return Math.hypot(x-s.fx-dx*t,z-s.fz-dz*t)<2.5+margin})}
DEPOT.ramp={...settlementPaths[0],endY:terrainHeight(settlementPaths[0].tx,settlementPaths[0].tz)};
function treeSightClear(x,z,radius){
 if(settlementClear(x,z,radius))return true;
 return settlementSites.some(s=>{const t=nearest(s.x,s.z).t;return [-.050,-.022,0,.016].some(offset=>{const q=curve.getPointAt((t+offset+1)%1),v=curve.getTangentAt((t+offset+1)%1);q.addScaledVector(v,-10);const dx=s.fx-q.x,dz=s.fz-q.z,u=clamp(((x-q.x)*dx+(z-q.z)*dz)/(dx*dx+dz*dz),0,1);return Math.hypot(x-q.x-u*dx,z-q.z-u*dz)<radius+1.2})});
}
// Freeze original tree candidates: only remove obstructing canopies, never shuffle the forest.
// Replay the original candidate RNG consumption so unrelated rocks/grass do not reshuffle.
let treeSeedIndex=0;for(let i=0;i<3600&&treeSeedIndex<270;i++){const x=rand(-146,135),z=rand(-100,130),p=TIDELINE_TREE_FIELD[treeSeedIndex];if(p&&x===p[0]&&z===p[2]){rand(.8,1.65);treeSeedIndex++}}
const trunks=[],crowns=[],rockList=[],grassList=[];for(const p of TIDELINE_TREE_FIELD){const [x,h,z,scale]=p;if(treeSightClear(x,z,3.03*scale))continue;trunks.push(p);crowns.push(p);obstacles.push({x,z,r:.40*scale});}
function instances(g,m,items,transform,shadow=true){const ins=new THREE.InstancedMesh(g,m,items.length),dummy=new THREE.Object3D();for(let i=0;i<items.length;i++){dummy.position.set(0,0,0);dummy.rotation.set(0,0,0);dummy.scale.set(1,1,1);transform(dummy,items[i],i);dummy.updateMatrix();ins.setMatrixAt(i,dummy.matrix)}ins.castShadow=shadow;ins.receiveShadow=true;scene.add(ins);return ins}
const canopyRandom=mulberry32(99013),branches=[],canopyLobes=[],allCanopyLobes=[];
for(const p of TIDELINE_TREE_FIELD){
 const keep=trunks.includes(p);
 for(let j=0;j<3;j++){
  const a=j*TAU/3+Math.sin(p[0]),start=new V3(p[0],p[1]+2.1*p[3],p[2]),end=new V3(p[0]+Math.cos(a)*1.3*p[3],p[1]+3.6*p[3],p[2]+Math.sin(a)*1.3*p[3]);
  if(keep)branches.push({start,end,scale:p[3]});
 }
 for(let j=0;j<15;j++){
  const a=j*2.399+canopyRandom(),radius=Math.sqrt(canopyRandom())*2.05*p[3],height=(4.08-.15*radius/p[3]+canopyRandom()*.30)*p[3];
  const lobe=[p[0]+Math.cos(a)*radius,p[1]+height,p[2]+Math.sin(a)*radius,p[3]*(.53+canopyRandom()*.40),a];allCanopyLobes.push(lobe);if(keep)canopyLobes.push(lobe);
 }
}
instances(new THREE.CylinderGeometry(.11,.23,3.7,7),mat('#5a4434'),trunks,(o,p)=>{o.position.set(p[0],p[1]+1.72*p[3],p[2]);o.scale.set(p[3],p[3],p[3]);o.rotation.z=.035*Math.sin(p[0])});
instances(new THREE.CylinderGeometry(.055,.13,1,6),mat('#604b35'),branches,(o,p)=>{o.position.copy(p.start).lerp(p.end,.5);const dir=p.end.clone().sub(p.start);o.quaternion.setFromUnitVectors(new V3(0,1,0),dir.clone().normalize());o.scale.set(p.scale,dir.length(),p.scale)});
const foliage=instances(new THREE.IcosahedronGeometry(1,0),canopyMaterial('#647b50'),canopyLobes,(o,p)=>{o.position.set(p[0],p[1],p[2]);o.scale.set(p[3]*1.05,p[3]*.57,p[3]*.87);o.rotation.y=p[4]},true);
let canopyIndex=0;for(const lobe of allCanopyLobes){const c=new THREE.Color().setHSL(.20+canopyRandom()*.05,.13+canopyRandom()*.11,.50+canopyRandom()*.20);if(canopyLobes.includes(lobe))foliage.setColorAt(canopyIndex++,c)}if(foliage.instanceColor)foliage.instanceColor.needsUpdate=true;
for(let i=0;i<2600;i++){const x=rand(-145,135),z=rand(-100,133),h=islandHeight(x,z),r=nearest(x,z);if(h>0&&r.dist>HALF+2&&r.dist<23&&!settlementClear(x,z)){if(i%6===0){rockList.push([x,h,z,rand(.4,1.5)]);if(h>.5)obstacles.push({x,z,r:.6})}else grassList.push([x,groundHeight(x,z,r),z,rand(.5,1)])}}
instances(new THREE.DodecahedronGeometry(1,0),mat('#847367'),rockList,(o,p)=>{o.position.set(p[0],p[1],p[2]);o.scale.set(p[3],p[3]*.7,p[3]*.85);o.rotation.set(p[0],p[2],0)});
const grassGeo=new THREE.BufferGeometry(),gp=[];for(let i=0;i<4;i++){const a=i*Math.PI/4,x=Math.cos(a)*.18,z=Math.sin(a)*.18;gp.push(-x,0,-z,x,0,z,.15,.8+i*.09,.1)}grassGeo.setAttribute('position',new THREE.Float32BufferAttribute(gp,3));grassGeo.computeVertexNormals();instances(grassGeo,new THREE.MeshStandardMaterial({color:'#a39b67',roughness:1,side:THREE.DoubleSide}),grassList,(o,p)=>{o.position.set(p[0],p[1],p[2]);o.scale.setScalar(p[3]);o.rotation.y=p[0]},false);
// Coastal detail layer. Separate deterministic stream preserves the existing track and collisions.
const detailRandom=mulberry32(42019),dr=(a,b)=>a+detailRandom()*(b-a);
const tussocks=[],flowerTufts=[],shoreRocks=[];
for(let attempt=0;attempt<19000;attempt++){
 const x=dr(-143,135),z=dr(-99,133),r=nearest(x,z);if(r.dist<HALF+1.4||r.dist>28||settlementClear(x,z))continue;
 const y=terrainHeight(x,z),raw=islandHeight(x,z),cluster=fbm(x*.09+31,z*.09-4);
 if(y<.05||y>6.8||raw<-.1||cluster<.43||detailRandom()>cluster)continue;
 tussocks.push([x,y,z,dr(.52,1.3),dr(0,TAU)]);
 if(detailRandom()<.15)flowerTufts.push([x,y,z,dr(.4,.72),dr(0,TAU)]);
}
const bladeVertices=[];for(let i=0;i<7;i++){const a=i*2.399,w=.035+detailRandom()*.035,h=.28+detailRandom()*.37,r=.06+detailRandom()*.14,cx=Math.cos(a)*r,cz=Math.sin(a)*r;bladeVertices.push(cx-w,0,cz,cx+w,0,cz,cx+Math.cos(a)*.18,h,cz+Math.sin(a)*.18)}
const blades=new THREE.BufferGeometry();blades.setAttribute('position',new THREE.Float32BufferAttribute(bladeVertices,3));blades.computeVertexNormals();
const grassDetails=instances(blades,new THREE.MeshStandardMaterial({color:'#b2a366',roughness:1,envMapIntensity:.14,side:THREE.DoubleSide}),tussocks,(o,p)=>{o.position.set(p[0],p[1],p[2]);o.scale.setScalar(p[3]);o.rotation.y=p[4]},false);
for(let i=0;i<tussocks.length;i++)grassDetails.setColorAt(i,new THREE.Color().setHSL(.125+detailRandom()*.075,.20+detailRandom()*.10,.39+detailRandom()*.17));if(grassDetails.instanceColor)grassDetails.instanceColor.needsUpdate=true;
instances(new THREE.IcosahedronGeometry(.065,0),new THREE.MeshStandardMaterial({color:'#c98368',roughness:1,envMapIntensity:.2}),flowerTufts,(o,p)=>{o.position.set(p[0],p[1]+p[3],p[2]);o.scale.set(1.1,.65,1.1);o.rotation.y=p[4]},false);
// The shoreline follows a height contour, not an arbitrary circular dashed line on the sea.
for(const isl of ISLANDS)for(let i=0;i<95;i++){
 const a=i/95*TAU+dr(-.018,.018);let lo=isl.r*.45,hi=isl.r*1.6;
 for(let k=0;k<14;k++){const m=(lo+hi)/2,h=islandHeight(isl.x+Math.cos(a)*m,isl.z+Math.sin(a)*m);if(h>-.28)lo=m;else hi=m}
 const r=(lo+hi)/2+dr(-.75,.75),x=isl.x+Math.cos(a)*r,z=isl.z+Math.sin(a)*r,y=terrainHeight(x,z);if(nearest(x,z).dist<HALF+1.4||y>1.2||y<-1.5)continue;
 shoreRocks.push([x,y,z,dr(.32,1.25),a]);
}
instances(new THREE.DodecahedronGeometry(1,0),new THREE.MeshStandardMaterial({color:'#8c7763',roughness:1,envMapIntensity:.20,flatShading:true}),shoreRocks,(o,p)=>{o.position.set(p[0],p[1]+p[3]*.16,p[2]);o.scale.set(p[3]*1.2,p[3]*.45,p[3]*.82);o.rotation.set(.12,p[4],.08)});
const cream=mat('#e8dcc1'),red=mat('#bb694c'),timber=mat('#736c58'),glass=mat('#416370',.2,.22);
const settlements=buildTidelineSettlements({THREE,scene,staticMesh,mat,terrainHeight,nearest,HALF,obstacles,canvasTexture,settlementPaths,DEPOT});
function lighthouse(x,z){const y=islandHeight(x,z);staticMesh(new THREE.CylinderGeometry(2.1,2.6,.6,16),stone,[x,y+.2,z]);for(let i=0;i<5;i++)staticMesh(new THREE.CylinderGeometry(1.1-i*.08,1.18-i*.08,2.0,16),i%2?red:cream,[x,y+.6+i*2+1,z]);staticMesh(new THREE.CylinderGeometry(1.4,1.4,.25,16),dark,[x,y+10.75,z]);staticMesh(new THREE.CylinderGeometry(.84,.84,1.25,12),glass,[x,y+11.45,z]);staticMesh(new THREE.ConeGeometry(1.45,.95,16),red,[x,y+12.5,z]);for(let i=0;i<10;i++){const a=i/10*TAU;staticBox(.055,.8,.055,cream,x+Math.cos(a)*1.24,y+11.05,z+Math.sin(a)*1.24)}staticMesh(new THREE.TorusGeometry(1.25,.045,5,32),cream,[x,y+11.4,z],[Math.PI/2,0,0]);obstacles.push({x,z,r:2.7});return new V3(x,y+11.7,z)}
const lighthousePos=lighthouse(66,-44);lighthouse(101,92);
function sign(text,sub,w=5,h=1.5){return canvasTexture(768,256,(c)=>{c.fillStyle='#e8e8ce';c.fillRect(0,0,768,256);c.fillStyle='#20454b';c.font='bold 74px sans-serif';c.textAlign='center';c.fillText(text,384,122);c.font='24px sans-serif';c.fillText(sub,384,187);c.fillStyle='#b66346';c.fillRect(28,23,9,210)})}
function trackSign(t,label,sub,side=1){const s=sampleAt(t),p=s.p.clone().addScaledVector(s.n,side*(HALF+2.6)),g=new THREE.Group();g.position.copy(p);g.rotation.y=-Math.atan2(s.v.z,s.v.x)+Math.PI/2;box(.15,2.8,.15,timber,-2,1.4,0,g);box(.15,2.8,.15,timber,2,1.4,0,g);mesh(new THREE.PlaneGeometry(5,1.7),new THREE.MeshStandardMaterial({map:sign(label,sub),side:THREE.DoubleSide}),[0,2.9,0],g);scene.add(g)}
// Removed the redundant .02 billboard: its reverse face obscured the coastal workshop.
trackSign(.3,'THE CAPE','SLOW IN. FAST OUT.');trackSign(.64,'PINE BAY','FIND YOUR OWN LINE.',-1);
// Start portal and sequential gate markers. The road itself always stays clear.
const CHECKS=12,gates=[],gateMats=[];
for(let j=0;j<CHECKS;j++){const s=sampleAt(j/CHECKS),group=new THREE.Group();group.position.copy(s.p);group.rotation.y=-Math.atan2(s.v.z,s.v.x);const gm=new THREE.MeshStandardMaterial({color:j===0?'#e2ed99':'#ddd9bd',emissive:'#e2ed99',emissiveIntensity:j===1?.22:0,roughness:.8});gateMats.push(gm);for(const side of[-1,1]){box(.30,j===0?5.1:2.1,.30,gm,0,j===0?2.45:1,side*(HALF+.8),group);box(.35,.32,1.0,coral,0,.18,side*(HALF+.6),group)}if(j===0){
 // No overhead beam: it crossed the low chase camera after launch (observed on touch).
 // Checkered pylons and outboard pennants mark the start without covering the car.
 for(const side of[-1,1]){
  box(.34,1.45,.72,coral,0,4.48,side*(HALF+.8),group);
  for(let k=0;k<5;k++)box(.38,.22,.76,k%2?dark:cream,0,.65+k*.30,side*(HALF+.8),group);
  box(.055,1.55,1.48,gm,0,4.50,side*(HALF+1.72),group);
  for(let k=0;k<5;k++)box(.07,.15,1.38,k%2?coral:gm,0,4.04+k*.24,side*(HALF+1.72),group);
 }
}scene.add(group);gates.push(group)}
for(let j=0;j<22;j++){const s=sampleAt(j*.032),p=s.p.clone().addScaledVector(s.n,HALF+1.7);staticBox(.07,3.4,.07,dark,p.x,p.y+1.7,p.z);staticMesh(new THREE.PlaneGeometry(.7,1.6),j%2?red:cream,[p.x,p.y+2.65,p.z],[0,-Math.atan2(s.v.z,s.v.x),0])}
// Start grid, two rows of squares painted onto the surface.
for(let i=0;i<18;i++){const s=sampleAt(0),offset=(i-8.5)*.59;for(let k=0;k<2;k++){const p=s.p.clone().addScaledVector(s.n,offset).addScaledVector(s.v,k*.48);staticMesh(new THREE.PlaneGeometry(.46,.57),(i+k)%2?dark:cream,[p.x,p.y+.025,p.z],[-Math.PI/2,0,-Math.atan2(s.v.z,s.v.x)+Math.PI/2])}}
// Dock, marker buoys and sailboats establish scale without cluttering the racing line.
for(let i=0;i<10;i++)staticBox(2,.14,.8,timber,9,.27,-43-i*.83);for(const x of[8,10])for(const z of[-43,-47,-51])staticMesh(new THREE.CylinderGeometry(.09,.11,2.6,6),timber,[x,-.5,z]);
const boats=[];for(const [x,z,s]of[[29,-49,1],[-50,-35,.8],[133,26,1.3]]){const g=new THREE.Group();g.position.set(x,-.1,z);g.rotation.y=rand(0,TAU);g.scale.setScalar(s);mesh(new THREE.SphereGeometry(1,16,8),cream,[0,.12,0],g).scale.set(2.2,.45,.75);box(.06,5.1,.06,timber,0,2.6,0,g);const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute([.08,.5,0,.08,4.8,0,2,.65,0],3));geo.computeVertexNormals();mesh(geo,new THREE.MeshStandardMaterial({color:'#ece4c7',side:THREE.DoubleSide}),null,g);scene.add(g);boats.push(g)}
const buoys=[];for(let i=0;i<24;i++){const a=i/24*TAU,x=45+Math.cos(a)*18,z=37+Math.sin(a)*16;if(islandHeight(x,z)>-.8||nearest(x,z).dist<8)continue;const b=mesh(new THREE.ConeGeometry(.38,.8,8),red,[x,0,z]);buoys.push(b)}
const coast=buildTidelineCoast({THREE,scene,staticMesh,mat,sampleAt,routeLength,HALF,canvasTexture,bends:routeBends});
flushBatch();
// Decode base64 geometry already produced by the offline converter; keep source node transforms.
function typed(str,Type){const b=atob(str),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return new Type(a.buffer)}
const carMaterials={shadeWhite:mat('#d2c6a7',.46,.07),shadeBlack:mat('#17252b',.64,.04),shadeRed:new THREE.MeshPhysicalMaterial({color:'#bd4d2c',metalness:.10,roughness:.42,clearcoat:.32,clearcoatRoughness:.42,envMapIntensity:.38}),pureYellow:new THREE.MeshStandardMaterial({color:'#ffe0a1',emissive:'#ffd294',emissiveIntensity:.6})};
function modelPart(data,center){const root=new THREE.Group(),geos=data.meshes.map(ps=>ps.map(p=>{const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(typed(p.POSITION,Float32Array),3));g.setAttribute('normal',new THREE.BufferAttribute(typed(p.NORMAL,Float32Array),3));g.setIndex(new THREE.BufferAttribute(typed(p.indices,Uint32Array),1));return g}));for(const n of data.nodes){if(n.mesh===undefined)continue;const key=n.name.split('_')[0].split('.')[0],m=carMaterials[key]||carMaterials.shadeWhite;for(const g of geos[n.mesh]){const o=mesh(g,m,null,root);o.name=n.name;if(n.translation)o.position.fromArray(n.translation);if(center)o.position.sub(center);if(n.rotation)o.quaternion.fromArray(n.rotation);if(n.scale)o.scale.fromArray(n.scale)}}root.rotation.x=-Math.PI/2;return root}
const car=new THREE.Group(),bodyRig=new THREE.Group();car.add(bodyRig);const chassis=modelPart(CAR_ASSET.chassis);chassis.scale.setScalar(1.65);bodyRig.add(chassis);const wheels=[];const wheelCenter=new V3(.64187455,.39952749,.24000521);for(const x of[1.06,-1.12])for(const z of[-.72,.72]){const pivot=new THREE.Group(),roll=new THREE.Group(),wm=modelPart(CAR_ASSET.wheel,wheelCenter);wm.scale.setScalar(1.65);if(z>0)wm.rotation.z=Math.PI;pivot.position.set(x,.405,z);roll.add(wm);pivot.add(roll);car.add(pivot);wheels.push({pivot,roll,front:x>0})}
// Compact race plate attached behind the source chassis, not an intersecting replacement body.
const plate=mesh(new THREE.PlaneGeometry(.66,.23),new THREE.MeshStandardMaterial({map:canvasTexture(256,96,c=>{c.fillStyle='#e8e4d2';c.fillRect(0,0,256,96);c.fillStyle='#28424b';c.font='bold 47px monospace';c.textAlign='center';c.fillText('TL·01',128,63)})}),[-1.67,.53,0],bodyRig);plate.rotation.y=-Math.PI/2;
const brakeMat=new THREE.MeshStandardMaterial({color:'#d94533',emissive:'#fb3a20',emissiveIntensity:.6});for(const z of[-.53,.53])box(.045,.17,.20,brakeMat,-1.62,.8,z,bodyRig);
car.traverse(o=>{if(o.isMesh)o.material.envMapIntensity=.45});
const contactTex=canvasTexture(128,128,(c)=>{const g=c.createRadialGradient(64,64,6,64,64,62);g.addColorStop(0,'rgba(10,27,28,.45)');g.addColorStop(1,'rgba(10,27,28,0)');c.fillStyle=g;c.fillRect(0,0,128,128)});const contact=mesh(new THREE.PlaneGeometry(4.4,2.6),new THREE.MeshBasicMaterial({map:contactTex,transparent:true,depthWrite:false}),null,scene,false);contact.rotation.x=-Math.PI/2;scene.add(car);
// A session-only best-lap ghost; not a scripted opponent and never sent to a service.
let bestRun=null,ghost;function makeGhost(){if(ghost)scene.remove(ghost);ghost=car.clone(true);ghost.traverse(o=>{if(o.isMesh){o.material=new THREE.MeshBasicMaterial({color:'#cdebe2',transparent:true,opacity:.19,depthWrite:false});o.castShadow=false}});scene.add(ghost);ghost.visible=false}
makeGhost();
const particleN=80,particles=Array.from({length:particleN},()=>({life:0,total:1,x:0,y:-50,z:0,vx:0,vz:0,size:0,smoke:false}));
const particleGeometry=new THREE.BufferGeometry(),particlePositions=new Float32Array(particleN*3),particleSizes=new Float32Array(particleN),particleAlpha=new Float32Array(particleN),particleColors=new Float32Array(particleN*3);
particleGeometry.setAttribute('position',new THREE.BufferAttribute(particlePositions,3));particleGeometry.setAttribute('size',new THREE.BufferAttribute(particleSizes,1));particleGeometry.setAttribute('alpha',new THREE.BufferAttribute(particleAlpha,1));particleGeometry.setAttribute('color',new THREE.BufferAttribute(particleColors,3));
const dust=new THREE.Points(particleGeometry,new THREE.ShaderMaterial({transparent:true,depthWrite:false,vertexColors:true,uniforms:{pixelScale:{value:innerHeight*.75}},vertexShader:`
 uniform float pixelScale;attribute float size;attribute float alpha;varying float vAlpha;varying vec3 vColor;
 void main(){vAlpha=alpha;vColor=color;vec4 mv=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*mv;gl_PointSize=clamp(size*pixelScale/max(1.,-mv.z),1.,56.);}
 `,fragmentShader:`varying float vAlpha;varying vec3 vColor;void main(){float r=length(gl_PointCoord-.5)*2.;float a=exp(-r*r*4.)*(1.-smoothstep(.55,1.,r))*vAlpha;if(a<.005)discard;gl_FragColor=vec4(vColor,a);
 #include <tonemapping_fragment>
 #include <encodings_fragment>
 }`}));dust.frustumCulled=false;scene.add(dust);let particleAt=0,emissionTimer=0;
const skidN=350,skid=new THREE.InstancedMesh(new THREE.PlaneGeometry(.20,1),new THREE.MeshBasicMaterial({color:'#263a37',transparent:true,opacity:.32,depthWrite:false}),skidN),skidDummy=new THREE.Object3D();for(let i=0;i<skidN;i++){skidDummy.position.y=-100;skidDummy.updateMatrix();skid.setMatrixAt(i,skidDummy.matrix)}scene.add(skid);let skidAt=0,skidLast=new V3();
const player={pos:new V3(),vel:new V3(),heading:0,speed:0,steer:0,steerAngle:0,acceleration:0,yaw:0,boost:1,slip:0,surface:'asphalt',grounded:true,vy:0,offTime:0};
const keys={},touch={};let state='menu',pausedFrom='race',raceTime=0,penalty=0,countTime=0,nextGate=1,lastGate=0,run=[],recordTime=0,toastTime=0,mode='race',cameraMode=0,highQuality=true,mute=false,simTime=0;let lastPos=new V3(),roadNow=nearest(0,0),hitCooldown=0;
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)').matches,isTouch=matchMedia('(pointer:coarse)').matches;
$('recover').hidden=!isTouch;if(isTouch)document.documentElement?.classList?.add('touch-ui');
function clearInput(){for(const k in keys)delete keys[k];for(const k in touch)delete touch[k];document.querySelectorAll('#touch .pressed').forEach(e=>e.classList.remove('pressed'))}
function toast(text,duration=2.5){$('toast').textContent=text;toastTime=duration;$('toast').style.opacity=1}
function formatTime(t){const ms=Math.round(Math.max(0,t)*1000),min=Math.floor(ms/60000),sec=Math.floor(ms/1000)%60;return String(min).padStart(2,'0')+':'+String(sec).padStart(2,'0')+'.'+String(ms%1000).padStart(3,'0')}
function positionCar(t=.0,back=4){const s=sampleAt(t);player.pos.copy(s.p).addScaledVector(s.v,-back);player.heading=Math.atan2(-s.v.z,s.v.x);player.vel.set(0,0,0);player.speed=0;player.steer=0;player.steerAngle=0;player.acceleration=0;player.yaw=0;player.vy=0;player.offTime=0;player.grounded=true;roadNow=nearest(player.pos.x,player.pos.z);player.pos.y=groundHeight(player.pos.x,player.pos.z,roadNow);lastPos.copy(player.pos);updateCarVisual(1);snapCamera()}
function updateGates(){for(let i=0;i<CHECKS;i++){const active=i===nextGate%CHECKS;gateMats[i].color.set(active?'#deefa2':i===0?'#e1dfc2':'#b8c6b1');gateMats[i].emissiveIntensity=active?.38:0}}
function startRace(){clearInput();mode='race';raceTime=0;penalty=0;nextGate=1;lastGate=0;run=[];recordTime=0;player.boost=1;countTime=3.1;state='countdown';$('intro').hidden=true;$('finish').hidden=true;$('pausepanel').hidden=true;$('racehud').hidden=false;$('countdown').hidden=false;$('touch').hidden=!isTouch;document.body.className='playing';$('mode-label').textContent='THE GOLDEN HOUR / 日落环线';$('best').textContent=bestRun?'本次会话最佳 '+formatTime(bestRun.time):'第一圈 · 先认识这条路';positionCar();updateGates();journey.reset(true);audioStart();chime(330,.09);focusDriving();}
function explore(fromFinish=false){clearInput();mode='explore';state='explore';$('intro').hidden=true;$('finish').hidden=true;$('pausepanel').hidden=true;$('countdown').hidden=true;$('racehud').hidden=false;$('touch').hidden=!isTouch;document.body.className='playing';$('mode-label').textContent='FREE DRIVE / 自由驾驶';if(!fromFinish)positionCar();ghost.visible=false;journey.reset(false);audioStart();focusDriving()}
function resetToRoad(){if(!['race','explore'].includes(state))return;const t=mode==='race'?lastGate/CHECKS:roadNow.t;positionCar(t,-2.3);journey.resetGuidance();player.boost=Math.max(.3,player.boost);if(mode==='race'){penalty+=3;toast('返回最近检查点 · +3.000 秒')}else toast('已返回赛道');clearInput()}
function togglePause(){if(state==='paused'){state=pausedFrom;$('pausepanel').hidden=true;$('touch').hidden=!isTouch;last=performance.now();focusDriving();return}if(!['race','explore','countdown'].includes(state))return;pausedFrom=state;state='paused';clearInput();$('pausepanel').hidden=false;$('touch').hidden=true;}
function returnHome(){state='menu';clearInput();$('intro').hidden=false;$('racehud').hidden=true;$('pausepanel').hidden=true;$('finish').hidden=true;$('touch').hidden=true;$('countdown').hidden=true;document.body.className='menu';positionCar();ghost.visible=false}
function finishRace(){state='finished';clearInput();player.speed=0;player.vel.set(0,0,0);player.slip=0;player.yaw=0;const total=raceTime+penalty;journey.finish(total,penalty);const medal=total<=40?'金牌':total<=55?'银牌':total<=75?'铜牌':'完赛';const newBest=!bestRun||total<bestRun.time;if(newBest)bestRun={time:total,rawTime:raceTime,frames:run.slice()};$('finish').hidden=false;$('touch').hidden=true;$('finish-title').textContent=medal+' · 海风带回来了';$('medal').style.color=medal==='金牌'?'#e2ed99':medal==='银牌'?'#d4e3e1':'#dcb088';$('finish-time').textContent=formatTime(total);$('finish-detail').textContent=(newBest?'本次会话新纪录。':'本次会话最佳 '+formatTime(bestRun.time)+'。')+(penalty?' 含回赛道罚时 '+penalty+' 秒。':' 全程无回赛道罚时。')+' 影子车记录本次会话最快一圈；刷新后清除。';chime(660,.16);ghost.visible=false}
function focusDriving(){if(['race','explore','countdown'].includes(state))renderer.domElement.focus?.({preventScroll:true})}
function controls(){return{throttle:!!(keys.KeyW||keys.ArrowUp||touch.throttle),brake:!!(keys.KeyS||keys.ArrowDown||touch.brake),steer:(keys.KeyA||keys.ArrowLeft||touch.left?1:0)-(keys.KeyD||keys.ArrowRight||touch.right?1:0),handbrake:!!(keys.Space||touch.handbrake),boost:!!(keys.ShiftLeft||keys.ShiftRight||touch.boost)}}
const forward=new V3(),right=new V3(),desiredCam=new V3(),look=new V3(),smoothLook=new V3(),framePos=new V3();
function updatePhysics(dt){const input=controls();lastPos.copy(player.pos);roadNow=nearest(player.pos.x,player.pos.z);const onDeck=Number.isFinite(depotSupport(player.pos.x,player.pos.z)),onRoad=roadNow.dist<HALF+.4||onDeck;player.surface=onDeck?'deck':onRoad?(roadNow.sample.bridge?'bridge':'asphalt'):'grass';let vf=player.vel.x*Math.cos(player.heading)-player.vel.z*Math.sin(player.heading);const ab=Math.abs(vf);const boost=input.boost&&input.throttle&&player.boost>0&&vf>2;player.boost=clamp(player.boost+(boost?-.22:.115)*dt,0,1);player.steer=lerp(player.steer,input.steer,1-Math.exp(-dt*(input.steer?5.8:9)));const angle=player.steer*(.52/(1+ab/20)+(input.handbrake?.07:0));player.steerAngle=angle;let yawTarget=vf/2.18*Math.tan(angle);const limit=(input.handbrake?19:12.8)/(ab+2);yawTarget=clamp(yawTarget,-limit,limit);player.yaw=lerp(player.yaw,yawTarget,1-Math.exp(-dt*(input.handbrake?7:10)));if(player.grounded)player.heading+=player.yaw*dt;
forward.set(Math.cos(player.heading),0,-Math.sin(player.heading));right.set(-forward.z,0,forward.x);vf=player.vel.dot(forward);let lat=player.vel.dot(right);const traction=onRoad?(input.handbrake?1.6:8.8):3.7;lat*=Math.exp(-traction*dt);let accel=input.throttle?(boost?17.5:11.5):0;if(input.brake){if(vf>.6)accel-=24;else if(!input.throttle)accel-=8.5}if(input.handbrake)accel-=Math.sign(vf)*7.2;accel-=vf*(onRoad?.26:.75)+vf*Math.abs(vf)*.007;if(!input.throttle&&!input.brake&&ab<.18)vf=0;vf=clamp(vf+accel*dt,-7.5,boost?42:33);player.vel.copy(forward).multiplyScalar(vf).addScaledVector(right,lat);player.pos.addScaledVector(player.vel,dt);player.slip=Math.abs(lat);player.acceleration=lerp(player.acceleration,clamp((vf-player.speed)/dt,-28,20),1-Math.exp(-dt*9));player.speed=vf;
let r=nearest(player.pos.x,player.pos.z);hitCooldown=Math.max(0,hitCooldown-dt);
// Collision envelope of the *vehicle*, not only its centre, stays inside bridge rails.
const railExtent=Math.abs(forward.dot(r.sample.n))*BODY_HALF_LENGTH+Math.abs(right.dot(r.sample.n))*BODY_HALF_WIDTH+.10;
if(r.sample.bridge&&r.dist>HALF-railExtent&&r.dist<HALF+4){const sign=Math.sign(r.side),n=r.sample.n;player.pos.x=r.cx+n.x*sign*(HALF-railExtent-.015);player.pos.z=r.cz+n.z*sign*(HALF-railExtent-.015);const outward=player.vel.dot(n)*sign;if(outward>0){player.vel.addScaledVector(n,-outward*sign*1.28);player.vel.multiplyScalar(.82);if(hitCooldown===0&&outward>1){toast('擦碰护栏 · 入弯前先松油门',1.5);journey.impact();hitCooldown=.8;chime(90,.05)}}r=nearest(player.pos.x,player.pos.z)}
for(const o of obstacles){
 const ox=o.x-player.pos.x,oz=o.z-player.pos.z;if(Math.hypot(ox,oz)>o.r+2.2)continue;
 const lx=ox*forward.x+oz*forward.z,lz=ox*right.x+oz*right.z;
 const ex=lx-clamp(lx,-BODY_HALF_LENGTH,BODY_HALF_LENGTH),ez=lz-clamp(lz,-BODY_HALF_WIDTH,BODY_HALF_WIDTH),d=Math.hypot(ex,ez);
 if(d>=o.r)continue;let nx,nz,penetration;
 if(d>.0001){nx=-(ex*forward.x+ez*right.x)/d;nz=-(ex*forward.z+ez*right.z)/d;penetration=o.r-d+.01}
 else {const gx=BODY_HALF_LENGTH-Math.abs(lx),gz=BODY_HALF_WIDTH-Math.abs(lz);if(gx<gz){nx=-Math.sign(lx||1)*forward.x;nz=-Math.sign(lx||1)*forward.z;penetration=o.r+gx+.01}else{nx=-Math.sign(lz||1)*right.x;nz=-Math.sign(lz||1)*right.z;penetration=o.r+gz+.01}}
 player.pos.x+=nx*penetration;player.pos.z+=nz*penetration;const impact=player.vel.x*nx+player.vel.z*nz;
 if(impact<0){player.vel.x-=nx*impact*1.15;player.vel.z-=nz*impact*1.15;player.vel.multiplyScalar(.72)}
 if(hitCooldown===0){toast(isTouch?'碰撞 · 点右上「回赛道」可重新出发':'碰撞 · R 可回到赛道',1.5);journey.impact();hitCooldown=1}break;
}
r=nearest(player.pos.x,player.pos.z);const h=groundHeight(player.pos.x,player.pos.z,r);if(h<-.18&&r.dist>HALF+1){player.offTime+=dt;player.vel.multiplyScalar(Math.exp(-dt*3));if(player.offTime>.65){resetToRoad();return}}else player.offTime=0;
if(h<player.pos.y-.45&&player.grounded){player.grounded=false;player.vy=0}if(!player.grounded){player.vy-=18*dt;player.pos.y+=player.vy*dt;if(player.pos.y<=h){player.pos.y=h;player.grounded=true;player.vy=0}}else player.pos.y=lerp(player.pos.y,h,1-Math.exp(-dt*32));
roadNow=r;
if(mode==='race'&&state==='race'){raceTime+=dt;recordTime+=dt;if(recordTime>=.05){run.push({time:raceTime,p:player.pos.toArray(),h:player.heading});recordTime-=.05}const g=sampleAt((nextGate%CHECKS)/CHECKS),old=(lastPos.x-g.p.x)*g.v.x+(lastPos.z-g.p.z)*g.v.z,now=(player.pos.x-g.p.x)*g.v.x+(player.pos.z-g.p.z)*g.v.z,lateral=Math.abs((player.pos.x-g.p.x)*g.n.x+(player.pos.z-g.p.z)*g.n.z);if(old<0&&now>=0&&lateral<HALF+1&&player.speed>0){if(nextGate===CHECKS){finishRace()}else{lastGate=nextGate;nextGate++;updateGates();journey.gate(lastGate,raceTime+penalty)}}}
}
function updateCarVisual(dt){foliageTarget.copy(player.pos).y+=1.;car.position.copy(player.pos);car.rotation.y=player.heading;const f=new V3(Math.cos(player.heading),0,-Math.sin(player.heading)),r=new V3(-f.z,0,f.x);const frontH=groundHeight(player.pos.x+f.x*1.05,player.pos.z+f.z*1.05),backH=groundHeight(player.pos.x-f.x*1.05,player.pos.z-f.z*1.05);const pitch=clamp(Math.atan2(frontH-backH,2.1),-.23,.23),bodyRoll=clamp(-player.yaw*player.speed*.005,-.13,.13);bodyRig.rotation.z=lerp(bodyRig.rotation.z,pitch+player.acceleration*.0018,Math.min(1,dt*10));bodyRig.rotation.x=lerp(bodyRig.rotation.x,bodyRoll,Math.min(1,dt*7));bodyRig.position.y=player.grounded?Math.sin(simTime*(player.surface==='grass'?27:18))*Math.min(player.surface==='grass'?.035:.008,Math.abs(player.speed)*.001):.04;for(const w of wheels){w.roll.rotation.z-=player.speed/.40*dt;if(w.front)w.pivot.rotation.y=player.steerAngle;const wp=w.pivot.position;const h=groundHeight(player.pos.x+f.x*wp.x+r.x*wp.z,player.pos.z+f.z*wp.x+r.z*wp.z);wp.y=.405+clamp(h-player.pos.y,-.18,.18)}brakeMat.emissiveIntensity=controls().brake||controls().handbrake?3.8:.55;contact.position.set(player.pos.x,Math.max(groundHeight(player.pos.x,player.pos.z)+.025,-.39),player.pos.z);contact.rotation.z=player.heading;contact.material.opacity=clamp(1-(player.pos.y-roadNow.height)*.2,.1,1)}
function cameraDesired(){const f=new V3(Math.cos(player.heading),0,-Math.sin(player.heading));if(state==='menu'){const s=sampleAt(0);desiredCam.copy(player.pos).add(new V3(10,6.3,11.5));look.copy(player.pos).add(new V3(-2.8,1.0,-2.8));return}const speed=Math.abs(player.speed),dist=cameraMode===1?16.5:10.5;desiredCam.copy(player.pos).addScaledVector(f,-dist-speed*.045);desiredCam.y+=cameraMode===1?12.7:6.0+speed*.018;const floor=groundHeight(desiredCam.x,desiredCam.z);desiredCam.y=Math.max(desiredCam.y,floor+2.8);look.copy(player.pos).addScaledVector(f,cameraMode===1?5:6.0+speed*.10);if(roadNow.dist<HALF+2)look.addScaledVector(sampleAt(roadNow.t+18/routeLength).v,Math.min(speed*.07,1.8));look.y+=.85}
function snapCamera(){cameraDesired();camera.position.copy(desiredCam);smoothLook.copy(look);camera.lookAt(smoothLook)}
function updateCamera(dt){cameraDesired();const rate=reduceMotion?12:5;camera.position.lerp(desiredCam,1-Math.exp(-dt*rate));smoothLook.lerp(look,1-Math.exp(-dt*7));camera.lookAt(smoothLook);const fov=52+(reduceMotion?0:clamp(Math.abs(player.speed)-14,0,22)*.27);if(Math.abs(camera.fov-fov)>.05){camera.fov=lerp(camera.fov,fov,1-Math.exp(-dt*3));camera.updateProjectionMatrix()}sun.position.copy(player.pos).add(SUN_OFFSET);sun.target.position.copy(player.pos)}
function updateEffects(dt){
 for(const p of particles)if(p.life>0){p.life-=dt;p.x+=p.vx*dt;p.z+=p.vz*dt;p.y+=dt*.25;p.size+=dt*.38}
 const active=['race','explore'].includes(state),moving=Math.abs(player.speed)>5,dirt=player.surface==='grass';
 const sliding=player.slip>1.8||(controls().handbrake&&moving);emissionTimer+=dt;
 if(active&&moving&&(dirt||sliding)&&emissionTimer>.045){
  emissionTimer=0;const f=new V3(Math.cos(player.heading),0,-Math.sin(player.heading)),r=new V3(-f.z,0,f.x);
  for(let k=0;k<2;k++){
   const p=particles[particleAt++%particleN];p.x=player.pos.x-f.x*1.3+r.x*(k-.5)*1.2;p.y=player.pos.y+.18;p.z=player.pos.z-f.z*1.3+r.z*(k-.5)*1.2;p.vx=-player.vel.x*.04+rand(-.2,.2);p.vz=-player.vel.z*.04+rand(-.2,.2);p.total=p.life=rand(.4,.75);p.size=rand(.25,.40);p.smoke=!dirt;
  }
 }
 if(active&&moving&&sliding&&skidLast.distanceTo(player.pos)>.5&&roadNow.dist<HALF&&player.grounded){
  for(const side of[-1,1]){const f=new V3(Math.cos(player.heading),0,-Math.sin(player.heading)),r=new V3(-f.z,0,f.x);skidDummy.position.copy(player.pos).addScaledVector(f,-1.1).addScaledVector(r,side*.7);skidDummy.position.y=roadNow.height+.024;skidDummy.rotation.set(-Math.PI/2,0,Math.PI/2+player.heading);skidDummy.updateMatrix();skid.setMatrixAt(skidAt++%skidN,skidDummy.matrix)}skid.instanceMatrix.needsUpdate=true;skidLast.copy(player.pos);
 }
 for(let i=0;i<particleN;i++){const p=particles[i];particlePositions.set([p.x,p.life>0?p.y:-100,p.z],i*3);particleSizes[i]=p.size;particleAlpha[i]=Math.max(0,p.life/p.total)*(p.smoke?.16:.29);particleColors.set(p.smoke?[.55,.59,.58]:[.40,.32,.20],i*3)}
 for(const key of['position','size','alpha','color'])particleGeometry.attributes[key].needsUpdate=true;
 dust.material.uniforms.pixelScale.value=innerHeight*.75*Math.min(devicePixelRatio,highQuality?1.5:1);
if(bestRun&&state==='race'){const frames=bestRun.frames,t=raceTime;let idx=Math.min(frames.length-1,Math.floor(t/.05));while(idx>0&&frames[idx].time>t)idx--;while(idx<frames.length-2&&frames[idx+1].time<t)idx++;const a=frames[idx],b=frames[Math.min(idx+1,frames.length-1)];if(a&&b&&t<=bestRun.rawTime){const alpha=clamp((t-a.time)/Math.max(.001,b.time-a.time),0,1);ghost.visible=true;ghost.position.fromArray(a.p).lerp(new V3().fromArray(b.p),alpha);ghost.rotation.y=lerp(a.h,b.h,alpha)}else ghost.visible=false}else ghost.visible=false;
coast.update(simTime);settlements.update(simTime);water.material.uniforms.time.value=simTime;boats.forEach((b,i)=>{b.position.y=-.05+Math.sin(simTime*.9+i)*.06;b.rotation.x=Math.sin(simTime*.8+i)*.025});buoys.forEach((b,i)=>b.position.y=Math.sin(simTime+i)*.075);}
const mapCtx=$('map').getContext('2d'),mapProject=(x,z)=>[190+x*1.28,95+z*1.28];
function drawMap(){const c=mapCtx;c.clearRect(0,0,380,300);c.save();for(const isl of ISLANDS){const[x,y]=mapProject(isl.x,isl.z);c.fillStyle='#a6bd9f18';c.beginPath();c.ellipse(x,y,isl.r*1.65,isl.r*1.65,0,0,TAU);c.fill()}c.lineWidth=7;c.lineJoin='round';c.strokeStyle='#0c2e3680';c.beginPath();samples.forEach((s,i)=>{const[x,y]=mapProject(s.p.x,s.p.z);i?c.lineTo(x,y):c.moveTo(x,y)});c.closePath();c.stroke();c.lineWidth=2.3;c.strokeStyle='#c8dbc3bb';c.stroke();if(mode==='race'){const s=sampleAt(nextGate%CHECKS/CHECKS),[x,y]=mapProject(s.p.x,s.p.z);c.fillStyle='#e2ee91';c.beginPath();c.arc(x,y,5,0,TAU);c.fill()}const[x,y]=mapProject(player.pos.x,player.pos.z);c.translate(x,y);c.rotate(-player.heading);c.fillStyle='#eff4d8';c.shadowColor='#0d333c';c.shadowBlur=8;c.beginPath();c.moveTo(7,0);c.lineTo(-4,-4);c.lineTo(-2,0);c.lineTo(-4,4);c.closePath();c.fill();c.restore()}
function updateHUD(dt){if(toastTime>0){toastTime-=dt;if(toastTime<=0)$('toast').style.opacity=0}$('timer').textContent=mode==='race'?formatTime(raceTime+penalty):'海风漫游';$('best').hidden=mode!=='race';$('speed').textContent=Math.round(Math.abs(player.speed)*3.6);$('gear').textContent=player.speed<-1?'R':Math.abs(player.speed)<.3?'N':Math.min(5,1+Math.floor(Math.abs(player.speed)/7));$('boost-bar').style.width=(player.boost*100)+'%';$('boost-label').textContent=Math.round(player.boost*100);$('gate-count').textContent=mode==='race'?'CHECKPOINT '+String(Math.min(nextGate,CHECKS)).padStart(2,'0')+' / 12':player.surface==='grass'?'草地 · 抓地力降低':'沿着海岸，选择你的路线';journey.update(dt);drawMap()}
// Low-level original procedural sound. A load-sensitive motor, road, tyres and
// sea air share one limited mix. Created only by an explicit user's start/click.
let audio=null;
function audioStart(){
 if(mute)return;
 try{
  if(!audio){
   const ctx=new (window.AudioContext||window.webkitAudioContext)(),master=ctx.createGain(),limiter=ctx.createDynamicsCompressor();
   master.gain.value=0;limiter.threshold.value=-18;limiter.knee.value=16;limiter.ratio.value=5;
   master.connect(limiter);limiter.connect(ctx.destination);
   const osc=ctx.createOscillator(),osc2=ctx.createOscillator(),eng=ctx.createGain(),filter=ctx.createBiquadFilter();
   // Rounded exhaust harmonics instead of a raw buzzing sawtooth.
   osc.setPeriodicWave(ctx.createPeriodicWave(new Float32Array([0,0,0,0,0,0,0,0]),new Float32Array([0,.65,.24,.12,.18,.055,.06,.025])));
   osc2.type='sine';filter.type='lowpass';filter.Q.value=.55;filter.frequency.value=360;eng.gain.value=0;
   osc.connect(filter);osc2.connect(filter);filter.connect(eng);eng.connect(master);osc.start();osc2.start();
   const buffer=ctx.createBuffer(1,ctx.sampleRate*3,ctx.sampleRate),data=buffer.getChannelData(0);let soft=0;
   for(let i=0;i<data.length;i++){soft=(soft+(Math.random()*2-1)*.12)/1.035;data[i]=soft*2.8}
   function noiseLayer(type,hz,q){const source=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();source.buffer=buffer;source.loop=true;f.type=type;f.frequency.value=hz;f.Q.value=q;g.gain.value=0;source.connect(f);f.connect(g);g.connect(master);source.start();return{filter:f,gain:g}}
   const tyre=noiseLayer('bandpass',1700,.8),wind=noiseLayer('lowpass',600,.6),road=noiseLayer('bandpass',280,.5);
   audio={ctx,master,osc,osc2,eng,filter,ng:tyre.gain,tyre:tyre.filter,wind:wind.gain,road:road.gain,roadFilter:road.filter};
  }
  audio.ctx.resume().catch(()=>{mute=true;$('sound').textContent='声音 关'});
 }catch(e){mute=true;$('sound').textContent='声音不可用'}
}
function updateAudio(){
 if(!audio)return;
 const t=audio.ctx.currentTime,active=['race','explore'].includes(state)&&!mute&&!document.hidden,audible=['race','explore','countdown','finished'].includes(state)&&!mute&&!document.hidden;
 const speed=Math.abs(player.speed),input=controls(),gear=Math.min(4,Math.floor(speed/7.2)),load=input.throttle?1:.25;
 audio.master.gain.setTargetAtTime(audible?.23:0,t,.10);
 audio.eng.gain.setTargetAtTime(active?.17+load*.035:0,t,.10);
 const hz=33+(speed-gear*7.2)*7.8+gear*4+(input.throttle?6:0);
 audio.osc.frequency.setTargetAtTime(hz,t,.10);audio.osc2.frequency.setTargetAtTime(hz*.5,t,.15);
 audio.filter.frequency.setTargetAtTime(180+load*230+speed*10,t,.12);
 audio.ng.gain.setTargetAtTime(active?clamp(player.slip*.075+(input.handbrake&&speed>3?.10:0),0,.26):0,t,.065);
 audio.tyre.frequency.setTargetAtTime(1100+clamp(player.slip,0,5)*170,t,.1);
 audio.wind.gain.setTargetAtTime(audible?.045+(active?clamp(speed/36,0,1)*.10:0):0,t,.5);
 audio.road.gain.setTargetAtTime(active?clamp(speed/30,0,1)*(player.surface==='grass'?.24:.075):0,t,.09);
 audio.roadFilter.frequency.setTargetAtTime(player.surface==='grass'?700:player.surface==='bridge'?185:280,t,.12);
}
function chime(hz,duration){if(mute||!audio)return;const a=audio,o=a.ctx.createOscillator(),g=a.ctx.createGain(),t=a.ctx.currentTime;o.frequency.value=hz;g.gain.setValueAtTime(.12,t);g.gain.exponentialRampToValueAtTime(.001,t+duration);o.connect(g);g.connect(a.master);o.start();o.stop(t+duration)}
const journey=createTidelineJourney({$,clamp,sampleAt,routeLength,getPlayer:()=>player,getRoad:()=>roadNow,getState:()=>state,getRace:()=>({nextGate,time:raceTime,penalty}),getInput:controls,chime,bends:routeBends,usingTouch:()=>isTouch});
$('start').onclick=startRace;$('explore').onclick=()=>explore();$('recover').onclick=resetToRoad;$('pause').onclick=togglePause;$('resume').onclick=togglePause;$('restart').onclick=startRace;$('retry').onclick=startRace;$('home').onclick=returnHome;$('finish-explore').onclick=()=>explore(true);$('sound').onclick=()=>{mute=!mute;$('sound').textContent=mute?'声音 关':'声音 开';audioStart()};$('quality').onclick=()=>{highQuality=!highQuality;needsRender=true;ocean.setQuality(highQuality);renderer.setPixelRatio(Math.min(devicePixelRatio,highQuality?1.5:1));renderer.shadowMap.enabled=highQuality;dust.visible=highQuality;$('quality').textContent=highQuality?'画质 高':'画质 轻量'};
for(const id of ['sound','quality','recover'])$(id).addEventListener('click',e=>{if(e.detail>0)focusDriving()});
window.addEventListener('keydown',e=>{if(e.altKey||e.ctrlKey||e.metaKey||e.target.closest('input,textarea,select'))return;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)&&!(e.code==='Space'&&e.target.closest('button')))e.preventDefault();if(e.code==='Space'&&e.target.closest('button'))return;if(!e.repeat){if(e.code==='Escape')togglePause();if(e.code==='KeyR')resetToRoad();if(e.code==='KeyC'){cameraMode=1-cameraMode;toast(cameraMode?'高位追踪镜头':'近距追踪镜头',1.2)}if(e.code==='KeyM')$('sound').click();if(e.code==='Enter'&&state==='menu')startRace()}keys[e.code]=true});window.addEventListener('keyup',e=>delete keys[e.code]);window.addEventListener('blur',()=>{clearInput();if(['race','explore','countdown'].includes(state))togglePause()});document.addEventListener('visibilitychange',()=>{if(document.hidden){clearInput();if(['race','explore','countdown'].includes(state))togglePause();updateAudio()}});
for(const b of document.querySelectorAll('[data-control]')){const key=b.dataset.control;b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);touch[key]=true;b.classList.add('pressed')});const release=()=>{delete touch[key];b.classList.remove('pressed')};b.addEventListener('pointerup',release);b.addEventListener('pointercancel',release);b.addEventListener('lostpointercapture',release)}
let needsRender=true;let last=performance.now(),accumulator=0,frames=0,fps=60,hudTimer=0,frameTimes=[];function tick(now){if(document.hidden){last=now;requestAnimationFrame(tick);return}const elapsed=Math.max(0,(now-last)/1000),dt=Math.min(.08,elapsed);last=now;fps=lerp(fps,1/Math.max(elapsed,.001),.04);if(elapsed<.5){frameTimes.push(elapsed*1000);if(frameTimes.length>600)frameTimes.shift()}if(state!=='paused'){simTime+=dt;if(state==='countdown'){const prev=Math.ceil(countTime);countTime-=dt;$('countdown').textContent=countTime>0?Math.ceil(countTime):'GO';if(Math.ceil(countTime)!==prev)chime(countTime>0?400:700,.09);if(countTime<=-.45){state='race';$('countdown').hidden=true;toast(isTouch?'出发吧。按住右下油门，沿灰色路面前进。':'出发吧。按住 W / ↑，沿灰色路面前进。',2)}}if(['race','explore'].includes(state)){accumulator+=dt;while(accumulator>=1/120){updatePhysics(1/120);accumulator-=1/120;if(!['race','explore'].includes(state)){accumulator=0;break}}}else accumulator=0;updateCarVisual(dt);updateEffects(dt);updateCamera(dt);hudTimer+=dt;if(hudTimer>.09){updateHUD(hudTimer);hudTimer=0}}updateAudio();if(state!=='paused'||needsRender){renderer.render(scene,camera);needsRender=false}frames++;if(frames===3){$('loading').style.opacity=0;setTimeout(()=>$('loading').hidden=true,600)}requestAnimationFrame(tick)}
returnHome();requestAnimationFrame(tick);window.addEventListener('resize',()=>{needsRender=true;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
// Readable QA instrumentation, no storage, backend, navigation, or new private-state channel.
window.__game={version:'golden-hour-2',get state(){return state},get player(){return player},get race(){return{time:raceTime,penalty,nextGate,lastGate,best:bestRun?.time,recorded:run.length}},get journey(){return journey.stats},get stats(){return{fps,frames,drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,reflectionFrames:ocean.reflectionFrames,frameTimes:[...frameTimes]}},routeLength,samples,nearest,groundHeight,scene,camera,car,renderer,controls};
