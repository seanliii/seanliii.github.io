/* TIDELINE / one connected drive, not a second mode.
 * Local, session-only timing. No steering assistance, storage or network.
 * Sector splits include recovery penalties; personal sector bests may come from
 * different laps and are explicitly labelled as a theoretical personal target.
 */
function createTidelineJourney({$, clamp, sampleAt, routeLength, getPlayer, getRoad, getState, getRace, getInput, chime, bends, usingTouch}) {
 const chapters=[
  {name:'出港',en:'LEAVE THE HARBOUR',line:'先找到节奏，再追上风。'},
  {name:'远岬',en:'ACROSS THE OPEN WATER',line:'松开一点，弯道会给你空间。'},
  {name:'归航',en:'THE WAY HOME',line:'把最后几个弯，连成一条线。'}
 ];
 const bestSectors=[null,null,null];
 let splits=[],sectorStart=0,chapter=0,chapterTime=0,elapsed=0,departure=0;
 let cleanCorners=0,corner=null,collisionCount=0,offRoad=0,throttleSeconds=0,brakeSeconds=0;
 let firstRun=true,lapNumber=0,lastDelta=null,bannerTime=0,lastInput='',lastSurface='';
 let completed=null,comparison=null;
 const paceNotes=createTidelinePaceNotes(bends,routeLength);
 let note=null,shown=null,pending=null,pendingTime=0,shownTime=0,emergencyTime=0;
 let phaseChanges=0;
 const device=(keyboard,touch)=>usingTouch()?touch:keyboard;
 function resetGuidance(){paceNotes.reset();note=null;shown=null;pending=null;pendingTime=0;shownTime=0;emergencyTime=0;corner=null}
 function present(value,dt,urgent=false){
  shownTime+=dt;
  if(!shown||urgent&&shown.key!==value.key){shown=value;shownTime=0;pending=null;pendingTime=0;phaseChanges++}
  else if(shown.key!==value.key){
   if(pending===value.key)pendingTime+=dt;else {pending=value.key;pendingTime=dt}
   const minimum=shown.phase==='ready'?.55:.90;
   if(pendingTime>=(shown.urgent?.5:.18)&&shownTime>=minimum){shown=value;shownTime=0;pending=null;pendingTime=0;phaseChanges++}
  } else {shown=value;pending=null;pendingTime=0}
  return shown;
 }
 const time=t=>t.toFixed(2)+' s';
 const delta=t=>(t>0?'+':'−')+Math.abs(t).toFixed(2)+' s';
 const text=(id,value)=>{const node=$(id);if(node.textContent!==value)node.textContent=value};
 function showChapter(index) {
  chapter=index;chapterTime=4.5;
  const c=chapters[index];
  text('chapter-number','0'+(index+1));text('chapter-name',c.name);
  text('chapter-sub',c.en);text('chapter-line',c.line);
  $('chapter-card').classList.add('visible');
 }
 function reset(racing=true) {
  splits=[];sectorStart=0;chapter=0;elapsed=0;departure=0;offRoad=0;
  cleanCorners=0;corner=null;collisionCount=0;throttleSeconds=0;brakeSeconds=0;
  lastDelta=null;completed=null;comparison=[...bestSectors];resetGuidance();phaseChanges=0;
  bannerTime=0;lastInput='';lastSurface='';
  $('split-flash').classList.remove('visible');
  $('finish-sectors').replaceChildren();
  text('journey-title',racing?'出港 · 第一段':'沿海岸，自由探索');$('coach').dataset.quiet='false';
  $('sector-progress').style.width='0%';
  $('chapter-card').classList.remove('visible');
  if(racing){lapNumber++;firstRun=lapNumber===1;showChapter(0)}
 }
 function feedback(title,detail,good=true) {
  text('split-title',title);text('split-detail',detail);
  $('split-flash').dataset.good=String(good);
  $('split-flash').classList.add('visible');bannerTime=3.5;
 }
 function closeSector(total) {
  const i=splits.length;if(i>=3)return;
  const duration=Math.max(0,total-sectorStart),previous=bestSectors[i];
  splits.push(duration);sectorStart=total;
  lastDelta=previous===null?null:duration-previous;
  if(previous===null||duration<previous)bestSectors[i]=duration;
  if(i<2) {
   feedback(chapters[i].name+'  /  '+time(duration),previous===null?'记住这一段。下一圈，和自己比。':delta(duration-previous)+'  相比个人最佳分段',previous===null||duration<=previous);
   showChapter(i+1);chime(660+i*110,.13);
  }
 }
 function gate(n,total) {if(n===4||n===8)closeSector(total)}
 function impact() {collisionCount++;if(corner)corner.clean=false}
 function finish(total,penalty) {
  closeSector(total);
  completed={splits:[...splits],cleanCorners,collisionCount,offRoad,throttleSeconds,brakeSeconds};
  $('chapter-card').classList.remove('visible');
  const wrap=$('finish-sectors');wrap.replaceChildren();
  splits.forEach((value,i)=>{
   const row=document.createElement('div'),label=document.createElement('span'),duration=document.createElement('b'),diff=document.createElement('small');
   label.textContent='0'+(i+1)+' / '+chapters[i].name;duration.textContent=time(value);
   const prev=comparison[i];diff.textContent=prev===null?'首次记录':delta(value-prev);
   diff.dataset.good=String(prev===null||value<=prev);row.append(label,duration,diff);wrap.append(row);
  });
  text('finish-drive',cleanCorners+' 次顺畅过弯 · '+collisionCount+' 次碰撞'+(penalty?' · 回赛道 +'+penalty+' s':''));
  let target;
  if(collisionCount>0)target='下一圈：入弯前松油门，争取少一次碰撞。';
  else if(offRoad>2)target='下一圈：把车留在路面，出弯再踩油门。';
  else if(comparison.some(v=>v!==null)) {
   const losses=splits.map((v,i)=>comparison[i]===null?0:v-comparison[i]);
   const i=losses.indexOf(Math.max(...losses));
   target=Math.max(...losses)>.15?'下一圈：在「'+chapters[i].name+'」找回 '+time(Math.max(...losses))+'。':'这一圈很连贯。影子车会留下你的最快线路。';
  } else target='你完成了一圈。下一圈，跟着自己的影子车再快一点。';
  text('finish-next',target);
  const ideal=bestSectors.every(v=>v!==null)?bestSectors.reduce((a,b)=>a+b,0):null;
  text('personal-target',ideal===null?'':'个人分段最佳之和 '+time(ideal)+' · 不等于实际圈速');
  return completed;
 }
 function update(dt) {
  if(chapterTime>0){chapterTime-=dt;if(chapterTime<=0)$('chapter-card').classList.remove('visible')}
  if(bannerTime>0){bannerTime-=dt;if(bannerTime<=0)$('split-flash').classList.remove('visible')}
  const state=getState();if(!['race','explore','countdown'].includes(state))return;
  const p=getPlayer(),road=getRoad(),input=getInput(),race=getRace(),speed=Math.abs(p.speed),racing=state!=='explore';
  const resetHint=device('按 R 回到最近检查点','点右上的「回赛道」');
  text('journey-title',racing?chapters[chapter].name+' / '+(chapter+1)+' — 3':'海风漫游 / 不计时');
  const lower=(race.nextGate-1)/12,upper=race.nextGate/12;
  // The launch pose is before t=0, not at 99% of a finished lap.
  const legalT=road.t>=lower-.01&&road.t<=upper+.025?clamp(road.t,lower,upper):lower;
  $('sector-progress').style.width=(racing?legalT*100:road.t*100)+'%';
  text('live-split',racing?(lastDelta===null?(firstRun?'第一圈认识路线':'这一圈，和自己比'):delta(lastDelta)+'  最近分段'):device('随时 R 回赛道','右上可点「回赛道」'));
  $('live-split').dataset.good=String(lastDelta===null||lastDelta<=0);
  const ready={key:'ready',phase:'ready',icon:'↑',label:'准备出发',sub:'先让车动起来',action:device('按住 W / ↑，让车动起来','按住右下「油门」，让车动起来'),detail:device('A D 转向 · S 刹车。松开方向键，前轮会回正。','左侧 ◀ ▶ 转向 · 右侧刹车。松开方向，前轮会回正。')};
  let target=ready;
  if(state==='countdown') {
   target={...ready,action:device('按住 W / ↑ 准备出发','按住右下「油门」准备出发')};
  } else {
   elapsed+=dt;if(speed>2)departure+=dt;
   if(input.throttle)throttleSeconds+=dt;if(input.brake)brakeSeconds+=dt;
   note=paceNotes.update(road.t,speed,dt);
   if(note.justExited&&corner&&corner.key===note.justExited.key){
    if(corner.clean&&corner.time>1.1&&speed>5){cleanCorners++;if(firstRun&&cleanCorners<=2)feedback('这一弯，很顺。','把收油、转向、出弯连起来。');chime(540,.075)}
    corner=null;
   }
   if(note.stage==='turn'&&note.active&&(!corner||corner.key!==note.active.key))corner={key:note.active.key,clean:true,time:0};
   if(corner){corner.time+=dt;if(road.dist>4.4||p.surface==='grass')corner.clean=false}
   if(p.surface==='grass')offRoad+=dt;
   const bend=note.active,sign=bend?.sign||0,direction=sign>0?'右':'左',arrow=sign>0?'↱':'↰';
   if(bend) {
    const suggested=Math.round(bend.suggested*3.6/5)*5;
    const distance=Math.ceil(note.distance/5)*5;
    const turnAction=device(sign>0?'轻按 D / →':'轻按 A / ←',sign>0?'短按左下 ▶':'短按左下 ◀');
    if(note.stage==='approach') {
     target={key:bend.key+':approach'+(bend.fast?':slow':''),phase:bend.fast?'brake':'approach',icon:arrow,label:'前方'+direction+'弯',sub:distance>0?'约 '+distance+' m · '+suggested+' km/h 左右':'弯道就在前面',
      action:bend.fast?'前方'+direction+'弯 · 先松油门':'前方'+direction+'弯 · 稳住节奏',
      detail:bend.fast?device('直线上轻点 S / ↓，转进去以后再稳住方向。','直线上轻点「刹车」，转进去以后再稳住方向。'):'看向弯道出口，不必一直按着方向。'};
    } else {
     target={key:bend.key+':turn',phase:'turn',icon:arrow,label:direction+(bend.linked?'连弯':'弯'),sub:suggested+' km/h 左右 · 看向出口',
      action:direction+(bend.linked?'连弯':'弯')+' · '+turnAction,
      detail:'稳住方向，别急着加速。车头回正后再给油。'};
    }
   } else {
    target={key:'exit',phase:'exit',icon:'↑',label:'路已打开',sub:'出弯再加速',action:device('方向回正 · W 加速出弯','方向回正 · 按「油门」出弯'),detail:device('短按方向修正。直道还可以按 Shift 加速。','短按左侧方向修正，不必一直按住。')};
   }
   const forward=Math.cos(p.heading)*road.sample.v.x-Math.sin(p.heading)*road.sample.v.z;
   if(p.speed<-.3){target={key:'reverse',phase:'recover',urgent:true,icon:'↶',label:'倒车中',sub:'找回前进方向',action:device('倒车中 · W 重新向前','倒车中 · 按「油门」重新向前'),detail:'卡住不用慌，'+resetHint+'。'}}
   else if(speed>3&&forward<-.45){target={key:'wrong-way',phase:'recover',urgent:true,icon:'↶',label:'反向行驶',sub:'安全调头或回赛道',action:'方向反了 · 先减速再调头',detail:resetHint+'，重新顺着环线出发。'}}
   else if(p.surface==='grass'){target={key:'grass',phase:'recover',urgent:true,icon:'↗',label:'回到路面',sub:'草地抓地力较低',action:'回到灰色路面，抓地更稳',detail:'别一直加速顶着障碍。'+resetHint+'。'}}
   else if(p.slip>3.2||(input.handbrake&&speed>4)){
    emergencyTime+=dt;
    if(emergencyTime>.16)target={key:'slip',phase:'slide',urgent:true,icon:'↝',label:'后轮在滑',sub:'松手刹，收一点方向',action:'后轮在滑 · 松开手刹找回抓地',detail:'收一点方向，让车身跟上。漂移不是过弯必需。'};
   } else emergencyTime=0;
   if(departure<1.2&&speed<5&&!target.urgent)target=ready;
  }
  const value=present(target,dt,!!target.urgent);
  $('coach').dataset.phase=value.phase;$('coach').dataset.bend=note?.active?.key||'';
  $('coach').dataset.quiet=String(!firstRun&&['exit','cruise'].includes(value.phase));
  text('coach-action',value.action);text('coach-detail',value.detail);text('turn-icon',value.icon);
  $('turn-label').firstChild.textContent=value.label;text('turn-distance',value.sub);
  const inputName=input.handbrake?'手刹':input.brake?'刹车':input.throttle?(input.boost?'加速':'油门'):'滑行';
  if(inputName!==lastInput){text('input-label',inputName);lastInput=inputName}
  $('input-meter').style.setProperty('--pedal',input.throttle||input.brake||input.handbrake?'100%':'0%');
  $('input-meter').dataset.brake=String(input.brake||input.handbrake);$('steering-needle').style.transform='translateX('+(-p.steer*20)+'px)';
  const surface=p.surface==='grass'?'草地 · 低抓地':p.surface==='bridge'?'海桥 · 稳住线路':'路面 · 抓地稳定';
  if(surface!==lastSurface){text('surface-label',surface);lastSurface=surface}
 }
 return {reset,resetGuidance,gate,impact,finish,update,get stats(){return {chapter,splits:[...splits],bestSectors:[...bestSectors],cleanCorners,collisionCount,offRoad,completed,coach:{phase:shown?.phase,key:shown?.key,shownTime,phaseChanges,bend:note?.active?.key,distance:note?.distance,position:note?.position}}}};
}
