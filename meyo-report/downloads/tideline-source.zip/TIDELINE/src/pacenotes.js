/* Route-derived pace notes, independent of UI and vehicle controls.
 * A bend has a stable spatial identity. The car never steers or brakes itself.
 * Circular samples are smoothed once, not re-peaked at every HUD update.
 */
function buildTidelineBends(sampleAt,routeLength) {
 const count=Math.ceil(routeLength),step=routeLength/count,curvature=[];
 for(let i=0;i<count;i++){
  const a=sampleAt((i*step-4)/routeLength).v,b=sampleAt((i*step+4)/routeLength).v;
  curvature.push(Math.atan2(a.x*b.z-a.z*b.x,a.dot(b))/8);
 }
 const smooth=curvature.map((_,i)=>[-2,-1,0,1,2].reduce((sum,j)=>sum+curvature[(i+j+count)%count],0)/5);
 const groups=[];
 smooth.forEach((k,i)=>{
  const sign=Math.abs(k)>.010?Math.sign(k):0,last=groups[groups.length-1];
  if(last&&last.sign===sign){last.end=(i+1)*step;last.angle+=k*step;if(Math.abs(k)>last.peak){last.peak=Math.abs(k);last.apex=i*step}}
  else groups.push({start:i*step,end:(i+1)*step,angle:k*step,peak:Math.abs(k),apex:i*step,sign});
 });
 // This route's start is a straight. Preserve a wraparound bend if the route is
 // later edited, instead of splitting it into two contradictory pace notes.
 const first=groups[0],last=groups[groups.length-1];
 if(groups.length>1&&first.sign&&first.sign===last.sign){
  last.end=first.end+routeLength;last.angle+=first.angle;
  if(first.peak>last.peak){last.peak=first.peak;last.apex=first.apex+routeLength}
  groups.shift();
 }
 return groups.filter(g=>g.sign&&Math.abs(g.angle)>.23&&g.end-g.start>6).map((g,id)=>({
  ...g,id,suggested:Math.max(9,Math.min(24,Math.sqrt(10.3/Math.max(.018,g.peak)))),
  linked:g.end-g.start>55
 }));
}

function createTidelinePaceNotes(bends,routeLength) {
 let position=0,lastT=null,active=null,stage='cruise',distance=0,justExited=null;
 function reset(){lastT=null;active=null;stage='cruise';justExited=null}
 function update(t,speed,dt) {
  justExited=null;
  if(lastT===null){position=t*routeLength;if(t>.90)position-=routeLength}
  else {
   let d=(t-lastT)*routeLength;
   if(d>routeLength/2)d-=routeLength;if(d<-routeLength/2)d+=routeLength;
   // R/automatic recovery changes location discontinuously. Never keep a note
   // belonging to the road that has just been left.
   if(Math.abs(d)>Math.max(18,speed*dt*3)){active=null;stage='cruise'}
   position+=d;
  }
  lastT=t;
  if(active&&position>active.end+2){
   justExited=active;active=null;stage='exit';
  }
  if(active&&position<active.start-65){active=null;stage='cruise'}
  if(!active){
   const lap=Math.floor(position/routeLength),candidates=[];
   for(let l=lap-1;l<=lap+1;l++)for(const bend of bends){
    const offset=l*routeLength,start=bend.start+offset,end=bend.end+offset;
    if(end>=position-1&&start-position<Math.max(22,Math.min(48,speed*1.9+8)))
     candidates.push({...bend,start,end,apex:bend.apex+offset,key:l+':'+bend.id,fast:speed>bend.suggested*1.06});
   }
   candidates.sort((a,b)=>a.start-b.start);
   if(candidates.length){active=candidates[0];stage=position>=active.start?'turn':'approach';distance=Math.max(0,active.start-position)}
  }
  if(active){
   // Exactly one direction of ordinary phase progression per bend.
   if(position>=active.start-1)stage='turn';
   else if(stage!=='turn')stage='approach';
   if(stage==='approach'&&speed>active.suggested*1.10)active.fast=true;
   distance=Math.max(0,Math.min(distance,active.start-position));
  }
  return {stage,active,distance,position,justExited};
 }
 return{reset,update};
}
