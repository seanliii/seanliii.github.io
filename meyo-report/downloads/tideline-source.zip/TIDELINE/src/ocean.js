/* TIDELINE sea. Mirror-camera / oblique-clipping algorithm adapted from
 * Three.js r149 examples/jsm/objects/Water.js (MIT, Three.js Authors).
 * Source snapshot and license are in assets/. The wave, depth and color shader is local.
 * Reflection is rendered into an actual offscreen target; no pre-baked fake scene image.
 */
function createTidelineOcean(THREE, options){
 const {scene,sunDirection,skyTexture}=options;
 const size=128,data=new Uint8Array(size*size*4);
 // Periodic multi-scale wave slopes, sampled in four moving nonparallel directions.
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
  const u=x/size*Math.PI*2,v=y/size*Math.PI*2;
  const a=Math.sin(3*u+2*v)+.47*Math.sin(7*u-5*v+.8)+.22*Math.sin(13*u+9*v);
  const b=Math.cos(2*u-3*v+.7)+.44*Math.cos(5*u+7*v)+.19*Math.cos(11*u-13*v);
  const i=(y*size+x)*4;data[i]=128+a*47;data[i+1]=128+b*47;data[i+2]=128+Math.sin(4*u+5*v)*100;data[i+3]=255;
 }
 const normalTex=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);normalTex.wrapS=normalTex.wrapT=THREE.RepeatWrapping;normalTex.magFilter=THREE.LinearFilter;normalTex.minFilter=THREE.LinearMipMapLinearFilter;normalTex.generateMipmaps=true;normalTex.needsUpdate=true;
 const target=new THREE.WebGLRenderTarget(768,512,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,depthBuffer:true});
 // Render targets are linear and are encoded only once in the final ocean material.
 target.texture.encoding=THREE.LinearEncoding;
 const textureMatrix=new THREE.Matrix4(),eye=new THREE.Vector3();
 const uniforms={time:{value:0},normalTex:{value:normalTex},mirrorTex:{value:target.texture},textureMatrix:{value:textureMatrix},eye:{value:eye},sunDirection:{value:sunDirection},skyTexture:{value:skyTexture},mirrorReady:{value:0},depthMap:{value:null}};
 const material=new THREE.ShaderMaterial({uniforms,vertexShader:`
 uniform mat4 textureMatrix;varying vec3 world;varying vec4 mirrorCoord;
 void main(){vec4 p=modelMatrix*vec4(position,1.);world=p.xyz;mirrorCoord=textureMatrix*p;gl_Position=projectionMatrix*viewMatrix*p;}
 `,fragmentShader:`
 uniform sampler2D normalTex,mirrorTex,depthMap;uniform samplerCube skyTexture;
 uniform float time,mirrorReady;uniform vec3 eye,sunDirection;
 varying vec3 world;varying vec4 mirrorCoord;
 vec2 slopes(vec2 p){
  vec2 a=texture2D(normalTex,p*.031+vec2(time*.008,time*.003)).rg*2.-1.;
  vec2 b=texture2D(normalTex,mat2(.8,-.6,.6,.8)*p*.053-vec2(time*.004,time*.006)).gr*2.-1.;
  vec2 c=texture2D(normalTex,p*.12+vec2(-time*.009,time*.005)).rg*2.-1.;
  return a*.50+b*.32+c*.18;
 }
 void main(){
  vec2 p=world.xz;vec3 toEye=eye-world;float dist=length(toEye);vec3 v=normalize(toEye);
  vec2 slope=slopes(p)*mix(.075,.022,smoothstep(30.,240.,dist));vec3 n=normalize(vec3(slope.x,1.,slope.y));
  vec3 reflected=reflect(-v,n);vec3 sky=textureCube(skyTexture,vec3(-reflected.x,reflected.yz)).rgb;
  // skyTexture stores sRGB bytes; linearize before combining with linear reflection target.
  sky=mix(sky/12.92,pow((sky+.055)/1.055,vec3(2.4)),step(vec3(.04045),sky));
  vec2 uv=mirrorCoord.xy/max(.001,mirrorCoord.w)+slope*(.025+1./max(dist,8.));
  float inside=step(0.,uv.x)*step(0.,uv.y)*step(uv.x,1.)*step(uv.y,1.);
  vec3 reflectedScene=texture2D(mirrorTex,clamp(uv,.001,.999)).rgb;
  vec3 reflection=mix(sky,reflectedScene,mirrorReady*inside);
  float land=texture2D(depthMap,(p+vec2(220.,180.))/vec2(440.,390.)).r*11.-3.;
  float depth=max(0.,-.42-land),shallow=exp(-depth*1.45);
  vec3 body=mix(vec3(.014,.074,.105),vec3(.085,.24,.205),shallow);
  float fresnel=.14+.66*pow(1.-max(dot(v,n),0.),4.);
  vec3 color=mix(body,reflection,fresnel);
  float glint=pow(max(dot(reflect(-sunDirection,n),v),0.),340.);
  color+=vec3(1.8,1.08,.40)*glint;
  float foam=(1.-smoothstep(.015,.30,depth))*(.55+.45*sin(time*1.2+p.x*.9+p.y*.65));
  color=mix(color,vec3(.43,.56,.49),foam*.55);
  float haze=smoothstep(110.,470.,dist);color=mix(color,vec3(.48,.35,.34),haze*.68);
  gl_FragColor=vec4(color,1.);
  #include <tonemapping_fragment>
  #include <encodings_fragment>
 }
 `});
 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(1700,1700),material);mesh.rotation.x=-Math.PI/2;mesh.position.y=-.42;scene.add(mesh);
 const mirrorCamera=new THREE.PerspectiveCamera(),plane=new THREE.Plane(),normal=new THREE.Vector3(),mirrorPosition=new THREE.Vector3(),cameraPosition=new THREE.Vector3(),rotation=new THREE.Matrix4(),lookAt=new THREE.Vector3(),clip=new THREE.Vector4(),q=new THREE.Vector4(),view=new THREE.Vector3(),lookTarget=new THREE.Vector3();
 let enabled=true,frames=0,reflectionFrames=0;
 mesh.onBeforeRender=function(renderer,worldScene,camera){
  eye.setFromMatrixPosition(camera.matrixWorld);
  if(!enabled){uniforms.mirrorReady.value=0;return}
  // Every other frame: fixed low-resolution reflection; never recompute shadow maps here.
  if(frames++%2&&uniforms.mirrorReady.value)return;
  mirrorPosition.setFromMatrixPosition(mesh.matrixWorld);cameraPosition.setFromMatrixPosition(camera.matrixWorld);
  rotation.extractRotation(mesh.matrixWorld);normal.set(0,0,1).applyMatrix4(rotation);
  view.subVectors(mirrorPosition,cameraPosition);if(view.dot(normal)>0)return;
  view.reflect(normal).negate().add(mirrorPosition);rotation.extractRotation(camera.matrixWorld);
  lookAt.set(0,0,-1).applyMatrix4(rotation).add(cameraPosition);lookTarget.subVectors(mirrorPosition,lookAt).reflect(normal).negate().add(mirrorPosition);
  mirrorCamera.position.copy(view);mirrorCamera.up.set(0,1,0).applyMatrix4(rotation).reflect(normal);mirrorCamera.lookAt(lookTarget);mirrorCamera.far=camera.far;mirrorCamera.updateMatrixWorld();mirrorCamera.projectionMatrix.copy(camera.projectionMatrix);
  textureMatrix.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1).multiply(mirrorCamera.projectionMatrix).multiply(mirrorCamera.matrixWorldInverse);
  plane.setFromNormalAndCoplanarPoint(normal,mirrorPosition).applyMatrix4(mirrorCamera.matrixWorldInverse);clip.set(plane.normal.x,plane.normal.y,plane.normal.z,plane.constant);
  const projection=mirrorCamera.projectionMatrix;q.set((Math.sign(clip.x)+projection.elements[8])/projection.elements[0],(Math.sign(clip.y)+projection.elements[9])/projection.elements[5],-1,(1+projection.elements[10])/projection.elements[14]);clip.multiplyScalar(2/clip.dot(q));projection.elements[2]=clip.x;projection.elements[6]=clip.y;projection.elements[10]=clip.z+1-.002;projection.elements[14]=clip.w;
  const oldTarget=renderer.getRenderTarget(),oldXr=renderer.xr.enabled,oldShadow=renderer.shadowMap.autoUpdate;
  mesh.visible=false;renderer.xr.enabled=false;renderer.shadowMap.autoUpdate=false;
  try{renderer.setRenderTarget(target);renderer.state.buffers.depth.setMask(true);if(!renderer.autoClear)renderer.clear();renderer.render(worldScene,mirrorCamera);uniforms.mirrorReady.value=1;reflectionFrames++}
  finally{mesh.visible=true;renderer.xr.enabled=oldXr;renderer.shadowMap.autoUpdate=oldShadow;renderer.setRenderTarget(oldTarget);if(camera.viewport)renderer.state.viewport(camera.viewport)}
 };
 function setDepth(heightAt){const n=256,bytes=new Uint8Array(n*n*4);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const h=heightAt(-220+(x+.5)/n*440,-180+(y+.5)/n*390),v=Math.round(THREE.MathUtils.clamp((h+3)/11,0,1)*255),i=(y*n+x)*4;bytes[i]=bytes[i+1]=bytes[i+2]=v;bytes[i+3]=255}const map=new THREE.DataTexture(bytes,n,n,THREE.RGBAFormat);map.magFilter=map.minFilter=THREE.LinearFilter;map.needsUpdate=true;uniforms.depthMap.value=map}
 return{mesh,setDepth,setQuality(on){enabled=on;if(!on)uniforms.mirrorReady.value=0},get reflectionFrames(){return reflectionFrames},dispose(){target.dispose();normalTex.dispose();uniforms.depthMap.value?.dispose();mesh.geometry.dispose();material.dispose()}};
}
