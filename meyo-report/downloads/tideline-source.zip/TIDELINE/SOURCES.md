# 2026-09-22 · 同伴采用后的第二版补充

本次没有新增外部资源、联网模型或另换研究对象。主作者实际读取 Hermes 对 b71f263 的原生浏览器记录，并通过原生图像工具查看对应九张真实画面；发现并返工高山压画面、同弯提示抖动、手机控件/文案不一致。具体观察、版本与修改范围见 `verification/experience/ADOPTION-REVIEW.md`。当前 `src/pacenotes.js`、低海岬高度场、触屏修改均为本项目代码；所用授权车模仍来自 folio-2019，不是 folio-2025。

上述同伴仅使用 gpt-6-astra，提供的是实际运行/DOM证据和诊断；其识图调用失败，因此不把同伴报告说成独立视觉通过。当前修改后需新的运行图像，旧截图/报告不自动继承结论。

---

# 2026-09-22 · Golden Hour 体验候选的当前来源边界

下方旧轮记录原样保留，均是历史语境；当前入口以 README 与 verification/experience/REVIEW.md 为准，不能把旧版的运行/视觉结论迁移到新版。

## 这次真实访问与使用

- `https://bruno-simon.com/`：2026-09-22 HTTP 200，保存公开 HTML 到 `evidence/experience-reference/bruno.txt`。本轮自己实际查看了先前浏览器采集的 `evidence/author-baseline/bruno-after-input.png`；这是已保存画面的观察，不是本轮亲手驾驶官网。观察决定：车辆四周需要可读的地表层次、近中远景组织；发光/阴影应围绕可识别物体而不是盖一层滤镜。
- `https://github.com/brunosimon/folio-2025`：GitHub API 主分支树读取成功，树 SHA `41046b57eeed8d156d9c3fd7fa259900baef7816`。根 `license.md` 为 MIT（2025 Bruno Simon）；只作实现组织研究，没有以根许可推断全部音乐/依赖可复用，也没有导入 2025 的模型/音乐/整站。源码快照在 `evidence/experience-reference/folio2025-*.js`。读取 `PhysicsVehicle.js` 的前轮真实转向与悬挂参数、`VisualVehicle.js` 的车辆表现分离，以及 `View.js` 的焦点/镜头组织。决定：本作让显示前轮使用同一个实际转向角，让视觉点头来源于实际加速度；不把本作简化动力学称作 Rapier 射线车。
- `https://www.artofrally.com/`：2026-09-22 HTTP 200。官网 Gallery3 原图 HTTP 200，本轮原生 `view_image` 实际查看（`evidence/experience-reference/rally-gallery.png`）。决定：保留一整条干净的路面为视觉负空间；暖色地物与较冷远景分层，轮廓比满屏物件更重要。未运行商业游戏，不能据官网截图声称测过其手感。
- 访问原始 GitHub 文件时一次 `PhysicsVehicle.js` 读取超时，后改用同一已固定树中 Git blob API 成功读取；超时没有伪称成功，也没有因此换到不相干来源。

## 本轮新增内容的权利/资源

`src/journey.js`、`src/coast.js`、新增天空 shader、驾驶/声音/UI 修改是本项目新编写的代码、程序几何与 Web Audio 合成。没有新下载游戏素材、商业贴图、录音、字体或生成式图片。现有运行基线车体/车轮仍为 **folio-2019** 两项授权 GLB，绝不是 2025 新车。Three.js r149、水面镜像算法和 Draco 声明继续保留。

原作 `original/` 未修改。公开参考网页/截图/源码只放研究目录，不进入运行页面或精简源码 ZIP。

---

# 来源与参照

历史研究日期：2026-09-20；当前作者续作：2026-09-21。全部网址为可回访的原始来源。

## 最后收尾（sign-cleanup）

Codex/Astra 第二次原生看图复验已确认 `859cebde…94a3` 的普通驾驶画面获得实质改进，并指出旧广告牌遮棚口及深色棚牌裁字。主作者核对返回文件、入口和图像哈希后，移除 `.02` 路边牌、缩短棚牌并按 Canvas 实测字宽适配；保留起点立柱和维修棚布局。无新增外部素材。

最终入口 `b313225b835bcf2b3b0cbc0fb56a37bc670faa3aeb1222cc9543d9eba9db9ba0` 的新运行证据在 `evidence/sign-cleanup-final/`、`sign-cleanup-driveby/`、`sign-cleanup-visit/`。独立视觉复验报告为 `verification/codex-peer-adoption-review.md`，只对应收尾前 SHA；最后招牌调整后没有冒称再次独立看图。README 按这一区分记录协作净收益及未验范围。

## 已采用的上一阶段评审与返工（peer-adoption）

- `verification/codex-visual-review.md` 是 Codex/Astra 通过原生图片输入实际查看 16 张原始截图后给出的独立意见；对应旧入口 `105348a1…1359`。主作者本轮核对了完整回传文件 SHA-256、入口哈希和图像索引中全部原图哈希，然后实际读取和采用，而不是把同伴 done 当作改进。
- 采用重点：解决正常驾驶看不到维修屋、树冠遮入口、路径矩形硬边。当前改为道路外侧开放维修棚、具有物理支撑的接入平台；保持赛车、道路及比赛，按树冠外伸和真实道路接近方向筛选树木，并为另外两处路径增加首尾渐隐及落脚区。`assets/tree-field.js` 是从本项目旧版确定性场景导出的树候选；没有新导入第三方美术或生成媒体。
- 独立同伴观察澄清：在 `evidence/author-baseline` 中，`bruno-after-start.png` 仍显示 CLICK TO START；`bruno-after-input.png` 才呈现展开世界。文件名不是进入成功的证据。参照的关键是低/中/高层物件围绕可读行驶空间组织，而不是无差别加数量。
- 本轮新入口 `859cebde…94a3` 的实驾证据：`evidence/peer-adoption-final/result.json`、`evidence/peer-adoption-3/depot-visit.json`、`evidence/peer-adoption-driveby/sequence.json`。旧报告没有被移作新版本视觉通过；本轮新截图仍需原生图像复验。
- 此次新几何、平台、木板坡道和局部贴图为当前项目编写。外部引擎、车模及水面算法来源继续沿用下文许可，不把项目全部文件统称 MIT。

## 上一轮续作历史（author-final，以下“本轮”为当时语境）

- 本轮主作者串行真实打开了 `https://bruno-simon.com/`，发送点击和 W/D 输入，抓取页面原文并保留 `evidence/author-baseline/bruno-*.png`。官网原文确认其内容为可自由驾驶/交互的世界，含 Rapier 与 WebGL/WebGPU。**由于当前 Astra 会话图像通路不可用，不能把截图已生成宣称为主作者已看见或已对照。** 下文旧轮次的“本轮”保持其历史语境。
- 新增 `src/settlements.js` 为本项目原创程序化几何/Canvas 贴图：三处建筑、门廊、花箱、木箱、渔网、维修物件、风向袋、贴地碎石路径。未获取或导入新的外部模型、商业贴图、声音或 AI 媒体。
- 选择改善“建筑过于简单、地点缺少可辨认细节”来自当前源码与既有用户反馈，不是新的看图评审。保留赛道净空、近中远景组织与地标辨认作为参照目标，不宣称已经达到 Bruno 的密度/交互/艺术完成度。
- 新版实驾通过与视觉阻塞分开记录：`evidence/author-final/result.json` 是当前入口对应的真实实键/整圈/模拟触控证据；`evidence/author-baseline/visual-review.md` 是内部 Astra 同伴对无法看图的复核。后者未带来艺术品质净收益，不计作成功协作改进。
- 前任最后原生调用 timeout、未正常 final 的事实没有因本轮实驾成功而被抹去。完整运行许可与边界见 `README.md`、`LICENSES.md`。


## 实际用于游戏的外部资源

### Three.js r149 — MIT

原工程已内嵌的 Three.js 代码原样提取为 `assets/three-r149.min.js`。没有为了升级而偷偷替换引擎版本。

- 官方仓库：https://github.com/mrdoob/three.js
- 同版本许可证：https://cdn.jsdelivr.net/npm/three@0.149.0/LICENSE
- 本地：`assets/THREE-LICENSE.txt`

### Bruno Simon / folio-2019 — MIT

- 仓库：https://github.com/brunosimon/folio-2019
- 本轮 API 返回树 SHA：`540f13573a6da282eae942a4c67335b97cd18970`
- 源车体：`static/models/car/default/chassis.glb`
- 源车轮：`static/models/car/default/wheel.glb`
- 原始资源：https://github.com/brunosimon/folio-2019/tree/master/static/models/car/default
- 授权：https://github.com/brunosimon/folio-2019/blob/master/license.md
- 本地：`assets/bruno-chassis.glb`、`assets/bruno-wheel.glb`、`assets/BRUNO-LICENSE.txt`

已核查资源处于该源仓库内，没有发现这两个 GLB 附带不同授权说明；资源本身没有外部纹理依赖。根许可不能泛化到所有第三方资源，本轮只复用了上列两项。

GLB 实际下载成功、Draco 几何已在构建阶段解码。节点变换保留，Z-up 转为 Y-up，重新指定材质与赛车涂色；四轮用独立支点驱动。解码后几何内嵌为 `assets/car-data.js`。本轮未使用旧工程中虚假的“GLTFLoader 已加载”路径。

### Draco 解码器 — Apache-2.0 等随附声明

仅构建时使用，游戏入口无需解码器和 Worker：

- 下载：https://cdn.jsdelivr.net/npm/three@0.149.0/examples/jsm/libs/draco/draco_decoder.js
- 项目：https://github.com/google/draco
- 授权：https://github.com/google/draco/blob/main/LICENSE
- 本地：`assets/DRACO-LICENSE.txt`
- 可重复解码：`node verification/convert-car.cjs`

最初尝试安装 DracoPy 到候选目录；后来改用上述已下载 JS 解码器成功完成，未使用的候选依赖目录已移除。

## 参照，不是本作品素材

### Bruno Simon《Folio》

https://bruno-simon.com/

本轮抓取官网文字并读了 `folio-2019` 的 `World/Car.js`。官网当前页面包含自由驾驶、镜头、交互、重生和赛事等说明。**没有在本轮浏览器中亲手操作官网**：本机浏览器启动/已有连接均失败，故没有伪造参考实玩结论。

采用的可实现尺度：独立轮胎、统一坐标系、稳定视野、环境的明确地标与自由转向。未复用整个网站、声音、品牌或所有物件；未声称实现当前 Folio 的 Rapier 世界交互、音频和内容密度。

### funselektor《art of rally》

https://www.artofrally.com/

查看了官网 Gallery3 原图：
https://cdn.prod.website-files.com/5f9217931198fa7e47c84927/5fa9adbe563545c7cd219e39_Gallery3.png

可观察的艺术组织：车身有完整轮廓而非盒子叠加；道路保留大片连续可读负空间；路边草/花/矮障碍/树/建筑形成近中远景层次；有限暖色色板以深色玻璃/路面维持对比。由此选择海岸街机而非写实 3A 假承诺，路面净宽 11 米，植被与障碍退出赛道净空，文字界面驾驶时撤出中心。

只用这张图研究视觉构图，不把它装进游戏，也不将其作为自己的游戏截图。未运行商业游戏，不对其驾驶物理作本轮实测声明。

## 原工程与原创增量

`original/index.html` 为收到的原文件，未修改；原 README、change-note 和检查脚本也保留。

新增赛道/岛屿分级、车辆控制、碰撞、计时赛、UI、海面 shader、程序化环境、轮迹和合成音频由本轮在候选中实现。无需额外素材下载，无商业贴图/录音，无 AI 生成媒体。实际完成代码审查、产出并被采用的同伴是 Astra。

2026-09-20 后续请求 cc 协助浏览器验证时，尽管请求明确限定 Astra，平台返回的失败记录却列出 `model=GLM-5.3`、`cc-router-down`。没有返回模型正文、工具动作、截图或文件，未采用任何该次输出，未重试这条不符合型号约束的通路。因此不能声称调度层的所有尝试都遵守了 Astra 限制，也不能将这次失败计为有效作品协作。


## 2026-09-20 真实画面对照与水面复用补充

- `assets/three-Water-r149.js`：Three.js r149 官方 Water 源文件快照，MIT（许可证同 `assets/THREE-LICENSE.txt`）。源地址：
  https://raw.githubusercontent.com/mrdoob/three.js/r149/examples/jsm/objects/Water.js
- `src/ocean.js`：采用上述源文件的镜像相机、斜裁剪平面与渲染目标恢复算法，保留源头说明；波纹、浅水深度、泡沫、色彩着色代码为本项目新增。768×512离屏目标隔帧更新，轻量画质关闭场景反射。不是用纹理图片冒充实时场景倒影。
- `src/game.js` 中 PBR 环境 cubemap 为本地程序生成的小尺寸天空色环境，不是下载的HDR图，也不声称天空 cubemap 本身包含场景物件；场景倒影由独立水面反射相机生成。
- Hermes（本单 `gpt-6-astra`）以已有原生工具串行运行候选与参考官网。我实际读取结果文件、核对游戏 SHA-256，并亲自查看保存的浏览器截图。第一轮 `bruno-live.png` 仅为入口；第二轮 `bruno-after-start.png` / `bruno-after-input.png` 显示已进入官网世界并发送实际按键。不能把我查看同伴截图说成我在当前 sandbox 中亲手运行成功。
- 对照观察：Bruno 的真实画面在地表装饰密度、叶片层次、局部发光与小物件的细节上仍明显更丰富。本作品保留海岸驾驶的开阔视野取向，但尚不等同于该参照的完整世界内容、车辆物理和音效完成度。
- 本轮未将 Bruno 官网截图嵌入游戏。研究图片只作来源与对照证据，不作为交付游戏画面或自有美术素材。此前内部 Astra 物理审查有效，CC路由失败、auto平台预检未执行以及后续Hermes原生验证成功，均分别保留，未混为“全部成功”。
