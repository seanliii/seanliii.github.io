"""Rebuild the standalone offline HTML from readable source (Python stdlib only)."""
from pathlib import Path
root=Path(__file__).resolve().parent
page=(root/'src/page.html').read_text()
for marker,file in [('STYLE','src/style.css'),('THREE','assets/three-r149.min.js'),('ASSET','assets/car-data.js'),('OCEAN','src/ocean.js'),('TREEFIELD','assets/tree-field.js'),('SETTLEMENTS','src/settlements.js'),('PACENOTES','src/pacenotes.js'),('COAST','src/coast.js'),('JOURNEY','src/journey.js'),('GAME','src/game.js')]:
 page=page.replace('/*'+marker+'*/',(root/file).read_text())
(root/'index.html').write_text(page)
print('Built index.html:',len(page.encode()),'bytes; all resources embedded.')
