
/* =====================================================================
 * Seeded RNG (Mulberry32) — deterministic world for repeatable screenshots
 * ===================================================================== */
function mulberry32(a){return function(){let t=(a+=0x6D2B79F5);t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
const SEED = 1337;
const rng = mulberry32(SEED);
function rand(min, max){ return min + rng()*(max-min); }

/* =====================================================================
 * Renderer / scene / camera (matches Bruno's exposure & tonemap chain)
 * ===================================================================== */
const container = document.getElementById('app');
const heroCopy=document.getElementById('heroCopy'); let px=0,py=0,wheelImpulse=0;
addEventListener('pointermove',e=>{px=e.clientX/innerWidth-.5;py=e.clientY/innerHeight-.5;});
addEventListener('wheel',e=>{if(e.deltaY) setIntroVisible(false);wheelImpulse=Math.max(-1,Math.min(1,wheelImpulse+e.deltaY*.0015));},{passive:true});
const renderer = new THREE.WebGLRenderer({ antialias:true, powerPreference:'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.82;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(58, window.innerWidth/window.innerHeight, 0.1, 1500);
camera.position.set(30, 8.5, -9);

/* =====================================================================
 * Sky (Preetham) at golden hour — sun on the horizon
 * elevation 3° (matches concept anchor; Bruno uses 2-5°)
 * ===================================================================== */
const sky = new THREE.Mesh(new THREE.SphereGeometry(700,32,16), new THREE.MeshBasicMaterial({color:0xf08a62,side:THREE.BackSide}));
sky.scale.setScalar(450000);
scene.add(sky);

const skyU = {sunPosition:{value:new THREE.Vector3()}};

const sunElevDeg = 3.0;
const sunAzimuth = 145;
const sunPhi = THREE.MathUtils.degToRad(90 - sunElevDeg);
const sunTheta = THREE.MathUtils.degToRad(sunAzimuth);
const sunVec = new THREE.Vector3().setFromSphericalCoords(1, sunPhi, sunTheta);
skyU.sunPosition.value.copy(sunVec);

/* =====================================================================
 * Environment map from sky (for PBR reflections on car/rocks)
 * ===================================================================== */
scene.background = new THREE.Color(0xf08a62);

/* =====================================================================
 * Lighting
 *  - DirectionalLight = sun (low angle, warm)
 *  - HemisphereLight  = Bruno's purple bounce (the "hidden" recipe)
 * ===================================================================== */
const sunLight = new THREE.DirectionalLight(0xffd1a0, 3.2);
sunLight.position.copy(sunVec).multiplyScalar(180);
sunLight.castShadow = true;
sunLight.shadow.mapSize.set(2048, 2048);
sunLight.shadow.bias = -0.0008;
sunLight.shadow.normalBias = 0.04;
sunLight.shadow.radius = 4;
const sb = sunLight.shadow.camera;
sb.left = -120; sb.right = 120; sb.top = 120; sb.bottom = -120;
sb.near = 1; sb.far = 500;
sb.updateProjectionMatrix();
scene.add(sunLight);

const hemi = new THREE.HemisphereLight(0xfff1d6, 0x6e4a7a, 0.78);
hemi.position.set(0, 50, 0);
scene.add(hemi);

const fillLight = new THREE.DirectionalLight(0xb8cfff, 0.48);
fillLight.position.set(-40, 30, -20);
scene.add(fillLight);

/* =====================================================================
 * Fog — warm horizon blend with sky bottom (matches sky base)
 * ===================================================================== */
const fogColor = new THREE.Color(0xffa070);
scene.fog = new THREE.FogExp2(fogColor.getHex(), 0.0036);

/* =====================================================================
 * Water (three.js Water shader) — real reflection + sun glint
 * ===================================================================== */
const waterGeometry = new THREE.PlaneGeometry(2000,2000,120,120);
const water = new THREE.Mesh(waterGeometry,new THREE.MeshPhysicalMaterial({color:0x174b67,metalness:0.45,roughness:0.18,transparent:true,opacity:0.94}));
water.rotation.x=-Math.PI/2; water.position.y=0; scene.add(water);
water.material.uniforms={time:{value:0}};

/* =====================================================================
 * Procedural terrain helper — multi-island via SDF blending
 * ===================================================================== */
function fbm(x,z){
  function vn(ix,iz){
    const a=Math.sin(ix*12.9898+iz*78.233)*43758.5453;
    return a-Math.floor(a);
  }
  let amp=1, freq=1, sum=0, norm=0;
  for(let o=0;o<4;o++){
    const fx=x*freq, fz=z*freq;
    const ix=Math.floor(fx), iz=Math.floor(fz);
    const tx=fx-ix, tz=fz-iz;
    const a=vn(ix,iz), b=vn(ix+1,iz), c=vn(ix,iz+1), d=vn(ix+1,iz+1);
    const sx=tx*tx*(3-2*tx), sz=tz*tz*(3-2*tz);
    const n=(a*(1-sx)+b*sx)*(1-sz)+(c*(1-sx)+d*sx)*sz;
    sum += n*amp; norm += amp; amp*=0.5; freq*=2.0;
  }
  return sum/norm;
}

const ISLANDS = [
  { x:   0, z:   0, r: 38, peak: 6.5, name:'home' },
  { x: -78, z:  55, r: 30, peak: 5.5, name:'west' },
  { x:  68, z: -42, r: 26, peak: 4.5, name:'east' },
  { x:  92, z:  88, r: 22, peak: 4.0, name:'far' },
  { x:-110, z: -70, r: 18, peak: 3.0, name:'mist' }
];

function islandHeight(x,z){
  let h = -2.5;
  let onLand = false;
  for (const isl of ISLANDS){
    const dx = x - isl.x, dz = z - isl.z;
    const d = Math.sqrt(dx*dx + dz*dz);
    if (d < isl.r * 1.6){
      const t = Math.max(0, 1 - d / (isl.r * 1.6));
      const falloff = t * t * (3 - 2*t);
      const noise = fbm((x + isl.x*7.3)*0.05, (z + isl.z*11.1)*0.05);
      const local = (noise - 0.5) * 0.6;
      const peak = isl.peak * falloff + local * falloff * 1.2;
      if (falloff > 0.05) onLand = true;
      h = Math.max(h, peak);
    }
  }
  return { h, onLand };
}

/* =====================================================================
 * Build island terrain
 * ===================================================================== */
function buildTerrain(){
  const SIZE = 600, SEG = 220;
  const geo = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG);
  geo.rotateX(-Math.PI/2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count*3);
  const colBeach = new THREE.Color(0xd9b27a);
  const colGrass = new THREE.Color(0x4a6b3a);
  const colRock  = new THREE.Color(0x7a6a55);
  const colSand  = new THREE.Color(0xeac796);
  for (let i=0;i<pos.count;i++){
    const x = pos.getX(i), z = pos.getZ(i);
    const { h, onLand } = islandHeight(x,z);
    pos.setY(i, h);
    let c;
    if (h < 0.15 && h > -0.5) c = colSand;
    else if (h < 0.6) c = colBeach;
    else if (h < 2.5) c = colGrass;
    else c = colRock;
    colors[i*3+0] = c.r;
    colors[i*3+1] = c.g;
    colors[i*3+2] = c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({
    vertexColors:true, roughness:0.95, metalness:0.0, flatShading:false
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  mesh.castShadow = false;
  return mesh;
}
const terrain = buildTerrain();
scene.add(terrain);

/* =====================================================================
 * Vegetation — InstancedMesh for trees & rocks
 * ===================================================================== */
function buildTreeProto(){
  const trunkGeo = new THREE.CylinderGeometry(0.18, 0.25, 1.6, 7);
  const trunkMat = new THREE.MeshStandardMaterial({ color:0x5a3a22, roughness:0.95 });
  const crownMat = new THREE.MeshStandardMaterial({ color:0x3a6b32, roughness:0.8, flatShading:true });
  const cones = [];
  for (let i=0;i<3;i++){
    cones.push(new THREE.ConeGeometry(1.0 - i*0.22, 1.4 - i*0.18, 7));
  }
  // Build a single bakeable geometry (trunk + 3 cones at offsets) with vertex colors per part
  function makeMesh(geo, mat, yOff, color){
    const colors = new Float32Array(geo.attributes.position.count*3);
    for (let i=0;i<geo.attributes.position.count;i++){
      colors[i*3]=color.r; colors[i*3+1]=color.g; colors[i*3+2]=color.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors,3));
    geo.translate(0, yOff, 0);
    return geo;
  }
  const trunkColor = new THREE.Color(0x5a3a22);
  const crownColor = new THREE.Color(0x3a6b32);
  const tOff = makeMesh(trunkGeo.clone(), null, 0.8, trunkColor);
  const c1 = makeMesh(cones[0].clone(), null, 1.6, crownColor);
  const c2 = makeMesh(cones[1].clone(), null, 2.3, crownColor);
  const c3 = makeMesh(cones[2].clone(), null, 3.0, crownColor);
  // merge positions
  const parts = [tOff, c1, c2, c3];
  let totalVerts = 0, totalIndices = 0;
  parts.forEach(g=>{
    totalVerts += g.attributes.position.count;
    if (g.index) totalIndices += g.index.count;
    else totalIndices += g.attributes.position.count;
  });
  const positions = new Float32Array(totalVerts*3);
  const normals = new Float32Array(totalVerts*3);
  const colsA = new Float32Array(totalVerts*3);
  const idxs = [];
  let off = 0;
  parts.forEach(g=>{
    positions.set(g.attributes.position.array, off*3);
    normals.set(g.attributes.normal.array, off*3);
    colsA.set(g.attributes.color.array, off*3);
    if (g.index){
      const idx = g.index.array;
      for (let i=0;i<idx.length;i++) idxs.push(idx[i]+off);
    } else {
      for (let i=0;i<g.attributes.position.count;i++) idxs.push(i+off);
    }
    off += g.attributes.position.count;
  });
  const merged = new THREE.BufferGeometry();
  merged.setAttribute('position', new THREE.BufferAttribute(positions,3));
  merged.setAttribute('normal', new THREE.BufferAttribute(normals,3));
  merged.setAttribute('color', new THREE.BufferAttribute(colsA,3));
  merged.setIndex(idxs);
  return merged;
}

function buildRockProto(){
  const g = new THREE.IcosahedronGeometry(0.7, 0);
  const p = g.attributes.position;
  for (let i=0;i<p.count;i++){
    const x=p.getX(i), y=p.getY(i), z=p.getZ(i);
    const k = 1 + (rng()-0.5)*0.4;
    p.setXYZ(i, x*k, y*k, z*k);
  }
  g.computeVertexNormals();
  return g;
}

const treeGeom = buildTreeProto();
const treeMat = new THREE.MeshStandardMaterial({ vertexColors:true, roughness:0.9 });
const TREE_N = 220;
const trees = new THREE.InstancedMesh(treeGeom, treeMat, TREE_N);
trees.castShadow = true;
trees.receiveShadow = false;
scene.add(trees);

const rockProtoGeom = buildRockProto();
const rockMat = new THREE.MeshStandardMaterial({ color:0x8a7a68, roughness:0.92, flatShading:true });
const ROCK_N = 70;
const ROCK_INST = new THREE.InstancedMesh(rockProtoGeom, rockMat, ROCK_N);
ROCK_INST.castShadow = true; ROCK_INST.receiveShadow = false;
scene.add(ROCK_INST);

const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
let placedTrees = 0, placedRocks = 0;
const tries = 1500;
for (let i=0; i<tries && (placedTrees<TREE_N || placedRocks<ROCK_N); i++){
  const x = rand(-110, 110), z = rand(-110, 110);
  const { h, onLand } = islandHeight(x,z);
  if (!onLand) continue;
  const dHome = Math.sqrt(x*x+z*z);
  if (dHome < 7 || (dHome > 14 && dHome < 31)) continue;
  if (placedTrees < TREE_N && h > 0.6 && rng() < 0.85){
    _q.setFromAxisAngle(new THREE.Vector3(0,1,0), rand(0, Math.PI*2));
    _s.set(rand(0.7, 1.4), rand(0.7, 1.6), rand(0.7, 1.4));
    _m.compose(new THREE.Vector3(x, h, z), _q, _s);
    trees.setMatrixAt(placedTrees, _m);
    placedTrees++;
  } else if (placedRocks < ROCK_N && h > -0.2 && h < 3){
    _q.setFromAxisAngle(new THREE.Vector3(0,1,0), rand(0, Math.PI*2));
    _s.set(rand(0.5, 1.5), rand(0.4, 1.0), rand(0.5, 1.5));
    _m.compose(new THREE.Vector3(x, h - 0.1, z), _q, _s);
    ROCK_INST.setMatrixAt(placedRocks, _m);
    placedRocks++;
  }
}
trees.count = placedTrees;
ROCK_INST.count = placedRocks;
trees.instanceMatrix.needsUpdate = true;
ROCK_INST.instanceMatrix.needsUpdate = true;

/* =====================================================================
 * Road loop on home island
 * ===================================================================== */
function buildRoad(){
  const points = [];
  const N = 40;
  for (let i=0;i<N;i++){
    const t = (i/N) * Math.PI * 2;
    const r = 22 + Math.sin(t*2)*3;
    const x=Math.cos(t)*r, z=Math.sin(t)*r; points.push(new THREE.Vector3(x, islandHeight(x,z).h + 0.18, z));
  }
  const curve = new THREE.CatmullRomCurve3(points, true);
  const tubeGeo = new THREE.TubeGeometry(curve, 200, 1.6, 12, true);
  const mat = new THREE.MeshStandardMaterial({ color:0x2a2622, roughness:0.95 });
  const mesh = new THREE.Mesh(tubeGeo, mat);
  mesh.receiveShadow=true;
  return { mesh, curve };
}
const road = buildRoad();
scene.add(road.mesh);

/* =====================================================================
 * Lamp posts along the road
 * ===================================================================== */
function buildLampProto(){
  const poleGeo = new THREE.CylinderGeometry(0.08, 0.1, 4, 8);
  const poleMat = new THREE.MeshStandardMaterial({ color:0x222222, metalness:0.6, roughness:0.5 });
  const lampGeo = new THREE.SphereGeometry(0.25, 12, 8);
  const lampMat = new THREE.MeshStandardMaterial({
    color:0xffe2a8, emissive:0xffaa55, emissiveIntensity:1.6, roughness:0.4
  });
  // Bake
  function colorize(geo, color){
    const c = new Float32Array(geo.attributes.position.count*3);
    for (let i=0;i<geo.attributes.position.count;i++){
      c[i*3]=color.r; c[i*3+1]=color.g; c[i*3+2]=color.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(c,3));
    return geo;
  }
  const pole = colorize(poleGeo.clone(), new THREE.Color(0x222222));
  pole.translate(0, 2, 0);
  const lamp = colorize(lampGeo.clone(), new THREE.Color(0xffe2a8));
  lamp.translate(0, 4.2, 0);
  // Merge
  const parts = [pole, lamp];
  let total = 0; let totalI = 0;
  parts.forEach(g=>{
    total += g.attributes.position.count;
    totalI += g.index ? g.index.count : g.attributes.position.count;
  });
  const posA = new Float32Array(total*3);
  const norA = new Float32Array(total*3);
  const colA = new Float32Array(total*3);
  const idxs = [];
  let off = 0;
  parts.forEach(g=>{
    posA.set(g.attributes.position.array, off*3);
    norA.set(g.attributes.normal.array, off*3);
    colA.set(g.attributes.color.array, off*3);
    if (g.index){
      const idx = g.index.array;
      for (let i=0;i<idx.length;i++) idxs.push(idx[i]+off);
    } else {
      for (let i=0;i<g.attributes.position.count;i++) idxs.push(i+off);
    }
    off += g.attributes.position.count;
  });
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(posA,3));
  out.setAttribute('normal', new THREE.BufferAttribute(norA,3));
  out.setAttribute('color', new THREE.BufferAttribute(colA,3));
  out.setIndex(idxs);
  return out;
}
const lampGeom = buildLampProto();
const lampMat = new THREE.MeshStandardMaterial({
  vertexColors:true, roughness:0.6, metalness:0.5,
  emissive:0xffaa55, emissiveIntensity:1.2
});
const LAMP_N = 12;
const lamps = new THREE.InstancedMesh(lampGeom, lampMat, LAMP_N);
lamps.castShadow=true;
scene.add(lamps);
for (let i=0;i<LAMP_N;i++){
  const t = (i/LAMP_N) * Math.PI * 2;
  const r = 22 + Math.sin(t*2)*3;
  const x = Math.cos(t)*r, z = Math.sin(t)*r;
  _q.setFromAxisAngle(new THREE.Vector3(0,1,0), t + Math.PI/2);
  _s.set(1,1,1);
  _m.compose(new THREE.Vector3(x, islandHeight(x,z).h + 0.18, z), _q, _s);
  lamps.setMatrixAt(i, _m);
  if (i % 3 === 0){
    const pl = new THREE.PointLight(0xffb070, 1.2, 12, 2);
    pl.position.set(x, islandHeight(x,z).h + 4.2, z);
    scene.add(pl);
  }
}
lamps.instanceMatrix.needsUpdate = true;

/* =====================================================================
 * Procedural car — 22+ parts
 * ===================================================================== */
function buildCar(){
  const car = new THREE.Group();
  const bodyMat = new THREE.MeshPhysicalMaterial({
    color:0xc92c2c, metalness:0.65, roughness:0.32,
    clearcoat:0.6, clearcoatRoughness:0.2
  });
  const blackMat = new THREE.MeshStandardMaterial({ color:0x111111, roughness:0.8, metalness:0.2 });
  const chromeMat = new THREE.MeshStandardMaterial({ color:0xdddddd, metalness:0.9, roughness:0.25 });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color:0x222831, metalness:0.1, roughness:0.05,
    transmission:0.7, thickness:0.4, ior:1.45,
    transparent:true, opacity:0.55
  });
  const lightMat = new THREE.MeshStandardMaterial({
    color:0xfff4d0, emissive:0xfff0c0, emissiveIntensity:2.2, roughness:0.3
  });
  const tailMat = new THREE.MeshStandardMaterial({
    color:0xff3030, emissive:0xff2020, emissiveIntensity:1.5, roughness:0.4
  });

  const chassis = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.45, 1.9), blackMat);
  chassis.position.y = 0.45; chassis.castShadow=true; car.add(chassis);
  const body = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.6, 1.85), bodyMat);
  body.position.y = 0.95; body.castShadow=true; car.add(body);
  const hood = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.35, 1.7), bodyMat);
  hood.position.set(1.3, 1.25, 0); hood.castShadow=true; car.add(hood);
  const trunk = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.4, 1.7), bodyMat);
  trunk.position.set(-1.4, 1.2, 0); trunk.castShadow=true; car.add(trunk);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.65, 1.7), bodyMat);
  roof.position.set(-0.2, 1.65, 0); roof.castShadow=true; car.add(roof);
  const ws = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.55, 1.65), glassMat);
  ws.position.set(0.7, 1.6, 0); ws.rotation.z = -0.25; car.add(ws);
  const rw = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.5, 1.65), glassMat);
  rw.position.set(-1.05, 1.55, 0); rw.rotation.z = 0.2; car.add(rw);
  for (const s of [1,-1]){
    const sw = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.4, 0.04), glassMat);
    sw.position.set(-0.2, 1.7, 0.85*s); car.add(sw);
  }
  for (const s of [1,-1]){
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.2, 0.4), lightMat);
    hl.position.set(2.05, 0.95, 0.6*s); car.add(hl);
  }
  for (const s of [1,-1]){
    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 0.4), tailMat);
    tl.position.set(-2.05, 0.95, 0.65*s); car.add(tl);
  }
  const grille = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.3, 1.2), chromeMat);
  grille.position.set(2.06, 0.7, 0); car.add(grille);
  for (const sx of [2.05, -2.05]){
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.25, 1.95), chromeMat);
    b.position.set(sx, 0.55, 0); car.add(b);
  }
  const spBase = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.15, 1.6), blackMat);
  spBase.position.set(-2.05, 1.4, 0); car.add(spBase);
  const spWing = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.06, 1.8), bodyMat);
  spWing.position.set(-2.0, 1.55, 0); car.add(spWing);
  for (const s of [1,-1]){
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.18, 0.18), bodyMat);
    m.position.set(0.5, 1.45, 0.95*s); car.add(m);
  }
  for (const s of [1,-1]){
    const ex = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.2, 10), chromeMat);
    ex.rotation.z = Math.PI/2;
    ex.position.set(-2.16, 0.4, 0.4*s); car.add(ex);
  }
  const wheelPos = [[ 1.3, 0.45,  0.95],[ 1.3, 0.45, -0.95],
                    [-1.3, 0.45,  0.95],[-1.3, 0.45, -0.95]];
  for (const [wx,wy,wz] of wheelPos){
    const wg = new THREE.Group();
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.35, 16), blackMat);
    tire.rotation.x = Math.PI/2; tire.castShadow=true; wg.add(tire);
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.36, 12), chromeMat);
    rim.rotation.x = Math.PI/2; wg.add(rim);
    for (let i=0;i<5;i++){
      const sp = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.34, 0.08), chromeMat);
      sp.rotation.z = (i/5)*Math.PI*2;
      sp.position.y = Math.cos(sp.rotation.z)*0.18;
      sp.position.x = Math.sin(sp.rotation.z)*0.18;
      wg.add(sp);
    }
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.38, 8), chromeMat);
    hub.rotation.x = Math.PI/2; wg.add(hub);
    wg.position.set(wx, wy, wz);
    car.add(wg);
  }
  return car;
}
const car = new THREE.Group();
const fallbackCar = buildCar(); fallbackCar.visible = false; car.add(fallbackCar);
fallbackCar.visible = true; /* real MIT asset supplied separately; standalone mode uses detailed fallback */
/* new GLTFLoader().load('./assets/bruno-default-car.glb', gltf => {
  const model = gltf.scene; const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3()); const scale = 4.8 / Math.max(size.x,size.z);
  model.scale.setScalar(scale); box.setFromObject(model);
  const center=box.getCenter(new THREE.Vector3()); model.position.sub(center);
  model.position.y -= new THREE.Box3().setFromObject(model).min.y;
  model.rotation.y = Math.PI/2;
  model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true; if(o.material){o.material.envMapIntensity=1.35;o.material.needsUpdate=true;}}});
  car.add(model);
}, undefined, e=>{ console.error('CC/MIT car load failed',e); fallbackCar.visible=true; }); */
car.position.set(20, 0.1, -6);
car.rotation.y = Math.PI + 0.4;
scene.add(car);

/* =====================================================================
 * Player controller
 * ===================================================================== */
const player = {
  pos: new THREE.Vector3(20, 0.1, -6),
  vel: new THREE.Vector3(),
  heading: Math.PI + 0.4,
  steer: 0,
  speed: 0,
  maxSpeed: 22,
  onWater: false
};
const keys = {};
const introToggle = document.getElementById('introToggle');
const driveKeys = new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowDown','ArrowRight']);
function setIntroVisible(visible){
  document.body.classList.toggle('driving', !visible);
  heroCopy.setAttribute('aria-hidden', String(!visible));
  introToggle.setAttribute('aria-expanded', String(visible));
  introToggle.textContent = visible ? 'Drive · hide intro' : 'About / controls';
}
introToggle.addEventListener('click', ()=>setIntroVisible(introToggle.getAttribute('aria-expanded') !== 'true'));
window.addEventListener('keydown', e=>{
  if(e.altKey || e.ctrlKey || e.metaKey) return;
  if(e.code==='Escape'){setIntroVisible(false);return;}
  if(e.target.closest && e.target.closest('input,textarea,select,[contenteditable="true"]')) return;
  if(e.code==='Space' && e.target.closest && e.target.closest('button')) return;
  if(driveKeys.has(e.code) || e.code==='Space') e.preventDefault();
  keys[e.code]=true;
  if(driveKeys.has(e.code)) setIntroVisible(false);
  if(e.code==='Space' && !e.repeat) resetCar();
});
window.addEventListener('keyup', e=>{ delete keys[e.code]; });
function releaseControls(){for(const code of Object.keys(keys)) delete keys[code]; wheelImpulse=0;}
window.addEventListener('blur', releaseControls);
document.addEventListener('visibilitychange', ()=>{if(document.hidden) releaseControls();});

function resetCar(){
  player.pos.set(20, 0.1, -6);
  player.heading = Math.PI + 0.4;
  player.vel.set(0,0,0);
  player.speed = 0;
  player.steer = 0;
}

function updatePlayer(dt){
  const accel = (keys['KeyW']||keys['ArrowUp']) ? 12 : 0;
  const brake = (keys['KeyS']||keys['ArrowDown']) ? 14 : 0;
  const boost = keys['ShiftLeft']||keys['ShiftRight'] ? 1.7 : 1.0;
  const left  = (keys['KeyA']||keys['ArrowLeft']) ? 1 : 0;
  const right = (keys['KeyD']||keys['ArrowRight']) ? 1 : 0;

  const steerInput = (right - left);
  const speedFactor = Math.min(1, Math.abs(player.speed) / 5);
  player.steer += (steerInput * 0.04 - player.steer * 0.1);
  player.heading += -player.steer * dt * (1.5 + speedFactor*1.0);

  if (accel){ player.speed += accel * boost * dt; }
  if (brake){
    if (player.speed > 0) player.speed = Math.max(0, player.speed - brake*dt);
    else player.speed -= brake * 0.6 * dt;
  }
  player.speed *= Math.exp(-0.6 * dt);
  player.speed = Math.max(-6, Math.min(player.maxSpeed * boost, player.speed));

  // The car model's nose points along local +X. Drive on that same axis so the
  // vehicle no longer slides sideways while accelerating.
  player.vel.set(Math.cos(player.heading), 0, -Math.sin(player.heading)).multiplyScalar(player.speed);
  player.pos.addScaledVector(player.vel, dt);

  const { h } = islandHeight(player.pos.x, player.pos.z);
  const targetY = h > 0 ? h : -0.05;
  player.onWater = (h < 0.05);
  player.pos.y += (targetY - player.pos.y) * Math.min(1, dt*8);

  const maxR = 240;
  const r = Math.sqrt(player.pos.x**2 + player.pos.z**2);
  if (r > maxR){
    const k = maxR / r;
    player.pos.x *= k; player.pos.z *= k;
  }

  car.position.copy(player.pos);
  car.rotation.y = player.heading;
}

const camDesired = new THREE.Vector3();
const camTarget = new THREE.Vector3();
function updateCamera(dt){
  // Follow directly behind the model's local +X forward axis.
  const back = new THREE.Vector3(-Math.cos(player.heading), 0, Math.sin(player.heading));
  camDesired.copy(player.pos).addScaledVector(back, 8.5).add(new THREE.Vector3(0, 7.8, 0));
  camera.position.lerp(camDesired, 1 - Math.pow(0.001, dt));
  camTarget.copy(player.pos).add(new THREE.Vector3(0, 1.0, 0));
  camera.lookAt(camTarget);
}

/* =====================================================================
 * Post-processing
 * ===================================================================== */
const composer={render:()=>renderer.render(scene,camera),setSize:(w,h)=>renderer.setSize(w,h)}; const bloomPass={setSize:()=>{}};

let last = performance.now()/1000;
let frame = 0;
let fpsAvg = 60, fpsSamples = 0, fpsTimer = 0;
function tick(){
  const now = performance.now()/1000;
  const dt = Math.min(0.05, now - last);
  last = now;
  updatePlayer(dt);
  if(Math.abs(wheelImpulse)>.01){ player.speed += wheelImpulse*dt*4; wheelImpulse*=Math.pow(.05,dt); }
  updateCamera(dt);
  camera.position.x += px*.32; camera.position.y += -py*.16;
  heroCopy.style.transform=`translate3d(${px*-10}px,${py*-7}px,0)`;
  water.material.uniforms.time.value += dt;
  composer.render();
  if (dt > 0.001){
    const fps = 1/dt;
    fpsAvg = fpsAvg*0.95 + fps*0.05;
    fpsSamples++;
  }
  frame++;
  if (frame === 3){
    document.getElementById('loader').classList.add('hidden');
  }
  if (!window.__pause) requestAnimationFrame(tick);
}
tick();

window.__scene = scene;
window.__camera = camera;
window.__renderer = renderer;
window.__composer = composer;
window.__player = player;
window.__car = car;
window.__fpsAvg = () => fpsAvg;
window.__frame = () => frame;

window.addEventListener('resize', ()=>{
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
  bloomPass.setSize(window.innerWidth, window.innerHeight);
});
