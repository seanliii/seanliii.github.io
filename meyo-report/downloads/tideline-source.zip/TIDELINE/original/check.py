from pathlib import Path
import json,time
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True)
 try:
  page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto((root/'index.html').as_uri())
  page.wait_for_timeout(1600)
  assert page.locator('#introToggle').get_attribute('aria-expanded')=='true'
  pos=page.evaluate('window.__player.pos.toArray()')
  page.keyboard.down('w');page.wait_for_timeout(1000);page.keyboard.up('w')
  page.wait_for_timeout(400)
  assert page.evaluate('window.__player.pos.toArray()')!=pos
  assert page.locator('#introToggle').get_attribute('aria-expanded')=='false'
  assert page.locator('#heroCopy').evaluate('(e)=>getComputedStyle(e).visibility')=='hidden'
  page.screenshot(path=str(root/'verification/driving.png'))
  page.keyboard.press('Space');page.wait_for_timeout(400)
  assert page.locator('#introToggle').get_attribute('aria-expanded')=='false'
  page.locator('#introToggle').click();page.wait_for_timeout(400)
  assert page.locator('#introToggle').get_attribute('aria-expanded')=='true'
  page.keyboard.press('Escape');page.wait_for_timeout(400)
  assert page.locator('#introToggle').get_attribute('aria-expanded')=='false'
  page.keyboard.down('ArrowUp');page.wait_for_timeout(100)
  page.evaluate("window.dispatchEvent(new Event('blur'))")
  assert page.evaluate('Object.keys(keys).length')==0
  page.keyboard.up('ArrowUp')
  page.set_viewport_size({'width':390,'height':844})
  page.wait_for_timeout(400)
  page.screenshot(path=str(root/'verification/narrow.png'))
  assert page.locator('#introToggle').is_visible()
  assert not errors,errors
  (root/'verification/result.json').write_text(json.dumps({'passed':True,'page_errors':errors,'checks':['file:// rendering','W moves vehicle and dismisses intro','reset keeps intro hidden','button restores intro','Escape closes intro','blur clears held keys','390px viewport button visible']},indent=2))
  print('PASS',flush=True)
 finally:
  browser.close()
