const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('index.html','utf8');
const scripts=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(x=>x[1]);
for(const s of scripts)new vm.Script(s);
const events={}, attrs={'aria-expanded':'true'}, classes=new Set();
const button={getAttribute:k=>attrs[k],setAttribute:(k,v)=>attrs[k]=v,addEventListener:(k,f)=>events['button:'+k]=f};
const ctx={Set,Object,String,keys:null,wheelImpulse:1,heroCopy:{setAttribute(){}},resetCar(){ctx.resets++},resets:0,
 document:{hidden:false,body:{classList:{toggle(k,on){on?classes.add(k):classes.delete(k)}}},getElementById:()=>button,addEventListener:(k,f)=>events[k]=f},
 window:{addEventListener:(k,f)=>events[k]=f}};
vm.createContext(ctx);
const code=scripts.at(-1);vm.runInContext(code.slice(code.indexOf('const keys = {};'),code.indexOf('\nfunction resetCar(){')),ctx);
const key=(code,target={closest:()=>null})=>({code,target,preventDefault(){}});
events.keydown(key('KeyW'));assert(classes.has('driving'));assert.equal(attrs['aria-expanded'],'false');
events.keyup(key('KeyW'));events.keydown(key('Space'));assert.equal(ctx.resets,1);assert(classes.has('driving'));
events['button:click']();assert(!classes.has('driving'));assert.equal(attrs['aria-expanded'],'true');
events.keydown(key('Escape'));assert(classes.has('driving'));
events.keydown(key('ArrowUp'));events.blur();assert.equal(vm.runInContext('Object.keys(keys).length',ctx),0);assert.equal(ctx.wheelImpulse,0);
events.keydown(key('Space',{closest:s=>s==='button'?button:null}));assert.equal(ctx.resets,1);
assert(!html.includes('heroCopy.style.opacity='));
console.log('PASS: both inline scripts parse; drive/reset/toggle/Escape/blur/button-space checks pass. Browser rendering NOT verified.');
