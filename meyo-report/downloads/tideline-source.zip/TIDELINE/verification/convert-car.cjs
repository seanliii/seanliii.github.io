// Decode Bruno Simon's source GLBs at build time. No runtime network or Draco dependency.
const fs=require('fs');const Draco=require('../assets/draco_decoder.js');
Draco({onModuleLoaded(d){
 function convert(name){
  const b=fs.readFileSync('assets/bruno-'+name+'.glb');const jl=b.readUInt32LE(12),j=JSON.parse(b.subarray(20,20+jl)),binary=b.subarray(28+jl);
  const meshes=j.meshes.map(m=>m.primitives.map(p=>{
   const ext=p.extensions.KHR_draco_mesh_compression,v=j.bufferViews[ext.bufferView],buf=new d.DecoderBuffer();buf.Init(new Int8Array(binary.subarray(v.byteOffset||0,(v.byteOffset||0)+v.byteLength)),v.byteLength);
   const dec=new d.Decoder(),mesh=new d.Mesh();const status=dec.DecodeBufferToMesh(buf,mesh);if(!status.ok())throw Error(status.error_msg());
   const result={};for(const [semantic,id] of Object.entries(ext.attributes)){
    const att=dec.GetAttributeByUniqueId(mesh,id),arr=new d.DracoFloat32Array();dec.GetAttributeFloatForAllPoints(mesh,att,arr);
    const a=new Float32Array(arr.size());for(let i=0;i<a.length;i++)a[i]=arr.GetValue(i);result[semantic]=Buffer.from(a.buffer).toString('base64');d.destroy(arr);
   }
   const ia=new Uint32Array(mesh.num_faces()*3),face=new d.DracoInt32Array();for(let i=0;i<mesh.num_faces();i++){dec.GetFaceFromMesh(mesh,i,face);for(let k=0;k<3;k++)ia[i*3+k]=face.GetValue(k)}result.indices=Buffer.from(ia.buffer).toString('base64');d.destroy(face);d.destroy(mesh);d.destroy(dec);d.destroy(buf);return result;
  }));return {nodes:j.nodes,meshes,scenes:j.scenes};
 }
 const models={chassis:convert('chassis'),wheel:convert('wheel')};fs.writeFileSync('assets/car-data.js','/* Geometry: Bruno Simon, MIT, 2019. Decoded from source GLBs; see BRUNO-LICENSE.txt. */\nconst CAR_ASSET='+JSON.stringify(models)+';');console.log('Decoded chassis and wheel:',fs.statSync('assets/car-data.js').size);
}});
