"""Actual-browser recheck of the changed visual composition & trustworthy coach.
One sandboxed native Chrome, one WebGL page at a time. No scene/vehicle mutations.
Scripted input is not human usability testing; owner must inspect actual PNGs.
"""
from pathlib import Path
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright
import argparse,time,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
ap=argparse.ArgumentParser();ap.add_argument('--browser',default='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');a=ap.parse_args()
OUT=ROOT/'evidence/experience-adoption';OUT.mkdir(exist_ok=True,parents=True)
r={'started_utc':datetime.now(timezone.utc).isoformat(),'sha256':hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest(),'browser_verified':False,'images_reviewed':False,'human_playtested':False,'errors':[],'screenshots':[]}
def snap(page,name):
 p=OUT/(name+'.png');page.screenshot(path=str(p));r['screenshots'].append(str(p.relative_to(ROOT)))
def observe(page):
 return page.evaluate('({state:__game.state,speed:__game.player.speed,pos:__game.player.pos.toArray(),heading:__game.player.heading,race:__game.race,journey:__game.journey,stats:__game.stats})')
def ready(page):
 page.goto((ROOT/'index.html').as_uri());page.wait_for_function('window.__game?.stats.frames>5');page.locator('#loading').wait_for(state='hidden')
with sync_playwright() as pw:
 b=None
 try:
  b=pw.chromium.launch(headless=True,chromium_sandbox=True,executable_path=a.browser,timeout=15000)
  page=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1);page.on('pageerror',lambda e:r['errors'].append(str(e)))
  ready(page);snap(page,'menu');page.locator('#explore').click();page.wait_for_timeout(400);snap(page,'start')
  # Identical ordinary key sequence as b71 & b313 comparisons, without road sensors.
  page.keyboard.down('w');page.wait_for_timeout(1100);page.keyboard.down('d');page.wait_for_timeout(250);page.keyboard.up('d');page.wait_for_timeout(400);page.keyboard.up('w');page.keyboard.down('s');page.wait_for_timeout(280);page.keyboard.up('s');snap(page,'first-turn');r['fixed_keys']=observe(page)
  page.keyboard.press('Escape');page.locator('#restart').click();page.wait_for_function("__game.state==='race'",timeout=10000)
  pressed=set();trace=[];shots=set();start=time.monotonic()
  try:
   while time.monotonic()-start<100:
    obs=page.evaluate('''()=>{const g=__game,p=g.player,r=g.nearest(p.pos.x,p.pos.z),v=Math.max(0,p.speed),N=g.samples.length;
     const target=g.samples[Math.floor(((r.t+(6+v*.38)/g.routeLength)%1)*N)],h=Math.atan2(-(target.p.z-p.pos.z),target.p.x-p.pos.x),err=Math.atan2(Math.sin(h-p.heading),Math.cos(h-p.heading));
     const f=g.samples[Math.floor(((r.t+20/g.routeLength)%1)*N)],curve=Math.abs(r.sample.v.x*f.v.z-r.sample.v.z*f.v.x),desired=curve>.65?10:curve>.35?14:20;
     return{state:g.state,gate:g.race.nextGate,speed:v,left:err>.055,right:err<-.055,throttle:v<desired,brake:v>desired+1,deviation:r.dist,coach:g.journey.coach,advice:document.getElementById('coach-action').textContent,detail:document.getElementById('turn-distance').textContent,browser_ms:performance.now()};}''')
    obs['wall_seconds']=time.monotonic()-start;trace.append(obs)
    if obs['state']=='finished':break
    desired={k for k,on in [('w',obs['throttle']),('s',obs['brake']),('a',obs['left']),('d',obs['right'])] if on}
    for k in pressed-desired:page.keyboard.up(k)
    for k in desired-pressed:page.keyboard.down(k)
    pressed=desired
    if obs['gate'] in [5,9] and obs['gate'] not in shots:
     for k in pressed:page.keyboard.up(k)
     pressed=set();snap(page,'sector-'+str(obs['gate']));shots.add(obs['gate'])
    page.wait_for_timeout(80)
  finally:
   for k in pressed:page.keyboard.up(k)
  r['lap']={'final':observe(page),'trace':trace};snap(page,'finish');assert page.evaluate('__game.state')=='finished'
  runs=[]
  for obs in trace:
   c=obs['coach'];key=c.get('key');now=obs['browser_ms']/1000
   if not runs or key!=runs[-1]['key']:runs.append({'key':key,'phase':c['phase'],'start':now,'end':now,'advice':obs['advice']})
   else:runs[-1]['end']=now
  for i,seg in enumerate(runs):seg['duration_until_next']=(runs[i+1]['start'] if i+1<len(runs) else seg['end'])-seg['start']
  ranks={};regressions=[]
  for obs in trace:
   c=obs['coach'];key=c.get('key','');parts=key.split(':')
   if len(parts)>=3 and parts[0].lstrip('-').isdigit():
    bend=':'.join(parts[:2]);rank=2 if c['phase']=='turn' else 1 if c['phase']=='brake' else 0
    if rank<ranks.get(bend,-1):regressions.append({'bend':bend,'at':obs['browser_ms']})
    ranks[bend]=rank
  r['guidance']={'runs':runs,'ordinary_under_650ms':[s for s in runs[1:-1] if s['duration_until_next']<.65 and s['phase'] not in ['slide','recover']],'turn_to_brake_regressions':regressions}
  page.locator('#retry').click();page.wait_for_function("__game.state==='race'");page.keyboard.down('w');page.wait_for_timeout(1200);page.keyboard.up('w');assert page.evaluate('ghost.visible');r['retry_ghost_visible']=True;page.close()
  mobile=b.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
  page=mobile.new_page();page.on('pageerror',lambda e:r['errors'].append(str(e)));ready(page);snap(page,'mobile-menu');page.locator('#explore').tap();page.wait_for_timeout(400);snap(page,'mobile-start')
  r['touch_intro']=page.evaluate("({action:document.getElementById('coach-action').textContent,detail:document.getElementById('coach-detail').textContent,sub:document.getElementById('live-split').textContent,recoverVisible:!document.getElementById('recover').hidden})")
  assert '油门' in r['touch_intro']['action'];assert r['touch_intro']['recoverVisible']
  session=mobile.new_cdp_session(page)
  def point(k,i):
   box=page.locator('[data-control="'+k+'"]').bounding_box();return {'x':box['x']+box['width']/2,'y':box['y']+box['height']/2,'id':i}
  gas,right=point('throttle',1),point('right',2)
  session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[gas]});page.wait_for_timeout(800);session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[gas,right]});page.wait_for_timeout(400);session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});snap(page,'mobile-driving')
  before=observe(page);page.locator('#recover').tap();page.wait_for_timeout(130);after=observe(page);assert abs(after['speed'])<.2;assert after['race']['penalty']==0;r['touch_free_recover']={'before':before,'after':after}
  page.locator('#pause').tap();page.locator('#restart').tap();page.wait_for_function("__game.state==='race'");page.locator('#recover').tap();page.wait_for_timeout(120);r['touch_race_recover']=observe(page);assert r['touch_race_recover']['race']['penalty']==3
  r['mobile_rects']=page.evaluate("()=>['coach','touch','map','recover','pace'].map(id=>{const e=document.getElementById(id),b=e.getBoundingClientRect();return{id,x:b.x,y:b.y,w:b.width,h:b.height,text:e.innerText}})")
  page.close();mobile.close();assert not r['errors'];assert not regressions;r['browser_verified']=True
 except Exception as e:r['failure']=str(e);raise
 finally:
  if b:b.close()
  r['ended_utc']=datetime.now(timezone.utc).isoformat();(OUT/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({k:r.get(k) for k in ['sha256','browser_verified','failure','errors','started_utc','ended_utc','screenshots']},ensure_ascii=False,indent=2))
