"""Focused Golden Hour browser pass. Use only an already permitted local browser.
No pose/state mutations, no sandbox override, no VM, server, upload or model call.
Sequential baseline/new frames + real keys; route controller proves only functionality.
Inspect PNGs yourself. This script cannot pronounce taste, sound or novice understanding.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
from datetime import datetime,timezone
import argparse,hashlib,json,time
ROOT=Path(__file__).resolve().parents[2]
ap=argparse.ArgumentParser();ap.add_argument('--browser',default='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');args=ap.parse_args()
out=ROOT/'evidence/experience-browser';out.mkdir(parents=True,exist_ok=True)
r={'at_utc':datetime.now(timezone.utc).isoformat(),'entry_sha256':hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest(),'browser_verified':False,'human_playtested':False,'images_reviewed':False,'errors':[],'screenshots':[],'method':'serial native sandboxed Chrome; real keyboard/pointer input; state observations read-only'}
def snap(page,name):
 p=out/(name+'.png');page.screenshot(path=str(p));r['screenshots'].append(str(p.relative_to(ROOT)))
def observe(page):return page.evaluate('({state:__game.state,speed:__game.player.speed,pos:__game.player.pos.toArray(),race:__game.race,journey:__game.journey,stats:__game.stats})')
with sync_playwright() as pw:
 browser=None
 try:
  browser=pw.chromium.launch(headless=True,chromium_sandbox=True,executable_path=args.browser,timeout=15000)
  for tag,file in [('before',ROOT/'verification/experience/before/index.html'),('after',ROOT/'index.html')]:
   if not file.exists():continue
   page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
   page.on('pageerror',lambda e:r['errors'].append(str(e)))
   page.goto(file.as_uri());page.wait_for_function('window.__game?.stats.frames>5');page.wait_for_timeout(700);snap(page,tag+'-menu')
   page.locator('#explore').click();page.wait_for_timeout(450);snap(page,tag+'-start')
   # Identical ordinary user input sequence, not identical poses after changed physics.
   page.keyboard.down('w');page.wait_for_timeout(1100);page.keyboard.down('d');page.wait_for_timeout(250);page.keyboard.up('d');page.wait_for_timeout(400);page.keyboard.up('w');page.keyboard.down('s');page.wait_for_timeout(280);page.keyboard.up('s');snap(page,tag+'-first-turn');r[tag+'-drive']=observe(page)
   page.keyboard.press('Escape');assert page.evaluate('__game.state')=='paused'
   if tag=='before':page.close();continue
   page.locator('#restart').click();page.wait_for_function("__game.state==='race'",timeout=10000)
   pressed=set();trace=[];seen=set();start=time.monotonic()
   try:
    while time.monotonic()-start<110:
     obs=page.evaluate('''()=>{const g=__game,p=g.player,r=g.nearest(p.pos.x,p.pos.z),v=Math.max(0,p.speed),N=g.samples.length;
      const target=g.samples[Math.floor(((r.t+(6+v*.38)/g.routeLength)%1)*N)],h=Math.atan2(-(target.p.z-p.pos.z),target.p.x-p.pos.x),err=Math.atan2(Math.sin(h-p.heading),Math.cos(h-p.heading));
      const f=g.samples[Math.floor(((r.t+20/g.routeLength)%1)*N)],curve=Math.abs(r.sample.v.x*f.v.z-r.sample.v.z*f.v.x),desired=curve>.65?10:curve>.35?14:20;
      return{state:g.state,gate:g.race.nextGate,speed:v,left:err>.055,right:err<-.055,throttle:v<desired,brake:v>desired+1,deviation:r.dist,chapter:g.journey.chapter,advice:document.getElementById('coach-action').textContent};}''')
     trace.append(obs)
     if obs['state']=='finished':break
     desired={k for k,on in [('w',obs['throttle']),('s',obs['brake']),('a',obs['left']),('d',obs['right'])] if on}
     for k in pressed-desired:page.keyboard.up(k)
     for k in desired-pressed:page.keyboard.down(k)
     pressed=desired
     if obs['gate'] in [5,9] and obs['gate'] not in seen:
      for k in pressed:page.keyboard.up(k)
      pressed=set();snap(page,'after-sector-'+str(obs['chapter']));seen.add(obs['gate'])
     page.wait_for_timeout(85)
   finally:
    for k in pressed:page.keyboard.up(k)
   r['lap']={'trace':trace,'final':observe(page),'wall_seconds':time.monotonic()-start}
   snap(page,'after-result');assert page.evaluate('__game.state')=='finished'
   assert page.evaluate('__game.journey.splits.length')==3
   page.locator('#retry').click();page.wait_for_function("__game.state==='race'");page.keyboard.down('w');page.wait_for_timeout(1100);page.keyboard.up('w');snap(page,'after-ghost');assert page.evaluate('ghost.visible');page.close()
  # Only one WebGL page at a time. Emulated touch, not a physical-phone claim.
  mobile=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
  page=mobile.new_page();page.on('pageerror',lambda e:r['errors'].append(str(e)));page.goto((ROOT/'index.html').as_uri());page.wait_for_function('window.__game?.stats.frames>5');snap(page,'after-mobile-menu');page.locator('#explore').tap();page.wait_for_timeout(400)
  session=mobile.new_cdp_session(page)
  def point(k,i):
   box=page.locator('[data-control="'+k+'"]').bounding_box();return {'x':box['x']+box['width']/2,'y':box['y']+box['height']/2,'id':i}
  gas,right=point('throttle',1),point('right',2)
  session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[gas]});page.wait_for_timeout(800)
  session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[gas,right]});page.wait_for_timeout(400)
  session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});snap(page,'after-mobile-driving')
  r['touch']=observe(page);assert not page.evaluate('__game.controls().throttle');assert r['touch']['speed']>2
  page.close();mobile.close();assert not r['errors'];r['browser_verified']=True
 except Exception as e:r['failure']=str(e);raise
 finally:
  if browser:browser.close()
  (out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
  print(json.dumps({k:r.get(k) for k in ['at_utc','entry_sha256','browser_verified','failure','screenshots']},ensure_ascii=False,indent=2))
