// Only the changed pace-note/coach contract. Not a browser or human-play test.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'../..'),THREE=require(root+'/assets/three-r149.min.js');
const c=new THREE.CatmullRomCurve3([[12,-22],[28,-11],[30,14],[47,38],[77,61],[108,77],[112,99],[93,113],[68,100],[33,81],[-9,71],[-49,71],[-77,81],[-98,70],[-108,48],[-88,32],[-51,26],[-20,16],[-23,-7],[-8,-27]].map(p=>new THREE.Vector3(p[0],0,p[1])),true,'centripetal');c.arcLengthDivisions=2400;c.updateArcLengths();
const L=c.getLength(),samples=Array.from({length:960},(_,i)=>({v:c.getTangentAt(i/960).normalize(),t:i/960})),at=t=>samples[(Math.round(t*960)%960+960)%960];
const nodes=new Map(),node=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',dataset:{},style:{setProperty(){}},firstChild:{textContent:''},classList:{add(){},remove(){}},replaceChildren(){},append(){}});return nodes.get(id)};
const ctx={console,document:{createElement:()=>node(Math.random())},Math};vm.createContext(ctx);for(const p of ['src/pacenotes.js','src/journey.js'])vm.runInContext(fs.readFileSync(root+'/'+p,'utf8'),ctx);
const bends=ctx.buildTidelineBends(at,L);assert(bends.length>=6&&bends.length<=10);
let state='race',position=-4,mobile=false,input={throttle:false,brake:false,handbrake:false,boost:false},p={speed:0,heading:0,surface:'asphalt',slip:0,steer:0},r={t:0,dist:0,sample:at(0)},race={nextGate:1};
const journey=ctx.createTidelineJourney({$:node,clamp:THREE.MathUtils.clamp,sampleAt:at,routeLength:L,getPlayer:()=>p,getRoad:()=>r,getState:()=>state,getRace:()=>race,getInput:()=>input,chime(){},bends,usingTouch:()=>mobile});
const trace=[];journey.reset();
for(let step=0;position<L+35;step++){
 p.speed=step<8?step*.8:step%2?12:16;position+=p.speed*.1;r.t=((position/L)%1+1)%1;r.sample=at(r.t);p.heading=Math.atan2(-r.sample.v.z,r.sample.v.x);race.nextGate=Math.min(12,Math.floor(Math.max(0,position)/L*12)+1);journey.update(.1);
 trace.push({time:step*.1,...journey.stats.coach,text:node('coach-action').textContent});
}
let intervals=[],last=null;for(const t of trace){if(!last||last.key!==t.key){last={key:t.key,phase:t.phase,start:t.time,end:t.time,text:t.text};intervals.push(last)}else last.end=t.time}
assert(intervals.slice(1,-1).every(s=>s.end-s.start>=.79),'ordinary coach flickers');
const ranks=new Map(),distanceByBend=new Map();for(const t of trace){
 const match=t.key.match(/^(.*):(approach|turn)/);if(match){const rank=t.phase==='turn'?2:t.phase==='brake'?1:0;assert(rank>=(ranks.get(match[1])??-1),'bend regresses turn -> brake');ranks.set(match[1],rank)}
 if(t.bend&&t.distance>0){const old=distanceByBend.get(t.bend);if(old!==undefined)assert(t.distance<=old+.001,'same bend distance jumped away');distanceByBend.set(t.bend,t.distance)}
}
mobile=true;state='countdown';journey.reset();journey.update(.1);assert.match(node('coach-action').textContent,/右下.*油门/);assert(!/[WASDR]|Shift|↑|↓/.test(node('coach-action').textContent+node('coach-detail').textContent));
state='explore';p.speed=0;journey.update(.1);assert.match(node('live-split').textContent,/右上/);
p.surface='grass';journey.update(.1);assert.equal(node('coach').dataset.phase,'recover');assert.match(node('coach-detail').textContent,/「回赛道」/);
p.surface='asphalt';p.speed=-2;journey.update(.1);assert.match(node('coach-action').textContent,/「油门」/);
journey.resetGuidance();p.speed=0;r.t=.6;journey.update(.1);assert(journey.stats.coach.bend!==undefined);
const report={utc:new Date().toISOString(),passed:true,warning:'pure synthetic telemetry stress test; not runtime or human feedback',bends:bends.map(b=>({id:b.id,start:b.start,end:b.end,sign:b.sign,suggested:b.suggested})),ordinary_intervals:intervals,touch_copy_and_immediate_recovery:true};
fs.writeFileSync(root+'/verification/experience/adoption-contract.json',JSON.stringify(report,null,2));console.log('Pace-note contract passed: '+bends.length+' stable bends; '+intervals.length+' readable ordinary intervals; touch copy and immediate recovery.');
