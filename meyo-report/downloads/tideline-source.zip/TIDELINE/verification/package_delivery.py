"""Package editable Golden Hour candidate, without internal evidence/old bundles.
Integrity is not a gameplay pass. Run browser_pass.py separately when permitted.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile,tempfile
root=Path(__file__).resolve().parent.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
subprocess.run([sys.executable,str(root/'build.py')],cwd=root,check=True)
files=[root/n for n in ['index.html','README.md','SOURCES.md','LICENSES.md','build.py','verification/convert-car.cjs','verification/package_delivery.py','verification/experience/smoke.cjs','verification/experience/browser_pass.py','verification/experience/adoption_contract.cjs','verification/experience/adoption_pass.py']]
for folder in ['src','assets','original']:
 files.extend(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files=sorted(set(files));entry=sha((root/'index.html').read_bytes())
original={str(p.relative_to(root)):sha(p.read_bytes()) for p in (root/'original').rglob('*') if p.is_file()}
archive=root/'deliverables/TIDELINE-source.zip'
if archive.exists():
 with zipfile.ZipFile(archive) as old:
  for name,digest in original.items():assert sha(old.read('TIDELINE/'+name))==digest,'Original source differs from previous delivery: '+name
manifest={str(p.relative_to(root)):sha(p.read_bytes()) for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'TIDELINE/'+str(p.relative_to(root)))
 z.writestr('TIDELINE/MANIFEST.json',json.dumps({'entry_sha256':entry,'files':manifest,'status':'Golden Hour candidate; integrity is not WebGL acceptance'},indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in files:assert z.read('TIDELINE/'+str(p.relative_to(root)))==p.read_bytes()
 # Rebuild inside the candidate. Temporary extraction is removed automatically.
 with tempfile.TemporaryDirectory(prefix='package-check-',dir=root/'verification') as tmp:
  z.extractall(tmp);extracted=Path(tmp)/'TIDELINE'
  subprocess.run([sys.executable,str(extracted/'build.py')],cwd=extracted,check=True)
  assert sha((extracted/'index.html').read_bytes())==entry
runtime_sources=[]
for result in ['evidence/experience-adoption/result.json','evidence/experience-browser/result.json']:
 path=root/result
 if path.exists():
  evidence=json.loads(path.read_text())
  if evidence.get('sha256',evidence.get('entry_sha256'))==entry and evidence.get('browser_verified'):
   runtime_sources.append(result)
report={'utc':datetime.now(timezone.utc).isoformat(),'entry_sha256':entry,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'files_including_manifest':len(files)+1,'source_matches_entry':True,'extracted_rebuild_matches':True,'original_matches_prior_archive':True,'browser_verified':bool(runtime_sources),'runtime_sources':runtime_sources,'visual_acceptance_complete':False,'world_class_claim':False,'excluded':'internal screenshots, references, logs, old ZIPs and tool catalogs'}
(root/'verification/experience/package.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
